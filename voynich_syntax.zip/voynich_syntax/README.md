# Voynich syntax lab

Pharmaceutical / procedural **syntax**, not a spoken language.

Drop this folder into `RN-Top/Voynich` (or any repo). The ZL 3b EVA file lives in `data/`. The rule contract lives in `spec/matrix.json`. Change the spec, rerun the translator — the whole manuscript updates.

## What you get

| file | job |
|---|---|
| `spec/matrix.json` | frozen rules: glyph→sound, affix roles, shared stems, zodiac-only cribs |
| `voynich/parser.py` | IVTFF parser, bracket `[a:b]` handling |
| `voynich/matrix.py` | apply the spec to a token or a line |
| `voynich/translate.py` | batch: whole manuscript → markdown + CSV + stats JSON |
| `app.py` | Streamlit: folio browser, stem-context test, terminal audit |

## Batch — spit out the whole thing

```bash
cd voynich_syntax
python -m voynich.translate
```

Writes:

- `output/full_translation.md`  — every folio, raw + phoneme stream
- `output/full_translation.csv` — one row per token (folio, section, locus, phoneme, crib)
- `output/stats.json`           — terminals-by-section, top stems, crib hits

## Streamlit

```bash
pip install -r requirements.txt
streamlit run app.py
```

Deploy: push the folder to GitHub → [share.streamlit.io](https://share.streamlit.io) → point at `app.py`. No secrets. The ZL file is in the repo.

### Tabs

1. **Folio browser** — pick a folio, see raw EVA, phonemes, bracket alts.
2. **Stem context test** — pick `qokedy` (or any shared stem), get every hit with a 2-word window, grouped by section. This is the falsifiability test.
3. **Terminal audit** — `y/n/r/l` percentages by section. If the rank order holds across herbal / stars / baths, the terminals are grammar.

## Proof loop

1. Edit `spec/matrix.json` (split a glyph, add a crib, restrict a folio list).
2. `python -m voynich.translate`
3. Open the app and run the stem test + terminal table.
4. Commit spec + `output/` so the result is reproducible without running anything.

Cribs only fire on `f70`–`f73` (see `crib_folios` in the spec). That stops `otol` lighting up as Scorpio on every herbal page.
