"""Streamlit explorer for the Voynich pharmaceutical-syntax pipeline.

Run locally:
    streamlit run app.py

Deploy: push this repo to GitHub, then connect it on share.streamlit.io.
No secrets needed — the ZL file lives in data/.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

import streamlit as st

from voynich.matrix import folio_section, load_spec, translate_line, translate_token
from voynich.parser import parse_zl
from voynich.translate import run

ROOT = Path(__file__).resolve().parent
ZL = ROOT / "data" / "ZL3b-n.txt"
SPEC_PATH = ROOT / "spec" / "matrix.json"


@st.cache_data(show_spinner=False)
def load_all():
    spec = load_spec(SPEC_PATH)
    parsed = parse_zl(ZL)
    result = run(ZL, SPEC_PATH)
    return spec, parsed, result


def main():
    st.set_page_config(page_title="Voynich syntax lab", layout="wide")
    spec, parsed, result = load_all()

    st.title("Voynich syntax lab")
    st.caption(
        f"spec {spec.get('version')} · {result['stats']['folios']} folios · "
        f"{result['stats']['tokens']:,} tokens · pharmaceutical syntax, not a spoken language"
    )

    tab_browse, tab_stem, tab_audit = st.tabs(
        ["Folio browser", "Stem context test", "Terminal audit"]
    )

    # ------------------------------------------------------------------ browse
    with tab_browse:
        folios = parsed["order"]
        col_a, col_b = st.columns([1, 3])
        with col_a:
            fid = st.selectbox("Folio", folios)
            folio = parsed["folios"][fid]
            section = folio_section(folio, spec)
            st.metric("Section", section)
            st.json(folio.get("meta", {}), expanded=False)
        with col_b:
            st.subheader(f"{fid}")
            for line in folio["lines"]:
                mapped = translate_line(line["tokens"], spec)
                phon = "  ".join(m["phoneme"] or "—" for m in mapped)
                with st.expander(f"{line['locus']}  ·  {line['raw'][:80]}", expanded=False):
                    st.code(line["raw"], language=None)
                    st.code(phon, language=None)
                    rows = [
                        {
                            "raw": m["raw"],
                            "cleaned": m["cleaned"],
                            "phoneme": m["phoneme"],
                            "alts": ", ".join(m["alts"]),
                            "terminal": m["terminal"],
                            "crib": m["crib"],
                        }
                        for m in mapped
                    ]
                    st.dataframe(rows, use_container_width=True, hide_index=True)

    # ------------------------------------------------------------------ stem
    with tab_stem:
        st.markdown(
            "Pick a shared stem. The app pulls every line that contains it, "
            "with a two-word window on each side, grouped by section. "
            "If the neighbors stay in the same family across herbal / stars / baths, "
            "the stem is a slot in the syntax — not a drifting word."
        )
        stems = spec.get("shared_stems", [])
        stem = st.selectbox("Stem", stems, index=stems.index("qokedy") if "qokedy" in stems else 0)
        window = st.slider("Context window", 1, 4, 2)

        by_sec = defaultdict(list)
        for fid in parsed["order"]:
            folio = parsed["folios"][fid]
            section = folio_section(folio, spec)
            for line in folio["lines"]:
                cleaned = []
                from voynich.parser import clean_token

                for t in line["tokens"]:
                    cleaned.append(clean_token(t))
                for i, t in enumerate(cleaned):
                    if t == stem:
                        lo = max(0, i - window)
                        hi = min(len(cleaned), i + window + 1)
                        ctx = cleaned[lo:i] + [f"[{t}]"] + cleaned[i + 1 : hi]
                        by_sec[section].append(
                            {
                                "folio": fid,
                                "locus": line["locus"],
                                "context": " ".join(ctx),
                            }
                        )

        cols = st.columns(max(1, len(by_sec)))
        for col, sec in zip(cols, sorted(by_sec)):
            hits = by_sec[sec]
            col.metric(sec, len(hits))

        for sec in sorted(by_sec):
            hits = by_sec[sec]
            st.subheader(f"{sec}  ·  {len(hits)} hits")
            st.dataframe(hits[:200], use_container_width=True, hide_index=True)
            if len(hits) > 200:
                st.caption(f"Showing first 200 of {len(hits)}")

    # ------------------------------------------------------------------ audit
    with tab_audit:
        st.markdown(
            "Terminal glyphs are the grammar. If `y / n / r / l` dominate every section "
            "in the same rank order, that's a closed vocabulary — not linguistic drift."
        )
        terms = result["stats"]["terminals_by_section"]
        # normalize to percents
        table = []
        keys = ["y", "n", "r", "l", "m", "s", "o"]
        for sec, counts in sorted(terms.items()):
            tot = sum(counts.values()) or 1
            row = {"section": sec, "tokens": tot}
            for k in keys:
                row[f"{k}%"] = round(100.0 * counts.get(k, 0) / tot, 1)
            table.append(row)
        st.dataframe(table, use_container_width=True, hide_index=True)

        st.subheader("Top stems by section")
        for sec, tops in sorted(result["stats"]["top_stems_by_section"].items()):
            with st.expander(sec):
                st.dataframe(
                    [{"stem": w, "count": c} for w, c in tops],
                    use_container_width=True,
                    hide_index=True,
                )

        st.subheader("Zodiac crib hits")
        st.dataframe(result["stats"]["crib_hits"], use_container_width=True, hide_index=True)

        st.subheader("Live spec")
        st.json(spec, expanded=False)

        st.download_button(
            "Download full translation (CSV)",
            data=Path(ROOT / "output" / "full_translation.csv").read_bytes()
            if (ROOT / "output" / "full_translation.csv").exists()
            else _csv_bytes(result["rows"]),
            file_name="full_translation.csv",
            mime="text/csv",
        )


def _csv_bytes(rows):
    import csv
    import io

    buf = io.StringIO()
    fields = list(rows[0].keys()) if rows else []
    w = csv.DictWriter(buf, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue().encode("utf-8")


if __name__ == "__main__":
    main()
