# Voynich full translation  — spec 2.0.0

Pharmaceutical / procedural syntax. Not a spoken language.

- Folios: 226
- Tokens: 35029
- Bracket alternate readings captured: 775
- Zodiac-restricted crib hits: 11

## Glyph map

| Glyph | Sound | Role |
|---|---|---|
| `o` | O | prefix operational |
| `t` | T | connective |
| `c` | S | stem core (internal) |
| `h` | A | stem nucleus |
| `e` | R | stem core (internal) |
| `d` | N | terminal marker |
| `a` | U | stem nucleus |
| `i` | I | iterative inflection |
| `q` | C | prefix procedural (thermal driver) |
| `k` | Ō | thermal marker (gallows) |
| `p` | M | stem core |
| `m` | S | terminal buffer flush |
| `y` | M | terminal affix / inflection |
| `s` | P | stem core |
| `l` | L | liquid coda |
| `r` | R | liquid coda |

## Crib hits (zodiac range only)

| Folio | Locus | Token | Phoneme | Crib |
|---|---|---|---|---|
| f71r | f71r.1 | `otol` | OTOL | SCORPIO/OR |
| f71r | f71r.1 | `otol` | OTOL | SCORPIO/OR |
| f71r | f71r.12 | `oteodal` | OTRONUL | RADIS (Pisces decan 2) |
| f71v | f71v.1 | `dal` | NUL | LEO/L |
| f72r2 | f72r2.16 | `okeal` | OŌRUL | TAURUS/ORAN |
| f72v3 | f72v3.1 | `oteodal` | OTRONUL | RADIS (Pisces decan 2) |
| f72v2 | f72v2.20 | `otol` | OTOL | SCORPIO/OR |
| f73r | f73r.3 | `otedy` | OTRNM | SAGITTARIUS/RAM |
| f73r | f73r.22 | `dal` | NUL | LEO/L |
| f73r | f73r.33 | `oteodal` | OTRONUL | RADIS (Pisces decan 2) |
| f73v | f73v.23 | `otedy` | OTRNM | SAGITTARIUS/RAM |

## Manuscript

### f1r  ·  text/preface

`f1r.1`  fachys.ykal.ar.ataiin.shol.shory.[cth:oto]res.y.kor.sholdy
→ ?USAMP  MŌUL  UR  UTUII?  PAOL  PAORM  STARRP  M  ŌOR  PAOLNM

`f1r.2`  sory.ckhar.or,y.kair.chtaiin.shar.ase.cthar.cthar,dan
→ PORM  SŌAUR  ORM  ŌUIR  SATUII?  PAUR  UPR  STAUR  STAURNU?

`f1r.3`  syaiir.sheky.or.ykaiin.shod.cthoary.cthes.daraiin.sy
→ PMUIIR  PARŌM  OR  MŌUII?  PAON  STAOURM  STARP  NURUII?  PM

`f1r.4`  soiin.oteey.oteo[s:r],roloty.cthiar,daiin.okaiin.or.okan
→ POII?  OTRRM  OTROPROLOTM  STAIURNUII?  OŌUII?  OR  OŌU?

`f1r.5`  sair,y.chear.cthaiin.cphar.cfhaiin
→ PUIRM  SARUR  STAUII?  SMAUR  S?AUII?

`f1r.6`  ydaraishy
→ MNURUIPAM

`f1r.7`  odar.{c'y}.shol.cphoy.oydar.sh.s.cfhoaiin.shodary
→ ONUR  SM  PAOL  SMAOM  OMNUR  PA  P  S?AOUII?  PAONURM

`f1r.8`  yshey.shody.okchoy.otchol.chocthy.os,chy.dain.chor.kos
→ MPARM  PAONM  OŌSAOM  OTSAOL  SAOSTAM  OPSAM  NUI?  SAOR  ŌOP

`f1r.9`  daiin.shos.cfhol.shody
→ NUII?  PAOP  S?AOL  PAONM

`f1r.10`  dain.os.teody
→ NUI?  OP  TRONM

`f1r.11`  ydain.cphesaiin.ols.cphey.ytain.shoshy.cphodal,es
→ MNUI?  SMARPUII?  OLP  SMARM  MTUI?  PAOPAM  SMAONULRP

`f1r.12`  oksho.kshoy.otairin.oteol.okan.shodain.sckhey.daiin
→ OŌPAO  ŌPAOM  OTUIRI?  OTROL  OŌU?  PAONUI?  PSŌARM  NUII?

`f1r.13`  shoy.ckhey.kodaiin.cphy.cphodaiils.cthey.sho.oldain.d
→ PAOM  SŌARM  ŌONUII?  SMAM  SMAONUIILP  STARM  PAO  OLNUI?  N

`f1r.14`  dain.oiin.chol.odaiin.chodain.chdy.ok[a:o]in.d?n.cthy.kod
→ NUI?  OII?  SAOL  ONUII?  SAONUI?  SANM  OŌUI?  N?  STAM  ŌON

`f1r.15`  daiin.shckhey.{ck}eo.r.char.shey.kol.chol.chol.kor.chal
→ NUII?  PASŌARM  SŌRO  R  SAUR  PARM  ŌOL  SAOL  SAOL  ŌOR  SAUL

`f1r.16`  sho.chol.shodan.kshy.kchy.d.or.chodaiin.sho.koeam
→ PAO  SAOL  PAONU?  ŌPAM  ŌSAM  N  OR  SAONUII?  PAO  ŌORUS

`f1r.17`  ycho.tchey.chekain.sheo,pshol.dydyd.cthy.dai[{cto}:@194;]y
→ MSAO  TSARM  SARŌUI?  PAROMPAOL  NMNMN  STAM  NUISTOM

`f1r.18`  yto.shol.she.kodshey.cphealy.dar,ain.dain.ckhyds
→ MTO  PAOL  PAR  ŌONPARM  SMARULM  NURUI?  NUI?  SŌAMNP

`f1r.19`  dchar.shcthaiin.okaiir.chey.@192;chy.@130;tol.cthols.dlo{ct}o
→ NSAUR  PASTAUII?  OŌUIIR  SARM  SAM  TOL  STAOLP  NLOSTO

`f1r.20`  shok.chor.chey.dain.ckhey
→ PAOŌ  SAOR  SARM  NUI?  SŌARM

`f1r.21`  otol.daiiin
→ OTOL  NUIII?

`f1r.22`  cpho.shaiin.shokcheey.chol.tshodeesy.shey.pydeey.cha.ro,dar
→ SMAO  PAUII?  PAOŌSARRM  SAOL  TPAONRRPM  PARM  MMNRRM  SAU  RONUR

`f1r.23`  ydoin.chol.dain.cthal.dar.shear.kaiin.dar.shey.cthar
→ MNOI?  SAOL  NUI?  STAUL  NUR  PARUR  ŌUII?  NUR  PARM  STAUR

`f1r.24`  cho.?o.kaiin.shoaiin.okol.daiin.far.cthol.daiin.ctholdar
→ SAO  O  ŌUII?  PAOUII?  OŌOL  NUII?  ?UR  STAOL  NUII?  STAOLNUR

`f1r.25`  ycheey.okeey.oky.daiin.okchey.kokaiin.o?chol.k?dchy.dal
→ MSARRM  OŌRRM  OŌM  NUII?  OŌSARM  ŌOŌUII?  OSAOL  ŌNSAM  NUL

`f1r.26`  dcheo.shody.koshey.cthy.ok,chey.keey.keey,dal.chtor
→ NSARO  PAONM  ŌOPARM  STAM  OŌSARM  ŌRRM  ŌRRMNUL  SATOR

`f1r.27`  ?eo?.chol.chok.choty.chotey
→ RO  SAOL  SAOŌ  SAOTM  SAOTRM

`f1r.28`  dchaiin
→ NSAUII?

### f1v  ·  herbal

`f1v.1`  kchsy.chydaiin.ol<->o,l,tchey.char.cfhar,am
→ ŌSAPM  SAMNUII?  OLOLTSARM  SAUR  S?AURUS

`f1v.2`  yteey.char.or.ochy<->dcho.lkody.okodar.chody
→ MTRRM  SAUR  OR  OSAMNSAO  LŌONM  OŌONUR  SAONM

`f1v.3`  da,ckhy.ckhockhy.shy<->dksheey.cthy.kotchody.dal
→ NUSŌAM  SŌAOSŌAM  PAMNŌPARRM  STAM  ŌOTSAONM  NUL

`f1v.4`  dol.chokeo.dair.dam<->sochey.chokody
→ NOL  SAOŌRO  NUIR  NUSPOSARM  SAOŌONM

`f1v.5`  potoy.shol.dair.cphoal<->dar.chey.tody.otoaiin.shoshy
→ MOTOM  PAOL  NUIR  SMAOULNUR  SARM  TONM  OTOUII?  PAOPAM

`f1v.6`  choky.chol.ctho,l,shol.okal<->dolchey.chodo.lol.chy.cthy
→ SAOŌM  SAOL  STAOLPAOL  OŌULNOLSARM  SAONO  LOL  SAM  STAM

`f1v.7`  qo.ol,choees.cheol.dol.cthey<->ykol.dol.dolo.ykol.do,lchiody
→ CO  OLSAORRP  SAROL  NOL  STARMMŌOL  NOL  NOLO  MŌOL  NOLSAIONM

`f1v.8`  okolshol.kol,kechy.chol.ky<->chol.cthol.chody.chol.daiin
→ OŌOLPAOL  ŌOLŌRSAM  SAOL  ŌMSAOL  STAOL  SAONM  SAOL  NUII?

`f1v.9`  shor.okol.chol.dol,ky.dar<->shol.dchor.o,tcho.dar.[sh:{@209;h}]ody
→ PAOR  OŌOL  SAOL  NOLŌM  NURPAOL  NSAOR  OTSAO  NUR  PAONM

`f1v.10`  taor.chotchey.dal.chody<->schody.pol.chodar
→ TUOR  SAOTSARM  NUL  SAONMPSAONM  MOL  SAONUR

### f2r  ·  herbal

`f2r.1`  kydainy.ypchol.daiin.otchal<->ypchaiin.ckholsy
→ ŌMNUI?M  MMSAOL  NUII?  OTSAULMMSAUII?  SŌAOLPM

`f2r.2`  dorchory<->chkar.s<->shor.cthy.{cto}
→ NORSAORMSAŌUR  PPAOR  STAM  STO

`f2r.3`  qotaiin<->cthey.y<->chor.chy.ydy<->chaiin
→ COTUII?STARM  MSAOR  SAM  MNMSAUII?

`f2r.4`  {c'o}aiidy<->chtod,dy<->cphy.dals<->chokaiin.d
→ SOUIINMSATONNMSMAM  NULPSAOŌUII?  N

`f2r.5`  otochor.al<->shodaiin<->chol,dan<->ytchaiin.dan
→ OTOSAOR  ULPAONUII?SAOLNU?MTSAUII?  NU?

`f2r.6`  saiin.dain,d<->dkol.sor<->ytoldy<->dchol.dchy.cthy
→ PUII?  NUI?NNŌOL  PORMTOLNMNSAOL  NSAM  STAM

`f2r.7`  shor.ckhy.daiiny<->chol,dan
→ PAOR  SŌAM  NUII?MSAOLNU?

`f2r.8`  kydain.shaiin.qoy.s.shol.fodan<->yksh.olsheey.daiildy
→ ŌMNUI?  PAUII?  COM  P  PAOL  ?ONU?MŌPA  OLPARRM  NUIILNM

`f2r.9`  dls,sho.kol.sheey.qokey.ykody.so<->chol,yky.dain.daiisol
→ NLPPAO  ŌOL  PARRM  COŌRM  MŌONM  POSAOLMŌM  NUI?  NUIIPOL

`f2r.10`  qo'ky.cholaiin.shol.sheky.daiin<->cthey.keol.saiin.e'a'iin
→ COŌM  SAOLUII?  PAOL  PARŌM  NUII?STARM  ŌROL  PUII?  RUII?

`f2r.11`  ychain.dal.chy.dalor.shan.dan<->olsaiin.sheey.ckhor
→ MSAUI?  NUL  SAM  NULOR  PAU?  NU?OLPUII?  PARRM  SŌAOR

`f2r.12`  okol.chy.chor.cthor.yor.an.chan<->saiin.chety.chyky.sal
→ OŌOL  SAM  SAOR  STAOR  MOR  U?  SAU?PUII?  SARTM  SAMŌM  PUL

`f2r.13`  sho.ykeey.chey.daiin.chcthy
→ PAO  MŌRRM  SARM  NUII?  SASTAM

`f2r.14`  ytoail
→ MTOUIL

`f2r.15`  ios.an.on
→ IOP  U?  O?

### f2v  ·  herbal

`f2v.1`  kooiin.cheo,pchor.otaiin,odain.chor<->dair.shty
→ ŌOOII?  SAROMSAOR  OTUII?ONUI?  SAORNUIR  PATM

`f2v.2`  kcho,kchy.sho.shol.qotcho.loeees.qoty<->chor.daiin
→ ŌSAOŌSAM  PAO  PAOL  COTSAO  LORRRP  COTMSAOR  NUII?

`f2v.3`  otchy.chor.lshy.chol.chody.chodain<->chcthy.daiin
→ OTSAM  SAOR  LPAM  SAOL  SAONM  SAONUI?SASTAM  NUII?

`f2v.4`  sho.cholo.cheor.chodaiin
→ PAO  SAOLO  SAROR  SAONUII?

`f2v.5`  kchor.shy.daiiin.ch{cko}m<->s,shey.dor,chol,daiin
→ ŌSAOR  PAM  NUIII?  SASŌOSPPARM  NORSAOLNUII?

`f2v.6`  dor.chol.chor.chol.keol.chy.chty<->daiin.o,tchor.chan
→ NOR  SAOL  SAOR  SAOL  ŌROL  SAM  SATMNUII?  OTSAOR  SAU?

`f2v.7`  daiin.chotchey.qoteeey.chokeos<->chees.chr.cheaiin
→ NUII?  SAOTSARM  COTRRRM  SAOŌROPSARRP  SAR  SARUII?

`f2v.8`  chokoishe.chor.cheol.chol.dolody
→ SAOŌOIPAR  SAOR  SAROL  SAOL  NOLONM

### f3r  ·  herbal

`f3r.1`  tsheos.qopal.chol.cthol.daimg
→ TPAROP  COMUL  SAOL  STAOL  NUIS?

`f3r.2`  ycheor.chor.dam.qotcham.cham
→ MSAROR  SAOR  NUS  COTSAUS  SAUS

`f3r.3`  ochor.qocheor.chol.daiin.cthy
→ OSAOR  COSAROR  SAOL  NUII?  STAM

`f3r.4`  schey.chor.chal.chag.cham.cho
→ PSARM  SAOR  SAUL  SAU?  SAUS  SAO

`f3r.5`  qokol.chololy.s.cham.cthol
→ COŌOL  SAOLOLM  P  SAUS  STAOL

`f3r.6`  ychtaiin.chor.cthom.otaldam
→ MSATUII?  SAOR  STAOS  OTULNUS

`f3r.7`  otchol.qodaiin.chom.shom.damo
→ OTSAOL  CONUII?  SAOS  PAOS  NUSO

`f3r.8`  ysheor.chor.chol.oky.dago
→ MPAROR  SAOR  SAOL  OŌM  NU?O

`f3r.9`  sho.vor.sheoldam.otchody.ol
→ PAO  ?OR  PAROLNUS  OTSAONM  OL

`f3r.10`  ydar.cholcthom
→ MNUR  SAOLSTAOS

`f3r.11`  pcheol.shol.sols.sheol.shey
→ MSAROL  PAOL  POLP  PAROL  PARM

`f3r.12`  okadaiin.qokchor.qo,schodam.octhy
→ OŌUNUII?  COŌSAOR  COPSAONUS  OSTAM

`f3r.13`  qokeey.qot,shey.qokody.qokshey.cheody
→ COŌRRM  COTPARM  COŌONM  COŌPARM  SARONM

`f3r.14`  chor.qodair.okeey.qokeey
→ SAOR  CONUIR  OŌRRM  COŌRRM

`f3r.15`  tsheoarom.shor.or.chor.olchsy.chom.otchom<->oporar
→ TPAROUROS  PAOR  OR  SAOR  OLSAPM  SAOS  OTSAOSOMORUR

`f3r.16`  oteol.chol.s.cheol.ekshy.qokeom.qokol.daiin<->soleeg
→ OTROL  SAOL  P  SAROL  RŌPAM  COŌROS  COŌOL  NUII?POLRR?

`f3r.17`  soeom.okeom.yteody.qokeeodal.sam
→ POROS  OŌROS  MTRONM  COŌRRONUL  PUS

`f3r.18`  pcheoldom.shodaiin.qopchor.qopol.opchol,qoty<->otolom
→ MSAROLNOS  PAONUII?  COMSAOR  COMOL  OMSAOLCOTMOTOLOS

`f3r.19`  otchor.ol,cheor.qoeor.dair.qoteol.qosaiin<->chor.cthy
→ OTSAOR  OLSAROR  COROR  NUIR  COTROL  COPUII?SAOR  STAM

`f3r.20`  ycheor.chol.odaiin.chol.s.aiin.okol,or.am
→ MSAROR  SAOL  ONUII?  SAOL  P  UII?  OŌOLOR  US

### f3v  ·  herbal

`f3v.1`  koaiin.cphor.qotoy.sha.ckhol.ykoaiin.s.oly
→ ŌOUII?  SMAOR  COTOM  PAU  SŌAOL  MŌOUII?  P  OLM

`f3v.2`  daiidy.qoteeol.okeeor.okor.olytol.dol,dar
→ NUIINM  COTRROL  OŌRROR  OŌOR  OLMTOL  NOLNUR

`f3v.3`  okom.chol.shol.seees.chom.cheeykam.okai
→ OŌOS  SAOL  PAOL  PRRRP  SAOS  SARRMŌUS  OŌUI

`f3v.4`  qodar.ees.eey.kcheol.okal.do.r.chear,een
→ CONUR  RRP  RRM  ŌSAROL  OŌUL  NO  R  SARURRR?

`f3v.5`  ychear.otchal.cho,r.char.ckh[a:y]
→ MSARUR  OTSAUL  SAOR  SAUR  SŌAU

`f3v.6`  or.cheor.kor.chodaly.chom
→ OR  SAROR  ŌOR  SAONULM  SAOS

`f3v.7`  tchor.otcham.chor.cfham.s
→ TSAOR  OTSAUS  SAOR  S?AUS  P

`f3v.8`  ykchy.kchom.chor.chckhol.oka
→ MŌSAM  ŌSAOS  SAOR  SASŌAOL  OŌU

`f3v.9`  ytcheear.okeol.cthodoaly.chor.cthy
→ MTSARRUR  OŌROL  STAONOULM  SAOR  STAM

`f3v.10`  ochos.daiin.qokshol.daiim.chol.okary
→ OSAOP  NUII?  COŌPAOL  NUIIS  SAOL  OŌURM

`f3v.11`  sho.shockho.ckhy.tchor.chodaiin.chom
→ PAO  PAOSŌAO  SŌAM  TSAOR  SAONUII?  SAOS

`f3v.12`  osh.chodair.ytchy.tchor.kcham.s
→ OPA  SAONUIR  MTSAM  TSAOR  ŌSAUS  P

`f3v.13`  shar.shkaiin.qokchy.yty.cthal.chky
→ PAUR  PAŌUII?  COŌSAM  MTM  STAUL  SAŌM

`f3v.14`  dain.sheam.y,keam
→ NUI?  PARUS  MŌRUS

### f4r  ·  herbal

`f4r.1`  kodalchy.chpady.sheol.ol,sheey.qotey<->doiin.chor.ytoy
→ ŌONULSAM  SAMUNM  PAROL  OLPARRM  COTRMNOII?  SAOR  MTOM

`f4r.2`  dchor.shol.shol.cthol.shtchy.chaiin.@163;s<->choraiin.chom
→ NSAOR  PAOL  PAOL  STAOL  PATSAM  SAUII?  PSAORUII?  SAOS

`f4r.3`  otchol.chol.chy.chaiin.qotaiin<->daiin.shain
→ OTSAOL  SAOL  SAM  SAUII?  COTUII?NUII?  PAUI?

`f4r.4`  qotchol,chy.yty.daiin.okaiin.cthy
→ COTSAOLSAM  MTM  NUII?  OŌUII?  STAM

`f4r.5`  pydaiin.qotchy.dy,tydy
→ MMNUII?  COTSAM  NMTMNM

`f4r.6`  chor.shytchy.dytcheey
→ SAOR  PAMTSAM  NMTSARRM

`f4r.7`  qotaiin.cthol.daiin.cthom
→ COTUII?  STAOL  NUII?  STAOS

`f4r.8`  shor.shol.shol.cthy.cpholdy
→ PAOR  PAOL  PAOL  STAM  SMAOLNM

`f4r.9`  daiin.ckhochy.tchy.kor,aiin
→ NUII?  SŌAOSAM  TSAM  ŌORUII?

`f4r.10`  odal.shor.shyshol.cphaiin
→ ONUL  PAOR  PAMPAOL  SMAUII?

`f4r.11`  qotchoiin.she[o:a]r.qoty
→ COTSAOII?  PAROR  COTM

`f4r.12`  soiin.chaiin.chaiin
→ POII?  SAUII?  SAUII?

`f4r.13`  daiin.cthey
→ NUII?  STARM

### f4v  ·  herbal

`f4v.1`  pchooiin.ksheo.kchoy.chopchy.dolds<->dlod
→ MSAOOII?  ŌPARO  ŌSAOM  SAOMSAM  NOLNPNLON

`f4v.2`  ol.chey.chy.cthy.shkchor.sheo.cheory<->choldy
→ OL  SARM  SAM  STAM  PAŌSAOR  PARO  SARORMSAOLNM

`f4v.3`  sho.sho.chaiin.shaiin.daiin.qodaiin<->o,aram
→ PAO  PAO  SAUII?  PAUII?  NUII?  CONUII?OURUS

`f4v.4`  qok[sh:ch]y.qocthy.choteol.daiin.cthey<->choaiin
→ COŌPAM  COSTAM  SAOTROL  NUII?  STARMSAOUII?

`f4v.5`  shor.sheey.{cto}.otoiin.shey.qotchoiin<->chodain
→ PAOR  PARRM  STO  OTOII?  PARM  COTSAOII?SAONUI?

`f4v.6`  ytchoy.shokchy.cphody
→ MTSAOM  PAOŌSAM  SMAONM

`f4v.7`  torchy.sheeor.chor.chokch[y:e].cphydy
→ TORSAM  PARROR  SAOR  SAOŌSAM  SMAMNM

`f4v.8`  oleeeb.chor.cthol.sho.otor.cthory
→ OLRRR?  SAOR  STAOL  PAO  OTOR  STAORM

`f4v.9`  qooko,iiin,cheog.chcthy.shoky.daiin
→ COOŌOIII?SARO?  SASTAM  PAOŌM  NUII?

`f4v.10`  otaiin.sheo.okeody.chol,chokeody
→ OTUII?  PARO  OŌRONM  SAOLSAOŌRONM

`f4v.11`  sho.kcheor.shody.shtaiin.qotol,daiin
→ PAO  ŌSAROR  PAONM  PATUII?  COTOLNUII?

`f4v.12`  qokey.sho.okeol.s,keey.shar,char,ody
→ COŌRM  PAO  OŌROL  PŌRRM  PAURSAURONM

`f4v.13`  shody.s.cheor.chokody.shodaiin.qoty
→ PAONM  P  SAROR  SAOŌONM  PAONUII?  COTM

`f4v.14`  ochody.chy,key.chtody
→ OSAONM  SAMŌRM  SATONM

### f5r  ·  herbal

`f5r.1`  kchody.fchoy.chkoy.oaiin.oar,olsy.chody.dkshy,dy
→ ŌSAONM  ?SAOM  SAŌOM  OUII?  OUROLPM  SAONM  NŌPAMNM

`f5r.2`  ochey.okey.qokaiin.sho.ckhoy.cthey.chey.ok[a:y]{@131;o}s.otol
→ OSARM  OŌRM  COŌUII?  PAO  SŌAOM  STARM  SARM  OŌUOP  OTOL

`f5r.3`  qoaiin.otan,chy.daiin.oteeeb.chocthy.otchy.qotchody
→ COUII?  OTU?SAM  NUII?  OTRRR?  SAOSTAM  OTSAM  COTSAONM

`f5r.4`  otain.sheody.chan.s.cheor.chocthy
→ OTUI?  PARONM  SAU?  P  SAROR  SAOSTAM

`f5r.5`  tchy.shody.qoaiin.cholols.sho.qotcheo.daiin.shodaiin
→ TSAM  PAONM  COUII?  SAOLOLP  PAO  COTSARO  NUII?  PAONUII?

`f5r.6`  sho.cheor,chey.qoeeey.qoykeeey.qoeor.cthy.shotshy.dy
→ PAO  SARORSARM  CORRRM  COMŌRRRM  COROR  STAM  PAOTPAM  NM

`f5r.7`  qotoeey.keey.cheo,kchy.shody
→ COTORRM  ŌRRM  SAROŌSAM  PAONM

### f5v  ·  herbal

`f5v.1`  k,o,cheor.chor.ytchey.pshod.chols.chodaiin.ytoiiin.daiin
→ ŌOSAROR  SAOR  MTSARM  MPAON  SAOLP  SAONUII?  MTOIII?  NUII?

`f5v.2`  dchol.{c'y}.chol.otaiin.dain.cthor.chots.ychopordg
→ NSAOL  SM  SAOL  OTUII?  NUI?  STAOR  SAOTP  MSAOMORN?

`f5v.3`  qotcho.ytor.daiin.daiin.otchor.daiin.q'o.darchor.do
→ COTSAO  MTOR  NUII?  NUII?  OTSAOR  NUII?  CO  NURSAOR  NO

`f5v.4`  qotor.shees.otol.ykoiin.shol,daiin.cthor.okch,y,taiin
→ COTOR  PARRP  OTOL  MŌOII?  PAOLNUII?  STAOR  OŌSAMTUII?

`f5v.5`  shokeeol.chor.cheotol.otchol.daiin.dal.chol,chotaiin
→ PAOŌRROL  SAOR  SAROTOL  OTSAOL  NUII?  NUL  SAOLSAOTUII?

`f5v.6`  otol.chol.dairodg
→ OTOL  SAOL  NUIRON?

### f6r  ·  herbal

`f6r.1`  foar.y.shol.cholor.cphol.chor.ch{ck}<->chopchol.otcham
→ ?OUR  M  PAOL  SAOLOR  SMAOL  SAOR  SASŌSAOMSAOL  OTSAUS

`f6r.2`  daiin.chckhy.chor.chor.kar.cthy<->cthor.chotols
→ NUII?  SASŌAM  SAOR  SAOR  ŌUR  STAMSTAOR  SAOTOLP

`f6r.3`  foeear.kshor.choky.os.cheoeees<->ykeor.ytaiin.dam
→ ?ORRUR  ŌPAOR  SAOŌM  OP  SARORRRPMŌROR  MTUII?  NUS

`f6r.4`  dar.cho,s.sheor.cho{ith}y.otcham<->yaiir.chy
→ NUR  SAOP  PAROR  SAOITAM  OTSAUSMUIIR  SAM

`f6r.5`  t[a:o]r.okoiin.shees.ytaly.cthaiin<->odam
→ TUR  OŌOII?  PARRP  MTULM  STAUII?ONUS

`f6r.6`  or.al.daiin.ckham.okom.cthaiin<->ydaiin
→ OR  UL  NUII?  SŌAUS  OŌOS  STAUII?MNUII?

`f6r.7`  daiin.qodaiin.cho.s.chol.okaiin.s
→ NUII?  CONUII?  SAO  P  SAOL  OŌUII?  P

`f6r.8`  ychol.ckhor.pchar.sheo.ckhaiin
→ MSAOL  SŌAOR  MSAUR  PARO  SŌAUII?

`f6r.9`  dar.sheol.skaiiodar.otaiin.chory
→ NUR  PAROL  PŌUIIONUR  OTUII?  SAORM

`f6r.10`  tchor.ctheod.chy.shor.od,she.od
→ TSAOR  STARON  SAM  PAOR  ONPAR  ON

`f6r.11`  ychar.olchaj.ol.chokaiin
→ MSAUR  OLSAU?  OL  SAOŌUII?

`f6r.12`  or.shol.cthom.chor.cthy
→ OR  PAOL  STAOS  SAOR  STAM

`f6r.13`  qocthol.[y:q]odaiin.cthy
→ COSTAOL  MONUII?  STAM

`f6r.14`  ysho.taiin.y,kaiim
→ MPAO  TUII?  MŌUIIS

### f6v  ·  herbal

`f6v.1`  koary,sar.[ch:{oh}]eekar.qoor.shor.chapchy.s.chear.char.otchy
→ ŌOURMPUR  SARRŌUR  COOR  PAOR  SAUMSAM  P  SARUR  SAUR  OTSAM

`f6v.2`  oees.chor.chckhy.qoekchar.chea[s:r].odaiiin.kchey.chor,chaiin
→ ORRP  SAOR  SASŌAM  CORŌSAUR  SARUP  ONUIII?  ŌSARM  SAORSAUII?

`f6v.3`  qoair.ckhy.chol.oechockhy.chekchoy.ckhy.okol<->rychos
→ COUIR  SŌAM  SAOL  ORSAOSŌAM  SARŌSAOM  SŌAM  OŌOLRMSAOP

`f6v.4`  y,shckhy.ytchoy.s.os.y.jajy.dchy.dey.okody<->ytody
→ MPASŌAM  MTSAOM  P  OP  M  ?U?M  NSAM  NRM  OŌONMMTONM

`f6v.5`  dair.{c'ha},chodam.dam.okor.oty<->doldom
→ NUIR  SAUSAONUS  NUS  OŌOR  OTMNOLNOS

`f6v.6`  tchody.shocthol.cho{cthh}y.s
→ TSAONM  PAOSTAOL  SAOSTAAM  P

`f6v.7`  ychos.ychol.daiin.cthol.dol
→ MSAOP  MSAOL  NUII?  STAOL  NOL

`f6v.8`  ychor.chor.okchey.qokom
→ MSAOR  SAOR  OŌSARM  COŌOS

`f6v.9`  oeeo,dal.chor.cthom.s
→ ORRONUL  SAOR  STAOS  P

`f6v.10`  qokchod.ychear.kchdy
→ COŌSAON  MSARUR  ŌSANM

`f6v.11`  lor.char.otam.ctho,m,dy
→ LOR  SAUR  OTUS  STAOSNM

`f6v.12`  ytcho[s:r].shy.qokam.cthy
→ MTSAOP  PAM  COŌUS  STAM

`f6v.13`  yodaiin.cthy.s.chor.oees.or
→ MONUII?  STAM  P  SAOR  ORRP  OR

`f6v.14`  qokor.chol.cthol.tchalody
→ COŌOR  SAOL  STAOL  TSAULONM

`f6v.15`  chockhy.s.or.chy.s,ain.ar
→ SAOSŌAM  P  OR  SAM  PUI?  UR

`f6v.16`  ochy.cthar.cth[a:o]r.cthy
→ OSAM  STAUR  STAUR  STAM

`f6v.17`  y,chaies.ckhal.cthodam.dy
→ MSAUIRP  SŌAUL  STAONUS  NM

`f6v.18`  ytchocthol.ches.{ith}or
→ MTSAOSTAOL  SARP  ITAOR

`f6v.19`  ocholy.kchos.chy.dor
→ OSAOLM  ŌSAOP  SAM  NOR

`f6v.20`  dchor.choldar.okol.daiin
→ NSAOR  SAOLNUR  OŌOL  NUII?

`f6v.21`  ycheor.chor.octham
→ MSAROR  SAOR  OSTAUS

### f7r  ·  herbal

`f7r.1`  fchodaiin.shopchey.qko<->shey.qoos.sheey.charochy
→ ?SAONUII?  PAOMSARM  CŌOPARM  COOP  PARRM  SAUROSAM

`f7r.2`  dcheey.keo.r.shor.dold<->dchey.kchey.otchy.cheody
→ NSARRM  ŌRO  R  PAOR  NOLNNSARM  ŌSARM  OTSAM  SARONM

`f7r.3`  oeeees.cheodaiin.sheey<->ytcheey.qotchy.chald
→ ORRRRP  SARONUII?  PARRMMTSARRM  COTSAM  SAULN

`f7r.4`  qokcho.cho.lochey.daiin<->ychey.kchos.odaiin
→ COŌSAO  SAO  LOSARM  NUII?MSARM  ŌSAOP  ONUII?

`f7r.5`  oaiir<->otaiin
→ OUIIROTUII?

`f7r.6`  ksholo,chey.qotoees.chkoldy<->otchor.choaiin
→ ŌPAOLOSARM  COTORRP  SAŌOLNMOTSAOR  SAOUII?

`f7r.7`  dshoy.cthol.chol.otchol.dain<->shody.shol.chotchy
→ NPAOM  STAOL  SAOL  OTSAOL  NUI?PAONM  PAOL  SAOTSAM

`f7r.8`  okchey.deeeese.choty.qokchy<->shol.keey.choty.dain
→ OŌSARM  NRRRRPR  SAOTM  COŌSAMPAOL  ŌRRM  SAOTM  NUI?

`f7r.9`  qokechy.ol,choiin.chol.cphey<->shckhy.chochy.kchod
→ COŌRSAM  OLSAOII?  SAOL  SMARMPASŌAM  SAOSAM  ŌSAON

`f7r.10`  s,chain.chor.daiin.chckhy
→ PSAUI?  SAOR  NUII?  SASŌAM

### f7v  ·  herbal

`f7v.1`  polyshy.shey.tchody.qopchy.otshol.dy.daiin.tshodody
→ MOLMPAM  PARM  TSAONM  COMSAM  OTPAOL  NM  NUII?  TPAONONM

`f7v.2`  chochy.cthy.daiin.qoky.ch{cphh}y.daiin.cthol.cthy.cthd
→ SAOSAM  STAM  NUII?  COŌM  SASMAAM  NUII?  STAOL  STAM  STAN

`f7v.3`  qokchy.dykchy.chkeey.kshy.ky.ty.dor.cheey.o,l,cheol,dy
→ COŌSAM  NMŌSAM  SAŌRRM  ŌPAM  ŌM  TM  NOR  SARRM  OLSAROLNM

`f7v.4`  choteeeb.oeear.choschy.dain.sho.kshy.shol.deees.dol
→ SAOTRRR?  ORRUR  SAOPSAM  NUI?  PAO  ŌPAM  PAOL  NRRRP  NOL

`f7v.5`  dchodaiin.qotchy.cheey.tcheey
→ NSAONUII?  COTSAM  SARRM  TSARRM

`f7v.6`  kchor.sheod.sheodaiin.sho,daiin.oksho,lshol.dair.qos
→ ŌSAOR  PARON  PARONUII?  PAONUII?  OŌPAOLPAOL  NUIR  COP

`f7v.7`  okshodeeeb.chorcheor,odaiin.shotch[o:?]<->dol.dol.dor.aiin
→ OŌPAONRRR?  SAORSARORONUII?  PAOTSAONOL  NOL  NOR  UII?

`f7v.8`  qoteeeo.r.cho,cheeody.qotchey.tey<->o,kcho,r.daiin
→ COTRRRO  R  SAOSARRONM  COTSARM  TRMOŌSAOR  NUII?

`f7v.9`  sho.keeo.daiir.chokchy.dor.deol.dy<->dol,daiin
→ PAO  ŌRRO  NUIIR  SAOŌSAM  NOR  NROL  NMNOLNUII?

### f8r  ·  herbal

`f8r.1`  pshol.chor.otshal.chopy<->cph[o:a]l.chody.shy.cfhodar.shor
→ MPAOL  SAOR  OTPAUL  SAOMMSMAOL  SAONM  PAM  S?AONUR  PAOR

`f8r.2`  tchty.sh,kcheals.sho<->okche.do.dchy.dain.al
→ TSATM  PAŌSARULP  PAOOŌSAR  NO  NSAM  NUI?  UL

`f8r.3`  chodar.shy.sy<->chodaiin.shokchy.chor.dy
→ SAONUR  PAM  PMSAONUII?  PAOŌSAM  SAOR  NM

`f8r.4`  qotor.chor.chor.sheey<->dchol.shesed.chof.chy.dam
→ COTOR  SAOR  SAOR  PARRMNSAOL  PARPRN  SAO?  SAM  NUS

`f8r.5`  okchey.do.r.cheeey.dy.ky<->scho.chky.{ck}ooaiin.ch[y:a],taiin
→ OŌSARM  NO  R  SARRRM  NM  ŌMPSAO  SAŌM  SŌOOUII?  SAMTUII?

`f8r.6`  tosh.{ck}cheey.koltoldy<->shy.choety.cheeody.sol
→ TOPA  SŌSARRM  ŌOLTOLNMPAM  SAORTM  SARRONM  POL

`f8r.7`  choto.kchoan.choor.dain
→ SAOTO  ŌSAOU?  SAOOR  NUI?

`f8r.8`  dcho.dain
→ NSAO  NUI?

`f8r.9`  tchoep.sho.pcheey.pchey<->ofchey.dsheey.sholdaiin.shor
→ TSAORM  PAO  MSARRM  MSARMO?SARM  NPARRM  PAOLNUII?  PAOR

`f8r.10`  daiin.cheey.teeodan.dy<->cheocthy.oksheo.dol.dairg
→ NUII?  SARRM  TRRONU?  NMSAROSTAM  OŌPARO  NOL  NUIR?

`f8r.11`  shol.cheodaiin.daiin.do<->y,tchody.chot.choty.otariin
→ PAOL  SARONUII?  NUII?  NOMTSAONM  SAOT  SAOTM  OTURII?

`f8r.12`  qo,chodaiin.shotokody<->chotol
→ COSAONUII?  PAOTOŌONMSAOTOL

`f8r.13`  okokchodg
→ OŌOŌSAON?

`f8r.14`  {c@132;h}o.{c@196;h}ey.shol.chofydy<->sho.chey.kshey.lody.cholal
→ SAO  SARM  PAOL  SAO?MNMPAO  SARM  ŌPARM  LONM  SAOLUL

`f8r.15`  dchey.ckhol.chol.chey.kc{cs}<->chy.{cto}daiin.dol.daiiir[{ih}:ch]y.ckhy
→ NSARM  SŌAOL  SAOL  SARM  ŌSSPSAM  STONUII?  NOL  NUIIIRIAM  SŌAM

`f8r.16`  ychey.kch[e:o]kchy.chsey,kchy<->scheaiin.cthai{ih}ar.cthy.dar
→ MSARM  ŌSARŌSAM  SAPRMŌSAMPSARUII?  STAUIIAUR  STAM  NUR

`f8r.17`  chol.dchy.qokar.chl<->aiin.chean.{ck}y.char.chaiin
→ SAOL  NSAM  COŌUR  SALUII?  SARU?  SŌM  SAUR  SAUII?

`f8r.18`  okar.cfhaiin.chaiin.{cl}<->daiin.chor.cha.rchealcham
→ OŌUR  S?AUII?  SAUII?  SLNUII?  SAOR  SAU  RSARULSAUS

`f8r.19`  sair.cheain.cphol.dar<->shol.kaiin.shol.kaiin.dai,kam
→ PUIR  SARUI?  SMAOL  NURPAOL  ŌUII?  PAOL  ŌUII?  NUIŌUS

`f8r.20`  or.cho,kesey.shey.o.kal<->chal
→ OR  SAOŌRPRM  PARM  O  ŌULSAUL

`f8r.21`  schol.saim
→ PSAOL  PUIS

### f8v  ·  herbal

`f8v.1`  {c@216;h}od.soo{c@196;h}<->sol.shol.otol.chol.opcheaiin.opydaiin.saiin
→ SAON  POOSAPOL  PAOL  OTOL  SAOL  OMSARUII?  OMMNUII?  PUII?

`f8v.2`  shcthal.sar<->chor.sheaiin.shor.chykchy.otaiin.{ct}y
→ PASTAUL  PURSAOR  PARUII?  PAOR  SAMŌSAM  OTUII?  STM

`f8v.3`  qody.cheal.sy<->chory<->chear.shol.chaiin.shaiin.dolas
→ CONM  SARUL  PMSAORMSARUR  PAOL  SAUII?  PAUII?  NOLUP

`f8v.4`  dshol.shol<->dol<->chean.cthar.shealy.daiin.chary
→ NPAOL  PAOLNOLSARU?  STAUR  PARULM  NUII?  SAURM

`f8v.5`  chol.chol.dar<->otchar.etaiin.cthol.dar
→ SAOL  SAOL  NUROTSAUR  RTUII?  STAOL  NUR

`f8v.6`  daiin.cthan<->ytchy.chey,kaiin.dain.ar
→ NUII?  STAU?MTSAM  SARMŌUII?  NUI?  UR

`f8v.7`  sho.kchol<->dar.shey.cthar.chotain.ry
→ PAO  ŌSAOLNUR  PARM  STAUR  SAOTUI?  RM

`f8v.8`  okcholksh<->chol.chol.chol.cthaiin.dain
→ OŌSAOLŌPASAOL  SAOL  SAOL  STAUII?  NUI?

`f8v.9`  shol.orchl<->chokchy.chol.cthor.chaiin
→ PAOL  ORSALSAOŌSAM  SAOL  STAOR  SAUII?

`f8v.10`  scharchy<->oeesody.kchey.pchy.cpharom
→ PSAURSAMORRPONM  ŌSARM  MSAM  SMAUROS

`f8v.11`  sorain
→ PORUI?

`f8v.12`  pchar.cho.rol.dal<->shear.chchotaiin.chal.daiin
→ MSAUR  SAO  ROL  NULPARUR  SASAOTUII?  SAUL  NUII?

`f8v.13`  kchor.otchar.oky<->chokain.keoky.otorchy.satar
→ ŌSAOR  OTSAUR  OŌMSAOŌUI?  ŌROŌM  OTORSAM  PUTUR

`f8v.14`  shor.okol.lokaiin<->shol.kol.char.cthey.tchy.ckham
→ PAOR  OŌOL  LOŌUII?PAOL  ŌOL  SAUR  STARM  TSAM  SŌAUS

`f8v.15`  or.chol.chan.ch{ck}y<->chor.cheain.char.cheeky.chor.ry
→ OR  SAOL  SAU?  SASŌMSAOR  SARUI?  SAUR  SARRŌM  SAOR  RM

`f8v.16`  chor.cheor.chear<->oteey.dchor.chodey.cho.raiin
→ SAOR  SAROR  SARUROTRRM  NSAOR  SAONRM  SAO  RUII?

`f8v.17`  dain.chear.daiin
→ NUI?  SARUR  NUII?

### f9r  ·  herbal

`f9r.1`  tydlo.choly.cthor.orchey.s.shy.odaiin.sary<->shor.cthy
→ TMNLO  SAOLM  STAOR  ORSARM  P  PAM  ONUII?  PURMPAOR  STAM

`f9r.2`  oykeey.chol,ytaiin.okchody.toeoky.okoiin.dy<->or.chaiin
→ OMŌRRM  SAOLMTUII?  OŌSAONM  TOROŌM  OŌOII?  NMOR  SAUII?

`f9r.3`  toiin.cphy.qotod.otaiin.cthy.okor.chey<->ctho,d.ram
→ TOII?  SMAM  COTON  OTUII?  STAM  OŌOR  SARMSTAON  RUS

`f9r.4`  [y:o]shy.chokcho.chcthod,shor.shaiin.otar,dor<->ytol.dayty
→ MPAM  SAOŌSAO  SASTAONPAOR  PAUII?  OTURNORMTOL  NUMTM

`f9r.5`  daiin.chor.sor.cthy.chokoiin.shol.dsholdy<->otchol.ot.dy
→ NUII?  SAOR  POR  STAM  SAOŌOII?  PAOL  NPAOLNMOTSAOL  OT  NM

`f9r.6`  pshoain.cthoaiin.okaiir.{c@134;h}odoral.shar<->sy<->shydal.chdy
→ MPAOUI?  STAOUII?  OŌUIIR  SAONORUL  PAURPMPAMNUL  SANM

`f9r.7`  or.chol.chy,tchy.tchol.ytor.qotol.chyky<->chodar.aiin
→ OR  SAOL  SAMTSAM  TSAOL  MTOR  COTOL  SAMŌMSAONUR  UII?

`f9r.8`  qotcho.qokchy.cthey.koraiin.okain.d<->dal<->s.olshocth[y:g]
→ COTSAO  COŌSAM  STARM  ŌORUII?  OŌUI?  NNULP  OLPAOSTAM

`f9r.9`  ocho,cthy.cho{cto}y.chodykchy.saiin,dchy<->daiin
→ OSAOSTAM  SAOSTOM  SAONMŌSAM  PUII?NSAMNUII?

`f9r.10`  ytcha[s:r].oraiin.chkor
→ MTSAUP  ORUII?  SAŌOR

### f9v  ·  herbal

`f9v.1`  fochor.oporody.opy.shor.daiin.qopchypcho.qofol.shol.cfhol.daiin
→ ?OSAOR  OMORONM  OMM  PAOR  NUII?  COMSAMMSAO  CO?OL  PAOL  S?AOL  NUII?

`f9v.2`  dchor.qoaiin.chkaiin.cthor.chol.chor.cphol.dy<->oty.qokaiin.dy
→ NSAOR  COUII?  SAŌUII?  STAOR  SAOL  SAOR  SMAOL  NMOTM  COŌUII?  NM

`f9v.3`  ykey.chor.ykaiin.daiin.cthy.otaiin.oky<->oeees.daiin
→ MŌRM  SAOR  MŌUII?  NUII?  STAM  OTUII?  OŌMORRRP  NUII?

`f9v.4`  ytey,tch,y.kaiin.cthor.otol.oty.toldy
→ MTRMTSAM  ŌUII?  STAOR  OTOL  OTM  TOLNM

`f9v.5`  pchor.ypcheey.qotor.ypchy.olcfholy.t[o:e]<->ar<->chty.daiiin
→ MSAOR  MMSARRM  COTOR  MMSAM  OLS?AOLM  TOURSATM  NUIII?

`f9v.6`  odol.choy.ksheody.chody<->da[in:iin]<->otchy.cthod<->yko
→ ONOL  SAOM  ŌPARONM  SAONMNUI?OTSAM  STAONMŌO

`f9v.7`  qo.chol.chol.{ct}chy.daiin<->otal<->dor<->daim
→ CO  SAOL  SAOL  STSAM  NUII?OTULNORNUIS

`f9v.8`  soiin.daiin.qokcho.rokyd<->daly
→ POII?  NUII?  COŌSAO  ROŌMNNULM

`f9v.9`  daiin.chy.tor.chyty.dary<->ytoldy
→ NUII?  SAM  TOR  SAMTM  NURMMTOLNM

`f9v.10`  oty.kchol.chol.chy.kyty
→ OTM  ŌSAOL  SAOL  SAM  ŌMTM

`f9v.11`  ychor.chshoty.oky,kaiin
→ MSAOR  SAPAOTM  OŌMŌUII?

`f9v.12`  chkaiin.ckhy.chor
→ SAŌUII?  SŌAM  SAOR

### f10r  ·  herbal

`f10r.1`  pchocthy.shor.octhody.chorchy.pchodol.chopchal.ypch,kom
→ MSAOSTAM  PAOR  OSTAONM  SAORSAM  MSAONOL  SAOMSAUL  MMSAŌOS

`f10r.2`  dchey.cthoor.char.chty.os,chair.otytchol.oky.daiin.etyd
→ NSARM  STAOOR  SAUR  SATM  OPSAUIR  OTMTSAOL  OŌM  NUII?  RTMN

`f10r.3`  qotor.o,tchy.daiin.chocthy.qotchy.chol.or.yty.dy.dy
→ COTOR  OTSAM  NUII?  SAOSTAM  COTSAM  SAOL  OR  MTM  NM  NM

`f10r.4`  sor.chaiin.chcthy.ctho,ckhy.or.aiin.chtchor.do[iir:iin].ody
→ POR  SAUII?  SASTAM  STAOSŌAM  OR  UII?  SATSAOR  NOIIR  ONM

`f10r.5`  qokchy.qotchol.chol.cthy
→ COŌSAM  COTSAOL  SAOL  STAM

`f10r.6`  ycheor.cthy.chor.cthaiin.qoctholy.dy<->chy.taiin.shy
→ MSAROR  STAM  SAOR  STAUII?  COSTAOLM  NMSAM  TUII?  PAM

`f10r.7`  dchy.qokchol.y,kchaiin.yty.daiin.cth<->dain.dair,am
→ NSAM  COŌSAOL  MŌSAUII?  MTM  NUII?  STANUI?  NUIRUS

`f10r.8`  qotchor.chor.otol.chol.cholor<->chol.daiin.dar
→ COTSAOR  SAOR  OTOL  SAOL  SAOLORSAOL  NUII?  NUR

`f10r.9`  oykchor.shor.chor.chy.kaiiin.dy<->chodaiin
→ OMŌSAOR  PAOR  SAOR  SAM  ŌUIII?  NMSAONUII?

`f10r.10`  oqot[o:a]r.otor.cfhy.cthor.osain<->ytoiin
→ OCOTOR  OTOR  S?AM  STAOR  OPUI?MTOII?

`f10r.11`  @135;otchoshor.qoty.qotor.cthyd<->otar
→ OTSAOPAOR  COTM  COTOR  STAMNOTUR

`f10r.12`  @135;odaiin.daiin.qotchy.qotor
→ ONUII?  NUII?  COTSAM  COTOR

### f10v  ·  herbal

`f10v.1`  paiin,daiin.sheo.pcheey.qoty.daiin.cthor.otydy.sain
→ MUII?NUII?  PARO  MSARRM  COTM  NUII?  STAOR  OTMNM  PUI?

`f10v.2`  dain.daiin.ckhy.chcthor.choiin.qot.chodaiin.cthy.daiin
→ NUI?  NUII?  SŌAM  SASTAOR  SAOII?  COT  SAONUII?  STAM  NUII?

`f10v.3`  dsho.ytey.kchol.ol,ty.chol.dy
→ NPAO  MTRM  ŌSAOL  OLTM  SAOL  NM

`f10v.4`  qotchytor.shoiin.daiin.qotchey.sh{cthh}y.ytor.dain
→ COTSAMTOR  PAOII?  NUII?  COTSARM  PASTAAM  MTOR  NUI?

`f10v.5`  sho,ykeey.daiin.qotchy.qotor.chol.daiin.qokchy,ky
→ PAOMŌRRM  NUII?  COTSAM  COTOR  SAOL  NUII?  COŌSAMŌM

`f10v.6`  shoiin.chor.shcthy.qoty.qotoiin.qokol.chor,aiin
→ PAOII?  SAOR  PASTAM  COTM  COTOII?  COŌOL  SAORUII?

`f10v.7`  qokol.chy,ky.chol,cheky.daiin.dain.chckhan
→ COŌOL  SAMŌM  SAOLSARŌM  NUII?  NUI?  SASŌAU?

### f11r  ·  herbal

`f11r.1`  tshol.schoal.cfhy.shfydaiin.cphy.shey.tchody.shoyty
→ TPAOL  PSAOUL  S?AM  PA?MNUII?  SMAM  PARM  TSAONM  PAOMTM

`f11r.2`  socthody.qodor,y.kshy.daiin.ytchy.ytchoky.kchol.daiin
→ POSTAONM  CONORM  ŌPAM  NUII?  MTSAM  MTSAOŌM  ŌSAOL  NUII?

`f11r.3`  qoty.chol.cthy.d[o:a]r.ykychy.choty.dain.chaiin.daiin.d[o:e]d
→ COTM  SAOL  STAM  NOR  MŌMSAM  SAOTM  NUI?  SAUII?  NUII?  NON

`f11r.4`  dchol.chy.kchy.dy.daiin
→ NSAOL  SAM  ŌSAM  NM  NUII?

`f11r.5`  tchol.shor.shor.dky.{c'h@148;h}y.daiin.cthy.d,y,chodl,daiin
→ TSAOL  PAOR  PAOR  NŌM  SAAM  NUII?  STAM  NMSAONLNUII?

`f11r.6`  odl.d,s,y.otol.chaiin.ykchor.dair.chody.cthy.s.daiin
→ ONL  NPM  OTOL  SAUII?  MŌSAOR  NUIR  SAONM  STAM  P  NUII?

`f11r.7`  qotchy.okchol.cthy.dy
→ COTSAM  OŌSAOL  STAM  NM

### f11v  ·  herbal

`f11v.1`  poldchody.shcphy.shordy.qoty<->shol.cphar.dan,y
→ MOLNSAONM  PASMAM  PAORNM  COTMPAOL  SMAUR  NU?M

`f11v.2`  shol.dy.chckhy.shcthy.daiin.dam<->ykchy.dain.dchy
→ PAOL  NM  SASŌAM  PASTAM  NUII?  NUSMŌSAM  NUI?  NSAM

`f11v.3`  otchor.dy.kchy.tchy.[@152;:d]ar.qokchd<->oky.choldy,dy
→ OTSAOR  NM  ŌSAM  TSAM  UR  COŌSANOŌM  SAOLNMNM

`f11v.4`  qokchor.cholol{cr}.chyky.dchy.qoky<->ctho.tchey.tu
→ COŌSAOR  SAOLOLSR  SAMŌM  NSAM  COŌMSTAO  TSARM  T?

`f11v.5`  dd
→ NN

`f11v.6`  soydy.qoteey.qot.chor.dy.ddy<->cthor.shy,arg
→ POMNM  COTRRM  COT  SAOR  NM  NNMSTAOR  PAMUR?

`f11v.7`  ycheor.ksho.dor.cthey.s,chold
→ MSAROR  ŌPAO  NOR  STARM  PSAOLN

### f13r  ·  herbal

`f13r.1`  torshor.opchy.shol.dy.qopchy.shol.opchor.dypchy.dchg
→ TORPAOR  OMSAM  PAOL  NM  COMSAM  PAOL  OMSAOR  NMMSAM  NSA?

`f13r.2`  dchol.chol.dol.shkchy.ydal.shy.ykchy.qot[?:ch]y.daiin.s.y
→ NSAOL  SAOL  NOL  PAŌSAM  MNUL  PAM  MŌSAM  COTM  NUII?  P  M

`f13r.3`  s,y.dchor.shaiin.oeees.ykor.chor.ytshy.ykchy.kchy.dar
→ PM  NSAOR  PAUII?  ORRRP  MŌOR  SAOR  MTPAM  MŌSAM  ŌSAM  NUR

`f13r.4`  qodchy.ytchy.otchor
→ CONSAM  MTSAM  OTSAOR

`f13r.5`  shorodo.shy.tshy.kchol.dpchy,qopchy.otchol.cfholdy
→ PAORONO  PAM  TPAM  ŌSAOL  NMSAMCOMSAM  OTSAOL  S?AOLNM

`f13r.6`  tchor.dor.daiin.qotchol.okchy.okchor,oiin.chckhy.d
→ TSAOR  NOR  NUII?  COTSAOL  OŌSAM  OŌSAOROII?  SASŌAM  N

`f13r.7`  dchy.qoky.chol.dy.qo{kh}y.d,oldy<->okchor.doaiin
→ NSAM  COŌM  SAOL  NM  COŌAM  NOLNMOŌSAOR  NOUII?

`f13r.8`  shochy.qokchy.torchy.k{chky}<->s.okchey.daiin
→ PAOSAM  COŌSAM  TORSAM  ŌSAŌMP  OŌSARM  NUII?

`f13r.9`  oldy.shey.chol.d[o:a]iin.ykoly<->okchal.daldy
→ OLNM  PARM  SAOL  NOII?  MŌOLMOŌSAUL  NULNM

`f13r.10`  sotchy.kchy.okorory
→ POTSAM  ŌSAM  OŌORORM

### f13v  ·  herbal

`f13v.1`  koair.chtoiin.otchy.kchod.otol.otchy.octhos
→ ŌOUIR  SATOII?  OTSAM  ŌSAON  OTOL  OTSAM  OSTAOP

`f13v.2`  oko.qokol.chodal.otchol.cphol.choty
→ OŌO  COŌOL  SAONUL  OTSAOL  SMAOL  SAOTM

`f13v.3`  qokchy.qokod.chy.otchy.cthody
→ COŌSAM  COŌON  SAM  OTSAM  STAONM

`f13v.4`  o,l,s.chey.okos.oa[iin:in].okshy.qo{cky}
→ OLP  SARM  OŌOP  OUII?  OŌPAM  COSŌM

`f13v.5`  qoky.daiin
→ COŌM  NUII?

`f13v.6`  foldaiin.olcphy.shol.dy<->oty.shor.qotyd<->dairod
→ ?OLNUII?  OLSMAM  PAOL  NMOTM  PAOR  COTMNNUIRON

`f13v.7`  dain.okal.chy.qokchory<->dchy.kok[y:a]daiin<->shon
→ NUI?  OŌUL  SAM  COŌSAORMNSAM  ŌOŌMNUII?PAO?

`f13v.8`  otchy.daiin.y,dain.ykol<->okchy.o,kald<->d,y,taiin
→ OTSAM  NUII?  MNUI?  MŌOLOŌSAM  OŌULNNMTUII?

`f13v.9`  tchtod.otal.cthor.ytal<->y.cho,tal<->sho.qocthy
→ TSATON  OTUL  STAOR  MTULM  SAOTULPAO  COSTAM

`f13v.10`  y,ol.chy.kchey.kchor.dal
→ MOL  SAM  ŌSARM  ŌSAOR  NUL

### f14r  ·  herbal

`f14r.1`  pcho,daiin.chopol.shoiin.daiin.dain
→ MSAONUII?  SAOMOL  PAOII?  NUII?  NUI?

`f14r.2`  o,ykeey.soiiin.chok.qokchy.da.okol
→ OMŌRRM  POIII?  SAOŌ  COŌSAM  NU  OŌOL

`f14r.3`  ydaiin.olchy.kchor.daiin.olol
→ MNUII?  OLSAM  ŌSAOR  NUII?  OLOL

`f14r.4`  ochkch[o:a]r.kol.shy.daiin.dorody
→ OSAŌSAOR  ŌOL  PAM  NUII?  NORONM

`f14r.5`  qokchol.dar.dalo.qotolo
→ COŌSAOL  NUR  NULO  COTOLO

`f14r.6`  ychol.oir.okor.choor.ockhy
→ MSAOL  OIR  OŌOR  SAOOR  OSŌAM

`f14r.7`  otcho.dain.chckhy
→ OTSAO  NUI?  SASŌAM

`f14r.8`  soshy.@137;chol.shor.cheos.ykaiin.s
→ POPAM  SAOL  PAOR  SAROP  MŌUII?  P

`f14r.9`  sody.chody.otchody.qotchy,koiin.sy<->sho.ty,dy
→ PONM  SAONM  OTSAONM  COTSAMŌOII?  PMPAO  TMNM

`f14r.10`  qotchor.chod.shoty.chody.dol,dy,dy<->okchydy
→ COTSAOR  SAON  PAOTM  SAONM  NOLNMNMOŌSAMNM

`f14r.11`  dchokchy.schol.dy.shey.dar.qoty<->ykeeyky
→ NSAOŌSAM  PSAOL  NM  PARM  NUR  COTMMŌRRMŌM

`f14r.12`  oeeeb.chey.keor.chey.tchyky<->chodalg
→ ORRR?  SARM  ŌROR  SARM  TSAMŌMSAONUL?

`f14r.13`  sodaiin.chy.kchy.kchy.ykeody
→ PONUII?  SAM  ŌSAM  ŌSAM  MŌRONM

### f14v  ·  herbal

`f14v.1`  pdychoiin.yfodain.otyshy.dy.ypchor.daiin.kol.ydain
→ MNMSAOII?  M?ONUI?  OTMPAM  NM  MMSAOR  NUII?  ŌOL  MNUI?

`f14v.2`  okchor.d,chytshy.oty.chy.cthy.otchy,ty.chol,daiin
→ OŌSAOR  NSAMTPAM  OTM  SAM  STAM  OTSAMTM  SAOLNUII?

`f14v.3`  ychy,dy.daiin.chcthy.y[k:t],ykaiin.dytchy.{ykhh}y.ky,dy
→ MSAMNM  NUII?  SASTAM  MŌMŌUII?  NMTSAM  MŌAAM  ŌMNM

`f14v.4`  ytychy.ksho.ykshy.shokshor.yty.darody.dyoty,ds
→ MTMSAM  ŌPAO  MŌPAM  PAOŌPAOR  MTM  NURONM  NMOTMNP

`f14v.5`  okshy.daiin.okchor,chky.qotchy.daiin.cthor.oty
→ OŌPAM  NUII?  OŌSAORSAŌM  COTSAM  NUII?  STAOR  OTM

`f14v.6`  qoty.choky.cthy.chokchy.dy,dy,dy.chckhy.dchyd.n
→ COTM  SAOŌM  STAM  SAOŌSAM  NMNMNM  SASŌAM  NSAMN  ?

`f14v.7`  oy,kshy.cho,ty.dydy,odyd.otchy.o.kchy.dshy.dardy
→ OMŌPAM  SAOTM  NMNMONMN  OTSAM  O  ŌSAM  NPAM  NURNM

`f14v.8`  chokshor.daiin<->okshody.daiin<->dol.dair.dam
→ SAOŌPAOR  NUII?OŌPAONM  NUII?NOL  NUIR  NUS

`f14v.9`  dykchy.ctholdg<->dchckhy
→ NMŌSAM  STAOLN?NSASŌAM

### f15r  ·  herbal

`f15r.1`  tshor.shey.tchaly<->shy.chtols.shey.daiin
→ TPAOR  PARM  TSAULMPAM  SATOLP  PARM  NUII?

`f15r.2`  otchor.qokchor.oly<->okor.shy.koly
→ OTSAOR  COŌSAOR  OLMOŌOR  PAM  ŌOLM

`f15r.3`  qokaiin.qotchy,tydy<->daiin.chol.cthy
→ COŌUII?  COTSAMTMNMNUII?  SAOL  STAM

`f15r.4`  scheaiin.chodaiin.chl<->sol.ckhaiin.sal
→ PSARUII?  SAONUII?  SALPOL  SŌAUII?  PUL

`f15r.5`  qotchy.r,shor.cthy<->daiin.cthy.dy
→ COTSAM  RPAOR  STAMNUII?  STAM  NM

`f15r.6`  dchy.ko,kaiin.chdy<->saiin.okear
→ NSAM  ŌOŌUII?  SANMPUII?  OŌRUR

`f15r.7`  daiin.shkaiin.cthy<->sho.keocthy
→ NUII?  PAŌUII?  STAMPAO  ŌROSTAM

`f15r.8`  shocthy.tol,kaiin,s<->dain.ctholy
→ PAOSTAM  TOLŌUII?PNUI?  STAOLM

`f15r.9`  octhain.qokaiin.chos<->odaiin.cthl,s.y
→ OSTAUI?  COŌUII?  SAOPONUII?  STALP  M

`f15r.10`  ychain.ch{ckhh}y.okshy<->saiiin.dolchds
→ MSAUI?  SASŌAAM  OŌPAMPUIII?  NOLSANP

`f15r.11`  okaiin.otaiin.chl.sy<->chor.choross
→ OŌUII?  OTUII?  SAL  PMSAOR  SAOROPP

`f15r.12`  qotor.shor.tcheor.chy<->cthaiin<->shan
→ COTOR  PAOR  TSAROR  SAMSTAUII?PAU?

`f15r.13`  ykshol.dor.sheey.cthy.dain<->sky<->shor,shoty
→ MŌPAOL  NOR  PARRM  STAM  NUI?PŌMPAORPAOTM

`f15r.14`  otcho.kchy.chol.daiin.{ith}ar<->ytol.dor.dom
→ OTSAO  ŌSAM  SAOL  NUII?  ITAURMTOL  NOR  NOS

`f15r.15`  qotchor.chaiin.chy,kol.daky
→ COTSAOR  SAUII?  SAMŌOL  NUŌM

### f15v  ·  herbal

`f15v.1`  poror.orshy.choiin.dtchan.opchordy
→ MOROR  ORPAM  SAOII?  NTSAU?  OMSAORNM

`f15v.2`  @138;chor.or.oro.r,aiin.cthy.[?:t]ain,dar
→ SAOR  OR  ORO  RUII?  STAM  UI?NUR

`f15v.3`  cthor.daiin.qokor.okeor.okaiin
→ STAOR  NUII?  COŌOR  OŌROR  OŌUII?

`f15v.4`  doiin.choky.shol.qoky.qotchod
→ NOII?  SAOŌM  PAOL  COŌM  COTSAON

`f15v.5`  otchor.chor.chor.ytchor.cthy.s
→ OTSAOR  SAOR  SAOR  MTSAOR  STAM  P

`f15v.6`  qotchey.choty.kaiin.otchy.r.aiin
→ COTSARM  SAOTM  ŌUII?  OTSAM  R  UII?

`f15v.7`  {co}y.cho[iin:iir].sho.[?:s].chy.s.chy.tor.ols
→ SOM  SAOII?  PAO  —  SAM  P  SAM  TOR  OLP

`f15v.8`  ytchor.chor.ol.oiin.oty.shol.daiin
→ MTSAOR  SAOR  OL  OII?  OTM  PAOL  NUII?

`f15v.9`  otchol,octhol.chol.chol.chody.kan
→ OTSAOLOSTAOL  SAOL  SAOL  SAONM  ŌU?

`f15v.10`  sor.chor.cthoiin.cthy.qokaiin
→ POR  SAOR  STAOII?  STAM  COŌUII?

`f15v.11`  sol,oiin.cheor.chol.daiin.cthy
→ POLOII?  SAROR  SAOL  NUII?  STAM

`f15v.12`  daiin.cthor.chol.chor
→ NUII?  STAOR  SAOL  SAOR

### f16r  ·  herbal

`f16r.1`  pocheody.qopchey.sykaiin.opchy,dor.ychy<->daiin.dy<->chor.orom
→ MOSARONM  COMSARM  PMŌUII?  OMSAMNOR  MSAMNUII?  NMSAOR  OROS

`f16r.2`  ychykchy.otey.kol.shor.ody.otody.qoy<->oeesordy
→ MSAMŌSAM  OTRM  ŌOL  PAOR  ONM  OTONM  COMORRPORNM

`f16r.3`  ydor.sheal.okchy.qoy,koiin.choky.ykair
→ MNOR  PARUL  OŌSAM  COMŌOII?  SAOŌM  MŌUIR

`f16r.4`  dainod.ychealod
→ NUI?ON  MSARULON

`f16r.5`  tchor.chor.chs.y,kch.shocthy.opchy.ty,ky
→ TSAOR  SAOR  SAP  MŌSA  PAOSTAM  OMSAM  TMŌM

`f16r.6`  oshaiin.dyky.oeees.deeeod.aiin.d,toaiin
→ OPAUII?  NMŌM  ORRRP  NRRRON  UII?  NTOUII?

`f16r.7`  daiin.dalchy.dyky.schy.s,aiin.doal.qoky
→ NUII?  NULSAM  NMŌM  PSAM  PUII?  NOUL  COŌM

`f16r.8`  shotchy.ydain.yky.shody.otol.daiin
→ PAOTSAM  MNUI?  MŌM  PAONM  OTOL  NUII?

`f16r.9`  saiin.ytaiin
→ PUII?  MTUII?

`f16r.10`  toror.dal[y:o],dal.opchy,fchol.ypcho{cfy}.okal
→ TOROR  NULMNUL  OMSAM?SAOL  MMSAOS?M  OŌUL

`f16r.11`  sokchy.qokol.choty.okchy.cthy.chy,kchy
→ POŌSAM  COŌOL  SAOTM  OŌSAM  STAM  SAMŌSAM

`f16r.12`  dy,cho,kchy.shcthy.shtshy.sho.tchokyd
→ NMSAOŌSAM  PASTAM  PATPAM  PAO  TSAOŌMN

`f16r.13`  qok[{oh}:ch]or.dl.dy.shey
→ COŌOAOR  NL  NM  PARM

### f16v  ·  herbal

`f16v.1`  pchroiin.otchor.chpchol.chpchey.s,pcho{ct}y
→ MSAROII?  OTSAOR  SAMSAOL  SAMSARM  PMSAOSTM

`f16v.2`  ytchor.y.ky,chokchy.qokchocthor.shory
→ MTSAOR  M  ŌMSAOŌSAM  COŌSAOSTAOR  PAORM

`f16v.3`  ykchy.dy.choy.qoty.chy,kchy.koshet
→ MŌSAM  NM  SAOM  COTM  SAMŌSAM  ŌOPART

`f16v.4`  dchol.chcthody.cphod.chotol.dal
→ NSAOL  SASTAONM  SMAON  SAOTOL  NUL

`f16v.5`  ytchy.chyty.chor.chol.ytchy.dan
→ MTSAM  SAMTM  SAOR  SAOL  MTSAM  NU?

`f16v.6`  sor.ch,k[a:o]r.oty.chkar.chol.dairin
→ POR  SAŌUR  OTM  SAŌUR  SAOL  NUIRI?

`f16v.7`  pchocthy.chypchy.qotchy.ch{cfhh}y.sy
→ MSAOSTAM  SAMMSAM  COTSAM  SAS?AAM  PM

`f16v.8`  daiin.chol.y.daiin.chcthy.qot,char.chor.sholo
→ NUII?  SAOL  M  NUII?  SASTAM  COTSAUR  SAOR  PAOLO

`f16v.9`  dshy.okaiin.okaiin.chol.chor.cthor.ty.chody
→ NPAM  OŌUII?  OŌUII?  SAOL  SAOR  STAOR  TM  SAONM

`f16v.10`  qokchy.chy,dy.ykchy.chckhy.otain.cthor.[cth:{ith}]y
→ COŌSAM  SAMNM  MŌSAM  SASŌAM  OTUI?  STAOR  STAM

`f16v.11`  okytaiin.chkchy.saiin
→ OŌMTUII?  SAŌSAM  PUII?

`f16v.12`  daiin.yky.otor.chody
→ NUII?  MŌM  OTOR  SAONM

`f16v.13`  sokar.oaorar
→ POŌUR  OUORUR

### f17r  ·  herbal

`f17r.1`  fshody.daram.ydar,chog.opydy.ypod.chop.otchy.dody.oldckhy
→ ?PAONM  NURUS  MNURSAO?  OMMNM  MMON  SAOM  OTSAM  NONM  OLNSŌAM

`f17r.2`  ydair.choky.okshy.qodar.ckhody.dor.otchol.qodcthy.ods
→ MNUIR  SAOŌM  OŌPAM  CONUR  SŌAONM  NOR  OTSAOL  CONSTAM  ONP

`f17r.3`  chol.or.chy.qodam.okor.chor.okchom
→ SAOL  OR  SAM  CONUS  OŌOR  SAOR  OŌSAOS

`f17r.4`  tcho@154;.shol.qokol.qor.olaiin.opydg<->som.ypchy.ypaim
→ TSAO  PAOL  COŌOL  COR  OLUII?  OMMN?POS  MMSAM  MMUIS

`f17r.5`  ychekchy.cthy.chor.shor.cphor.cphaldy<->dair.cthey.qody
→ MSARŌSAM  STAM  SAOR  PAOR  SMAOR  SMAULNMNUIR  STARM  CONM

`f17r.6`  tsho.qof,cho.qokcheor.cheteg
→ TPAO  CO?SAO  COŌSAROR  SARTR?

`f17r.7`  ksheo.qokchy.choldshy.zepchy<->d{c'a}<->opchordy
→ ŌPARO  COŌSAM  SAOLNPAM  ?RMSAMNSUOMSAORNM

`f17r.8`  dchchy.dychear.schar.ykchy
→ NSASAM  NMSARUR  PSAUR  MŌSAM

`f17r.9`  soy.chckho.o.da[s:r].chypcham
→ POM  SASŌAO  O  NUP  SAMMSAUS

`f17r.10`  dar.chear.dcheor.[s:?]ain.y.mol
→ NUR  SARUR  NSAROR  PUI?  M  SOL

`f17r.11`  otchol.cthar.okaiin.chol.daiiin
→ OTSAOL  STAUR  OŌUII?  SAOL  NUIII?

`f17r.12`  ychod,y.chotom
→ MSAONM  SAOTOS

`f17r.13`  oteeeon.oiil
→ OTRRRO?  OIIL

### f17v  ·  herbal

`f17v.1`  pchodol.chor.pchy.opydaiin.odal,dy
→ MSAONOL  SAOR  MSAM  OMMNUII?  ONULNM

`f17v.2`  ycheey.keeor.cthodal.okol.odaiin.okal
→ MSARRM  ŌRROR  STAONUL  OŌOL  ONUII?  OŌUL

`f17v.3`  oldaig.odaiin.okal.oldaiin.chockhol.olol
→ OLNUI?  ONUII?  OŌUL  OLNUII?  SAOSŌAOL  OLOL

`f17v.4`  kchor.fchol.cphol.olcheol.ok[eee:eeee]y
→ ŌSAOR  ?SAOL  SMAOL  OLSAROL  OŌRRRM

`f17v.5`  ychol.chol.dolcheey.tchol.dar.ckhy
→ MSAOL  SAOL  NOLSARRM  TSAOL  NUR  SŌAM

`f17v.6`  oekor.or.okaiin.or.otaiin,d
→ ORŌOR  OR  OŌUII?  OR  OTUII?N

`f17v.7`  sor.chkeey.poiis.cheor.os.s.aiin
→ POR  SAŌRRM  MOIIP  SAROR  OP  P  UII?

`f17v.8`  qokeey.kchar.ol.dy.choldaiin.sy
→ COŌRRM  ŌSAUR  OL  NM  SAOLNUII?  PM

`f17v.9`  ycheol.shol.kchol.choltaiin.ol
→ MSAROL  PAOL  ŌSAOL  SAOLTUII?  OL

`f17v.10`  oytor.okeor.okar.okol.daiir,a[r:m]
→ OMTOR  OŌROR  OŌUR  OŌOL  NUIIRUR

`f17v.11`  qokcheo.qokoiir.ctheol.chol
→ COŌSARO  COŌOIIR  STAROL  SAOL

`f17v.12`  oy.choy.keaiin.chckhey.ol.chor
→ OM  SAOM  ŌRUII?  SASŌARM  OL  SAOR

`f17v.13`  ykeor.chol.chol.cthol.chkor.sheol
→ MŌROR  SAOL  SAOL  STAOL  SAŌOR  PAROL

`f17v.14`  olo.r.okeeol.chodaiin.okeol.tchory
→ OLO  R  OŌRROL  SAONUII?  OŌROL  TSAORM

`f17v.15`  ychor.cthy.che'eky.cheo.otor.oteol
→ MSAOR  STAM  SARRŌM  SARO  OTOR  OTROL

`f17v.16`  okcheol.chol.okeol.cthol.otcheolom
→ OŌSAROL  SAOL  OŌROL  STAOL  OTSAROLOS

`f17v.17`  qoain.[s:e']ar.she.dol.qopchaiin.cthor
→ COUI?  PUR  PAR  NOL  COMSAUII?  STAOR

`f17v.18`  otor.cheeor.ol.chol.dor.chr.or,eees
→ OTOR  SARROR  OL  SAOL  NOR  SAR  ORRRRP

`f17v.19`  dain.chey.qoaiin.cthor.cholchom
→ NUI?  SARM  COUII?  STAOR  SAOLSAOS

`f17v.20`  ykeey.okeey.cheor.chol.sho.odaiin
→ MŌRRM  OŌRRM  SAROR  SAOL  PAO  ONUII?

`f17v.21`  oal.sheor.sholor.or.shecthy.cpheor.daiin
→ OUL  PAROR  PAOLOR  OR  PARSTAM  SMAROR  NUII?

`f17v.22`  qokeee.dar.chey.keeor.cheeol.ctheey.cthy
→ COŌRRR  NUR  SARM  ŌRROR  SARROL  STARRM  STAM

`f17v.23`  chkeey.okeor.sh[a:o]r.okeom
→ SAŌRRM  OŌROR  PAUR  OŌROS

### f18r  ·  herbal

`f18r.1`  pdrairdy.darod{cf}.yoar.ykchol.dar.om.chckhy<->octhor.dal
→ MNRUIRNM  NURONS?  MOUR  MŌSAOL  NUR  OS  SASŌAMOSTAOR  NUL

`f18r.2`  otshol.qokchol.chykchy.okchal.daiin.dy<->chol.dain
→ OTPAOL  COŌSAOL  SAMŌSAM  OŌSAUL  NUII?  NMSAOL  NUI?

`f18r.3`  qokchor.chor.{c@139;h}{@246;k}ey.or,chey.qokchol.dy<->ytcharg
→ COŌSAOR  SAOR  SAŌRM  ORSARM  COŌSAOL  NMMTSAUR?

`f18r.4`  chor.[cth:{ith}]or.okeor.ykchol.okain
→ SAOR  STAOR  OŌROR  MŌSAOL  OŌUI?

`f18r.5`  tchor.shor.cthaiin.cthol.chlol.chom
→ TSAOR  PAOR  STAUII?  STAOL  SALOL  SAOS

`f18r.6`  ychy.kchor.dair.ytol.chcthy.dar.dar.dal
→ MSAM  ŌSAOR  NUIR  MTOL  SASTAM  NUR  NUR  NUL

`f18r.7`  oshor.shaiin.cthy.sholdy.doldy<->doldaiin
→ OPAOR  PAUII?  STAM  PAOLNM  NOLNMNOLNUII?

`f18r.8`  qokchor.ckhol.olody.okal,dy<->dary
→ COŌSAOR  SŌAOL  OLONM  OŌULNMNURM

`f18r.9`  chol.chcthal.okshal.chykald
→ SAOL  SASTAUL  OŌPAUL  SAMŌULN

`f18r.10`  dar.shor.qokchol.ol.ydaiin
→ NUR  PAOR  COŌSAOL  OL  MNUII?

`f18r.11`  sotchaiin.chokchy.chckhol.chor.g
→ POTSAUII?  SAOŌSAM  SASŌAOL  SAOR  ?

`f18r.12`  ychair.cthol.daiin.qokchy.cthy
→ MSAUIR  STAOL  NUII?  COŌSAM  STAM

`f18r.13`  or.shaiin.cth[a:o]r.cthal.okal.dar
→ OR  PAUII?  STAUR  STAUL  OŌUL  NUR

`f18r.14`  ychekch,y.kchaiin
→ MSARŌSAM  ŌSAUII?

### f18v  ·  herbal

`f18v.1`  told.shor.ytshy.otchdal.dchal.dchy.ytdg
→ TOLN  PAOR  MTPAM  OTSANUL  NSAUL  NSAM  MTN?

`f18v.2`  qoeees.or.oaiin.shy@140;.okshy.qokchy.qokchy.s.g
→ CORRRP  OR  OUII?  PAM  OŌPAM  COŌSAM  COŌSAM  P  ?

`f18v.3`  orshy.qoky.qoky.chkchy.qokshy.qokam
→ ORPAM  COŌM  COŌM  SAŌSAM  COŌPAM  COŌUS

`f18v.4`  qotchy.qokay.qokchy.ykcho.ydl.dar
→ COTSAM  COŌUM  COŌSAM  MŌSAO  MNL  NUR

`f18v.5`  ychoees.ykchy.qol.kchy.qotchol.daiir,om
→ MSAORRP  MŌSAM  COL  ŌSAM  COTSAOL  NUIIROS

`f18v.6`  qotor,chor.otchy.qokeees.chy.s.ar.ykar
→ COTORSAOR  OTSAM  COŌRRRP  SAM  P  UR  MŌUR

`f18v.7`  ychol.dor.chod.qokol.daiin.qokol.dar.dy
→ MSAOL  NOR  SAON  COŌOL  NUII?  COŌOL  NUR  NM

`f18v.8`  tolol.sh.cphoy.daror.ddy.ytor.ykam
→ TOLOL  PA  SMAOM  NUROR  NNM  MTOR  MŌUS

`f18v.9`  okchor.qotchy.qokchy.ytol.doky.dy
→ OŌSAOR  COTSAM  COŌSAM  MTOL  NOŌM  NM

`f18v.10`  yk[o:a].dshy.dair.ykol.dom
→ MŌO  NPAM  NUIR  MŌOL  NOS

### f19r  ·  herbal

`f19r.1`  pchor.qodchy.qotshy.dy.tchy.qotchy.qoky.daiin.dchydy
→ MSAOR  CONSAM  COTPAM  NM  TSAM  COTSAM  COŌM  NUII?  NSAMNM

`f19r.2`  dshy.chor.y.tchy.chol.dytchy.chordy.daiin.dyty.@241;.cho@242;
→ NPAM  SAOR  M  TSAM  SAOL  NMTSAM  SAORNM  NUII?  NMTM  —  SAO

`f19r.3`  oscheor.shy.tdaiin.chol.dor.yky
→ OPSAROR  PAM  TNUII?  SAOL  NOR  MŌM

`f19r.4`  qokorar.daiin.chckhy.shy,kchor
→ COŌORUR  NUII?  SASŌAM  PAMŌSAOR

`f19r.5`  otchy.tchy.qoky.daiin.@243;
→ OTSAM  TSAM  COŌM  NUII?  —

`f19r.6`  yshor.shy.daiin.otytchy.daiin
→ MPAOR  PAM  NUII?  OTMTSAM  NUII?

`f19r.7`  qo'k.cho.ky.cthar.dor.chan.dar
→ COŌ  SAO  ŌM  STAUR  NOR  SAU?  NUR

`f19r.8`  or.chor.daky.dal.chor.dorl.shy
→ OR  SAOR  NUŌM  NUL  SAOR  NORL  PAM

`f19r.9`  qotchor.dy.dor.y.tchy,kchy.shdaiin
→ COTSAOR  NM  NOR  M  TSAMŌSAM  PANUII?

`f19r.10`  daiin.cthor.chol.ykchor.chordy
→ NUII?  STAOR  SAOL  MŌSAOR  SAORNM

`f19r.11`  qotchy.qolody.choldy.cthyd
→ COTSAM  COLONM  SAOLNM  STAMN

`f19r.12`  ykchor.chor.daiin.daiinol
→ MŌSAOR  SAOR  NUII?  NUII?OL

`f19r.13`  os,octhor.ytchor
→ OPOSTAOR  MTSAOR

### f19v  ·  herbal

`f19v.1`  pochaiin.cthor.chpcheos.opchey.py,kchy
→ MOSAUII?  STAOR  SAMSAROP  OMSARM  MMŌSAM

`f19v.2`  qokchy.kchol.sor.qokchos.ykchy.darom
→ COŌSAM  ŌSAOL  POR  COŌSAOP  MŌSAM  NUROS

`f19v.3`  otchy.chol,daiin.qotol.ytol.daiiin
→ OTSAM  SAOLNUII?  COTOL  MTOL  NUIII?

`f19v.4`  ytch.chcthy.qotol.daiin.daiin
→ MTSA  SASTAM  COTOL  NUII?  NUII?

`f19v.5`  qotchy.qoteey.daiin.doty.qot
→ COTSAM  COTRRM  NUII?  NOTM  COT

`f19v.6`  ychoy.kchor.cthol.chocthy.s
→ MSAOM  ŌSAOR  STAOL  SAOSTAM  P

`f19v.7`  ycho.[r:s].chaiin.cthor
→ MSAO  R  SAUII?  STAOR

`f19v.8`  toy.tchey,qo.dchol.qokchs.dom
→ TOM  TSARMCO  NSAOL  COŌSAP  NOS

`f19v.9`  ychor.oky.chor.yt[o:a]l.chol.oky,ddor
→ MSAOR  OŌM  SAOR  MTOL  SAOL  OŌMNNOR

`f19v.10`  daiin.chor.daiin.qoko[r:n].y.okchan
→ NUII?  SAOR  NUII?  COŌOR  M  OŌSAU?

`f19v.11`  qotol.d[o:a]r.okchor.daiin.cthor.otam
→ COTOL  NOR  OŌSAOR  NUII?  STAOR  OTUS

`f19v.12`  otch.okchodshy.daiin.or.otaiin.dai[s:r]
→ OTSA  OŌSAONPAM  NUII?  OR  OTUII?  NUIP

`f19v.13`  yees.ykchol.oty.ytor.ytar.ytchor.ytaiin
→ MRRP  MŌSAOL  OTM  MTOR  MTUR  MTSAOR  MTUII?

`f19v.14`  otchol,cheaiin.cthol
→ OTSAOLSARUII?  STAOL

### f20r  ·  herbal

`f20r.1`  kdchody.chopy.cheey.qotchol.qotoeey.dchor.chaiin
→ ŌNSAONM  SAOMM  SARRM  COTSAOL  COTORRM  NSAOR  SAUII?

`f20r.2`  chod,ey.cthey.chotol.odaiir.qotchy.cthody.chodchy
→ SAONRM  STARM  SAOTOL  ONUIIR  COTSAM  STAONM  SAONSAM

`f20r.3`  qoteey.cho,chodaiin.sho.qochy.chey.tcheodal.daral
→ COTRRM  SAOSAONUII?  PAO  COSAM  SARM  TSARONUL  NURUL

`f20r.4`  ochol.ol.teey.ot[o:a]lchey
→ OSAOL  OL  TRRM  OTOLSARM

`f20r.5`  pchocthy.chokoaiin.{cp}y.cheeeb.opchey.shosaiin.@243;
→ MSAOSTAM  SAOŌOUII?  SMM  SARRR?  OMSARM  PAOPUII?  —

`f20r.6`  choees.okchor.qotol.cheey.daiin.chy.choiin.daiin
→ SAORRP  OŌSAOR  COTOL  SARRM  NUII?  SAM  SAOII?  NUII?

`f20r.7`  ocho,lshod.daiin.choteol.chol.dol.shol.otaiin
→ OSAOLPAON  NUII?  SAOTROL  SAOL  NOL  PAOL  OTUII?

`f20r.8`  schodain.cheo.r.cheody
→ PSAONUI?  SARO  R  SARONM

`f20r.9`  fchodees.shody.qotchey.qokchey.qocphy.chokoldy
→ ?SAONRRP  PAONM  COTSARM  COŌSARM  COSMAM  SAOŌOLNM

`f20r.10`  ochoaiin.chor.sody.pchodaiin.chetody.choky.dchy.toy
→ OSAOUII?  SAOR  PONM  MSAONUII?  SARTONM  SAOŌM  NSAM  TOM

`f20r.11`  dchod.qoteeody.ytchy.qo,tshey.dchaiin.chol,ody
→ NSAON  COTRRONM  MTSAM  COTPARM  NSAUII?  SAOLONM

`f20r.12`  shoiin.cheody.otchey.otchy.tchy.qoteey.daiin.dar
→ PAOII?  SARONM  OTSARM  OTSAM  TSAM  COTRRM  NUII?  NUR

`f20r.13`  ochaiin.chor.chor,cheey.tchey
→ OSAUII?  SAOR  SAORSARRM  TSARM

### f20v  ·  herbal

`f20v.1`  faiis,ar.okoy.shy,pofochey.opchy.qopy.choldy.opydy.cphy
→ ?UIIPUR  OŌOM  PAMMO?OSARM  OMSAM  COMM  SAOLNM  OMMNM  SMAM

`f20v.2`  sos.ykoiin.cheol.chol.choiin.checthy.otol.chol.chodaiin.oty
→ POP  MŌOII?  SAROL  SAOL  SAOII?  SARSTAM  OTOL  SAOL  SAONUII?  OTM

`f20v.3`  okchy.sho,kchol.shol.chcthy.qoty.chy.tolshy.qotchy
→ OŌSAM  PAOŌSAOL  PAOL  SASTAM  COTM  SAM  TOLPAM  COTSAM

`f20v.4`  sho.or.aiin.shol.daiin
→ PAO  OR  UII?  PAOL  NUII?

`f20v.5`  tshol.folchol.otor.shol.shor.fshodchy.otchy.chcphy.dy
→ TPAOL  ?OLSAOL  OTOR  PAOL  PAOR  ?PAONSAM  OTSAM  SASMAM  NM

`f20v.6`  doiiin.chockhy.da[n:r].cheo{ikh}y.shos.cheos.char.[{ith}:cth]aiin
→ NOIII?  SAOSŌAM  NU?  SAROIŌAM  PAOP  SAROP  SAUR  ITAUII?

`f20v.7`  shocthy.sho.cthy.daiin.sheoy.tey.s<->soaiin
→ PAOSTAM  PAO  STAM  NUII?  PAROM  TRM  PPOUII?

`f20v.8`  shain.choraly.sho.ar.chy.daiin.d.s
→ PAUI?  SAORULM  PAO  UR  SAM  NUII?  N  P

`f20v.9`  ykchy.keody.cho.cthy.chol.shd.qoty.d@244;
→ MŌSAM  ŌRONM  SAO  STAM  SAOL  PAN  COTM  N

`f20v.10`  shokaiin.chocthy.chol.daiin.chy.chor.ety
→ PAOŌUII?  SAOSTAM  SAOL  NUII?  SAM  SAOR  RTM

`f20v.11`  okoiin.chey.{@200;ph}ol.chory
→ OŌOII?  SARM  MAOL  SAORM

### f21r  ·  herbal

`f21r.1`  pchor.o,eeockhy.o.fychey.ypchey.qopcheody.otaiin.chan
→ MSAOR  ORROSŌAM  O  ?MSARM  MMSARM  COMSARONM  OTUII?  SAU?

`f21r.2`  saiin.chcphy.oky,sheaiin.qotchol.oteos.sheey.cthy.daiin
→ PUII?  SASMAM  OŌMPARUII?  COTSAOL  OTROP  PARRM  STAM  NUII?

`f21r.3`  qotol,shy.o.l.cheor.chy.qokchey.chey.keey.dy
→ COTOLPAM  O  L  SAROR  SAM  COŌSARM  SARM  ŌRRM  NM

`f21r.4`  pchofychy.daiin.cthain.o,tolosheey.qocthey.tolchory
→ MSAO?MSAM  NUII?  STAUI?  OTOLOPARRM  COSTARM  TOLSAORM

`f21r.5`  ykeey.daiin.chosy.qokoiin.otol.chol.qotcheol.okeoaiin
→ MŌRRM  NUII?  SAOPM  COŌOII?  OTOL  SAOL  COTSAROL  OŌROUII?

`f21r.6`  dchor.y.kol,y,ky.chol.kol.qokeol.chol,ol.qoteeol.dady
→ NSAOR  M  ŌOLMŌM  SAOL  ŌOL  COŌROL  SAOLOL  COTRROL  NUNM

`f21r.7`  shoeor.cheor.choke[o:a]dy.cho,cthor.shy
→ PAOROR  SAROR  SAOŌRONM  SAOSTAOR  PAM

`f21r.8`  fcho,kshy.otor.sheol.ocphal.opsheas.cthodaiin.oty
→ ?SAOŌPAM  OTOR  PAROL  OSMAUL  OMPARUP  STAONUII?  OTM

`f21r.9`  okaiin.sho.tshaiin.chkaiin.sh,cthey.cthody.cthy.s
→ OŌUII?  PAO  TPAUII?  SAŌUII?  PASTARM  STAONM  STAM  P

`f21r.10`  totchy.keor.chy,ky.qotaiin.qotchol.ty.ctheey.otaiin
→ TOTSAM  ŌROR  SAMŌM  COTUII?  COTSAOL  TM  STARRM  OTUII?

`f21r.11`  shol.chol.shol.tchol.chcthy.otyky.shey.yteol.shody
→ PAOL  SAOL  PAOL  TSAOL  SASTAM  OTMŌM  PARM  MTROL  PAONM

`f21r.12`  ykeey.chor.sheey.ysheol.chor.chol.daiin.chkaiin
→ MŌRRM  SAOR  PARRM  MPAROL  SAOR  SAOL  NUII?  SAŌUII?

### f21v  ·  herbal

`f21v.1`  toldshy.chofchy.qofshey.shckhol.odaiin.shey.ckholy
→ TOLNPAM  SAO?SAM  CO?PARM  PASŌAOL  ONUII?  PARM  SŌAOLM

`f21v.2`  oeeesoy.qokchy.chody.qotchy.qokchy.choty.tchol.daiin
→ ORRRPOM  COŌSAM  SAONM  COTSAM  COŌSAM  SAOTM  TSAOL  NUII?

`f21v.3`  qotol.keeees.chotchy.tcho.choty.chor.qotol.daiin.dal
→ COTOL  ŌRRRRP  SAOTSAM  TSAO  SAOTM  SAOR  COTOL  NUII?  NUL

`f21v.4`  sho.chodaiin.choty.chol.daiin.daiin.chty<->chtol
→ PAO  SAONUII?  SAOTM  SAOL  NUII?  NUII?  SATMSATOL

`f21v.5`  osho.deey.ctho.l.sho,cthy.daiin.dait.oky
→ OPAO  NRRM  STAO  L  PAOSTAM  NUII?  NUIT  OŌM

`f21v.6`  sho.tsho.chotshol.chol.todaiin.daiin
→ PAO  TPAO  SAOTPAOL  SAOL  TONUII?  NUII?

`f21v.7`  ykcho.lchol.cho,l,chaiin.otchy.s.sheaiin
→ MŌSAO  LSAOL  SAOLSAUII?  OTSAM  P  PARUII?

`f21v.8`  cho.l.kchochaiin
→ SAO  L  ŌSAOSAUII?

### f22r  ·  herbal

`f22r.1`  pol.olshy.fcholy.shol.dpchy.oty.okoly.daiin.opchy,s.ocphy
→ MOL  OLPAM  ?SAOLM  PAOL  NMSAM  OTM  OŌOLM  NUII?  OMSAMP  OSMAM

`f22r.2`  ol.oiin.shol.o.kor.qokchol.daiin.okaiin.cthor.dain.ckhy.dom
→ OL  OII?  PAOL  O  ŌOR  COŌSAOL  NUII?  OŌUII?  STAOR  NUI?  SŌAM  NOS

`f22r.3`  qokol.dykaiin.o,kchy.daiin.cthol.ctholo.dar.shain
→ COŌOL  NMŌUII?  OŌSAM  NUII?  STAOL  STAOLO  NUR  PAUI?

`f22r.4`  pchaiin.ofchy.daiin.cfhy.doroiin.ypchol.sy<->schor.daiin
→ MSAUII?  O?SAM  NUII?  S?AM  NOROII?  MMSAOL  PMPSAOR  NUII?

`f22r.5`  ol.daiin.qokchy.dar.daiin.chor.oldor.oky<->y,choldchy
→ OL  NUII?  COŌSAM  NUR  NUII?  SAOR  OLNOR  OŌMMSAOLNSAM

`f22r.6`  y.chokshchy.cth[eeb:een]
→ M  SAOŌPASAM  STARR?

`f22r.7`  kchol.shol.dsheor.{c'@162;@136;}.chdoly.ytaiin.ol<->otchy.cphal
→ ŌSAOL  PAOL  NPAROR  S  SANOLM  MTUII?  OLOTSAM  SMAUL

`f22r.8`  dchor.oty.daiin.ctholy.qoky.chotaiin.chocthy<->do[@203;:l]iin.dchor
→ NSAOR  OTM  NUII?  STAOLM  COŌM  SAOTUII?  SAOSTAMNOII?  NSAOR

`f22r.9`  odaiin.dain.cthy.ctheo,r.o[r:in]aiino
→ ONUII?  NUI?  STAM  STAROR  ORUII?O

`f22r.10`  kchol.chor.daiin.cthoiin.dchor.chey.qokol,dy<->opchol.oldam
→ ŌSAOL  SAOR  NUII?  STAOII?  NSAOR  SARM  COŌOLNMOMSAOL  OLNUS

`f22r.11`  do[iin:iir].yckhody.qokchy.oky.otoldy.yty.dol.or<->d[ch:a]chy.daiin
→ NOII?  MSŌAONM  COŌSAM  OŌM  OTOLNM  MTM  NOL  ORNSASAM  NUII?

`f22r.12`  odchaiin.cthy.okchy.kchy.dchol.daiin<->ydaiin
→ ONSAUII?  STAM  OŌSAM  ŌSAM  NSAOL  NUII?MNUII?

`f22r.13`  dchor.dy,dain.qockhy.ykol,okain
→ NSAOR  NMNUI?  COSŌAM  MŌOLOŌUI?

### f22v  ·  herbal

`f22v.1`  pysaiinor.ofchar.oky.tchy.otdy<->sor.shy.qo'd
→ MMPUII?OR  O?SAUR  OŌM  TSAM  OTNMPOR  PAM  CON

`f22v.2`  daiin.y,kaiin.qotchy.kchy.[o:y]tchyd<->dshor.ychy
→ NUII?  MŌUII?  COTSAM  ŌSAM  OTSAMNNPAOR  MSAM

`f22v.3`  qoky.kchorl.otchy.cthy.otchyky<->ytchol.otam
→ COŌM  ŌSAORL  OTSAM  STAM  OTSAMŌMMTSAOL  OTUS

`f22v.4`  otchaiin.shoty.qoky<->saiin<->odaiin.ytaiin
→ OTSAUII?  PAOTM  COŌMPUII?ONUII?  MTUII?

`f22v.5`  dor.y,kcheor.daiin
→ NOR  MŌSAROR  NUII?

`f22v.6`  fshor.shy,tchor.otaiin
→ ?PAOR  PAMTSAOR  OTUII?

`f22v.7`  ychor.chor.qokchol.chory
→ MSAOR  SAOR  COŌSAOL  SAORM

`f22v.8`  qotchy.cthy.qokol.daiin.dam
→ COTSAM  STAM  COŌOL  NUII?  NUS

`f22v.9`  okshor.shody.chol.tchol.otaiin,daiin
→ OŌPAOR  PAONM  SAOL  TSAOL  OTUII?NUII?

`f22v.10`  qokchy.daiin.s<->or.ytal
→ COŌSAM  NUII?  POR  MTUL

`f22v.11`  sokaiin.oty.dy
→ POŌUII?  OTM  NM

`f22v.12`  ychky.daiin.cthy
→ MSAŌM  NUII?  STAM

`f22v.13`  okchain.chkoldy.shotoly
→ OŌSAUI?  SAŌOLNM  PAOTOLM

`f22v.14`  qotch[y:?].olshly.shol.daiin
→ COTSAM  OLPALM  PAOL  NUII?

`f22v.15`  sho.cthy.chocthy.qokchy.dory
→ PAO  STAM  SAOSTAM  COŌSAM  NORM

`f22v.16`  saiinchy.daldalol
→ PUII?SAM  NULNULOL

### f23r  ·  herbal

`f23r.1`  pydchdom.chy.fcholdy.oty.otchol,shy.opyaiin.y',yfchy.daiin.ololdy.dal
→ MMNSANOS  SAM  ?SAOLNM  OTM  OTSAOLPAM  OMMUII?  MM?SAM  NUII?  OLOLNM  NUL

`f23r.2`  to.ar.chor.daiin.chk,dain.otchy.lolchor.daiin.dam.okchol.dain,g
→ TO  UR  SAOR  NUII?  SAŌNUI?  OTSAM  LOLSAOR  NUII?  NUS  OŌSAOL  NUI??

`f23r.3`  dchar.ykor.y,kaiin.daiin.cth[?:o].g
→ NSAUR  MŌOR  MŌUII?  NUII?  STA  ?

`f23r.4`  qokoldy.okaiir.ykaiil,g.qokeey.ofchol.dain.yfchor.olfchor.otchald
→ COŌOLNM  OŌUIIR  MŌUIIL?  COŌRRM  O?SAOL  NUI?  M?SAOR  OL?SAOR  OTSAULN

`f23r.5`  ychor.qokchol.ytym.chol.da[ir:in].chol.ar.ol.ol.dol.dain
→ MSAOR  COŌSAOL  MTMS  SAOL  NUIR  SAOL  UR  OL  OL  NOL  NUI?

`f23r.6`  tshol.y,kor.qokaiin.yky.dar.okol.dchey.daiidal.dam.ytcho.ldals
→ TPAOL  MŌOR  COŌUII?  MŌM  NUR  OŌOL  NSARM  NUIINUL  NUS  MTSAO  LNULP

`f23r.7`  okar.olchar.shaiin.qokchol.dar.qokchol.dairo.r.ol.daiin.alg
→ OŌUR  OLSAUR  PAUII?  COŌSAOL  NUR  COŌSAOL  NUIRO  R  OL  NUII?  UL?

`f23r.8`  qokshy.char.daiir.qokaiin.olol.qoaiin.ykchy.s<->dal.okchy
→ COŌPAM  SAUR  NUIIR  COŌUII?  OLOL  COUII?  MŌSAM  PNUL  OŌSAM

`f23r.9`  okol,ok,shy.qokol,dy<->dal.[d:j]she.qokeees.y.oly<->daiin.dal
→ OŌOLOŌPAM  COŌOLNMNUL  NPAR  COŌRRRP  M  OLMNUII?  NUL

`f23r.10`  q[o:y]k.okaiin.chkchy,s<->yteain.odal.chal,dy<->dar.ykain
→ COŌ  OŌUII?  SAŌSAMPMTRUI?  ONUL  SAULNMNUR  MŌUI?

`f23r.11`  ykyk[a:o].dalory
→ MŌMŌU  NULORM

### f23v  ·  herbal

`f23v.1`  podairol.odaiiily.sho,al,dy.opchol.otol.ol.chcphy.qotchar.s
→ MONUIROL  ONUIIILM  PAOULNM  OMSAOL  OTOL  OL  SASMAM  COTSAUR  P

`f23v.2`  qot{co}tor.chy.okchaldy.qokchey.dol<->otchol.chal.otchg
→ COTSOTOR  SAM  OŌSAULNM  COŌSARM  NOLOTSAOL  SAUL  OTSA?

`f23v.3`  ycho.okaiin.okeol.eees.o,l.daiin.okeeor<->daiin.qotcholg
→ MSAO  OŌUII?  OŌROL  RRRP  OL  NUII?  OŌRRORNUII?  COTSAOL?

`f23v.4`  okchey.dair.sholol.ol,dal<->otchor,[d:g]ar
→ OŌSARM  NUIR  PAOLOL  OLNULOTSAORNUR

`f23v.5`  dor,chear.shor.dol.oaldary
→ NORSARUR  PAOR  NOL  OULNURM

`f23v.6`  tshol.shor.shkshy.okol.daiin<->otshor.olsar
→ TPAOL  PAOR  PAŌPAM  OŌOL  NUII?OTPAOR  OLPUR

`f23v.7`  otor.oiin.sho.shol.qokol.daiin<->sol.daiin.ylg
→ OTOR  OII?  PAO  PAOL  COŌOL  NUII?POL  NUII?  ML?

`f23v.8`  qokaiin.dain.qokor.okal,g.dam<->chor.olol.dam
→ COŌUII?  NUI?  COŌOR  OŌUL?  NUSSAOR  OLOL  NUS

`f23v.9`  otshy.dal.dar.oldar.ar.or<->qoto.l,chees.g
→ OTPAM  NUL  NUR  OLNUR  UR  ORCOTO  LSARRP  ?

`f23v.10`  dor.chy.kshol.chol.ctho[?:l]<->otol.oloiir
→ NOR  SAM  ŌPAOL  SAOL  STAOOTOL  OLOIIR

`f23v.11`  y,okaiin.doroiin.olols.oiin<->ol.cheeb.ols
→ MOŌUII?  NOROII?  OLOLP  OII?OL  SARR?  OLP

`f23v.12`  ol,aiios.oloro.eeeoly
→ OLUIIOP  OLORO  RRROLM

### f24r  ·  herbal

`f24r.1`  por,or,y.chor.opchar.she.cheol.daiin.or
→ MORORM  SAOR  OMSAUR  PAR  SAROL  NUII?  OR

`f24r.2`  qotaiin.char.odaiin.okai{ikh}al.oky
→ COTUII?  SAUR  ONUII?  OŌUIIŌAUL  OŌM

`f24r.3`  ycthar.cthal.okol.qotar.ckhy
→ MSTAUR  STAUL  OŌOL  COTUR  SŌAM

`f24r.4`  or.chckhaly.cthar.eeor.chees.da
→ OR  SASŌAULM  STAUR  RROR  SARRP  NU

`f24r.5`  qodar.cho.r.chey.cthy.cthe.keom
→ CONUR  SAO  R  SARM  STAM  STAR  ŌROS

`f24r.6`  oeeeos.cthor.otal.qocthol.qoky
→ ORRROP  STAOR  OTUL  COSTAOL  COŌM

`f24r.7`  q@145;kar.chtar.s.cheor.cthol.qodol
→ CŌUR  SATUR  P  SAROR  STAOL  CONOL

`f24r.8`  ychor.s.om.qoear.daiin.qokeol
→ MSAOR  P  OS  CORUR  NUII?  COŌROL

`f24r.9`  odaiin.ckham.qodai{ikh}y.dol.dal
→ ONUII?  SŌAUS  CONUIIŌAM  NOL  NUL

`f24r.10`  q[?:e]or.cfhar.chor.s.am.chotaiin.dy
→ COR  S?AUR  SAOR  P  US  SAOTUII?  NM

`f24r.11`  sar.cheoiees.okeem.cheor.qokain
→ PUR  SAROIRRP  OŌRRS  SAROR  COŌUI?

`f24r.12`  qokchy.qotchy.tol.tod.ckhy
→ COŌSAM  COTSAM  TOL  TON  SŌAM

`f24r.13`  oees.ol.s.chey.chcth.s,ar
→ ORRP  OL  P  SARM  SASTA  PUR

`f24r.14`  qor.cheey.qod.char.cthal
→ COR  SARRM  CON  SAUR  STAUL

`f24r.15`  ockhoees.oeees.ol.dal.s
→ OSŌAORRP  ORRRP  OL  NUL  P

`f24r.16`  sham.okeal.dal.dam.dal
→ PAUS  OŌRUL  NUL  NUS  NUL

`f24r.17`  sshey.otam.sham.cthoj.oky
→ PPARM  OTUS  PAUS  STAO?  OŌM

`f24r.18`  ycheol.chol.daiin.chol.s
→ MSAROL  SAOL  NUII?  SAOL  P

`f24r.19`  yol.kol.chol.shom.otacphy
→ MOL  ŌOL  SAOL  PAOS  OTUSMAM

`f24r.20`  sam.chorly
→ PUS  SAORLM

### f24v  ·  herbal

`f24v.1`  tchodar.chocfhey.opom.shod.chcphy.opshody.ocphoraiin.o,k,o@146;am
→ TSAONUR  SAOS?ARM  OMOS  PAON  SASMAM  OMPAONM  OSMAORUII?  OŌOUS

`f24v.2`  ydals.ckhor.shy.cho.dch[o:a]r.otol.otaiir<->otchos.okchom.okcho
→ MNULP  SŌAOR  PAM  SAO  NSAOR  OTOL  OTUIIROTSAOP  OŌSAOS  OŌSAO

`f24v.3`  octh[y:o]l.odchees.oesearies.okam.chcth
→ OSTAML  ONSARRP  ORPRURIRP  OŌUS  SASTA

`f24v.4`  ydal.sh.okol.okaiin.odaiin.dlos
→ MNUL  PA  OŌOL  OŌUII?  ONUII?  NLOP

`f24v.5`  oeor.oraiin.tchar.oro
→ OROR  ORUII?  TSAUR  ORO

`f24v.6`  tochol.chor.{cf}arsa,r
→ TOSAOL  SAOR  S?URPUR

`f24v.7`  ycheol.daid.dar.olom
→ MSAROL  NUIN  NUR  OLOS

`f24v.8`  kochky.chcthy.shol.sain
→ ŌOSAŌM  SASTAM  PAOL  PUI?

`f24v.9`  ychol.chol.or.chor.om
→ MSAOL  SAOL  OR  SAOR  OS

`f24v.10`  okoeor.ctheod.choy.keol
→ OŌOROR  STARON  SAOM  ŌROL

`f24v.11`  ydaiin.chear.qodom.okodaiin
→ MNUII?  SARUR  CONOS  OŌONUII?

`f24v.12`  ksho.foar.{ct}o.sho.qok[ch:ee].ok.okchal
→ ŌPAO  ?OUR  STO  PAO  COŌSA  OŌ  OŌSAUL

`f24v.13`  oeeey.cheol.chol.odor.sho.do.otolodal
→ ORRRM  SAROL  SAOL  ONOR  PAO  NO  OTOLONUL

`f24v.14`  do[iir:ar].cheeodam.sho.sho.dy
→ NOIIR  SARRONUS  PAO  PAO  NM

`f24v.15`  dchey.kchod.dch[a:o]l.ochdy
→ NSARM  ŌSAON  NSAUL  OSANM

`f24v.16`  otchol.odaiim
→ OTSAOL  ONUIIS

### f25r  ·  herbal

`f25r.1`  fcholdy.soshy.daiin.{ck}y.shody.daiin,ocholdy.cpholdy.sy
→ ?SAOLNM  POPAM  NUII?  SŌM  PAONM  NUII?OSAOLNM  SMAOLNM  PM

`f25r.2`  otor.chor.chsky.chotchy.shair.qod.sh[a:o]chy.kchy.chkain
→ OTOR  SAOR  SAPŌM  SAOTSAM  PAUIR  CON  PAUSAM  ŌSAM  SAŌUI?

`f25r.3`  qotchy.qotshy.cheesees.sheear.s.chain.daiin.chain.dan
→ COTSAM  COTPAM  SARRPRRP  PARRUR  P  SAUI?  NUII?  SAUI?  NU?

`f25r.4`  dchckhy.shocthy.ytchey.cthor.s.chan.chaiin.qotchain
→ NSASŌAM  PAOSTAM  MTSARM  STAOR  P  SAU?  SAUII?  COTSAUI?

`f25r.5`  qotcheaiin.dchain.cthain.daiin.daiin.cthain.qotaiin
→ COTSARUII?  NSAUI?  STAUI?  NUII?  NUII?  STAUI?  COTUII?

`f25r.6`  okal.chotaiin
→ OŌUL  SAOTUII?

`f25r.7`  dair.otaiir.otosy
→ NUIR  OTUIIR  OTOPM

### f25v  ·  herbal

`f25v.1`  poeeaiin.qo,ky.shy.daiin.qopchey.otchey.qofchor,sos
→ MORRUII?  COŌM  PAM  NUII?  COMSARM  OTSARM  CO?SAORPOP

`f25v.2`  dchor.cthor.chor.daiin.s.okeeaiin.daiin.ckhey.daiin
→ NSAOR  STAOR  SAOR  NUII?  P  OŌRRUII?  NUII?  SŌARM  NUII?

`f25v.3`  orcho.kchor.chol.daiin.sh[cfh:ckh]o,r,daiin.dshey.daiity
→ ORSAO  ŌSAOR  SAOL  NUII?  PAS?AORNUII?  NPARM  NUIITM

`f25v.4`  qokaiin.qokcho.shol.daiin.ckhear.ckhol.daiin.chkear
→ COŌUII?  COŌSAO  PAOL  NUII?  SŌARUR  SŌAOL  NUII?  SAŌRUR

`f25v.5`  dar.chokeey.dshor.dshey.qochol.dol.cho.daiin.daiin
→ NUR  SAOŌRRM  NPAOR  NPARM  COSAOL  NOL  SAO  NUII?  NUII?

`f25v.6`  qokcho,r,ochy.qotchy.qotoral<->cho.@147;.chain.deeaiir.s
→ COŌSAOROSAM  COTSAM  COTORULSAO  —  SAUI?  NRRUIIR  P

`f25v.7`  o{c'o}.chkey.daiiol.daiin.shckh<->orchaiin
→ OSO  SAŌRM  NUIIOL  NUII?  PASŌAORSAUII?

### f26r  ·  herbal

`f26r.1`  psheoky.odaiir.qoy<->ofshod.chypchey.ypchedy.ain<->chofo,che{ph}dy
→ MPAROŌM  ONUIIR  COMO?PAON  SAMMSARM  MMSARNM  UI?SAO?OSARMANM

`f26r.2`  dchey.@138;aiin.adeeody<->ykecthey.chedy.ytedy.dy<->checthedy.ls
→ NSARM  UII?  UNRRONMMŌRSTARM  SARNM  MTRNM  NMSARSTARNM  LP

`f26r.3`  oaiin.shcthy.cthedy.oloy<->ykeedy.olchedy.dal<->y.sheey.s,aiin.s
→ OUII?  PASTAM  STARNM  OLOMMŌRRNM  OLSARNM  NULM  PARRM  PUII?  P

`f26r.4`  qokedy.cheos.ytedy.qokedy<->ytedy.chekedy<->daiin.odam.s,aldy
→ COŌRNM  SAROP  MTRNM  COŌRNMMTRNM  SARŌRNMNUII?  ONUS  PULNM

`f26r.5`  saiin.shedy.eedy.eedy.s,chy<->daiin.cthedy<->qokeedy.qokedy.cthey
→ PUII?  PARNM  RRNM  RRNM  PSAMNUII?  STARNMCOŌRRNM  COŌRNM  STARM

`f26r.6`  rchedy.qokedy
→ RSARNM  COŌRNM

`f26r.7`  pcho.qokedy.dar,sheo.ypchseds.s<->aiin<->sha,p,chedyfchy.dalchedy.sar
→ MSAO  COŌRNM  NURPARO  MMSAPRNP  PUII?PAUMSARNM?SAM  NULSARNM  PUR

`f26r.8`  daiin.shedy.qokeedy.qoteedar.s<->ok<->ol<->ytedy.qokeedy.qokedy
→ NUII?  PARNM  COŌRRNM  COTRRNUR  POŌOLMTRNM  COŌRRNM  COŌRNM

`f26r.9`  tcheoshy.dchdy.okedy.chckhy.s<->dy<->dy<->ykeechy.okeedy.cheky
→ TSAROPAM  NSANM  OŌRNM  SASŌAM  PNMNMMŌRRSAM  OŌRRNM  SARŌM

`f26r.10`  shese.aiin.sheos.cheody<->otal
→ PARPR  UII?  PAROP  SARONMOTUL

### f26v  ·  herbal

`f26v.1`  pchedar.qodary.daiiin.pcheety.s,air.shedy.ypchedy.ypchdy.qopy.shdy
→ MSARNUR  CONURM  NUIII?  MSARRTM  PUIR  PARNM  MMSARNM  MMSANM  COMM  PANM

`f26v.2`  saraiir.chekedy.qokedy.otedy.sar,y,etedy.qokedy.or.a{i'h}e.alys.chedy
→ PURUIIR  SARŌRNM  COŌRNM  OTRNM  PURMRTRNM  COŌRNM  OR  UIAR  ULMP  SARNM

`f26v.3`  pchdar.opar.dar.cheeol.ofchdy.otedy.{c@176;h}dy.odar.chedy.ytedy.okchdy.g
→ MSANUR  OMUR  NUR  SARROL  O?SANM  OTRNM  SANM  ONUR  SARNM  MTRNM  OŌSANM  ?

`f26v.4`  y[ckhe:{ck}ee]ody.qokedy.deey.saldy.okedor.or.cheos.oraiin.okeo.chekaiin
→ MSŌARONM  COŌRNM  NRRM  PULNM  OŌRNOR  OR  SAROP  ORUII?  OŌRO  SARŌUII?

`f26v.5`  deeol.cheody.qoteedy.qokody.qotedy.qotedy.opchedy.ofchy.chs.ar
→ NRROL  SARONM  COTRRNM  COŌONM  COTRNM  COTRNM  OMSARNM  O?SAM  SAP  UR

`f26v.6`  toeedy.keody.shedy.dar.chedy.sches.or,cheeky.dar.chey.cheky.yteedy
→ TORRNM  ŌRONM  PARNM  NUR  SARNM  PSARP  ORSARRŌM  NUR  SARM  SARŌM  MTRRNM

`f26v.7`  pchedy.dar.cheoet.chy.sair.chees.odaiiin.chkeeey.ykey.sheey
→ MSARNM  NUR  SARORT  SAM  PUIR  SARRP  ONUIII?  SAŌRRRM  MŌRM  PARRM

`f26v.8`  tchedy.okeeos.cheeos.ysaiin.okcheey.keody.s,aiin.cheeos.qokes.ory
→ TSARNM  OŌRROP  SARROP  MPUII?  OŌSARRM  ŌRONM  PUII?  SARROP  COŌRP  ORM

`f26v.9`  ysheey.okeshy.shody.peshy.todydy
→ MPARRM  OŌRPAM  PAONM  MRPAM  TONMNM

### f27r  ·  herbal

`f27r.1`  ksor.shey.shoteo.chforaiin.shy<->shod.chary
→ ŌPOR  PARM  PAOTRO  SA?ORUII?  PAMPAON  SAURM

`f27r.2`  dy.{co}ain.shol.dain.dar.shokyd<->dchol.cthey,ds
→ NM  SOUI?  PAOL  NUI?  NUR  PAOŌMNNSAOL  STARMNP

`f27r.3`  chol.shy.keol.chol.chy.shol.chy<->daiin.chey.dam
→ SAOL  PAM  ŌROL  SAOL  SAM  PAOL  SAMNUII?  SARM  NUS

`f27r.4`  qokey.chor.char.chy.dchy.keey<->chos.cthody
→ COŌRM  SAOR  SAUR  SAM  NSAM  ŌRRMSAOP  STAONM

`f27r.5`  dor.chees.ctho,shy.{c@148;h}ar,y<->daiin.dair
→ NOR  SARRP  STAOPAM  SAURMNUII?  NUIR

`f27r.6`  chy.t,chols.chor.chol{oh}aiin<->shy.kchal,dy
→ SAM  TSAOLP  SAOR  SAOLOAUII?PAM  ŌSAULNM

`f27r.7`  kchey.chey.kcheol.pch[o:y].schey.ly<->chals.cham
→ ŌSARM  SARM  ŌSAROL  MSAO  PSARM  LMSAULP  SAUS

`f27r.8`  ytchy.chy.t,chol.dy.t,chey.dain<->chol.dal
→ MTSAM  SAM  TSAOL  NM  TSARM  NUI?SAOL  NUL

`f27r.9`  dchey.keeod.shotchey.chol.oty<->chy,tolg
→ NSARM  ŌRRON  PAOTSARM  SAOL  OTMSAMTOL?

`f27r.10`  qotchey.shes.s.y.chy.tchey.dy
→ COTSARM  PARP  P  M  SAM  TSARM  NM

`f27r.11`  chol.daiiin.chees.chos.{ct}ey.dan
→ SAOL  NUIII?  SARRP  SAOP  STRM  NU?

`f27r.12`  dain.cheokeey.chey.cthey.otal
→ NUI?  SAROŌRRM  SARM  STARM  OTUL

`f27r.13`  o[t:k]chodeey
→ OTSAONRRM

### f27v  ·  herbal

`f27v.1`  pochof.chof.cho.sho.soly.shol.ytchar.opchory.kchor,chor
→ MOSAO?  SAO?  SAO  PAO  POLM  PAOL  MTSAUR  OMSAORM  ŌSAORSAOR

`f27v.2`  dchy.chkar.otchy.shy.shy.dchy.dshy.kchy.cheo.daidy.dchy
→ NSAM  SAŌUR  OTSAM  PAM  PAM  NSAM  NPAM  ŌSAM  SARO  NUINM  NSAM

`f27v.3`  kchey.kchy.dchokchy.dsho.d{ca}r.chodchy.etcheody.shld
→ ŌSARM  ŌSAM  NSAOŌSAM  NPAO  NSUR  SAONSAM  RTSARONM  PALN

`f27v.4`  okcho.chy.kch[ee:o]d.chl.chol.kod<->o.oksho.do,cheesg
→ OŌSAO  SAM  ŌSARRN  SAL  SAOL  ŌONO  OŌPAO  NOSARRP?

`f27v.5`  qoky.sh,keeo.[s:r]cho,dar.shkol<->chotchy.ctho,dol
→ COŌM  PAŌRRO  PSAONUR  PAŌOLSAOTSAM  STAONOL

`f27v.6`  dsho.kchrrr.okeedy<->dch[s:r]chy<->sotchdy
→ NPAO  ŌSARRR  OŌRRNMNSAPSAMPOTSANM

`f27v.7`  sho.shoykcho.shdy<->dchd<->chschsy<->otchdy
→ PAO  PAOMŌSAO  PANMNSANSAPSAPMOTSANM

`f27v.8`  okshes.okchokshy
→ OŌPARP  OŌSAOŌPAM

### f28r  ·  herbal

`f28r.1`  pchodar.shod.chocphy.opchol.daiin<->otchol.chy.qo,ldy
→ MSAONUR  PAON  SAOSMAM  OMSAOL  NUII?OTSAOL  SAM  COLNM

`f28r.2`  otchor.otchor.cthol.{ct}y.ctheol.dy<->dchar.chakod.dly
→ OTSAOR  OTSAOR  STAOL  STM  STAROL  NMNSAUR  SAUŌON  NLM

`f28r.3`  qotchaiin.shor.cthol.cthol.shor<->chotchy.tchodar
→ COTSAUII?  PAOR  STAOL  STAOL  PAORSAOTSAM  TSAONUR

`f28r.4`  choty.chtol.otol.chotchy.cthol<->otol.choky.qoty
→ SAOTM  SATOL  OTOL  SAOTSAM  STAOLOTOL  SAOŌM  COTM

`f28r.5`  oksho.otorchy.kchoror.chodaiin<->sho,cthody.okoy
→ OŌPAO  OTORSAM  ŌSAOROR  SAONUII?PAOSTAONM  OŌOM

`f28r.6`  qokchol.qodaiin.otcholchy.daiin<->cho.qokol.o,kam
→ COŌSAOL  CONUII?  OTSAOLSAM  NUII?SAO  COŌOL  OŌUS

`f28r.7`  sho.otor.shockhy.shocthy.otoldy<->dshor.dol.dar
→ PAO  OTOR  PAOSŌAM  PAOSTAM  OTOLNMNPAOR  NOL  NUR

`f28r.8`  oschotshl.daiin.okchey.kol.daiin<->shol.dsho.otaiin
→ OPSAOTPAL  NUII?  OŌSARM  ŌOL  NUII?PAOL  NPAO  OTUII?

`f28r.9`  ytchol.deey.yteol.deaiin
→ MTSAOL  NRRM  MTROL  NRUII?

### f28v  ·  herbal

`f28v.1`  kshol.qooiiin.shor.pshoiiin.shepchy.qoty.dy.shory
→ ŌPAOL  COOIII?  PAOR  MPAOIII?  PARMSAM  COTM  NM  PAORM

`f28v.2`  ykcholy.qoty.chy,dy.qokchol.chor.tchy.qokchody.cheor.o
→ MŌSAOLM  COTM  SAMNM  COŌSAOL  SAOR  TSAM  COŌSAONM  SAROR  O

`f28v.3`  chor.chol.chy.choiin
→ SAOR  SAOL  SAM  SAOII?

`f28v.4`  tshoiin.cheor.chor.o.chty.qotol.sheol.shor.daiin.qoty
→ TPAOII?  SAROR  SAOR  O  SATM  COTOL  PAROL  PAOR  NUII?  COTM

`f28v.5`  otol.chol.daiin.chkaiin.shoiin.qotchey.qotshey.daiiin
→ OTOL  SAOL  NUII?  SAŌUII?  PAOII?  COTSARM  COTPARM  NUIII?

`f28v.6`  daiin.chkaiin
→ NUII?  SAŌUII?

`f28v.7`  pchol.oiir.chol.tsho.daiin.sho<->t{co}<->chy.chtshy.dair,am
→ MSAOL  OIIR  SAOL  TPAO  NUII?  PAOTSOSAM  SATPAM  NUIRUS

`f28v.8`  okain.chan.chain.cthor.dain<->yk<->chy<->daiin.cthol
→ OŌUI?  SAU?  SAUI?  STAOR  NUI?MŌSAMNUII?  STAOL

`f28v.9`  sor.chear.chl.[{c'}:s].choly.dar
→ POR  SARUR  SAL  S  SAOLM  NUR

### f29r  ·  herbal

`f29r.1`  posaiin.she.aiin.chep,oty.chy.qotchy.qoty.cheecthy
→ MOPUII?  PAR  UII?  SARMOTM  SAM  COTSAM  COTM  SARRSTAM

`f29r.2`  dshe.ykchy.choty.oky.cho,l.chchoty.choky.chy,ty,dy
→ NPAR  MŌSAM  SAOTM  OŌM  SAOL  SASAOTM  SAOŌM  SAMTMNM

`f29r.3`  qokchy.qoty.kchaiin.shear.cthor<->dchor.choly
→ COŌSAM  COTM  ŌSAUII?  PARUR  STAORNSAOR  SAOLM

`f29r.4`  chocthy.qoos.chos
→ SAOSTAM  COOP  SAOP

`f29r.5`  kcheol.cheor.sheos.sheey.teey.d[a:y]<->shos.o{cty}
→ ŌSAROL  SAROR  PAROP  PARRM  TRRM  NUPAOP  OSTM

`f29r.6`  chokshy.shocthy.shor.shor.daiin<->qokaiiin
→ SAOŌPAM  PAOSTAM  PAOR  PAOR  NUII?COŌUIII?

`f29r.7`  qokchy.chol.shokchy.qokaiin.choety<->choty.kaiin
→ COŌSAM  SAOL  PAOŌSAM  COŌUII?  SAORTMSAOTM  ŌUII?

`f29r.8`  shor.chor.shosheky.shy.qoty,kody<->daiin.cthy
→ PAOR  SAOR  PAOPARŌM  PAM  COTMŌONMNUII?  STAM

`f29r.9`  qokshe.qor.chey.kor.cheod.ychom
→ COŌPAR  COR  SARM  ŌOR  SARON  MSAOS

### f29v  ·  herbal

`f29v.1`  kooiin.shor.chetchy.ol,ls.shytchy.cthy,shy<->cho.shy.daiin
→ ŌOOII?  PAOR  SARTSAM  OLLP  PAMTSAM  STAMPAMSAO  PAM  NUII?

`f29v.2`  qotcheaiin.s.chol.chol.cthy.chey.cthold<->ytchor.dary
→ COTSARUII?  P  SAOL  SAOL  STAM  SARM  STAOLNMTSAOR  NURM

`f29v.3`  chol.chol.kor.shey.odaiin.qotchy.taiin<->s.she.otey.sy
→ SAOL  SAOL  ŌOR  PARM  ONUII?  COTSAM  TUII?P  PAR  OTRM  PM

`f29v.4`  ysho.otshy.okaiin.cthy.oltchy.{cto}s<->shot.sho.okaiin
→ MPAO  OTPAM  OŌUII?  STAM  OLTSAM  STOPPAOT  PAO  OŌUII?

`f29v.5`  tochon.chain.shan.shoty<->chshy<->shy
→ TOSAO?  SAUI?  PAU?  PAOTMSAPAMPAM

`f29v.6`  dchor.chol.chaiin.shaiin.cthod<->dar<->chs<->shody
→ NSAOR  SAOL  SAUII?  PAUII?  STAONNURSAPPAONM

`f29v.7`  qotcho.kchor.daiin.ykaiin.dy<->shdy<->chocthy.sheky
→ COTSAO  ŌSAOR  NUII?  MŌUII?  NMPANMSAOSTAM  PARŌM

`f29v.8`  otol.shotchor.cholody.dain<->ch[{cti}:cth]<->chy.cthody.dol
→ OTOL  PAOTSAOR  SAOLONM  NUI?SASTISAM  STAONM  NOL

`f29v.9`  sho.chokor.chor.chy.ydaiin.cho<->ykeeb<->oaiin
→ PAO  SAOŌOR  SAOR  SAM  MNUII?  SAOMŌRR?OUII?

`f29v.10`  qokoiin.okaiin.cho<->[{cti}:cth]<->chyd<->chykar
→ COŌOII?  OŌUII?  SAOSTISAMNSAMŌUR

`f29v.11`  daiin.chteo[r:s].octhy<->dar<->chyt<->otody
→ NUII?  SATROR  OSTAMNURSAMTOTONM

`f29v.12`  qekeochor.otchey.s,y
→ CRŌROSAOR  OTSARM  PM

### f30r  ·  herbal

`f30r.1`  okeeesy.chey.shorchey.fcheody.shey.tchy.che[s:r].d.o.shey
→ OŌRRRPM  SARM  PAORSARM  ?SARONM  PARM  TSAM  SARP  N  O  PARM

`f30r.2`  ychody.chey.chkeey.ksho.keeor.cheor.shey.she.keeodol.sy
→ MSAONM  SARM  SAŌRRM  ŌPAO  ŌRROR  SAROR  PARM  PAR  ŌRRONOL  PM

`f30r.3`  chodaiin.cho,ry.chey.doiin.sain.chorain.cheey,keem
→ SAONUII?  SAORM  SARM  NOII?  PUI?  SAORUI?  SARRMŌRRS

`f30r.4`  qokechy.qoko.qop.char.soin.chan.qot,chaiin
→ COŌRSAM  COŌO  COM  SAUR  POI?  SAU?  COTSAUII?

`f30r.5`  choko.qokochy.deeey.dkeeor.cheoldain.chory
→ SAOŌO  COŌOSAM  NRRRM  NŌRROR  SAROLNUI?  SAORM

`f30r.6`  dchorol.sho.chor.cho,ro.raiin.dor.chseeor.dy
→ NSAOROL  PAO  SAOR  SAORO  RUII?  NOR  SAPRROR  NM

`f30r.7`  qor.chain.cthorchy
→ COR  SAUI?  STAORSAM

`f30r.8`  opchol,ol.chesey.scheo,r,chey.okeal<->dcheo,rchey
→ OMSAOLOL  SARPRM  PSARORSARM  OŌRULNSARORSARM

`f30r.9`  dchey.qochar.chol.keeaiin.chcthey<->chor.cheky
→ NSARM  COSAUR  SAOL  ŌRRUII?  SASTARMSAOR  SARŌM

`f30r.10`  chokchaiin.dchor.chkchean.qotchy<->chctho.rchody
→ SAOŌSAUII?  NSAOR  SAŌSARU?  COTSAMSASTAO  RSAONM

`f30r.11`  qotchor.cheor.chey.cheor.chey.so[eeb:een]<->ydey<->sor.daiin
→ COTSAOR  SAROR  SARM  SAROR  SARM  PORR?MNRMPOR  NUII?

`f30r.12`  dcheey.ckhey.ckhey.daiin.chkeaiin.dar<->chor<->ychdain
→ NSARRM  SŌARM  SŌARM  NUII?  SAŌRUII?  NURSAORMSANUI?

`f30r.13`  chodaiin.chtchey.chear.shy,keey
→ SAONUII?  SATSARM  SARUR  PAMŌRRM

### f30v  ·  herbal

`f30v.1`  {c@132;h}s{c@133;h}ain.shosaiin.chocthey.sho.chepchy.shor.sheaiin
→ SAPSAUI?  PAOPUII?  SAOSTARM  PAO  SARMSAM  PAOR  PARUII?

`f30v.2`  qotchor.chy.she.kchor.chory.keor,ol.chy.daiin.ctholdy
→ COTSAOR  SAM  PAR  ŌSAOR  SAORM  ŌROROL  SAM  NUII?  STAOLNM

`f30v.3`  chotchol.daiin.cthol.doiin.daiin.chokeor.dal.chto[{ith}:cth]y
→ SAOTSAOL  NUII?  STAOL  NOII?  NUII?  SAOŌROR  NUL  SATOITAM

`f30v.4`  otchey.daiin.chor.checkhy.qotchod.daiin
→ OTSARM  NUII?  SAOR  SARSŌAM  COTSAON  NUII?

`f30v.5`  dain.choty.chkol.ytor.cheoldy
→ NUI?  SAOTM  SAŌOL  MTOR  SAROLNM

`f30v.6`  qokeeor.chokol.chokeody.dair,y
→ COŌRROR  SAOŌOL  SAOŌRONM  NUIRM

`f30v.7`  ch[a:o]kchy.sho,kcho,tcho.ctho.sos
→ SAUŌSAM  PAOŌSAOTSAO  STAO  POP

`f30v.8`  oyshy.cheotol.cphoaiin.cphey
→ OMPAM  SAROTOL  SMAOUII?  SMARM

`f30v.9`  qotchor.chor.sheey.cheolsos
→ COTSAOR  SAOR  PARRM  SAROLPOP

`f30v.10`  sho.sheoldy.otcheor.daiin
→ PAO  PAROLNM  OTSAROR  NUII?

`f30v.11`  sol.chokcheey.daiin.kchydy
→ POL  SAOŌSARRM  NUII?  ŌSAMNM

### f31r  ·  herbal

`f31r.1`  keedey.qofchedy.shee,s.aiin.qokee@149;.chepakeo
→ ŌRRNRM  CO?SARNM  PARRP  UII?  COŌRR  SARMUŌRO

`f31r.2`  dcheey.daiin.okeedy.qokees.s.aiin.shekeey.qef
→ NSARRM  NUII?  OŌRRNM  COŌRRP  P  UII?  PARŌRRM  CR?

`f31r.3`  qokeey.chey.daiin.qokeey.[s:r]air.chekey.s,aiin.da?
→ COŌRRM  SARM  NUII?  COŌRRM  PUIR  SARŌRM  PUII?  NU

`f31r.4`  qotar.chy.dar.lo,r,ar.cheey.keeol,chedy.qokey
→ COTUR  SAM  NUR  LORUR  SARRM  ŌRROLSARNM  COŌRM

`f31r.5`  daiin.sheeody.qokeor
→ NUII?  PARRONM  COŌROR

`f31r.6`  tshokeody.qokedy.qotedy.chep[o:a]s.cheda,[s:r].aiin.dal
→ TPAOŌRONM  COŌRNM  COTRNM  SARMOP  SARNUP  UII?  NUL

`f31r.7`  ykeedar.saiin.checkhey.sheol.qokedy.ykeedy.chedy.ldy
→ MŌRRNUR  PUII?  SARSŌARM  PAROL  COŌRNM  MŌRRNM  SARNM  LNM

`f31r.8`  shedy.qokedy.cheol.cheod.qokeody.cheol.checthy
→ PARNM  COŌRNM  SAROL  SARON  COŌRONM  SAROL  SARSTAM

`f31r.9`  daiir.sheeo.shcthey.okeol
→ NUIIR  PARRO  PASTARM  OŌROL

`f31r.10`  tol,shso.okedy.okedy.qokedy.qokeedy.dar.shedshey
→ TOLPAPO  OŌRNM  OŌRNM  COŌRNM  COŌRRNM  NUR  PARNPARM

`f31r.11`  olsheol.qokchy.dal,chey.deey.kchy.keey.okaiiin.ykeey
→ OLPAROL  COŌSAM  NULSARM  NRRM  ŌSAM  ŌRRM  OŌUIII?  MŌRRM

`f31r.12`  qoaiin.yches.okedy.sheey.chedaiin.dar
→ COUII?  MSARP  OŌRNM  PARRM  SARNUII?  NUR

`f31r.13`  olsheor.qoekedy.otedy.ykedy.dals
→ OLPAROR  CORŌRNM  OTRNM  MŌRNM  NULP

`f31r.14`  saii[s:r].or.chedy.daiin.okeedy
→ PUIIP  OR  SARNM  NUII?  OŌRRNM

`f31r.15`  yshedair.sheol,cheky.okedam
→ MPARNUIR  PAROLSARŌM  OŌRNUS

`f31r.16`  oteor.aiicthy
→ OTROR  UIISTAM

### f31v  ·  herbal

`f31v.1`  podair.sheedy.otedy.oteedy.qotolcheo.s.ar,ar.oteey.dk[ch:a]rar.als
→ MONUIR  PARRNM  OTRNM  OTRRNM  COTOLSARO  P  URUR  OTRRM  NŌSARUR  ULP

`f31v.2`  ytchos.[o:a]ckhey.okeeo,s.cheody.okeey.keeody.daiin.cheody.keedy
→ MTSAOP  OSŌARM  OŌRROP  SARONM  OŌRRM  ŌRRONM  NUII?  SARONM  ŌRRNM

`f31v.3`  ykeeo.daiin.shedal.okedy.okey.keo,dy.okchey.sair,okees.o.lkedy
→ MŌRRO  NUII?  PARNUL  OŌRNM  OŌRM  ŌRONM  OŌSARM  PUIROŌRRP  O  LŌRNM

`f31v.4`  dair.cthedy.qokedy.okeody.chedar.oked.al.ockhedy.okeedy.ota[s:d]
→ NUIR  STARNM  COŌRNM  OŌRONM  SARNUR  OŌRN  UL  OSŌARNM  OŌRRNM  OTUP

`f31v.5`  ykeos.cheeoy.or,aiin
→ MŌROP  SARROM  ORUII?

`f31v.6`  pcheeody.qop.chedal.checfhy.chefchol.or.cheef,alaiin.opal.sheo.otar
→ MSARRONM  COM  SARNUL  SARS?AM  SAR?SAOL  OR  SARR?ULUII?  OMUL  PARO  OTUR

`f31v.7`  olkeedam.ches.chol,keeol.checkhy.okeol.okal.oky.cheokar.okor.ary
→ OLŌRRNUS  SARP  SAOLŌRROL  SARSŌAM  OŌROL  OŌUL  OŌM  SAROŌUR  OŌOR  URM

`f31v.8`  ykaiin.chee,ksheey.ychekeeor.cheor.o,r,checthy.okechoked.lchey.okam
→ MŌUII?  SARRŌPARRM  MSARŌRROR  SAROR  ORSARSTAM  OŌRSAOŌRN  LSARM  OŌUS

`f31v.9`  ytecheol.sheoeky.okeos.aiin.a[{ikh}:ckh]edy.chkaiin.chetchey.ctheey.okear
→ MTRSAROL  PARORŌM  OŌROP  UII?  UIŌARNM  SAŌUII?  SARTSARM  STARRM  OŌRUR

`f31v.10`  dar.choar.al.kar.oeeeos.cheos.aiin.o.ckhey.okeo.kor.okeol.ain
→ NUR  SAOUR  UL  ŌUR  ORRROP  SAROP  UII?  O  SŌARM  OŌRO  ŌOR  OŌROL  UI?

`f31v.11`  saiin.ar.ckheos.chedy.okeey.qoear.oraiin.cheam
→ PUII?  UR  SŌAROP  SARNM  OŌRRM  CORUR  ORUII?  SARUS

### f32r  ·  herbal

`f32r.1`  fchaiin.shykeody.daiiody.dain<->sho.tchy.oty.qopy
→ ?SAUII?  PAMŌRONM  NUIIONM  NUI?PAO  TSAM  OTM  COMM

`f32r.2`  okor.okchor.sheor.ckhy.dal<->dshodar.qotchol
→ OŌOR  OŌSAOR  PAROR  SŌAM  NULNPAONUR  COTSAOL

`f32r.3`  qokchor.chor.cthol.chol.dol<->dcheodain.daiin
→ COŌSAOR  SAOR  STAOL  SAOL  NOLNSARONUI?  NUII?

`f32r.4`  schor.dsh[o:a]r.ytsho.dain<->daiin.choddal
→ PSAOR  NPAOR  MTPAO  NUI?NUII?  SAONNUL

`f32r.5`  qotchy.qokchy.daiin
→ COTSAM  COŌSAM  NUII?

`f32r.6`  fcho.tcheychedy
→ ?SAO  TSARMSARNM

`f32r.7`  otol.dol.ol,dair
→ OTOL  NOL  OLNUIR

`f32r.8`  qo,ar.daiin.dam
→ COUR  NUII?  NUS

`f32r.9`  dytchor.dary
→ NMTSAOR  NURM

`f32r.10`  dchor.ctho,daiin
→ NSAOR  STAONUII?

`f32r.11`  shos.chckhol.n
→ PAOP  SASŌAOL  ?

`f32r.12`  shodaiin.@150;tol
→ PAONUII?  TOL

`f32r.13`  otcho,rol.dain.daiin.cthy
→ OTSAOROL  NUI?  NUII?  STAM

`f32r.14`  schey.qot,shey.daiin.cths
→ PSARM  COTPARM  NUII?  STAP

`f32r.15`  qokchy.qotol.doiir.ol
→ COŌSAM  COTOL  NOIIR  OL

`f32r.16`  otchol.chey.soty
→ OTSAOL  SARM  POTM

`f32r.17`  chokeol.dchoty
→ SAOŌROL  NSAOTM

`f32r.18`  doiin.sho,shy
→ NOII?  PAOPAM

`f32r.19`  dol.dchol.dan
→ NOL  NSAOL  NU?

### f32v  ·  herbal

`f32v.1`  kcheodaiin.chol,kechy.qotaiin.daiioam<->o,chofchody
→ ŌSARONUII?  SAOLŌRSAM  COTUII?  NUIIOUSOSAO?SAONM

`f32v.2`  daiin.odar.chy.daiin.chey.tch[y:o].l,dy<->dain.teor
→ NUII?  ONUR  SAM  NUII?  SARM  TSAM  LNMNUI?  TROR

`f32v.3`  shor.daiin.chckhy.dsho.dain.daiin.s<->shokey.ka
→ PAOR  NUII?  SASŌAM  NPAO  NUI?  NUII?  PPAOŌRM  ŌU

`f32v.4`  or,chr.chor.dor,chaiin.qotcho,r,chy<->dch[o:a].daiin
→ ORSAR  SAOR  NORSAUII?  COTSAORSAMNSAO  NUII?

`f32v.5`  chokchy.daiin.shy.chor.qo.kaiin.dain<->dchol.dosg
→ SAOŌSAM  NUII?  PAM  SAOR  CO  ŌUII?  NUI?NSAOL  NOP?

`f32v.6`  o,kchan.chol,shal.dchcthy
→ OŌSAU?  SAOLPAUL  NSASTAM

`f32v.7`  ksho.cpho[s:r].she.sheaiin.otshcho.r.dain<->shckhy.s.odan
→ ŌPAO  SMAOP  PAR  PARUII?  OTPASAO  R  NUI?PASŌAM  P  ONU?

`f32v.8`  otchol.daiin.daiin.ctho,daiin.qotaiin<->otchy.d<->shan
→ OTSAOL  NUII?  NUII?  STAONUII?  COTUII?OTSAM  NPAU?

`f32v.9`  qotchy.cfhy.skey.chocthy.daiin.cthaiin<->daiin
→ COTSAM  S?AM  PŌRM  SAOSTAM  NUII?  STAUII?NUII?

`f32v.10`  sho.keol.chor.chol.daiin.cpho,l.cthol.da<->ar
→ PAO  ŌROL  SAOR  SAOL  NUII?  SMAOL  STAOL  NUUR

`f32v.11`  ol.sho.chy
→ OL  PAO  SAM

### f33r  ·  herbal

`f33r.1`  tshdar.shd[o:a]r.shepchdy.cphody.yfoldy.qofo{ikh}dy.otchedy.lfchdy.daiin
→ TPANUR  PANOR  PARMSANM  SMAONM  M?OLNM  CO?OIŌANM  OTSARNM  L?SANM  NUII?

`f33r.2`  ytchedy.qokar.cheky.okaldy.qokaldy.otor.oldar.qotar.otar.otardam
→ MTSARNM  COŌUR  SARŌM  OŌULNM  COŌULNM  OTOR  OLNUR  COTUR  OTUR  OTURNUS

`f33r.3`  laiin.y.cheky.qokedy.shedy.chdal.chechdaiin.qokchy.ody.chekeedy.yka[m:g]
→ LUII?  M  SARŌM  COŌRNM  PARNM  SANUL  SARSANUII?  COŌSAM  ONM  SARŌRRNM  MŌUS

`f33r.4`  taiin.chekey.or.al,aiiin.saiin.okaiin.dar.cheedy.chkeey.far.aiin.s
→ TUII?  SARŌRM  OR  ULUIII?  PUII?  OŌUII?  NUR  SARRNM  SAŌRRM  ?UR  UII?  P

`f33r.5`  pair.or.aiin.otaiin.ol,kor.aiin.okal.otal.chdal.shekal.qokar.ota[m:g]
→ MUIR  OR  UII?  OTUII?  OLŌOR  UII?  OŌUL  OTUL  SANUL  PARŌUL  COŌUR  OTUS

`f33r.6`  yteey.shody.kchedy,dy.chekar.okaiin.okaiin.daiin.okal
→ MTRRM  PAONM  ŌSARNMNM  SARŌUR  OŌUII?  OŌUII?  NUII?  OŌUL

`f33r.7`  dar.chos.aiin.or.aiin.cheekaiin.okain.ar.okeeey
→ NUR  SAOP  UII?  OR  UII?  SARRŌUII?  OŌUI?  UR  OŌRRRM

### f33v  ·  herbal

`f33v.1`  tar,ar.daiin<->ydain.cthey.dols<->sheky.ar,aiin.{cs}
→ TURUR  NUII?MNUI?  STARM  NOLPPARŌM  URUII?  SP

`f33v.2`  kchdy.dam.dy<->oky<->otal.dain.chdy<->ytam.otam.cham
→ ŌSANM  NUS  NMOŌMOTUL  NUI?  SANMMTUS  OTUS  SAUS

`f33v.3`  dar.chckhy.dy<->dyky<->ckhdy.oky.d[a:ch]m<->okar,dy.kam,dy
→ NUR  SASŌAM  NMNMŌMSŌANM  OŌM  NUSOŌURNM  ŌUSNM

`f33v.4`  tokar.shdy.dal<->qokar.shd<->otody.chedy<->ykedy.dodl.dain
→ TOŌUR  PANM  NULCOŌUR  PANOTONM  SARNMMŌRNM  NONL  NUI?

`f33v.5`  tchdy.chody.okaiin<->chckhy.dor.arl<->cthy.dy,ty,dy<->ykar.cheky.dy
→ TSANM  SAONM  OŌUII?SASŌAM  NOR  URLSTAM  NMTMNMMŌUR  SARŌM  NM

`f33v.6`  ycheo.dar.olaiin.okar.chdy.chdy.oldy<->okar.chdy
→ MSARO  NUR  OLUII?  OŌUR  SANM  SANM  OLNMOŌUR  SANM

`f33v.7`  tshdy.shefchdy.shckhdy.oltedy.daiin.oky<->cheol.orain<->chdyshdy.porar
→ TPANM  PAR?SANM  PASŌANM  OLTRNM  NUII?  OŌMSAROL  ORUI?SANMPANM  MORUR

`f33v.8`  dar,ar.sheey.keedy.okchy.okar.okedy.chy<->daiin.dy'.dy<->dar.aiin.okary
→ NURUR  PARRM  ŌRRNM  OŌSAM  OŌUR  OŌRNM  SAMNUII?  NM  NMNUR  UII?  OŌURM

`f33v.9`  sar.or,aiin.chor.or.shkair.shol.or.chckhy<->ar,aiin<->okain.dal.dy
→ PUR  ORUII?  SAOR  OR  PAŌUIR  PAOL  OR  SASŌAMURUII?OŌUI?  NUL  NM

`f33v.10`  lcho,ar.or.chey.lodaiin.o,or.okeedy.okaly
→ LSAOUR  OR  SARM  LONUII?  OOR  OŌRRNM  OŌULM

`f33v.11`  tar.al.keey.oram
→ TUR  UL  ŌRRM  ORUS

### f34r  ·  herbal

`f34r.1`  pcheoepchy.olar.yl<->yfody.okedody.shod.ololdy.dar.ytey
→ MSARORMSAM  OLUR  MLM?ONM  OŌRNONM  PAON  OLOLNM  NUR  MTRM

`f34r.2`  ytar.sheody.o,lam<->octhedy.otedy.chdain.oltey.kchy,ty
→ MTUR  PARONM  OLUSOSTARNM  OTRNM  SANUI?  OLTRM  ŌSAMTM

`f34r.3`  qotedy.chyty.chdaly<->dar.chd.otedy.qotol.okedy.dody.ody.kam
→ COTRNM  SAMTM  SANULMNUR  SAN  OTRNM  COTOL  OŌRNM  NONM  ONM  ŌUS

`f34r.4`  ytedy.daiin.chey.aiin<->shy.chckhy<~>oltchedy.otedy.dam.checthy
→ MTRNM  NUII?  SARM  UII?PAM  SASŌAMOLTSARNM  OTRNM  NUS  SARSTAM

`f34r.5`  qoteedy.shedy.shedy.ol<->okes.ar<~>ykeed,l.chedy.otey.okaiin
→ COTRRNM  PARNM  PARNM  OLOŌRP  URMŌRRNL  SARNM  OTRM  OŌUII?

`f34r.6`  oteol.chekey.chetey.oll<->chesy<~>daiin.cheky.fas.aiir.a[m:d]g
→ OTROL  SARŌRM  SARTRM  OLLSARPMNUII?  SARŌM  ?UP  UIIR  US?

`f34r.7`  qokedy.dal.chdy<->olchy<->ykch[y:?]<~>ykedy.qokchdy.s.as.oldam
→ COŌRNM  NUL  SANMOLSAMMŌSAMMŌRNM  COŌSANM  P  UP  OLNUS

`f34r.8`  {ch'}otchy.qoky<->olk<->checkhy<~>ys,air.air.chodar.ta[m:g]
→ SAOTSAM  COŌMOLŌSARSŌAMMPUIR  UIR  SAONUR  TUS

`f34r.9`  ykchdy.qod<->ar<->ch{ct}<->a[{ikh}:ckh]y<~>or.lchey.todaly.okaiin.dardy
→ MŌSANM  CONURSASTUIŌAMOR  LSARM  TONULM  OŌUII?  NURNM

`f34r.10`  tcheo.olchckhy.oly<->otchdy.chefalchhs
→ TSARO  OLSASŌAM  OLMOTSANM  SAR?ULSAAP

`f34r.11`  qokeey.sh.kaldaiin<->cheky.cthdaly<->otchedy.chty.s,aiin
→ COŌRRM  PA  ŌULNUII?SARŌM  STANULMOTSARNM  SATM  PUII?

`f34r.12`  char.aiin.okor,ar.tol<->qokar.chckhy.chdal.ked.qokar.ar.daiin.dam
→ SAUR  UII?  OŌORUR  TOLCOŌUR  SASŌAM  SANUL  ŌRN  COŌUR  UR  NUII?  NUS

`f34r.13`  ykeo.lor.ochey.oly<->okaly.kechdy.qokchdy.chor.ar.aiiin.daly
→ MŌRO  LOR  OSARM  OLMOŌULM  ŌRSANM  COŌSANM  SAOR  UR  UIII?  NULM

`f34r.14`  or.ar.y,kar.ol,al.oky<->chody.qokal,chedy.chcthedy.cheky.daram
→ OR  UR  MŌUR  OLUL  OŌMSAONM  COŌULSARNM  SASTARNM  SARŌM  NURUS

`f34r.15`  sair.chekar.cheky.shek<->cholchedy.qokedy.yk,cheolchcthy
→ PUIR  SARŌUR  SARŌM  PARŌSAOLSARNM  COŌRNM  MŌSAROLSASTAM

### f34v  ·  herbal

`f34v.1`  k[e':s]chdy.chdy.chefchy.shdy.qopchdy.shdydy.chdalchdy.ypchdy.chcthdy.spaiin
→ ŌRSANM  SANM  SAR?SAM  PANM  COMSANM  PANMNM  SANULSANM  MMSANM  SASTANM  PMUII?

`f34v.2`  tol.qokchy.dychedy.okchy.chckhdy.chdaiin.ckhy.loees.ykar.aiin.oldam
→ TOL  COŌSAM  NMSARNM  OŌSAM  SASŌANM  SANUII?  SŌAM  LORRP  MŌUR  UII?  OLNUS

`f34v.3`  ytal.shor.chdal.olchdy.char.or.ol.kedaiiin.chcthy.okchdy.chckhy.dasam
→ MTUL  PAOR  SANUL  OLSANM  SAUR  OR  OL  ŌRNUIII?  SASTAM  OŌSANM  SASŌAM  NUPUS

`f34v.4`  tchdaiin.chekal.shedy.qokedar.chdaiin.oldar.qoldar.chedy.daiin.otam
→ TSANUII?  SARŌUL  PARNM  COŌRNUR  SANUII?  OLNUR  COLNUR  SARNM  NUII?  OTUS

`f34v.5`  lshaiir.or,air.shedy.chechey.dykey.kair.chedy.qokar.chekaly.ch[a:o]lky
→ LPAUIIR  ORUIR  PARNM  SARSARM  NMŌRM  ŌUIR  SARNM  COŌUR  SARŌULM  SAULŌM

`f34v.6`  pchedar.shear.qokchdy.qokees.cheol.ypchdaiin.chedy.lr,ar.chedain
→ MSARNUR  PARUR  COŌSANM  COŌRRP  SAROL  MMSANUII?  SARNM  LRUR  SARNUI?

`f34v.7`  olchdaiin.chedy.chey,keedy.chy.kedy.dy.qokedy.okey.s,a[ir:is].chkain.otain
→ OLSANUII?  SARNM  SARMŌRRNM  SAM  ŌRNM  NM  COŌRNM  OŌRM  PUIR  SAŌUI?  OTUI?

`f34v.8`  ysheos.otar.ar.choraiin.cheky.olchdaiin.or.oldar.chdar.oka[m:g]
→ MPAROP  OTUR  UR  SAORUII?  SARŌM  OLSANUII?  OR  OLNUR  SANUR  OŌUS

`f34v.9`  lsheody.cphy.qokeey.keedy.kchdy.chedy.qokedy.chdy.kal,shs.oldaiin
→ LPARONM  SMAM  COŌRRM  ŌRRNM  ŌSANM  SARNM  COŌRNM  SANM  ŌULPAP  OLNUII?

`f34v.10`  daiin.chdy.tedy.kchdy.okeedy.checkhy.chdy.kain.chear.or.okedy.okam
→ NUII?  SANM  TRNM  ŌSANM  OŌRRNM  SARSŌAM  SANM  ŌUI?  SARUR  OR  OŌRNM  OŌUS

`f34v.11`  yshos.ody.s.aiin.okey.okal,shedy
→ MPAOP  ONM  P  UII?  OŌRM  OŌULPARNM

### f35r  ·  herbal

`f35r.1`  {c@132;h}oo.r,choly,{c@196;h}y.choty.char.dy
→ SAOO  RSAOLMSAM  SAOTM  SAUR  NM

`f35r.2`  qokeeaiin.chokaiin.qo,tchy.daiin
→ COŌRRUII?  SAOŌUII?  COTSAM  NUII?

`f35r.3`  dchaiin.cthey.qotchey.taiin.cthory
→ NSAUII?  STARM  COTSARM  TUII?  STAORM

`f35r.4`  qotchy.shet,chy.ckhol.cheey.daiin.dainl
→ COTSAM  PARTSAM  SŌAOL  SARRM  NUII?  NUI?L

`f35r.5`  otchor.sho.tcheey.scheey.daiin.dain,or
→ OTSAOR  PAO  TSARRM  PSARRM  NUII?  NUI?OR

`f35r.6`  schaiin.char.chan.daiin
→ PSAUII?  SAUR  SAU?  NUII?

`f35r.7`  shosaiin.tchor.choky
→ PAOPUII?  TSAOR  SAOŌM

`f35r.8`  qokeey.ky,kaiin.daiin
→ COŌRRM  ŌMŌUII?  NUII?

`f35r.9`  paiin.chear.aiin.chear.shorchaiin
→ MUII?  SARUR  UII?  SARUR  PAORSAUII?

`f35r.10`  o,aiin.chaiin.ckhy.r.chl.s.chochy.daiin
→ OUII?  SAUII?  SŌAM  R  SAL  P  SAOSAM  NUII?

`f35r.11`  sh[{oh}:ch]eaiin.chol.cthaiin.l,chaiin.lchal,dal<->dair,aldy.n
→ PAOARUII?  SAOL  STAUII?  LSAUII?  LSAULNULNUIRULNM  ?

`f35r.12`  olor.chy.chaiin.chy.taiin.kchey.koldy<->chetchaiin
→ OLOR  SAM  SAUII?  SAM  TUII?  ŌSARM  ŌOLNMSARTSAUII?

`f35r.13`  qokoiin.chaiin.qokchaiin.lshy.lodaly<->oteey.taiin
→ COŌOII?  SAUII?  COŌSAUII?  LPAM  LONULMOTRRM  TUII?

`f35r.14`  cthol.chol.aiin.qotchy.otchor.daiin<->shol.qotaiin
→ STAOL  SAOL  UII?  COTSAM  OTSAOR  NUII?PAOL  COTUII?

`f35r.15`  ochor.s.chiin.daiin.ytain
→ OSAOR  P  SAII?  NUII?  MTUI?

### f35v  ·  herbal

`f35v.1`  parchor.chocthy.roaiin.ar
→ MURSAOR  SAOSTAM  ROUII?  UR

`f35v.2`  qotchy.o,tchey.kchor.yty
→ COTSAM  OTSARM  ŌSAOR  MTM

`f35v.3`  dchor.choty.chyty.daiin
→ NSAOR  SAOTM  SAMTM  NUII?

`f35v.4`  ytchy.qotchy.dchy.cthy
→ MTSAM  COTSAM  NSAM  STAM

`f35v.5`  dchokchy.chocthy.chckhor
→ NSAOŌSAM  SAOSTAM  SASŌAOR

`f35v.6`  shol.tcheey.chkcheeu.chcthaiin
→ PAOL  TSARRM  SAŌSARR?  SASTAUII?

`f35v.7`  tcho,tchor.shol.sho.{co},kol.daiin
→ TSAOTSAOR  PAOL  PAO  SOŌOL  NUII?

`f35v.8`  oaiin.tchor.cho.chotchy.dchold
→ OUII?  TSAOR  SAO  SAOTSAM  NSAOLN

`f35v.9`  qokchaiin.cho.ksho,l,choiin
→ COŌSAUII?  SAO  ŌPAOLSAOII?

`f35v.10`  okcheey.chosar.shory
→ OŌSARRM  SAOPUR  PAORM

`f35v.11`  qotcheeaiin.chodaiin
→ COTSARRUII?  SAONUII?

`f35v.12`  dchaiin.d.aiin.d.aiin,dal,s
→ NSAUII?  N  UII?  N  UII?NULP

`f35v.13`  ol.char.od.ar.chear
→ OL  SAUR  ON  UR  SARUR

`f35v.14`  tcheain.shy.tar.dain
→ TSARUI?  PAM  TUR  NUI?

`f35v.15`  ykol.cheol.okchy.tch
→ MŌOL  SAROL  OŌSAM  TSA

`f35v.16`  ydaiin.okeey.d,aiin
→ MNUII?  OŌRRM  NUII?

`f35v.17`  daiin.dain.chkaly.choly
→ NUII?  NUI?  SAŌULM  SAOLM

`f35v.18`  daiin.qokeeeb.chokee[o:y].r
→ NUII?  COŌRRR?  SAOŌRRO  R

`f35v.19`  schokey.y,keol.chol.daiin
→ PSAOŌRM  MŌROL  SAOL  NUII?

`f35v.20`  sodaiin.shy.dchy.ckhy.dan
→ PONUII?  PAM  NSAM  SŌAM  NU?

`f35v.21`  doiin.chor.chor
→ NOII?  SAOR  SAOR

### f36r  ·  herbal

`f36r.1`  pcha@151;dan.qorain.chcfhal.soiin.cphor.shaiin.cthy.dair
→ MSAUNU?  CORUI?  SAS?AUL  POII?  SMAOR  PAUII?  STAM  NUIR

`f36r.2`  oral.shor.ytaiin.qotaiin.qooldy.chty.chol,dy.tor
→ ORUL  PAOR  MTUII?  COTUII?  COOLNM  SATM  SAOLNM  TOR

`f36r.3`  qotchy.tchy.daiin.@152;aiin.dolsain
→ COTSAM  TSAM  NUII?  UII?  NOLPUI?

`f36r.4`  podaiir.cphy.qoypchol.som<->{c'y}<->chy.dchy.fchom,dar
→ MONUIIR  SMAM  COMMSAOL  POSSMSAM  NSAM  ?SAOSNUR

`f36r.5`  daiin.qor.chol.ctholy.s<->o<->r<->chy.sy<->chytaroiin
→ NUII?  COR  SAOL  STAOLM  PORSAM  PMSAMTUROII?

`f36r.6`  okaiin.cthor.y,kaiiin.s<->dain.an<->dan
→ OŌUII?  STAOR  MŌUIII?  PNUI?  U?NU?

`f36r.7`  qotol.cthol.okol,dy.okchy<->ytorory<->sold
→ COTOL  STAOL  OŌOLNM  OŌSAMMTORORMPOLN

`f36r.8`  ytchor.cthol.chaiin.yd
→ MTSAOR  STAOL  SAUII?  MN

`f36r.9`  ytodaly.daiin.otaro
→ MTONULM  NUII?  OTURO

### f36v  ·  herbal

`f36v.1`  pchar,asy.qoforom.shoaiin.tchey.ch[{ckoh}:{ckhh}]y.otaiin.cphar.daiin
→ MSAURUPM  CO?OROS  PAOUII?  TSARM  SASŌOAM  OTUII?  SMAUR  NUII?

`f36v.2`  qotor.chol.daiin.otaiin.qotor.ytar.ochor.chety.ckh[o:a]r.dom
→ COTOR  SAOL  NUII?  OTUII?  COTOR  MTUR  OSAOR  SARTM  SŌAOR  NOS

`f36v.3`  dchytchy.ytor,s<->otaiin.qopchor.otar.otchaiin.s
→ NSAMTSAM  MTORPOTUII?  COMSAOR  OTUR  OTSAUII?  P

`f36v.4`  qotchor.y,ky,ty,dy<->daiin.cthor
→ COTSAOR  MŌMTMNMNUII?  STAOR

`f36v.5`  tchor.ckhoiin.daiin.cphchar
→ TSAOR  SŌAOII?  NUII?  SMASAUR

`f36v.6`  daiin.cthor.daiin.dal.dys
→ NUII?  STAOR  NUII?  NUL  NMP

`f36v.7`  qoky.keol.okchor.o,s,ch[y:a],shan
→ COŌM  ŌROL  OŌSAOR  OPSAMPAU?

`f36v.8`  ykshy.ytchy.dol.y,tydy.yky
→ MŌPAM  MTSAM  NOL  MTMNM  MŌM

`f36v.9`  okaiin.y,kcholqod.chory
→ OŌUII?  MŌSAOLCON  SAORM

`f36v.10`  ykchotchy.daiin.daiild
→ MŌSAOTSAM  NUII?  NUIILN

`f36v.11`  oty.chcthy.ytoryd
→ OTM  SASTAM  MTORMN

`f36v.12`  ytol.kchy.oty,chd
→ MTOL  ŌSAM  OTMSAN

`f36v.13`  oky.she.cthol.oty
→ OŌM  PAR  STAOL  OTM

`f36v.14`  soiin.chtain
→ POII?  SATUI?

### f37r  ·  herbal

`f37r.1`  tocphol.shaiin.qotor.ofchor.oty.chory.daiin.otod,[o:a]r
→ TOSMAOL  PAUII?  COTOR  O?SAOR  OTM  SAORM  NUII?  OTONOR

`f37r.2`  ykoiin.cthor.okaiin.qo,tchy.ytody.qokaiin.sho.ytaiin
→ MŌOII?  STAOR  OŌUII?  COTSAM  MTONM  COŌUII?  PAO  MTUII?

`f37r.3`  qo,shy.qokaiin.cthol,dy.ckhor.oky,dy
→ COPAM  COŌUII?  STAOLNM  SŌAOR  OŌMNM

`f37r.4`  pchotchy.daiin.cfholdar.chol.daiin<->yd
→ MSAOTSAM  NUII?  S?AOLNUR  SAOL  NUII?MN

`f37r.5`  yky.qokchy.qotchor.chkol.otoly
→ MŌM  COŌSAM  COTSAOR  SAŌOL  OTOLM

`f37r.6`  shor.shol.qokchy.qotomody<->dchol.daiin
→ PAOR  PAOL  COŌSAM  COTOSONMNSAOL  NUII?

`f37r.7`  sor.chey.kor.qokor.daiin
→ POR  SARM  ŌOR  COŌOR  NUII?

`f37r.8`  koiin.chorody.qokaiin.{c'hh}ory.otal<->shor.sheor.dar
→ ŌOII?  SAORONM  COŌUII?  SAAORM  OTULPAOR  PAROR  NUR

`f37r.9`  ykchody.qotchy.ykaiin.chy.qotordy<->otcho.loldaiin
→ MŌSAONM  COTSAM  MŌUII?  SAM  COTORNMOTSAO  LOLNUII?

`f37r.10`  qoto.o,kchochor.dchor.chy.shy.daiin<->ychey.kol,daiir
→ COTO  OŌSAOSAOR  NSAOR  SAM  PAM  NUII?MSARM  ŌOLNUIIR

`f37r.11`  okchor.daiin.ckhy.dain.daiin
→ OŌSAOR  NUII?  SŌAM  NUI?  NUII?

### f37v  ·  herbal

`f37v.1`  [t:k]shody.qocthy.qotoldy.chopdain.sol
→ TPAONM  COSTAM  COTOLNM  SAOMNUI?  POL

`f37v.2`  dor.chol.cthor.orchochor.daiin
→ NOR  SAOL  STAOR  ORSAOSAOR  NUII?

`f37v.3`  qokchon.shy.chon.daiin.dy
→ COŌSAO?  PAM  SAO?  NUII?  NM

`f37v.4`  dshor.dytory.dshor.daiin
→ NPAOR  NMTORM  NPAOR  NUII?

`f37v.5`  dchor.qotol.ykchon.dain
→ NSAOR  COTOL  MŌSAO?  NUI?

`f37v.6`  yokor.ytchor.saiin.oty
→ MOŌOR  MTSAOR  PUII?  OTM

`f37v.7`  qotchor.daiin
→ COTSAOR  NUII?

`f37v.8`  qotor.choiin.chetchy.daiin
→ COTOR  SAOII?  SARTSAM  NUII?

`f37v.9`  dor.chor.sho.daiiin.daiin
→ NOR  SAOR  PAO  NUIII?  NUII?

`f37v.10`  soiin.{ch'}ey.o,koiin.chey.tom
→ POII?  SARM  OŌOII?  SARM  TOS

`f37v.11`  qotoiin.choror.cthol.daiin
→ COTOII?  SAOROR  STAOL  NUII?

`f37v.12`  chor,sh[y:o]ly.sheaiin.do.tody
→ SAORPAMLM  PARUII?  NO  TONM

`f37v.13`  sotoiiin
→ POTOIII?

`f37v.14`  todain.cphaiin.cphorods
→ TONUI?  SMAUII?  SMAORONP

`f37v.15`  soiiin.cheoky.daiin.dain
→ POIII?  SAROŌM  NUII?  NUI?

`f37v.16`  qotor.daiin.chotaiin
→ COTOR  NUII?  SAOTUII?

`f37v.17`  sokchor.qokoiiin.ykeeols
→ POŌSAOR  COŌOIII?  MŌRROLP

`f37v.18`  oyteey.daiin.daiinody
→ OMTRRM  NUII?  NUII?ONM

`f37v.19`  daiin.qkaiin.qotal.daiin
→ NUII?  CŌUII?  COTUL  NUII?

`f37v.20`  y,cho{ckah}y.ykol,daiin,s
→ MSAOSŌUAM  MŌOLNUII?P

`f37v.21`  oshctho.do.daiin.cthols
→ OPASTAO  NO  NUII?  STAOLP

`f37v.22`  qotol.ytoiin.cho{cthh}y
→ COTOL  MTOII?  SAOSTAAM

`f37v.23`  yto.chol.daiin
→ MTO  SAOL  NUII?

### f38r  ·  herbal

`f38r.1`  tolor.chockhy<->oky.choiin.okshol.oly.oky
→ TOLOR  SAOSŌAMOŌM  SAOII?  OŌPAOL  OLM  OŌM

`f38r.2`  okshey.chodys<->ytoiin.otaiin.otaiin.cthar
→ OŌPARM  SAONMPMTOII?  OTUII?  OTUII?  STAUR

`f38r.3`  qokor.okaiin<->otaiin.qo,kchol.chokokor
→ COŌOR  OŌUII?OTUII?  COŌSAOL  SAOŌOŌOR

`f38r.4`  ychok.chey.chckh<->chy.chk[o:y].r.odaiin.d,aiin.sy
→ MSAOŌ  SARM  SASŌASAM  SAŌO  R  ONUII?  NUII?  PM

`f38r.5`  o,kor.chey.kain<->chor.ctho.dain.ckholdy
→ OŌOR  SARM  ŌUI?SAOR  STAO  NUI?  SŌAOLNM

`f38r.6`  ysho.sho.kos<->daiin.okoy.chochor.daiin
→ MPAO  PAO  ŌOPNUII?  OŌOM  SAOSAOR  NUII?

### f38v  ·  herbal

`f38v.1`  okchop.chol.shotol.oteol.okee[a:y].s<->chor.d.aiin,d
→ OŌSAOM  SAOL  PAOTOL  OTROL  OŌRRU  PSAOR  N  UII?N

`f38v.2`  choiin.shey.key.sho.oiin.s.chol,ldy<->okeaiin.o,kom
→ SAOII?  PARM  ŌRM  PAO  OII?  P  SAOLLNMOŌRUII?  OŌOS

`f38v.3`  qokeey.keor.daiin.okey.keey.daiin<->dair.daiin.s
→ COŌRRM  ŌROR  NUII?  OŌRM  ŌRRM  NUII?NUIR  NUII?  P

`f38v.4`  okeey.d,aiin.qokeey.chotey.tody<->oky.aiiin.d
→ OŌRRM  NUII?  COŌRRM  SAOTRM  TONMOŌM  UIII?  N

`f38v.5`  qoty.daiin.chol.oteeol.dody<->cheod.chody
→ COTM  NUII?  SAOL  OTRROL  NONMSARON  SAONM

`f38v.6`  sho.keeey.key.tey.daiin.daiiin<->dain.dain
→ PAO  ŌRRRM  ŌRM  TRM  NUII?  NUIII?NUI?  NUI?

`f38v.7`  daiin.qol.chy.dain.@153;.or.daiin<->dain.daldy
→ NUII?  COL  SAM  NUI?  —  OR  NUII?NUI?  NULNM

`f38v.8`  o,aiin.char.chshol.chokaiin
→ OUII?  SAUR  SAPAOL  SAOŌUII?

### f39r  ·  herbal

`f39r.1`  tedo,chshd.cphhofy.chdain.shey.f[sh:se]y,dy.orain.cheepaiin.ofy.shey.k[a:o]ly.dy
→ TRNOSAPAN  SMAAO?M  SANUI?  PARM  ?PAMNM  ORUI?  SARRMUII?  O?M  PARM  ŌULM  NM

`f39r.2`  olchey.cheky.qokedy.shekshey.qolain.ch{ckh'h}y.chdy.dair.shckhey.dold
→ OLSARM  SARŌM  COŌRNM  PARŌPARM  COLUI?  SASŌAAM  SANM  NUIR  PASŌARM  NOLN

`f39r.3`  qokalchdy.chekaiin.checkhy.darshed.qokeedar.eeedy.dar.ar.cheey.dyckhy
→ COŌULSANM  SARŌUII?  SARSŌAM  NURPARN  COŌRRNUR  RRRNM  NUR  UR  SARRM  NMSŌAM

`f39r.4`  tchedy.chdy.olaiin.chedy.shckhdchy.chol.or.ordy.chees.aly.okalcheg
→ TSARNM  SANM  OLUII?  SARNM  PASŌANSAM  SAOL  OR  ORNM  SARRP  ULM  OŌULSAR?

`f39r.5`  dchdy.chdy.ykaiin
→ NSANM  SANM  MŌUII?

`f39r.6`  pchdaiin.she,dam.qofchedy.shedy.kchdy.dydy.opchekaiin.sho{ckhh}y.shdalo.ry
→ MSANUII?  PARNUS  CO?SARNM  PARNM  ŌSANM  NMNM  OMSARŌUII?  PAOSŌAAM  PANULO  RM

`f39r.7`  dchdar.chedy.cholal.qokedar.chdy.chckhdy.dar.ar.al.ydy.eee,s.aiiin
→ NSANUR  SARNM  SAOLUL  COŌRNUR  SANM  SASŌANM  NUR  UR  UL  MNM  RRRP  UIII?

`f39r.8`  lchedy.shedy.qokaiin.chkeey.fchedy.okam.ch{cfhh}y.saiin.chckhy.daisog
→ LSARNM  PARNM  COŌUII?  SAŌRRM  ?SARNM  OŌUS  SAS?AAM  PUII?  SASŌAM  NUIPO?

`f39r.9`  tchedy.shol.odal.qokaiin.shdaiin
→ TSARNM  PAOL  ONUL  COŌUII?  PANUII?

`f39r.10`  pchdar.shedy.ar.aiir.okair.ykeols.shedy.qockhdy.laiin.{c'y}ky
→ MSANUR  PARNM  UR  UIIR  OŌUIR  MŌROLP  PARNM  COSŌANM  LUII?  SMŌM

`f39r.11`  dshdy.ar.aiin.y.yk[en:{cr}].chdy.ykal.olkaiin.qokaldar.cheol.dar.aiin
→ NPANM  UR  UII?  M  MŌR?  SANM  MŌUL  OLŌUII?  COŌULNUR  SAROL  NUR  UII?

`f39r.12`  tolchda[iin:ii?].chckhy.s,aiin.olor.chls.aiin.oky.ches.aiin.dal
→ TOLSANUII?  SASŌAM  PUII?  OLOR  SALP  UII?  OŌM  SARP  UII?  NUL

`f39r.13`  ytor.chdar.shey.qokaiin.chor.kar.sheolkedy.otedy.tedy.s,aiin
→ MTOR  SANUR  PARM  COŌUII?  SAOR  ŌUR  PAROLŌRNM  OTRNM  TRNM  PUII?

`f39r.14`  daiin.shckhy.chekl.ol,daiin.chedy.ykeey.daiin.otal.chdam.qokam
→ NUII?  PASŌAM  SARŌL  OLNUII?  SARNM  MŌRRM  NUII?  OTUL  SANUS  COŌUS

`f39r.15`  qolkain.ol,cheol.daiin.dar.ol.dld.[ar:iir].ador.aiin.ofcheefar
→ COLŌUI?  OLSAROL  NUII?  NUR  OL  NLN  UR  UNOR  UII?  O?SARR?UR

`f39r.16`  oteol.cholkal.qokal.dar.ykdy
→ OTROL  SAOLŌUL  COŌUL  NUR  MŌNM

### f39v  ·  herbal

`f39v.1`  pdair.chdy.fdykain.or.air.sheykaiiin.ofchy.kar.or.aiin.dolky.o[sh:{i'h}]dy
→ MNUIR  SANM  ?NMŌUI?  OR  UIR  PARMŌUIII?  O?SAM  ŌUR  OR  UII?  NOLŌM  OPANM

`f39v.2`  sor.shy.kar.chol.qoty.kchdy.olky.dar.chdy.ykar.olkedaiin.ody.dy
→ POR  PAM  ŌUR  SAOL  COTM  ŌSANM  OLŌM  NUR  SANM  MŌUR  OLŌRNUII?  ONM  NM

`f39v.3`  daiin.chor.okain.okaii,fchody.saiin.or,aiin.qokaiin.ytodaiin.okam
→ NUII?  SAOR  OŌUI?  OŌUII?SAONM  PUII?  ORUII?  COŌUII?  MTONUII?  OŌUS

`f39v.4`  y,okeey.chody.cheor.aiin.okody.chodal.ykedy.qokedy.dal,o,[d:?],aiin.shky
→ MOŌRRM  SAONM  SAROR  UII?  OŌONM  SAONUL  MŌRNM  COŌRNM  NULONUII?  PAŌM

`f39v.5`  ytedykor.or.sheky.kain.otar.or.aiin.okaiin.ckhol.ol.kor.oto,r.ofchy
→ MTRNMŌOR  OR  PARŌM  ŌUI?  OTUR  OR  UII?  OŌUII?  SŌAOL  OL  ŌOR  OTOR  O?SAM

`f39v.6`  lkedy.okchey.shor.qoykam.cho,ckh{cfhh}y.or.aly.shody
→ LŌRNM  OŌSARM  PAOR  COMŌUS  SAOSŌAS?AAM  OR  ULM  PAONM

`f39v.7`  pardy.shedy.qokar.sheedy.oraly<->olaiir.okar.ar
→ MURNM  PARNM  COŌUR  PARRNM  ORULMOLUIIR  OŌUR  UR

`f39v.8`  o{ek}ar.aiin.olkaiin.olky.dar.ald<->shek.chek.qokchy.dar.ain
→ ORŌUR  UII?  OLŌUII?  OLŌM  NUR  ULNPARŌ  SARŌ  COŌSAM  NUR  UI?

`f39v.9`  tar.aiin.dal.ar.ain.cheor.ydam<->shody.okal.shd,y.kshy.or
→ TUR  UII?  NUL  UR  UI?  SAROR  MNUSPAONM  OŌUL  PANM  ŌPAM  OR

`f39v.10`  dar.ar.ykar.or.yky.chdy.fchor<->qokain.ar.sheedy.olchef
→ NUR  UR  MŌUR  OR  MŌM  SANM  ?SAORCOŌUI?  UR  PARRNM  OLSAR?

`f39v.11`  sarol.chedy.shekam.q[o:e]kar.chl<->ykeedy.chckhy.dalor.dy
→ PUROL  SARNM  PARŌUS  COŌUR  SALMŌRRNM  SASŌAM  NULOR  NM

`f39v.12`  paiin.alaiin.otal,chd.okar.am<->okar.cheodal.ockhy
→ MUII?  ULUII?  OTULSAN  OŌUR  USOŌUR  SARONUL  OSŌAM

`f39v.13`  dain.ockhedy.otedy.okedy<->lchdy.okaiin.daiiin,y
→ NUI?  OSŌARNM  OTRNM  OŌRNMLSANM  OŌUII?  NUIII?M

`f39v.14`  tar,aiin.okaiin.cholody
→ TURUII?  OŌUII?  SAOLONM

### f40r  ·  herbal

`f40r.1`  pchey.k,eodar.aldydy<->qoky.okal.shdy.olkedy.opches.ar.ordaiin
→ MSARM  ŌRONUR  ULNMNMCOŌM  OŌUL  PANM  OLŌRNM  OMSARP  UR  ORNUII?

`f40r.2`  qokar.okar.okedy.dar<->ykchey.kaiin.ok[a:o]s,chedy.okar.a,ralos
→ COŌUR  OŌUR  OŌRNM  NURMŌSARM  ŌUII?  OŌUPSARNM  OŌUR  URULOP

`f40r.3`  shy.qokal.chdy.chckhd<->otor.aiir.o,ky.okolchy.qokar.okam
→ PAM  COŌUL  SANM  SASŌANOTOR  UIIR  OŌM  OŌOLSAM  COŌUR  OŌUS

`f40r.4`  or.aiin.chekody.dar<->qokol.okaiin.okar.oky.okoldy.ol
→ OR  UII?  SARŌONM  NURCOŌOL  OŌUII?  OŌUR  OŌM  OŌOLNM  OL

`f40r.5`  lokar.qokar.okar<->okol.ol.chedy.qokchd.ar.ar.or.da[g:m]
→ LOŌUR  COŌUR  OŌUROŌOL  OL  SARNM  COŌSAN  UR  UR  OR  NU?

`f40r.6`  tor.or.ar.shok.or.am<->o,lshedy.qokam.chdy.kar.oraiin
→ TOR  OR  UR  PAOŌ  OR  USOLPARNM  COŌUS  SANM  ŌUR  ORUII?

`f40r.7`  yaiin.chekaiin.oky<->ycheey
→ MUII?  SARŌUII?  OŌMMSARRM

`f40r.8`  ksheo.keeey.dar.ai[g:m]<->kcheo.cfhdy.or,ain.chefal.daiin.dg
→ ŌPARO  ŌRRRM  NUR  UI?ŌSARO  S?ANM  ORUI?  SAR?UL  NUII?  N?

`f40r.9`  taiin.ol.olaiin.or<->dain.okaiin.okaiin.okaiin.daram
→ TUII?  OL  OLUII?  ORNUI?  OŌUII?  OŌUII?  OŌUII?  NURUS

`f40r.10`  saiin.olcheey.chdy<->ychey.ka@154;ar.oky.ykedy.okair.ody
→ PUII?  OLSARRM  SANMMSARM  ŌUUR  OŌM  MŌRNM  OŌUIR  ONM

`f40r.11`  toar.ykaiin.ory.dal
→ TOUR  MŌUII?  ORM  NUL

### f40v  ·  herbal

`f40v.1`  pchedain.chefaiin.oldy
→ MSARNUI?  SAR?UII?  OLNM

`f40v.2`  todar.qokaiin.ol.ara[g:m]
→ TONUR  COŌUII?  OL  URU?

`f40v.3`  s,air,ain.okaiin.okam
→ PUIRUI?  OŌUII?  OŌUS

`f40v.4`  taraiin.okaiin.ch{ckhy}
→ TURUII?  OŌUII?  SASŌAM

`f40v.5`  solaiin.okar.oly.chckhy
→ POLUII?  OŌUR  OLM  SASŌAM

`f40v.6`  qoeedaiin.ol.chedy.daiin
→ CORRNUII?  OL  SARNM  NUII?

`f40v.7`  shody.qokol,chedy.s.ar
→ PAONM  COŌOLSARNM  P  UR

`f40v.8`  chodaiin.chkalykedy.okal
→ SAONUII?  SAŌULMŌRNM  OŌUL

`f40v.9`  tchy,pchody.pchdy.kor.ol
→ TSAMMSAONM  MSANM  ŌOR  OL

`f40v.10`  tchkaiin.tchedy.qokaiin.oraiin
→ TSAŌUII?  TSARNM  COŌUII?  ORUII?

`f40v.11`  schedy.qokol.chedy.dalor.a{ith}y
→ PSARNM  COŌOL  SARNM  NULOR  UITAM

`f40v.12`  ycheekeey.daiin.okaiin
→ MSARRŌRRM  NUII?  OŌUII?

`f40v.13`  toees.chedy.kedy.olfchedy.qokedy<->daiin.chefain
→ TORRP  SARNM  ŌRNM  OL?SARNM  COŌRNMNUII?  SAR?UI?

`f40v.14`  saiin.o.lchey.kchedy.okar.qokchdy.dy<->qokees.am.chdy
→ PUII?  O  LSARM  ŌSARNM  OŌUR  COŌSANM  NMCOŌRRP  US  SANM

`f40v.15`  qokchey.qody.or.aiiin.o,kaiin.o,ckhy<->sheod.faimy
→ COŌSARM  CONM  OR  UIII?  OŌUII?  OSŌAMPARON  ?UISM

`f40v.16`  shol.kedy.lor.ar.okar.qoky.kedy.r<->yteey.qokam
→ PAOL  ŌRNM  LOR  UR  OŌUR  COŌM  ŌRNM  RMTRRM  COŌUS

`f40v.17`  tochey.qokeedy.qokaiin.okeos.qokar<->okees.ar.o[k:?]y
→ TOSARM  COŌRRNM  COŌUII?  OŌROP  COŌUROŌRRP  UR  OŌM

`f40v.18`  saiin.otain.chckhy.okal.okair.arol<->qokey.okary
→ PUII?  OTUI?  SASŌAM  OŌUL  OŌUIR  UROLCOŌRM  OŌURM

`f40v.19`  pchedy.chetar.ofair.arody
→ MSARNM  SARTUR  O?UIR  URONM

### f41r  ·  herbal

`f41r.1`  pshey,kedal[ee:ch]y.oked.seekeeey<->opshes.[o:y]p[ch:ee]d.qotchedy.shkakeedy
→ MPARMŌRNULRRM  OŌRN  PRRŌRRRMOMPARP  OMSAN  COTSARNM  PAŌUŌRRNM

`f41r.2`  ykeeo.alshey,ykedy.kesh,dy.dy<->dor.[y:q]cheoky.qokee[d:?].chpy.qokedy.dy
→ MŌRRO  ULPARMMŌRNM  ŌRPANM  NMNOR  MSAROŌM  COŌRRN  SAMM  COŌRNM  NM

`f41r.3`  qok.sa[y:?].[q:y][o:e]kedy.ychdykchdy<->qokedy.qokedy.shekchy.cheky.daly
→ COŌ  PUM  COŌRNM  MSANMŌSANMCOŌRNM  COŌRNM  PARŌSAM  SARŌM  NULM

`f41r.4`  chdchy.ytcheeky.ypchedy.schdy<->ytedy.{cthh}y.chees.oteey.otal.da[m:g]
→ SANSAM  MTSARRŌM  MMSARNM  PSANMMTRNM  STAAM  SARRP  OTRRM  OTUL  NUS

`f41r.5`  qotchy.sal.yteedy.kchdy<->dchedy.k[ee:ch]dy.dchedy.dalain
→ COTSAM  PUL  MTRRNM  ŌSANMNSARNM  ŌRRNM  NSARNM  NULUI?

`f41r.6`  shedey.polchedy.qokeey.chekedy.ytey<->chkeeod<->ypchedpy.shepy.shedy
→ PARNRM  MOLSARNM  COŌRRM  SARŌRNM  MTRMSAŌRRONMMSARNMM  PARMM  PARNM

`f41r.7`  parchdy.kchey.yteedy.qokeod[o:y]<->okedy.chkedy.qokedy.ched[y:e].qokedy
→ MURSANM  ŌSARM  MTRRNM  COŌRONOOŌRNM  SAŌRNM  COŌRNM  SARNM  COŌRNM

`f41r.8`  dair.chedy.chckhy.qokey.lchdy<->qokedy.qokal.chekedy.qodar,a[g:j]
→ NUIR  SARNM  SASŌAM  COŌRM  LSANMCOŌRNM  COŌUL  SARŌRNM  CONURU?

`f41r.9`  qokeedy.okedy.chekedy.chedy<->chckheody.chekol.daiin.cheo.al.otedy
→ COŌRRNM  OŌRNM  SARŌRNM  SARNMSASŌARONM  SARŌOL  NUII?  SARO  UL  OTRNM

`f41r.10`  sshok.shedy.qekchdy.dchdaldy<->ykedy.qokeedy.qokedy.qokeg
→ PPAOŌ  PARNM  CRŌSANM  NSANULNMMŌRNM  COŌRRNM  COŌRNM  COŌR?

`f41r.11`  ykeod.ykeedy.chekeedy.cheked
→ MŌRON  MŌRRNM  SARŌRRNM  SARŌRN

### f41v  ·  herbal

`f41v.1`  keer[e:o]dal
→ ŌRRRRNUL

`f41v.2`  pcheody.qofcheepy.ofchdy.cfhekchdy<->ypchedy.chepchefy.shdchdy.qotal.dar
→ MSARONM  CO?SARRMM  O?SANM  S?ARŌSANMMMSARNM  SARMSAR?M  PANSANM  COTUL  NUR

`f41v.3`  dshedy.tchey.s,aiin.shekey.okedy.okaly<->daiin.okedy.ykeeody.choy.keoy.dam
→ NPARNM  TSARM  PUII?  PARŌRM  OŌRNM  OŌULMNUII?  OŌRNM  MŌRRONM  SAOM  ŌROM  NUS

`f41v.4`  qoke[o:d]dy.okey.qokeody.oleeol.lkedy<->lkeeody.qokeedy.okeey.qokol.sheols
→ COŌRONM  OŌRM  COŌRONM  OLRROL  LŌRNMLŌRRONM  COŌRRNM  OŌRRM  COŌOL  PAROLP

`f41v.5`  ycheos.olchey.daiin.or.chol[a:o]laiin<->oteedy.qoteol.oteodar.orain
→ MSAROP  OLSARM  NUII?  OR  SAOLULUII?OTRRNM  COTROL  OTRONUR  ORUI?

`f41v.6`  tadaiin.ol.cheos.yteedy.okal.[o:a]ld<->oteol.qokal.or.oteody
→ TUNUII?  OL  SAROP  MTRRNM  OŌUL  OLNOTROL  COŌUL  OR  OTRONM

`f41v.7`  ykeey.okey.ykeeol.ckhdy.chdal<->ykeo,aiin.okeody.oly
→ MŌRRM  OŌRM  MŌRROL  SŌANM  SANULMŌROUII?  OŌRONM  OLM

`f41v.8`  daiin.olkeeo.lkol,chedy.okeey
→ NUII?  OLŌRRO  LŌOLSARNM  OŌRRM

### f42r  ·  herbal

`f42r.1`  {c@155;h}o.ofaiin.ctha{ih}{c@196;h}y.otcheey.pchear
→ SAO  O?UII?  STAUIASAM  OTSARRM  MSARUR

`f42r.2`  solkaiin.char.cheky.otshaiin.daiir[y:a]
→ POLŌUII?  SAUR  SARŌM  OTPAUII?  NUIIRM

`f42r.3`  toshy.chtshar.chotar.chain.dal
→ TOPAM  SATPAUR  SAOTUR  SAUI?  NUL

`f42r.4`  shor.chetar.chotai[s:r].dar.cthaiin
→ PAOR  SARTUR  SAOTUIP  NUR  STAUII?

`f42r.5`  qokar.chockhy.chotor.chy.kary
→ COŌUR  SAOSŌAM  SAOTOR  SAM  ŌURM

`f42r.6`  dorain.[{ih}:ch]ar
→ NORUI?  IAUR

`f42r.7`  pcho.chy.kshaiin.shotaiin.cham.shan
→ MSAO  SAM  ŌPAUII?  PAOTUII?  SAUS  PAU?

`f42r.8`  yshol.chees.cthol.shor.shol.ety.char,y
→ MPAOL  SARRP  STAOL  PAOR  PAOL  RTM  SAURM

`f42r.9`  qotch[a:o]r.otchol.ctho.kchodan.chkchory
→ COTSAUR  OTSAOL  STAO  ŌSAONU?  SAŌSAORM

`f42r.10`  choty.dol.ksheo.cthor.otol.cthol.chol<->shol,dain
→ SAOTM  NOL  ŌPARO  STAOR  OTOL  STAOL  SAOLPAOLNUI?

`f42r.11`  qotor.cho.chody.daiin.shol.ctheey.dar<->chy.daiidy
→ COTOR  SAO  SAONM  NUII?  PAOL  STARRM  NURSAM  NUIINM

`f42r.12`  dcheey.chol.shol.chokaiin.choeky.d{cky}<->dain.dal
→ NSARRM  SAOL  PAOL  SAOŌUII?  SAORŌM  NSŌMNUI?  NUL

`f42r.13`  qopor.shol.shot.shol.shol.daiin.dain.s<->cheam
→ COMOR  PAOL  PAOT  PAOL  PAOL  NUII?  NUI?  PSARUS

`f42r.14`  sho,kshey.choty.chdain.chodaiin.daiin<->dam
→ PAOŌPARM  SAOTM  SANUI?  SAONUII?  NUII?NUS

`f42r.15`  pchody.otshey.dodaiin
→ MSAONM  OTPARM  NONUII?

`f42r.16`  pydaiin.sheor.shaiin.tsh.olchy.sholy
→ MMNUII?  PAROR  PAUII?  TPA  OLSAM  PAOLM

`f42r.17`  shotol,shol.chety.daiin.chokchy.chkaiin
→ PAOTOLPAOL  SARTM  NUII?  SAOŌSAM  SAŌUII?

`f42r.18`  qody.cthochy.otaiin.shy.kshes.chorain
→ CONM  STAOSAM  OTUII?  PAM  ŌPARP  SAORUI?

`f42r.19`  otchoty.daiin.chot,sho.{ck@191;h}y,{cty},s.os
→ OTSAOTM  NUII?  SAOTPAO  SŌAMSTMP  OP

`f42r.20`  shol.chol.shoky.okol.sho.chol.shol.chal
→ PAOL  SAOL  PAOŌM  OŌOL  PAO  SAOL  PAOL  SAUL

`f42r.21`  shol.chol.chol.shol.{ct}oiin.{c'o}s.odan
→ PAOL  SAOL  SAOL  PAOL  STOII?  SOP  ONU?

`f42r.22`  kchaiin.chos.ckhaiin.choro,r.chaiin
→ ŌSAUII?  SAOP  SŌAUII?  SAOROR  SAUII?

`f42r.23`  okchol,shol.kolschees
→ OŌSAOLPAOL  ŌOLPSARRP

### f42v  ·  herbal

`f42v.1`  @156;cho.{cto}.sheey.qocho.taiin.shols<->chol.chor.dain
→ SAO  STO  PARRM  COSAO  TUII?  PAOLPSAOL  SAOR  NUI?

`f42v.2`  dshey.tchey.y.kchey.chtchy.{c@245;h}y.dan<->dain.otol.daiin
→ NPARM  TSARM  M  ŌSARM  SATSAM  SAM  NU?NUI?  OTOL  NUII?

`f42v.3`  sho.chotody.chotol.oky.chol.chol<->dl.chcthy.otoy
→ PAO  SAOTONM  SAOTOL  OŌM  SAOL  SAOLNL  SASTAM  OTOM

`f42v.4`  qotchy.chkchy.sar.dy<->odaiil<->ykchy.o,kol,dg
→ COTSAM  SAŌSAM  PUR  NMONUIILMŌSAM  OŌOLN?

`f42v.5`  chokeeo,r.chey.chetan<->s,ary<->okol.chetaiin
→ SAOŌRROR  SARM  SARTU?PURMOŌOL  SARTUII?

`f42v.6`  okeokear.cheotchar<->sy<->saiin.cthar,d,am
→ OŌROŌRUR  SAROTSAURPMPUII?  STAURNUS

`f42v.7`  chok.sheo,key.keeeyd<->chekeesshy
→ SAOŌ  PAROŌRM  ŌRRRMNSARŌRRPPAM

`f42v.8`  sodal.saiin
→ PONUL  PUII?

`f42v.9`  posheor.sho.char.chekchey.qokod<->sho.cpheo.rchy
→ MOPAROR  PAO  SAUR  SARŌSARM  COŌONPAO  SMARO  RSAM

`f42v.10`  schor.okchey.chy.shol.olor.cheaiin<->{ct}chy.tcheeb,d
→ PSAOR  OŌSARM  SAM  PAOL  OLOR  SARUII?STSAM  TSARR?N

`f42v.11`  qo.aiin.qokeey.kchol.cheal.o,t,eold<->shey.teaiin,d
→ CO  UII?  COŌRRM  ŌSAOL  SARUL  OTROLNPARM  TRUII?N

`f42v.12`  ch[o:a]tcheey.chol.ol.chaiin.oteeaiin<->chkchy.taiin,y
→ SAOTSARRM  SAOL  OL  SAUII?  OTRRUII?SAŌSAM  TUII?M

`f42v.13`  sho.chey.teor.shey.che{cthh}y.daiin<->chokeey.daiin
→ PAO  SARM  TROR  PARM  SARSTAAM  NUII?SAOŌRRM  NUII?

`f42v.14`  qoteey.chy.kchy.cthy.{cts}ees.choly<->sarar.aral
→ COTRRM  SAM  ŌSAM  STAM  STPRRP  SAOLMPURUR  URUL

`f42v.15`  chokey.chol.okey
→ SAOŌRM  SAOL  OŌRM

`f42v.16`  okor.odeey
→ OŌOR  ONRRM

### f43r  ·  herbal

`f43r.1`  tarodaiin.ytedy.eeody.ofchtar.chcphedy.ypar.shol.folor.aiin.cphey.dar
→ TURONUII?  MTRNM  RRONM  O?SATUR  SASMARNM  MMUR  PAOL  ?OLOR  UII?  SMARM  NUR

`f43r.2`  yteody.oteol.ytedy.ar.chety.dar.aiir.okaldy.daral.otchdy.daiin.dals
→ MTRONM  OTROL  MTRNM  UR  SARTM  NUR  UIIR  OŌULNM  NURUL  OTSANM  NUII?  NULP

`f43r.3`  yty.yty.oty.she.ody.shy.olor.yteedy.kaiin.chky.qotydy.dar.aiin.ykam
→ MTM  MTM  OTM  PAR  ONM  PAM  OLOR  MTRRNM  ŌUII?  SAŌM  COTMNM  NUR  UII?  MŌUS

`f43r.4`  das,ar.ytey,tedy,kar.arar.she.kalchdy.cholky.qotaly.chedy.oty.otam
→ NUPUR  MTRMTRNMŌUR  URUR  PAR  ŌULSANM  SAOLŌM  COTULM  SARNM  OTM  OTUS

`f43r.5`  ykar.ch[e:i]dy.shekody.qotody.qotar.okedy.dar.choetchy.dam.otain.y,tam
→ MŌUR  SARNM  PARŌONM  COTONM  COTUR  OŌRNM  NUR  SAORTSAM  NUS  OTUI?  MTUS

`f43r.6`  kchedy.chedy.daly.cheody.cheolkeepchy
→ ŌSARNM  SARNM  NULM  SARONM  SAROLŌRRMSAM

`f43r.7`  pshesy.otey,kshdy.opchdy.kedar.okedy.chdy.sho{cphh}y.dyty,dy.pchdy.kedy.dam
→ MPARPM  OTRMŌPANM  OMSANM  ŌRNUR  OŌRNM  SANM  PAOSMAAM  NMTMNM  MSANM  ŌRNM  NUS

`f43r.8`  ytchedy.chedy.cheody.shy.qoiiin.sheeeky.chedy.dain.shy.ykolor.[o:a]taiin.old
→ MTSARNM  SARNM  SARONM  PAM  COIII?  PARRRŌM  SARNM  NUI?  PAM  MŌOLOR  OTUII?  OLN

`f43r.9`  dshedy.qotedy.dor.cheey.odain
→ NPARNM  COTRNM  NOR  SARRM  ONUI?

`f43r.10`  pshdar.shed.ody.qotedy.yfchdy.qo{ckhh}dy.opchdy.daiin.qokedy.dydydy.qotar
→ MPANUR  PARN  ONM  COTRNM  M?SANM  COSŌAANM  OMSANM  NUII?  COŌRNM  NMNMNM  COTUR

`f43r.11`  ytchedy.ty.shol.t[o:a]ldy.shody.oteedy.shdy.otolol.shd.olky.ytol.otary.cheky,dy
→ MTSARNM  TM  PAOL  TOLNM  PAONM  OTRRNM  PANM  OTOLOL  PAN  OLŌM  MTOL  OTURM  SARŌMNM

`f43r.12`  dor.shol.qokol,shedy.qotedy.qokeedy.qokody.okeedy.otedy.shedy.oty.yty,dy.saiin
→ NOR  PAOL  COŌOLPARNM  COTRNM  COŌRRNM  COŌONM  OŌRRNM  OTRNM  PARNM  OTM  MTMNM  PUII?

`f43r.13`  tshed.qosheckhey.odeeedy.qeokeey.qotedy.daiin.shodody.shochol.chckhy.y,kedydy
→ TPARN  COPARSŌARM  ONRRRNM  CROŌRRM  COTRNM  NUII?  PAONONM  PAOSAOL  SASŌAM  MŌRNMNM

`f43r.14`  ykeody.checkhy.choteey.odain.ch{ckhhh}y.chokoraiin
→ MŌRONM  SARSŌAM  SAOTRRM  ONUI?  SASŌAAAM  SAOŌORUII?

### f43v  ·  herbal

`f43v.1`  pdsairy.dalteoshy.d[o:a]ly.sheet.or.arodl.lkeo.r.araiin.otedy.opolde
→ MNPUIRM  NULTROPAM  NOLM  PARRT  OR  URONL  LŌRO  R  URUII?  OTRNM  OMOLNR

`f43v.2`  shedy.octhy.otedy.chedy.dar.ches{kh}y.okeody.oky.okaldy.kchdy.okar
→ PARNM  OSTAM  OTRNM  SARNM  NUR  SARPŌAM  OŌRONM  OŌM  OŌULNM  ŌSANM  OŌUR

`f43v.3`  tody.teedy.qot.chocthy.chky.oky.chdy.okedy.ykaiin.chey.ody.dary
→ TONM  TRRNM  COT  SAOSTAM  SAŌM  OŌM  SANM  OŌRNM  MŌUII?  SARM  ONM  NURM

`f43v.4`  d{ch'h}ey,ykeedy.chees.ain.shy.qocthedy.chey.qokar.checkhy.okam
→ NSAARMMŌRRNM  SARRP  UI?  PAM  COSTARNM  SARM  COŌUR  SARSŌAM  OŌUS

`f43v.5`  qokchedy.oralody.otedol.chcthdy.chtey
→ COŌSARNM  ORULONM  OTRNOL  SASTANM  SATRM

`f43v.6`  tolkchdy.okedy.qoked[a:o]l.shedy.okedal.shedy.pchdol.otey.dalorain
→ TOLŌSANM  OŌRNM  COŌRNUL  PARNM  OŌRNUL  PARNM  MSANOL  OTRM  NULORUI?

`f43v.7`  ytshedy.ykeody.oykeedy.chedy.tedy.chcthy.otam.ot.ytaiin.otas
→ MTPARNM  MŌRONM  OMŌRRNM  SARNM  TRNM  SASTAM  OTUS  OT  MTUII?  OTUP

`f43v.8`  shetcheodchs.ochedy.oteody.chedy.chody.daiin.sheody.ykar.chef
→ PARTSARONSAP  OSARNM  OTRONM  SARNM  SAONM  NUII?  PARONM  MŌUR  SAR?

`f43v.9`  yt[ch:ee]dy.olos.aiin.ockhy
→ MTSANM  OLOP  UII?  OSŌAM

`f43v.10`  tarchor.ar.aldar.chdy.daldar.chepy.yteedy.s,ypchey,pchedy.yfor
→ TURSAOR  UR  ULNUR  SANM  NULNUR  SARMM  MTRRNM  PMMSARMMSARNM  M?OR

`f43v.11`  ysheey.or,air.yteey.cheody.ar.sheo.qody.chckhy.chdy.choty.she{cthy}
→ MPARRM  ORUIR  MTRRM  SARONM  UR  PARO  CONM  SASŌAM  SANM  SAOTM  PARSTAM

`f43v.12`  yshee.kedy.dar.chey.qotedy.etaiin.chedy.cthey.oteol.or,aiin.odain
→ MPARR  ŌRNM  NUR  SARM  COTRNM  RTUII?  SARNM  STARM  OTROL  ORUII?  ONUI?

`f43v.13`  dshedy.tedy.ckhedy.chekcheey.dy,keody.otedy.cheetam.okedar.amam
→ NPARNM  TRNM  SŌARNM  SARŌSARRM  NMŌRONM  OTRNM  SARRTUS  OŌRNUR  USUS

`f43v.14`  dykeedain.chedy.okeedy.chedal.olkey.cheky.cho[a:y]l,chedy.oteorom
→ NMŌRRNUI?  SARNM  OŌRRNM  SARNUL  OLŌRM  SARŌM  SAOULSARNM  OTROROS

`f43v.15`  oteod.qolkeey.kaldy.chy.darod[y:?].qokeey.kol.dary.taros
→ OTRON  COLŌRRM  ŌULNM  SAM  NURONM  COŌRRM  ŌOL  NURM  TUROP

`f43v.16`  ol.eees.aiin.oloaiin.oteos.qoky.chey
→ OL  RRRP  UII?  OLOUII?  OTROP  COŌM  SARM

### f44r  ·  herbal

`f44r.1`  tshodpy.ora{iph}y.koees.ypsholy.shy.otoloaiin
→ TPAONMM  ORUIMAM  ŌORRP  MMPAOLM  PAM  OTOLOUII?

`f44r.2`  ydsh.dyeees.y,ty.oky.okchey.qykchey.dchy,dy
→ MNPA  NMRRRP  MTM  OŌM  OŌSARM  CMŌSARM  NSAMNM

`f44r.3`  oair.ekokeey.kshotol.otal.daiin.ototaykal
→ OUIR  RŌOŌRRM  ŌPAOTOL  OTUL  NUII?  OTOTUMŌUL

`f44r.4`  ychor.ykchey.ykchy.chody.dam
→ MSAOR  MŌSARM  MŌSAM  SAONM  NUS

`f44r.5`  toy.shysho.qoteey.char.cheeky.sheey.ytey.daiin
→ TOM  PAMPAO  COTRRM  SAUR  SARRŌM  PARRM  MTRM  NUII?

`f44r.6`  dshor.y,tchol.shy.o.@190;cheekchy.qotchy.otchy.dar
→ NPAOR  MTSAOL  PAM  O  SARRŌSAM  COTSAM  OTSAM  NUR

`f44r.7`  qot{ch'}.o[q:y]d.shol.qotshy.oyty.chom
→ COTSA  OCN  PAOL  COTPAM  OMTM  SAOS

`f44r.8`  pshy.opchey.qopchy.ofchey.roiry.sholos.ykchy
→ MPAM  OMSARM  COMSAM  O?SARM  ROIRM  PAOLOP  MŌSAM

`f44r.9`  otchol.ol,dchckhy.qoky.qotchy.qokchy.qokyd
→ OTSAOL  OLNSASŌAM  COŌM  COTSAM  COŌSAM  COŌMN

`f44r.10`  qokchor.okchy.qoto.ykol.choky.choky.chol,dam
→ COŌSAOR  OŌSAM  COTO  MŌOL  SAOŌM  SAOŌM  SAOLNUS

`f44r.11`  ytsho.qockhy.okchody
→ MTPAO  COSŌAM  OŌSAONM

### f44v  ·  herbal

`f44v.1`  tsho.qotshy.cthol.d.chor.otol.shol.tol.qotshol.otoldy
→ TPAO  COTPAM  STAOL  N  SAOR  OTOL  PAOL  TOL  COTPAOL  OTOLNM

`f44v.2`  yolkol.cheol.qokchain.daly.otchol.daiin.shol.qotor.ar
→ MOLŌOL  SAROL  COŌSAUI?  NULM  OTSAOL  NUII?  PAOL  COTOR  UR

`f44v.3`  tol.okchor.shcthy.otol.daiin.cthy.cthy
→ TOL  OŌSAOR  PASTAM  OTOL  NUII?  STAM  STAM

`f44v.4`  yokalod.shaiin.shor.shorody.shky.sho.y,tchy.opchod.opy
→ MOŌULON  PAUII?  PAOR  PAORONM  PAŌM  PAO  MTSAM  OMSAON  OMM

`f44v.5`  oain.shol.cthy.cphaiin.ykchor.otchy.qoty.ytchear.cthain
→ OUI?  PAOL  STAM  SMAUII?  MŌSAOR  OTSAM  COTM  MTSARUR  STAUI?

`f44v.6`  tol.dair.ytaiin.dol,y.kchain.oty,keey.otchol.ytaiin,dy
→ TOL  NUIR  MTUII?  NOLM  ŌSAUI?  OTMŌRRM  OTSAOL  MTUII?NM

`f44v.7`  ok[y:o],tchaiin.cthol.dy.cheol.ololy
→ OŌMTSAUII?  STAOL  NM  SAROL  OLOLM

`f44v.8`  tsheody.cthaiin.odaiin.shol.shey.cthy<->ykoda<->ol
→ TPARONM  STAUII?  ONUII?  PAOL  PARM  STAMMŌONUOL

`f44v.9`  dshor.cthees.l,o,lkeees.ckhy.chcthy.lo
→ NPAOR  STARRP  LOLŌRRRP  SŌAM  SASTAM  LO

`f44v.10`  lsho.qokchy.tshy.cphaiin.cthal.kal
→ LPAO  COŌSAM  TPAM  SMAUII?  STAUL  ŌUL

`f44v.11`  okal.chol.chol.choky.okaiin.cthy.otal
→ OŌUL  SAOL  SAOL  SAOŌM  OŌUII?  STAM  OTUL

`f44v.12`  ychey.teol.chaiin.chcthy.ctho.cthol
→ MSARM  TROL  SAUII?  SASTAM  STAO  STAOL

`f44v.13`  lchor.shol.dairl
→ LSAOR  PAOL  NUIRL

### f45r  ·  herbal

`f45r.1`  pykydal.sha{ikh}y.oty.shey.qop.char.opchal.ypchor.ofchar
→ MMŌMNUL  PAUIŌAM  OTM  PARM  COM  SAUR  OMSAUL  MMSAOR  O?SAUR

`f45r.2`  shor.cthy.qoky.qokol.qokaiin.chol.chol.ykaiin.dar.om
→ PAOR  STAM  COŌM  COŌOL  COŌUII?  SAOL  SAOL  MŌUII?  NUR  OS

`f45r.3`  qo.chcthy.kchol.daiin.qoaiin.cthy.chaiin.ykeey.cthom
→ CO  SASTAM  ŌSAOL  NUII?  COUII?  STAM  SAUII?  MŌRRM  STAOS

`f45r.4`  lor.y.kaiin.ykeol.ykeol.cham
→ LOR  M  ŌUII?  MŌROL  MŌROL  SAUS

`f45r.5`  kol,sho.pchor.kchey.ty.opchaldy.otshy.qokchy.dol,daiin
→ ŌOLPAO  MSAOR  ŌSARM  TM  OMSAULNM  OTPAM  COŌSAM  NOLNUII?

`f45r.6`  otchar.okchar.daiin.ytchody.tcholol.otar.dal.dary
→ OTSAUR  OŌSAUR  NUII?  MTSAONM  TSAOLOL  OTUR  NUL  NURM

`f45r.7`  lchar.qor.y.kar.dar
→ LSAUR  COR  M  ŌUR  NUR

`f45r.8`  tchol.cthy.qodaiin.cthy.dain.{@246;thh}ey.otydal.daiin.[g:d]
→ TSAOL  STAM  CONUII?  STAM  NUI?  TAARM  OTMNUL  NUII?  ?

`f45r.9`  @201;or.or.chain.dain.ykolody.ytaiin.qotchol.kol.dy
→ OR  OR  SAUI?  NUI?  MŌOLONM  MTUII?  COTSAOL  ŌOL  NM

`f45r.10`  okaiin.shar.yky.oky.kair.daldy.dalor.cheol.dal
→ OŌUII?  PAUR  MŌM  OŌM  ŌUIR  NULNM  NULOR  SAROL  NUL

`f45r.11`  l.okaiin.okcho.laldan.daldaiin
→ L  OŌUII?  OŌSAO  LULNU?  NULNUII?

### f45v  ·  herbal

`f45v.1`  ko[r:s]ary.chko.kol,chey.fsholom.shor.ykchy.dod.opchaiin.olald
→ ŌORURM  SAŌO  ŌOLSARM  ?PAOLOS  PAOR  MŌSAM  NON  OMSAUII?  OLULN

`f45v.2`  okol.chor.daiin.cthy.okchol.chom.okolo[r:n].dy<->okchol.s
→ OŌOL  SAOR  NUII?  STAM  OŌSAOL  SAOS  OŌOLOR  NMOŌSAOL  P

`f45v.3`  qokchy.l,or.cheol.qot[o:a]l.qotol,chy.ky.cthod<->ykar,yd
→ COŌSAM  LOR  SAROL  COTOL  COTOLSAM  ŌM  STAONMŌURMN

`f45v.4`  okchy.qockhy.dain.dail.dair.shy
→ OŌSAM  COSŌAM  NUI?  NUIL  NUIR  PAM

`f45v.5`  qotol.choiin.okchar.dar.oty<->shoto.dol,py<->otytam
→ COTOL  SAOII?  OŌSAUR  NUR  OTMPAOTO  NOLMMOTMTUS

`f45v.6`  ?s,aiin.cphor.qok{cy}.tod<->ytchdy.dy<->dy.cheg
→ PUII?  SMAOR  COŌSM  TONMTSANM  NMNM  SAR?

`f45v.7`  tchtcho,kchol.dshy.o,tyol<->ytchom
→ TSATSAOŌSAOL  NPAM  OTMOLMTSAOS

`f45v.8`  yksheor.odal.sho.dy.pchom<->otor.oa[iir:iin]
→ MŌPAROR  ONUL  PAO  NM  MSAOSOTOR  OUIIR

`f45v.9`  ychor.cthy.chol.qokom.sy<->sa,ykchom
→ MSAOR  STAM  SAOL  COŌOS  PMPUMŌSAOS

`f45v.10`  dshor.otshy.oky.tsholol<->ytchord
→ NPAOR  OTPAM  OŌM  TPAOLOLMTSAORN

`f45v.11`  or,chor.ytchy.doiin.dcholdy
→ ORSAOR  MTSAM  NOII?  NSAOLNM

### f46r  ·  herbal

`f46r.1`  pcheocphy.qotedy.chety.dy.chepchx.yfcheky.o[s:r]aiin.shee.qoteol.daiin.shee.dy.daly
→ MSAROSMAM  COTRNM  SARTM  NM  SARMSA?  M?SARŌM  OPUII?  PARR  COTROL  NUII?  PARR  NM  NULM

`f46r.2`  sodaiin.sheeoly.qoor.sheo,teoly.chckhy.daiin.sh[{ck}:ek].sheet.shedy.xo[r:s].aiin.sheckhy
→ PONUII?  PARROLM  COOR  PAROTROLM  SASŌAM  NUII?  PASŌ  PARRT  PARNM  ?OR  UII?  PARSŌAM

`f46r.3`  daiin.shor.ykal.che[{kh}:{th}]y.daiin.she.dalshedy.qokol.s.aiin.shee.ykar.daiin
→ NUII?  PAOR  MŌUL  SARŌAM  NUII?  PAR  NULPARNM  COŌOL  P  UII?  PARR  MŌUR  NUII?

`f46r.4`  tshedar.chol.kaldy.chckhy.qokaldy.chekal.chckhy.sheky.sheky.dalo{cthh}y
→ TPARNUR  SAOL  ŌULNM  SASŌAM  COŌULNM  SARŌUL  SASŌAM  PARŌM  PARŌM  NULOSTAAM

`f46r.5`  okeedy.shekeey.ykey.shedy.chdy.shky.qotsheod.ytedy.ytey.che[o:a]r
→ OŌRRNM  PARŌRRM  MŌRM  PARNM  SANM  PAŌM  COTPARON  MTRNM  MTRM  SAROR

`f46r.6`  tedy.d[y:o]tedy.shee.keedy.ypchedy.chdalor.sheedy.odo[s:r],aiin.opchedy.dykedy.chdam
→ TRNM  NMTRNM  PARR  ŌRRNM  MMSARNM  SANULOR  PARRNM  ONOPUII?  OMSARNM  NMŌRNM  SANUS

`f46r.7`  xol.shol.qokaiin.ytchdy.qokchdy.s,ar.chdy.cthy.otedy.chedy.qokar.chcthy.m
→ ?OL  PAOL  COŌUII?  MTSANM  COŌSANM  PUR  SANM  STAM  OTRNM  SARNM  COŌUR  SASTAM  S

`f46r.8`  dsheol.chy.chckhy.shy.shdy.chky.chody.cthdy.s.cheos.chey
→ NPAROL  SAM  SASŌAM  PAM  PANM  SAŌM  SAONM  STANM  P  SAROP  SARM

`f46r.9`  tshdy.shdy.fchedy.dyfchdy.shol.kees,ytaly.fchdy.dy.karal.shky.yty.dardam
→ TPANM  PANM  ?SARNM  NM?SANM  PAOL  ŌRRPMTULM  ?SANM  NM  ŌURUL  PAŌM  MTM  NURNUS

`f46r.10`  tchey.shy.chkal.chd.qokdy.shdy.adoldy.olaiir.sheol
→ TSARM  PAM  SAŌUL  SAN  COŌNM  PANM  UNOLNM  OLUIIR  PAROL

`f46r.11`  pchdair.shd.shep,daiin.shdy.o{ifh}edy.qopchdy.ldy.shear.opdarshdy.s.@136;yfchedy
→ MSANUIR  PAN  PARMNUII?  PANM  OI?ARNM  COMSANM  LNM  PARUR  OMNURPANM  P  M?SARNM

`f46r.12`  techy.daiin.sheockhy.choky.r.aiin.ches.shey.kar.sheckhy.chdy.chckham
→ TRSAM  NUII?  PAROSŌAM  SAOŌM  R  UII?  SARP  PARM  ŌUR  PARSŌAM  SANM  SASŌAUS

`f46r.13`  ar,akaiin.shol.okeey.chol.dar.ols.lain.y
→ URUŌUII?  PAOL  OŌRRM  SAOL  NUR  OLP  LUI?  M

`f46r.14`  otchealkar.sholkshy.qokar.cheol.okal.dam.chdam.qokam
→ OTSARULŌUR  PAOLŌPAM  COŌUR  SAROL  OŌUL  NUS  SANUS  COŌUS

`f46r.15`  qokar.shol,kal.[a:o]lkeody
→ COŌUR  PAOLŌUL  ULŌRONM

### f46v  ·  herbal

`f46v.1`  pody,lshed.ypdy,shedy.opchedy.ytedy.oepchol.yfchey.tochsy.oka[s:r].ykchdy.daiin
→ MONMLPARN  MMNMPARNM  OMSARNM  MTRNM  ORMSAOL  M?SARM  TOSAPM  OŌUP  MŌSANM  NUII?

`f46v.2`  ytair,aiin.otchdy.okaly.daiin.qokedy.otar.ar.oldy.otedy.saim.okey.tody.daiin
→ MTUIRUII?  OTSANM  OŌULM  NUII?  COŌRNM  OTUR  UR  OLNM  OTRNM  PUIS  OŌRM  TONM  NUII?

`f46v.3`  ytchey.keody.chockhdy.chotal.okalshdy.sh[?:d]y.qokar.oty.qoty.shedy.chedy.dam
→ MTSARM  ŌRONM  SAOSŌANM  SAOTUL  OŌULPANM  PAM  COŌUR  OTM  COTM  PARNM  SARNM  NUS

`f46v.4`  ydaiin.chckhy.chdal.olar.chckhdy.chdody.tar.cham.kedy.daiin.y,kaiir.shckhefy
→ MNUII?  SASŌAM  SANUL  OLUR  SASŌANM  SANONM  TUR  SAUS  ŌRNM  NUII?  MŌUIIR  PASŌAR?M

`f46v.5`  lodaiin.shedy.qokedy.chdy.okedy.dykaly.daiin.chedy.okeedy.s,ar,air.cthy
→ LONUII?  PARNM  COŌRNM  SANM  OŌRNM  NMŌULM  NUII?  SARNM  OŌRRNM  PURUIR  STAM

`f46v.6`  tor.aiirchar.shedy.olaiin.qotedy.sheedy.qokaldy.qokedy.d[o:a]ir.chody.cthey.m
→ TOR  UIIRSAUR  PARNM  OLUII?  COTRNM  PARRNM  COŌULNM  COŌRNM  NOIR  SAONM  STARM  S

`f46v.7`  dchedy.cheeky.dam,ched.lchedy.chedy
→ NSARNM  SARRŌM  NUSSARN  LSARNM  SARNM

`f46v.8`  okeedchsy.qokeedy.chetedar.or.ai{cky}y
→ OŌRRNSAPM  COŌRRNM  SARTRNUR  OR  UISŌMM

`f46v.9`  yteedy.shedy.che{ck}edy.chtedy.daim
→ MTRRNM  PARNM  SARSŌRNM  SATRNM  NUIS

`f46v.10`  sheol.[a:o]r.chey.okaiin.daim.oty.om
→ PAROL  UR  SARM  OŌUII?  NUIS  OTM  OS

`f46v.11`  tolshey.otedy.chocpheod.oty.dam
→ TOLPARM  OTRNM  SAOSMARON  OTM  NUS

`f46v.12`  dair.aly.chdam.chcthy.chdam
→ NUIR  ULM  SANUS  SASTAM  SANUS

`f46v.13`  ykar.chedy
→ MŌUR  SARNM

### f47r  ·  herbal

`f47r.1`  @159;chair.oly.sheaiin.shol.daiin.chdy
→ SAUIR  OLM  PARUII?  PAOL  NUII?  SANM

`f47r.2`  chokchol.chol,choldy.dair.cha[d:j],aiin
→ SAOŌSAOL  SAOLSAOLNM  NUIR  SAUNUII?

`f47r.3`  dor.chol.chy.chaiin.ckhey.chol.dain.okaiin
→ NOR  SAOL  SAM  SAUII?  SŌARM  SAOL  NUI?  OŌUII?

`f47r.4`  qokcheo.cthey.chokain.chol.daiin.kchdal
→ COŌSARO  STARM  SAOŌUI?  SAOL  NUII?  ŌSANUL

`f47r.5`  dain.olshey.chokolg
→ NUI?  OLPARM  SAOŌOL?

`f47r.6`  folr.chey,so.chol.shol,aiin.shol.shol.chdy.cholol
→ ?OLR  SARMPO  SAOL  PAOLUII?  PAOL  PAOL  SANM  SAOLOL

`f47r.7`  schesy.kchor.cthaiin.chol.chol.chol.chor.{ck@191;h}ey
→ PSARPM  ŌSAOR  STAUII?  SAOL  SAOL  SAOL  SAOR  SŌARM

`f47r.8`  shokeey.chy.tchod.choy.sho.chtchy.@161;char.ctham
→ PAOŌRRM  SAM  TSAON  SAOM  PAO  SATSAM  SAUR  STAUS

`f47r.9`  qoko,kor.chaiin.okal.chol.daiin.okcho,kcho[r:s]sy
→ COŌOŌOR  SAUII?  OŌUL  SAOL  NUII?  OŌSAOŌSAORPM

`f47r.10`  shy.otcho.keey.tor.chey.otchy.tchol.dain.dam
→ PAM  OTSAO  ŌRRM  TOR  SARM  OTSAM  TSAOL  NUI?  NUS

`f47r.11`  dsho.cphy.daiin.daiiny
→ NPAO  SMAM  NUII?  NUII?M

### f47v  ·  herbal

`f47v.1`  psheot.cheor.cholsho.chopchy.sal<->sary
→ MPAROT  SAROR  SAOLPAO  SAOMSAM  PULPURM

`f47v.2`  dsheey.shy.cphy.otchey.daiidy.chory<->daiiy
→ NPARRM  PAM  SMAM  OTSARM  NUIINM  SAORMNUIIM

`f47v.3`  shol.char.oteol.dor.otchol.chkchy<->daiin
→ PAOL  SAUR  OTROL  NOR  OTSAOL  SAŌSAMNUII?

`f47v.4`  qotol.sheey.kol.sho.keechy.qoty<->cthy
→ COTOL  PARRM  ŌOL  PAO  ŌRRSAM  COTMSTAM

`f47v.5`  dsholy.shees.chor.ody.shy.sy<->sary
→ NPAOLM  PARRP  SAOR  ONM  PAM  PMPURM

`f47v.6`  chody.cheor.saiin.dochod<->chol
→ SAONM  SAROR  PUII?  NOSAONSAOL

`f47v.7`  pchodaiin.dair.dcthy
→ MSAONUII?  NUIR  NSTAM

`f47v.8`  daiin.cheotar.chodaly.sal
→ NUII?  SAROTUR  SAONULM  PUL

`f47v.9`  qotcheey.chety.chol.chol.dain
→ COTSARRM  SARTM  SAOL  SAOL  NUI?

`f47v.10`  chotcho,ltchey.[o:y].tcho,tchy.dy<->chol.chody.dar
→ SAOTSAOLTSARM  O  TSAOTSAM  NMSAOL  SAONM  NUR

`f47v.11`  ot[ee:a:ei]y.cho.chdy.chy.key.chyky<->dchy.daiin.chy
→ OTRRM  SAO  SANM  SAM  ŌRM  SAMŌMNSAM  NUII?  SAM

`f47v.12`  ch[y:o].cho,keesy.chy.chy.cheky<->chochy.daiin
→ SAM  SAOŌRRPM  SAM  SAM  SARŌMSAOSAM  NUII?

`f47v.13`  dshy.daiin.chdlety.chaiin<->dcheey.otald
→ NPAM  NUII?  SANLRTM  SAUII?NSARRM  OTULN

`f47v.14`  chol.{ct}chey
→ SAOL  STSARM

### f48r  ·  herbal

`f48r.1`  pshdaiin.ypchdy.opchey.{c@162;h}y.dal.sheodaiin.sheokeol.ykeeody.olaiin.opaldy
→ MPANUII?  MMSANM  OMSARM  SAM  NUL  PARONUII?  PAROŌROL  MŌRRONM  OLUII?  OMULNM

`f48r.2`  daiin.yteeol.cheody.kechodshey.qotedy.chtaiin.otchdy.tedain.okain.ckhy
→ NUII?  MTRROL  SARONM  ŌRSAONPARM  COTRNM  SATUII?  OTSANM  TRNUI?  OŌUI?  SŌAM

`f48r.3`  sheody.she.teoteey.oteodaiin.ody.qoteo.l.kedy.dol,odal.qotar.opchety.ldy
→ PARONM  PAR  TROTRRM  OTRONUII?  ONM  COTRO  L  ŌRNM  NOLONUL  COTUR  OMSARTM  LNM

`f48r.4`  tolkeol,dain.otaiin.ykeedy.chet.ytedy,tedy.qokdy.tshdy.chetedy.ctheety.r
→ TOLŌROLNUI?  OTUII?  MŌRRNM  SART  MTRNMTRNM  COŌNM  TPANM  SARTRNM  STARRTM  R

`f48r.5`  yteey.teol.okeody.cheockhy.olsheey.qoekaiin.octhey.cholkar.aiin.cthar.od
→ MTRRM  TROL  OŌRONM  SAROSŌAM  OLPARRM  CORŌUII?  OSTARM  SAOLŌUR  UII?  STAUR  ON

`f48r.6`  alshey.lkeedy.ytchedy.qokedy.lotal.qotol.otal,ched.o,key.ykeey.da[l:?]dy
→ ULPARM  LŌRRNM  MTSARNM  COŌRNM  LOTUL  COTOL  OTULSARN  OŌRM  MŌRRM  NULNM

`f48r.7`  tocthy.qokeol.yteedy.lolkeol.otolches.al.ar.ykeeodam.okedy.okam
→ TOSTAM  COŌROL  MTRRNM  LOLŌROL  OTOLSARP  UL  UR  MŌRRONUS  OŌRNM  OŌUS

`f48r.8`  otchdain.shol.oteol.oteoly.ykeey.dam,dr
→ OTSANUI?  PAOL  OTROL  OTROLM  MŌRRM  NUSNR

`f48r.9`  yteched.ar.olkey.okeoam
→ MTRSARN  UR  OLŌRM  OŌROUS

### f48v  ·  herbal

`f48v.1`  pcheodchy.dshedy.fchedy.los.aiin.ykeeedy.shey.ypchedy.teedy.chdy.ypair,y.chedyty
→ MSARONSAM  NPARNM  ?SARNM  LOP  UII?  MŌRRRNM  PARM  MMSARNM  TRRNM  SANM  MMUIRM  SARNMTM

`f48v.2`  chey.tedy.otchody.ykeedy.otar,yotedy.cthdy<->okain.chety.choolkeey
→ SARM  TRNM  OTSAONM  MŌRRNM  OTURMOTRNM  STANMOŌUI?  SARTM  SAOOLŌRRM

`f48v.3`  alchey.kor.y.keody.olkeeey.chody.chedy.daly<->okeeor.aiin.otar,air,am
→ ULSARM  ŌOR  M  ŌRONM  OLŌRRRM  SAONM  SARNM  NULMOŌRROR  UII?  OTURUIRUS

`f48v.4`  dchedy,tchddy.otsh.okeey.ty.otar.alchdy<->yteedy.oteed.y,kedy.m
→ NSARNMTSANNM  OTPA  OŌRRM  TM  OTUR  ULSANMMTRRNM  OTRRN  MŌRNM  S

`f48v.5`  lkeey.qocthedy.taiin.shed.qokar.otedy.dy<->dain.tolkain.otam
→ LŌRRM  COSTARNM  TUII?  PARN  COŌUR  OTRNM  NMNUI?  TOLŌUI?  OTUS

`f48v.6`  shdy.qokain.okar.otar.or.otees.ol.or.ain<->otal.ok.y,tar.chedy.am
→ PANM  COŌUI?  OŌUR  OTUR  OR  OTRRP  OL  OR  UI?OTUL  OŌ  MTUR  SARNM  US

`f48v.7`  pchedar.chey<->ypchedy.otedy.shef,eeedy.al<->shedy.otedy.fcheodal.cpheeg
→ MSARNUR  SARMMMSARNM  OTRNM  PAR?RRRNM  ULPARNM  OTRNM  ?SARONUL  SMARR?

`f48v.8`  oteody.chkey<->okedy.chckhedy.ykedy.oldy<->otoly.chey.kaly.tokar.otam
→ OTRONM  SAŌRMOŌRNM  SASŌARNM  MŌRNM  OLNMOTOLM  SARM  ŌULM  TOŌUR  OTUS

`f48v.9`  tor.shody.okal<->otchedy.cheky.oly.loldy.lol<->otchdy.otoldy.ytam.otedy
→ TOR  PAONM  OŌULOTSARNM  SARŌM  OLM  LOLNM  LOLOTSANM  OTOLNM  MTUS  OTRNM

`f48v.10`  tol.chedy.ytedy<->ykeol.chdy.chdor.chtol.chdy<->ytchedal.cthey.okar,ar.ary
→ TOL  SARNM  MTRNMMŌROL  SANM  SANOR  SATOL  SANMMTSARNUL  STARM  OŌURUR  URM

`f48v.11`  ykeedal.chckhy<->ykal.y,tam.or.cheedls.[s:d]ary
→ MŌRRNUL  SASŌAMMŌUL  MTUS  OR  SARRNLP  PURM

### f49r  ·  herbal

`f49r.1`  pychol.dy.[sh:ch]or.shol.shtchy.shorpchor.opchor.shor,kchy
→ MMSAOL  NM  PAOR  PAOL  PATSAM  PAORMSAOR  OMSAOR  PAORŌSAM

`f49r.2`  qotor.sho.chotchy.choshy.qopchar.q'o.dor.daiin
→ COTOR  PAO  SAOTSAM  SAOPAM  COMSAUR  CO  NOR  NUII?

`f49r.3`  dsho<->dchor.dchor.daiin.dor.cheoraiin
→ NPAONSAOR  NSAOR  NUII?  NOR  SARORUII?

`f49r.4`  ksh[o:a].qodain.chotshy.dodar
→ ŌPAO  CONUI?  SAOTPAM  NONUR

`f49r.5`  chor.sheor.chey.teey.qotan
→ SAOR  PAROR  SARM  TRRM  COTU?

`f49r.6`  ol,or,sh{e'e}es.sheoty.choldaiin
→ OLORPARRRP  PAROTM  SAOLNUII?

`f49r.7`  qokeor.cheey.qokchy.qotody
→ COŌROR  SARRM  COŌSAM  COTONM

`f49r.8`  chot,chor.chy.cheet.qolsor
→ SAOTSAOR  SAM  SARRT  COLPOR

`f49r.9`  oykeeey.chey.kshey.choroiin
→ OMŌRRRM  SARM  ŌPARM  SAOROII?

`f49r.10`  sho.r.choiin.shor.shor,shy
→ PAO  R  SAOII?  PAOR  PAORPAM

`f49r.11`  chotcheol.dchol
→ SAOTSAROL  NSAOL

`f49r.12`  podaiin.cheo.kcho.daiin.chcthy
→ MONUII?  SARO  ŌSAO  NUII?  SASTAM

`f49r.13`  {c'o}d.chol,y.tcheol.daiin.cthodd
→ SON  SAOLM  TSAROL  NUII?  STAONN

`f49r.14`  q'o.shoqoky.shor.sheor.otol.daiin
→ CO  PAOCOŌM  PAOR  PAROR  OTOL  NUII?

`f49r.15`  ochol.chol.chody.dchodaiin.da'iin
→ OSAOL  SAOL  SAONM  NSAONUII?  NUII?

`f49r.16`  q'ocho.cheey.dchey.qotchody
→ COSAO  SARRM  NSARM  COTSAONM

`f49r.17`  olol,ol.chey.chey.kchy.qotchol.chosory
→ OLOLOL  SARM  SARM  ŌSAM  COTSAOL  SAOPORM

`f49r.18`  sheor.cheol.od.cho.dcheeey.qot,chotchy
→ PAROR  SAROL  ON  SAO  NSARRRM  COTSAOTSAM

`f49r.19`  dcheo.r.cheey.keolchey.chokchol.chokan
→ NSARO  R  SARRM  ŌROLSARM  SAOŌSAOL  SAOŌU?

`f49r.20`  qotcho.chods.cho.cho[ch:sh]y.chs.oriin
→ COTSAO  SAONP  SAO  SAOSAM  SAP  ORII?

`f49r.21`  odch[o:y].chor.ety.shol
→ ONSAO  SAOR  RTM  PAOL

### f49v  ·  herbal

`f49v.1`  f
→ ?

`f49v.2`  kshor.shol.cphokchol.ch{cfhh}y
→ ŌPAOR  PAOL  SMAOŌSAOL  SAS?AAM

`f49v.3`  o
→ O

`f49v.4`  qokchy.qokchod.sho.ckhy
→ COŌSAM  COŌSAON  PAO  SŌAM

`f49v.5`  r
→ R

`f49v.6`  chotchy.chcthy.cthey.koddy
→ SAOTSAM  SASTAM  STARM  ŌONNM

`f49v.7`  y
→ M

`f49v.8`  okeodsho.chotshol.dam
→ OŌRONPAO  SAOTPAOL  NUS

`f49v.9`  e
→ R

`f49v.10`  shol.shodaiin.qotchar
→ PAOL  PAONUII?  COTSAUR

`f49v.11`  @140;
→ —

`f49v.12`  qot[ch:ee]y.chokchy.choky
→ COTSAM  SAOŌSAM  SAOŌM

`f49v.13`  k
→ Ō

`f49v.14`  chotchy.chodaiin.dan
→ SAOTSAM  SAONUII?  NU?

`f49v.15`  s
→ P

`f49v.16`  qoteees.cheo.daiin,dol
→ COTRRRP  SARO  NUII?NOL

`f49v.17`  p
→ M

`f49v.18`  ochor.sheeod.ksheo,dl
→ OSAOR  PARRON  ŌPARONL

`f49v.19`  o
→ O

`f49v.20`  q'oksho,daiin.shckhy,dar
→ COŌPAONUII?  PASŌAMNUR

`f49v.21`  @192;
→ —

`f49v.22`  dchol.cthol.daiin.choky
→ NSAOL  STAOL  NUII?  SAOŌM

`f49v.23`  y
→ M

`f49v.24`  ochokeey.ckhey.daiin.dain.chokag
→ OSAOŌRRM  SŌARM  NUII?  NUI?  SAOŌU?

`f49v.25`  e
→ R

`f49v.26`  qokeol,chokeeody.otol.kcho,s.chol.daiin
→ COŌROLSAOŌRRONM  OTOL  ŌSAOP  SAOL  NUII?

`f49v.27`  @140;
→ —

`f49v.28`  fchochor.shol.tchol.opcheodal.dchsy<->chotchy
→ ?SAOSAOR  PAOL  TSAOL  OMSARONUL  NSAPMSAOTSAM

`f49v.29`  @164;
→ —

`f49v.30`  dcho.d.chol.chokchodaiin.chokchy.tchol<->okchokol
→ NSAO  N  SAOL  SAOŌSAONUII?  SAOŌSAM  TSAOLOŌSAOŌOL

`f49v.31`  p
→ M

`f49v.32`  tchotchey.chokeeodol.rcheey.otchodar<->dcho.dchog
→ TSAOTSARM  SAOŌRRONOL  RSARRM  OTSAONURNSAO  NSAO?

`f49v.33`  o
→ O

`f49v.34`  shocho.oaiin.sheo.choty
→ PAOSAO  OUII?  PARO  SAOTM

`f49v.35`  @192;
→ —

`f49v.36`  qotcho.cheol.chol,s.cho,chcthey.dcheol<->chotchody
→ COTSAO  SAROL  SAOLP  SAOSASTARM  NSAROLSAOTSAONM

`f49v.37`  y
→ M

`f49v.38`  chokeo.sho.cheor.cheokchet.chor.daiin,dy<->daiin.qok[g:d]
→ SAOŌRO  PAO  SAROR  SAROŌSART  SAOR  NUII?NMNUII?  COŌ?

`f49v.39`  e
→ R

`f49v.40`  oaiin.chy.daiin.chol.chaiin.kshardy<->chokchy
→ OUII?  SAM  NUII?  SAOL  SAUII?  ŌPAURNMSAOŌSAM

`f49v.41`  @140;
→ —

`f49v.42`  qokeaiin.cheo.chor.choteey.kcheol.dain<->cho.dai[s:r]in
→ COŌRUII?  SARO  SAOR  SAOTRRM  ŌSAROL  NUI?SAO  NUIPI?

`f49v.43`  d
→ N

`f49v.44`  chokaiin.cho.dls.chariin.daiin.chain.dy<->chetcho.dy
→ SAOŌUII?  SAO  NLP  SAURII?  NUII?  SAUI?  NMSARTSAO  NM

`f49v.45`  y
→ M

`f49v.46`  oaiin.cheky.@243;.cho.rchseesy.kchor.sol<->chctho.s
→ OUII?  SARŌM  —  SAO  RSAPRRPM  ŌSAOR  POLSASTAO  P

`f49v.47`  e
→ R

`f49v.48`  qotcheol.chey.chor.chokaly.chor,dal<->chaiin,d
→ COTSAROL  SARM  SAOR  SAOŌULM  SAORNULSAUII?N

`f49v.49`  k
→ Ō

`f49v.50`  chol.chor.ches.chkalchy.chokeeoky<->chokoran
→ SAOL  SAOR  SARP  SAŌULSAM  SAOŌRROŌMSAOŌORU?

`f49v.51`  y
→ M

`f49v.52`  ykchokeo.r.cheey.daiin
→ MŌSAOŌRO  R  SARRM  NUII?

### f50r  ·  herbal

`f50r.1`  psheor.olkair.olfchedy.qop[eee:che]dar.opchey.dair.o,laiin.chefchdy
→ MPAROR  OLŌUIR  OL?SARNM  COMRRRNUR  OMSARM  NUIR  OLUII?  SAR?SANM

`f50r.2`  sor.orsheckhy.ockhody.shos.alol.dy.kar.oky.daiiin.okar.ar.okam
→ POR  ORPARSŌAM  OSŌAONM  PAOP  ULOL  NM  ŌUR  OŌM  NUIII?  OŌUR  UR  OŌUS

`f50r.3`  tshol.kar.sheedy.okeody.qokedy.chody.kchdy.pchdy.chkaiin.odam
→ TPAOL  ŌUR  PARRNM  OŌRONM  COŌRNM  SAONM  ŌSANM  MSANM  SAŌUII?  ONUS

`f50r.4`  tchdy.qokas.chedy.qokchdy.qokaiin.or.ar.alol.keodaiin.ols
→ TSANM  COŌUP  SARNM  COŌSANM  COŌUII?  OR  UR  ULOL  ŌRONUII?  OLP

`f50r.5`  solkchy.chckhy.qokchdy.qokchdy.okar.ar.y.qokchdy.kar.ar.okain
→ POLŌSAM  SASŌAM  COŌSANM  COŌSANM  OŌUR  UR  M  COŌSANM  ŌUR  UR  OŌUI?

`f50r.6`  ykain.[sh:{c's}]ear.ol,kchedy.okal.qotor.cheeor.olk[ee:a]dy.daiin.qoky
→ MŌUI?  PARUR  OLŌSARNM  OŌUL  COTOR  SARROR  OLŌRRNM  NUII?  COŌM

`f50r.7`  todalain.qotal.kaiin.otaiin.otal.she.ka[r:s].ariin.okchedy.dariin
→ TONULUI?  COTUL  ŌUII?  OTUII?  OTUL  PAR  ŌUR  URII?  OŌSARNM  NURII?

`f50r.8`  yk,ykaiin.sheekar.otchdy.dar.kar.shedain.taipar.orolkain
→ MŌMŌUII?  PARRŌUR  OTSANM  NUR  ŌUR  PARNUI?  TUIMUR  OROLŌUI?

`f50r.9`  ytchdy.kchedy<->ykeey.kaiin.qokain.ald,[a:y]lo[s:r]am
→ MTSANM  ŌSARNMMŌRRM  ŌUII?  COŌUI?  ULNULOPUS

`f50r.10`  solkaiin<->opalke,chckhy.darin.chky
→ POLŌUII?OMULŌRSASŌAM  NURI?  SAŌM

### f50v  ·  herbal

`f50v.1`  tchy.do.ldar.shotchdy.qokchdy.opchedy.qokol.shor.ofar,fardam
→ TSAM  NO  LNUR  PAOTSANM  COŌSANM  OMSARNM  COŌOL  PAOR  O?UR?URNUS

`f50v.2`  tchodain.oeeey.okaiin.shedy.qokaly.chdy.oky.keody.cheey.okain
→ TSAONUI?  ORRRM  OŌUII?  PARNM  COŌULM  SANM  OŌM  ŌRONM  SARRM  OŌUI?

`f50v.3`  pochedy.qokody.checkhy.shckhy.dalol.ykeeey.qokedy.okain.okal
→ MOSARNM  COŌONM  SARSŌAM  PASŌAM  NULOL  MŌRRRM  COŌRNM  OŌUI?  OŌUL

`f50v.4`  dar.qoain.olaiin.ol[s:r].aiin.o,l.okeedy.okchdy.otar.chckhey.or
→ NUR  COUI?  OLUII?  OLP  UII?  OL  OŌRRNM  OŌSANM  OTUR  SASŌARM  OR

`f50v.5`  y,chy.tair.chckhy.qekaiin.qodaiin.olcheky.chedy.chkedy.okedyd
→ MSAM  TUIR  SASŌAM  CRŌUII?  CONUII?  OLSARŌM  SARNM  SAŌRNM  OŌRNMN

`f50v.6`  daiin.kedair.okal.chody.qokedy.okar.okchey.okedy.ota[r:s].chkeey
→ NUII?  ŌRNUIR  OŌUL  SAONM  COŌRNM  OŌUR  OŌSARM  OŌRNM  OTUR  SAŌRRM

`f50v.7`  tedaiin.odaiin.or.okaiin.ykor.daiin.choky.qotchdy.k[{cy}:ey].dairam
→ TRNUII?  ONUII?  OR  OŌUII?  MŌOR  NUII?  SAOŌM  COTSANM  ŌSM  NUIRUS

`f50v.8`  ykar.okair.otor.qokedy.ykchol.kar.chckhy.olkaiin.okain.qo'd
→ MŌUR  OŌUIR  OTOR  COŌRNM  MŌSAOL  ŌUR  SASŌAM  OLŌUII?  OŌUI?  CON

`f50v.9`  ytsheod.ain.sheshy.echedy.kchdy<->otaiin.okaiin.[o:a]ky
→ MTPARON  UI?  PARPAM  RSARNM  ŌSANMOTUII?  OŌUII?  OŌM

`f50v.10`  dchedy.okaiin.olchdy.oloeedy<->ykeeod,ar.aro[o:a]d
→ NSARNM  OŌUII?  OLSANM  OLORRNMMŌRRONUR  UROON

`f50v.11`  lchey.kar.ykchy.kchdy
→ LSARM  ŌUR  MŌSAM  ŌSANM

### f51r  ·  herbal

`f51r.1`  tsholdchy.qotchy.opchear.ypchedy
→ TPAOLNSAM  COTSAM  OMSARUR  MMSARNM

`f51r.2`  dcheodaiin.ckheody.ckhody.chody
→ NSARONUII?  SŌARONM  SŌAONM  SAONM

`f51r.3`  ydchody.ckhey.oty.ckhe[o:a]dar.qoky
→ MNSAONM  SŌARM  OTM  SŌARONUR  COŌM

`f51r.4`  daiin.{ct}[e:i]s.okol.cheody.ckhy.cheeey
→ NUII?  STRP  OŌOL  SARONM  SŌAM  SARRRM

`f51r.5`  tcheody.qodaiin.okeey.qockhey.taiin
→ TSARONM  CONUII?  OŌRRM  COSŌARM  TUII?

`f51r.6`  ycho,daiin.chokaiin.ykchodaiin.ykald
→ MSAONUII?  SAOŌUII?  MŌSAONUII?  MŌULN

`f51r.7`  ychos,ar.eeckhy.kcho.qokchy.qotal
→ MSAOPUR  RRSŌAM  ŌSAO  COŌSAM  COTUL

`f51r.8`  oshol.odaiin.[ckhe:{ckhh}]y.ckheody.qokey.otydy
→ OPAOL  ONUII?  SŌARM  SŌARONM  COŌRM  OTMNM

`f51r.9`  tol.daiin.daim.qchodal.dal.qody.qoetam
→ TOL  NUII?  NUIS  CSAONUL  NUL  CONM  CORTUS

`f51r.10`  ykchol.d[o:a]r.shey.qokeol.kchey.shol.okam
→ MŌSAOL  NOR  PARM  COŌROL  ŌSARM  PAOL  OŌUS

`f51r.11`  tchodaiin.[{oph}:cph]eody.qokol.ot[e:i]odaiin.kol,ota[g:m]
→ TSAONUII?  OMARONM  COŌOL  OTRONUII?  ŌOLOTU?

`f51r.12`  yoees.ckheey.kol.cheeal.okeor.qockhey.pchodal
→ MORRP  SŌARRM  ŌOL  SARRUL  OŌROR  COSŌARM  MSAONUL

`f51r.13`  oaiin.ckhol.yk[i:?]eol.otchey.cpheo,daiin.ykeoldy
→ OUII?  SŌAOL  MŌIROL  OTSARM  SMARONUII?  MŌROLNM

`f51r.14`  daii{ith}y.qodaiin.kaiiidal<->cphodal<->[s:r].al.dam
→ NUIIITAM  CONUII?  ŌUIIINULSMAONULP  UL  NUS

`f51r.15`  qokol.cheor.ckhal.s.or.aldy<->otal
→ COŌOL  SAROR  SŌAUL  P  OR  ULNMOTUL

### f51v  ·  herbal

`f51v.1`  poshody.qokodar.shodaiin.qotal<->dscheey.saiin,dy
→ MOPAONM  COŌONUR  PAONUII?  COTULNPSARRM  PUII?NM

`f51v.2`  dshody.ckhody.qokol.dykaiin.chy<->qokey.daiin.cthy
→ NPAONM  SŌAONM  COŌOL  NMŌUII?  SAMCOŌRM  NUII?  STAM

`f51v.3`  tchody.cthy.chckhey.qod.ytchody<->dchol.saiin.ytam
→ TSAONM  STAM  SASŌARM  CON  MTSAONMNSAOL  PUII?  MTUS

`f51v.4`  otaiin.qodal.yt[o:a]l.cheodar.s,ody<->oteo,daiin.shokog
→ OTUII?  CONUL  MTOL  SARONUR  PONMOTRONUII?  PAOŌO?

`f51v.5`  todaiin.yt[a:o]dy.qokol.shodol.qockhy<->ykol.otaiin.dar.y
→ TONUII?  MTUNM  COŌOL  PAONOL  COSŌAMMŌOL  OTUII?  NUR  M

`f51v.6`  okor.ctheody.qocphy.qok[a:o]l.qotaiin<->otyk[o:a]l.chol,daiin
→ OŌOR  STARONM  COSMAM  COŌUL  COTUII?OTMŌOL  SAOLNUII?

`f51v.7`  qotol.chodaiin.qokcheody.cho,r.chod<->ycthol.s.olcheety
→ COTOL  SAONUII?  COŌSARONM  SAOR  SAONMSTAOL  P  OLSARRTM

`f51v.8`  olkeeody.qokal.qodaiin.{ykh}or.[{ofa}:{yfa}:?]l
→ OLŌRRONM  COŌUL  CONUII?  MŌAOR  O?UL

`f51v.9`  daiin.ckhol.shain.kcholol
→ NUII?  SŌAOL  PAUI?  ŌSAOLOL

`f51v.10`  ykeol.sheo.qok[o:a]dy.fold
→ MŌROL  PARO  COŌONM  ?OLN

`f51v.11`  ycheoky.sheey.ykeey.chey
→ MSAROŌM  PARRM  MŌRRM  SARM

`f51v.12`  ochockhy.daiin.cho,ckhey
→ OSAOSŌAM  NUII?  SAOSŌARM

`f51v.13`  daiin.cheol.cheodain
→ NUII?  SAROL  SARONUI?

### f52r  ·  herbal

`f52r.1`  tdokchcfhy.ycphko.ytair.shar.qofy,daiin.ypchy.otchol.dar.yty
→ TNOŌSAS?AM  MSMAŌO  MTUIR  PAUR  CO?MNUII?  MMSAM  OTSAOL  NUR  MTM

`f52r.2`  oty.shor.ykoldy.qoky.koldal.oteees.dals<->otar,dl
→ OTM  PAOR  MŌOLNM  COŌM  ŌOLNUL  OTRRRP  NULPOTURNL

`f52r.3`  tchotshey.qoty.okchol.tchody.qotam.oky<->ytoldy
→ TSAOTPARM  COTM  OŌSAOL  TSAONM  COTUS  OŌMMTOLNM

`f52r.4`  l,shopchy.qoky.qotchy.oty.dar.oty.dam<->ychcthod
→ LPAOMSAM  COŌM  COTSAM  OTM  NUR  OTM  NUSMSASTAON

`f52r.5`  oky.chor.okchal.okchar.shor.tol.ykair<->ytchdam
→ OŌM  SAOR  OŌSAUL  OŌSAUR  PAOR  TOL  MŌUIRMTSANUS

`f52r.6`  daiin.shedaiin.qodal.dy.[ch:ee]okam.otchordy<->okchol.do
→ NUII?  PARNUII?  CONUL  NM  SAOŌUS  OTSAORNMOŌSAOL  NO

`f52r.7`  qok[{ch'}:{cs}]y.qockhom.dals.shodaim.tcham.dody<->ykeey.dai[g:m:d].a[m:@175;]
→ COŌSAM  COSŌAOS  NULP  PAONUIS  TSAUS  NONMMŌRRM  NUI?  US

`f52r.8`  or,cheey.dor.shey.kom.s.cheey.dch[o:a]m.daiin
→ ORSARRM  NOR  PARM  ŌOS  P  SARRM  NSAOS  NUII?

### f52v  ·  herbal

`f52v.1`  pchor.chcphol.cphaiiin.otcheor.ytor,kol.chocph[a:o]r
→ MSAOR  SASMAOL  SMAUIII?  OTSAROR  MTORŌOL  SAOSMAUR

`f52v.2`  ytchey.chol.ctho,daiir.shy.kor.ese,chor.chy.dam
→ MTSARM  SAOL  STAONUIIR  PAM  ŌOR  RPRSAOR  SAM  NUS

`f52v.3`  oor,chor.chochar.l[s:r].chteeor.ytol.sheol.otam
→ OORSAOR  SAOSAUR  LP  SATRROR  MTOL  PAROL  OTUS

`f52v.4`  tchor.ctheor.ctheol.cheeor.cheol.chckheey.s[o:a]dy
→ TSAOR  STAROR  STAROL  SARROR  SAROL  SASŌARRM  PONM

`f52v.5`  yteey.cthor,cheo[s:r].cpheodar.dy<->sarg
→ MTRRM  STAORSAROP  SMARONUR  NMPUR?

`f52v.6`  qotodaiin.cthor.oty.kcholy
→ COTONUII?  STAOR  OTM  ŌSAOLM

`f52v.7`  pcheol.sholoiin.cthor.aiin
→ MSAROL  PAOLOII?  STAOR  UII?

`f52v.8`  kodaiin.cthy.qokeey.s.ol
→ ŌONUII?  STAM  COŌRRM  P  OL

`f52v.9`  daiin.ckheol.chol.qoke[y:o]l.daiin
→ NUII?  SŌAROL  SAOL  COŌRML  NUII?

`f52v.10`  yokee[y:o].qokody.chol.sol,s.aiin
→ MOŌRRM  COŌONM  SAOL  POLP  UII?

`f52v.11`  daiin.shor.qodaiin.ckhey.sal
→ NUII?  PAOR  CONUII?  SŌARM  PUL

`f52v.12`  qoekar.ckhol.ykchody.ckhy
→ CORŌUR  SŌAOL  MŌSAONM  SŌAM

`f52v.13`  yk[o:a]r.okaiiin.ckheeey.daiig
→ MŌOR  OŌUIII?  SŌARRRM  NUII?

`f52v.14`  odar.cheokor.ckheey
→ ONUR  SAROŌOR  SŌARRM

### f53r  ·  herbal

`f53r.1`  k[o:a]dam,chocthody.oty
→ ŌONUSSAOSTAONM  OTM

`f53r.2`  dol.dain.s,cho,she.oty
→ NOL  NUI?  PSAOPAR  OTM

`f53r.3`  sho,[a:o][s:r].chokan.ody
→ PAOUP  SAOŌU?  ONM

`f53r.4`  ytchodaiin.yky.otchey.otod
→ MTSAONUII?  MŌM  OTSARM  OTON

`f53r.5`  ok[sh:?].otol.cfhy.cphodol.ykody.qokchod<->otcho.qot.oty
→ OŌPA  OTOL  S?AM  SMAONOL  MŌONM  COŌSAONOTSAO  COT  OTM

`f53r.6`  ykeodar.oqoor.o{cki}.odor.chain.qokod<->ykchdy.chees.dal
→ MŌRONUR  OCOOR  OSŌI  ONOR  SAUI?  COŌONMŌSANM  SARRP  NUL

`f53r.7`  sodar.otos.qoy.tchy.otey.chos.okod<->ykchody.qok[ch:ee]y
→ PONUR  OTOP  COM  TSAM  OTRM  SAOP  OŌONMŌSAONM  COŌSAM

`f53r.8`  qotchol.dar.qoty.chtor.oltsho.{cto}<->ykeeod.o.y,toyd
→ COTSAOL  NUR  COTM  SATOR  OLTPAO  STOMŌRRON  O  MTOMN

`f53r.9`  otol.chol.ctheees.os.orol.chod.qoty
→ OTOL  SAOL  STARRRP  OP  OROL  SAON  COTM

### f53v  ·  herbal

`f53v.1`  tshor,shey.qodckhy.e{ph}o.oltshey.daiin.qopchy
→ TPAORPARM  CONSŌAM  RMAO  OLTPARM  NUII?  COMSAM

`f53v.2`  okeey.daiin.sheekol.shom.shol.cthy.dchom.do
→ OŌRRM  NUII?  PARRŌOL  PAOS  PAOL  STAM  NSAOS  NO

`f53v.3`  ydaiin.cph[o:a]m.chol.dockhy.cthol.dam.oty
→ MNUII?  SMAOS  SAOL  NOSŌAM  STAOL  NUS  OTM

`f53v.4`  qokol,daiiin.qockhor.okchor.daiio,dain.d
→ COŌOLNUIII?  COSŌAOR  OŌSAOR  NUIIONUI?  N

`f53v.5`  ysheey.ckhol.chckhey.daiin.ctheody.ydy
→ MPARRM  SŌAOL  SASŌARM  NUII?  STARONM  MNM

`f53v.6`  ochoiky.dshey.chol.ykcheody.choldam
→ OSAOIŌM  NPARM  SAOL  MŌSARONM  SAOLNUS

`f53v.7`  todaiin.shodaiin.qote[a:o].dchy.qotod.odaiin
→ TONUII?  PAONUII?  COTRU  NSAM  COTON  ONUII?

`f53v.8`  sheey.kshody.tsheody.sheody.sheetchy.opod
→ PARRM  ŌPAONM  TPARONM  PARONM  PARRTSAM  OMON

`f53v.9`  octheody.shody.qodal.cthody.sheos.shodaiin
→ OSTARONM  PAONM  CONUL  STAONM  PAROP  PAONUII?

`f53v.10`  ychocthy.qodal.shodaiin
→ MSAOSTAM  CONUL  PAONUII?

`f53v.11`  otsho.or.chear.sheod.chkodal
→ OTPAO  OR  SARUR  PARON  SAŌONUL

`f53v.12`  ycheey.kchy.oky.kody<->ydam
→ MSARRM  ŌSAM  OŌM  ŌONMMNUS

`f53v.13`  yckhodaiin.otoldy
→ MSŌAONUII?  OTOLNM

### f54r  ·  herbal

`f54r.1`  podaiin.shodal.qopchol.cfhe[o:a]dy<->opcheol.chocphy
→ MONUII?  PAONUL  COMSAOL  S?ARONMOMSAROL  SAOSMAM

`f54r.2`  ytodaiin.otchey.otchey.qockhodal<->sockhody.sar
→ MTONUII?  OTSARM  OTSARM  COSŌAONULPOSŌAONM  PUR

`f54r.3`  daiir.cthody.ot[a:o]l.[e:o]kchody.ol.s.or.y<->ytchey.dam
→ NUIIR  STAONM  OTUL  RŌSAONM  OL  P  OR  MMTSARM  NUS

`f54r.4`  tor.ockhol.shokchy.kol,chom.[s:r]<->chey<->ctheot[o:a]l
→ TOR  OSŌAOL  PAOŌSAM  ŌOLSAOS  PSARMSTAROTOL

`f54r.5`  sar.sh.okeodain.chokey
→ PUR  PA  OŌRONUI?  SAOŌRM

`f54r.6`  korar[e:i].ckhos.shofom.cher.chom.kcheor<->she.qkchol.dam
→ ŌORURR  SŌAOP  PAO?OS  SARR  SAOS  ŌSARORPAR  CŌSAOL  NUS

`f54r.7`  dor.s.sheey.ksheody.sho.or.cheey.chety<->sol.de[sh:?].dam.dam
→ NOR  P  PARRM  ŌPARONM  PAO  OR  SARRM  SARTMPOL  NRPA  NUS  NUS

`f54r.8`  t[o:a]shey.kodl.ckho.dar.sheekal.s.aiin<->okeam.etchal
→ TOPARM  ŌONL  SŌAO  NUR  PARRŌUL  P  UII?OŌRUS  RTSAUL

`f54r.9`  oaiin.or.ol.sal.qokor.chor.ckhol.s<->s,sho.chol.daiin
→ OUII?  OR  OL  PUL  COŌOR  SAOR  SŌAOL  PPPAO  SAOL  NUII?

`f54r.10`  tor.ol.dol.or.chol.chol.ckhol.okol.oky<->ytchor.ol,koldy
→ TOR  OL  NOL  OR  SAOL  SAOL  SŌAOL  OŌOL  OŌMMTSAOR  OLŌOLNM

`f54r.11`  daiin.okor.or.ol.ckhol.chor.cho@165;.dam<->or.sho.chol.dom
→ NUII?  OŌOR  OR  OL  SŌAOL  SAOR  SAO  NUSOR  PAO  SAOL  NOS

`f54r.12`  yor.shodal.o.aiin.al.dol.choek,air,o,ldam
→ MOR  PAONUL  O  UII?  UL  NOL  SAORŌUIROLNUS

### f54v  ·  herbal

`f54v.1`  pcheodar.chpal.oloiin.ckhey.dar.qokeey.cpheeain.s,al
→ MSARONUR  SAMUL  OLOII?  SŌARM  NUR  COŌRRM  SMARRUI?  PUL

`f54v.2`  dcheain.cphaiin.s.ar.cheor.qodaiin.cthaildy.ypchal
→ NSARUI?  SMAUII?  P  UR  SAROR  CONUII?  STAUILNM  MMSAUL

`f54v.3`  yair.ykar.oky.cham.chody.ykoldam.cheol,am
→ MUIR  MŌUR  OŌM  SAUS  SAONM  MŌOLNUS  SAROLUS

`f54v.4`  dar,chor.cheky.chol.okaiin.chody.chol,dy
→ NURSAOR  SARŌM  SAOL  OŌUII?  SAONM  SAOLNM

`f54v.5`  o[d:?]aiin.ytaiin.qodaim.qokar.chy.s.am
→ ONUII?  MTUII?  CONUIS  COŌUR  SAM  P  US

`f54v.6`  tol.cheol.shocthy.qodaiin.k[ee:ch]ody
→ TOL  SAROL  PAOSTAM  CONUII?  ŌRRONM

`f54v.7`  daiin.sheody.qoctheol.s.aiin.qotchy
→ NUII?  PARONM  COSTAROL  P  UII?  COTSAM

`f54v.8`  daiino,d,aim.qokaiin.yteal.okal.om
→ NUII?ONUIS  COŌUII?  MTRUL  OŌUL  OS

`f54v.9`  ydaiin.qockhey.qodal.ytam.okal,dy
→ MNUII?  COSŌARM  CONUL  MTUS  OŌULNM

`f54v.10`  kol.{ck}aiin.chckhy.qokal.dal.qocthy
→ ŌOL  SŌUII?  SASŌAM  COŌUL  NUL  COSTAM

`f54v.11`  oaiin.qockhy.qokam
→ OUII?  COSŌAM  COŌUS

`f54v.12`  tol.chol.cthol.s
→ TOL  SAOL  STAOL  P

`f54v.13`  y,chol.okal.yckhey
→ MSAOL  OŌUL  MSŌARM

`f54v.14`  tar.cphey.tam.aldam
→ TUR  SMARM  TUS  ULNUS

`f54v.15`  or.alchy.ytal.dol.chodoldy
→ OR  ULSAM  MTUL  NOL  SAONOLNM

`f54v.16`  daiin.chol.oldaiin
→ NUII?  SAOL  OLNUII?

### f55r  ·  herbal

`f55r.1`  podaiin.shekchy.qofair.okar.yk.[{oh}:ch]epaiin.qokchdy.os.arod
→ MONUII?  PARŌSAM  CO?UIR  OŌUR  MŌ  OARMUII?  COŌSANM  OP  URON

`f55r.2`  okair.or.aiin.chody.ykair.y.qokar.okar.ol.ykar.ar.al
→ OŌUIR  OR  UII?  SAONM  MŌUIR  M  COŌUR  OŌUR  OL  MŌUR  UR  UL

`f55r.3`  ykaiir.chol.chky.okar.chky.chdy.qokar.okaiin.chckhy.s.aiin
→ MŌUIIR  SAOL  SAŌM  OŌUR  SAŌM  SANM  COŌUR  OŌUII?  SASŌAM  P  UII?

`f55r.4`  daiin.or.orol.char.ar.kaiin.okchd.ykar.odaiin.chdolaiin
→ NUII?  OR  OROL  SAUR  UR  ŌUII?  OŌSAN  MŌUR  ONUII?  SANOLUII?

`f55r.5`  y.or.aiin.okal.chol.kchoy.pchtchdy.o[{ck}:ek]aiin.oka[s:r]or.olkam
→ M  OR  UII?  OŌUL  SAOL  ŌSAOM  MSATSANM  OSŌUII?  OŌUPOR  OLŌUS

`f55r.6`  tcho,daiin.sho.ke@166;y.kedy.okol.chdy
→ TSAONUII?  PAO  ŌRM  ŌRNM  OŌOL  SANM

`f55r.7`  tchedar.che[o:a]l,kedy.chody.kshdy.qotchdy.qokchdy.olkardam
→ TSARNUR  SAROLŌRNM  SAONM  ŌPANM  COTSANM  COŌSANM  OLŌURNUS

`f55r.8`  dchykey.char.chek.xar.odas.xaloeees.cpheody.qokeeody
→ NSAMŌRM  SAUR  SARŌ  ?UR  ONUP  ?ULORRRP  SMARONM  COŌRRONM

`f55r.9`  dain.cheky.dar.chckhy.dal.qoko.lkeedy.dar.kaiin.dy.ka[g:m]
→ NUI?  SARŌM  NUR  SASŌAM  NUL  COŌO  LŌRRNM  NUR  ŌUII?  NM  ŌU?

`f55r.10`  dair.okal.qokar.or.[o:a]r@193;.o.ar.odaiin.okeey.darchd.ol
→ NUIR  OŌUL  COŌUR  OR  OR  O  UR  ONUII?  OŌRRM  NURSAN  OL

`f55r.11`  l[{oh}:ch]or.chey.keedy.dy.qokal.oka[m:j].dal,shdy.otal.otaldiin
→ LOAOR  SARM  ŌRRNM  NM  COŌUL  OŌUS  NULPANM  OTUL  OTULNII?

`f55r.12`  oain.ckhy.dl.oiiin.daiin.okaiin.chelal.qokaiin.okain.r
→ OUI?  SŌAM  NL  OIII?  NUII?  OŌUII?  SARLUL  COŌUII?  OŌUI?  R

`f55r.13`  lchdal.ockhy.daiin.otol.otar.shar,ain
→ LSANUL  OSŌAM  NUII?  OTOL  OTUR  PAURUI?

### f55v  ·  herbal

`f55v.1`  kcheedchdy.oedain.chckhy<->otoldaiin.dodyd
→ ŌSARRNSANM  ORNUI?  SASŌAMOTOLNUII?  NONMN

`f55v.2`  oeeed.yteey.okeedy.qoaiin<->okeody.ykee[s:r]an
→ ORRRN  MTRRM  OŌRRNM  COUII?OŌRONM  MŌRRPU?

`f55v.3`  qokeeey.os.ain.qool.al,chedy<->[s:?]ar,aiin.ol.kar,am
→ COŌRRRM  OP  UI?  COOL  ULSARNMPURUII?  OL  ŌURUS

`f55v.4`  okar.chckhdy.che[o:a]dy.keeyfar,al<->ochedy.qokain.ody
→ OŌUR  SASŌANM  SARONM  ŌRRM?URULOSARNM  COŌUI?  ONM

`f55v.5`  qokaiin.chaiin.ykain.ykan.ody<->daiin.chedy.talam
→ COŌUII?  SAUII?  MŌUI?  MŌU?  ONMNUII?  SARNM  TULUS

`f55v.6`  ykaiin.daiin.ykair.cheky.daiiny
→ MŌUII?  NUII?  MŌUIR  SARŌM  NUII?M

`f55v.7`  okchd.yk[a:?]in.[sh:ch]eokey.or.ain<->[ch:?].kchdy.pchal.ar,aldy.dary
→ OŌSAN  MŌUI?  PAROŌRM  OR  UI?SA  ŌSANM  MSAUL  URULNM  NURM

`f55v.8`  tar.chedy.qokaiin.okar.qol<->otar,cho@194;ar.talody.okar,y
→ TUR  SARNM  COŌUII?  OŌUR  COLOTURSAOUR  TULONM  OŌURM

`f55v.9`  ykaky.qokchy.okal.chey.or<->or,aiin.okaiin.ykain.otaky
→ MŌUŌM  COŌSAM  OŌUL  SARM  ORORUII?  OŌUII?  MŌUI?  OTUŌM

`f55v.10`  oaiin.ol.s.aiin.okaiin.oky<->ytaiin.otar.y,kal.ykar.ol
→ OUII?  OL  P  UII?  OŌUII?  OŌMMTUII?  OTUR  MŌUL  MŌUR  OL

`f55v.11`  ykaiin.cheoar.cheeky.oldy<->aiin.okal.oltchy.or,y.orain
→ MŌUII?  SAROUR  SARRŌM  OLNMUII?  OŌUL  OLTSAM  ORM  ORUI?

`f55v.12`  daiin.[a:o]r.cheky.olkeechy.sl<->ar.aiin.daiin.otam
→ NUII?  UR  SARŌM  OLŌRRSAM  PLUR  UII?  NUII?  OTUS

### f56r  ·  herbal

`f56r.1`  o@167;chal.chchs@168;y.oty.esedy.chy.ychocphy.chorchy.chy
→ OSAUL  SASAPM  OTM  RPRNM  SAM  MSAOSMAM  SAORSAM  SAM

`f56r.2`  chokchey.ch[o:a]l.choly.korchy.chykey.choty.shokaiin
→ SAOŌSARM  SAOL  SAOLM  ŌORSAM  SAMŌRM  SAOTM  PAOŌUII?

`f56r.3`  olchey.chokchol.chey.keey.qokeey.chokeey.choksy
→ OLSARM  SAOŌSAOL  SARM  ŌRRM  COŌRRM  SAOŌRRM  SAOŌPM

`f56r.4`  qot,chor.chor.chokor.chkor,chy<->okar.chdy
→ COTSAOR  SAOR  SAOŌOR  SAŌORSAMOŌUR  SANM

`f56r.5`  chochor.cho.chodaly.daiin
→ SAOSAOR  SAO  SAONULM  NUII?

`f56r.6`  ykch[o:a].dy.dchey.keey.daiin.y
→ MŌSAO  NM  NSARM  ŌRRM  NUII?  M

`f56r.7`  sho.kchol.otchor.choky.dal
→ PAO  ŌSAOL  OTSAOR  SAOŌM  NUL

`f56r.8`  schol.choy.choky.cheeckhody
→ PSAOL  SAOM  SAOŌM  SARRSŌAONM

`f56r.9`  tchoky.kchol.shol.chotchey,tchol
→ TSAOŌM  ŌSAOL  PAOL  SAOTSARMTSAOL

`f56r.10`  yt,chor.otchy.chok.y,t.chey.r.okaiin
→ MTSAOR  OTSAM  SAOŌ  MT  SARM  R  OŌUII?

`f56r.11`  shy,kcheey.daiin.cthol.chos.chokor
→ PAMŌSARRM  NUII?  STAOL  SAOP  SAOŌOR

`f56r.12`  sh.cho.kchey.qokokchy
→ PA  SAO  ŌSARM  COŌOŌSAM

`f56r.13`  okchy.chokcheo.kchal
→ OŌSAM  SAOŌSARO  ŌSAUL

`f56r.14`  s,chol.chotol.qotchy
→ PSAOL  SAOTOL  COTSAM

`f56r.15`  tcho,tchol.chol.cthy
→ TSAOTSAOL  SAOL  STAM

`f56r.16`  qotchy.chody.ctho,r.chey.kch[a:o]rg
→ COTSAM  SAONM  STAOR  SARM  ŌSAUR?

`f56r.17`  chokeey.qokcheey.schey.d,aiin.dy
→ SAOŌRRM  COŌSARRM  PSARM  NUII?  NM

`f56r.18`  sho.chokchy.kchoar<->sotodan
→ PAO  SAOŌSAM  ŌSAOURPOTONU?

`f56r.19`  otchey.keol.daiin
→ OTSARM  ŌROL  NUII?

### f56v  ·  herbal

`f56v.1`  kche[a:o]t.shol.chey.qokoiin.shor,qotcheol.choror
→ ŌSARUT  PAOL  SARM  COŌOII?  PAORCOTSAROL  SAOROR

`f56v.2`  shodshey.qot[eee:ech]y.qoteey.daiin.qoteey.cthar
→ PAONPARM  COTRRRM  COTRRM  NUII?  COTRRM  STAUR

`f56v.3`  ochey.chol.chol.qotchey.daiin.choteeey,dal
→ OSARM  SAOL  SAOL  COTSARM  NUII?  SAOTRRRMNUL

`f56v.4`  schy.t,chey.daiin.d,eey.tad<->dain
→ PSAM  TSARM  NUII?  NRRM  TUNNUI?

`f56v.5`  qoteees.sho.kcheey.s,aiin
→ COTRRRP  PAO  ŌSARRM  PUII?

`f56v.6`  chokchol.chor.ckhos
→ SAOŌSAOL  SAOR  SŌAOP

`f56v.7`  kchokchy.{ck}chol.shol.chol.otchyd
→ ŌSAOŌSAM  SŌSAOL  PAOL  SAOL  OTSAMN

`f56v.8`  ykchor.chokchy.qokcho.tcheey.kol
→ MŌSAOR  SAOŌSAM  COŌSAO  TSARRM  ŌOL

`f56v.9`  shotchot.chokcho.kcho,kaiin.oky
→ PAOTSAOT  SAOŌSAO  ŌSAOŌUII?  OŌM

`f56v.10`  ol,kchy.ksho.shy.ytol.chotor,y,dy
→ OLŌSAM  ŌPAO  PAM  MTOL  SAOTORMNM

`f56v.11`  chotchey.keeol.chey.kchol.tchain
→ SAOTSARM  ŌRROL  SARM  ŌSAOL  TSAUI?

`f56v.12`  qokchey.ctheey.lkeey.kcheeytain
→ COŌSARM  STARRM  LŌRRM  ŌSARRMTUI?

`f56v.13`  ykor.aiin.chorol.sho,shol.daiin
→ MŌOR  UII?  SAOROL  PAOPAOL  NUII?

`f56v.14`  chol,cheo.kchol.chol.choky.chotor
→ SAOLSARO  ŌSAOL  SAOL  SAOŌM  SAOTOR

`f56v.15`  otchol.chol.chol.daiin.chotaiin
→ OTSAOL  SAOL  SAOL  NUII?  SAOTUII?

`f56v.16`  s,o,kchol.chol.chol.daiin
→ POŌSAOL  SAOL  SAOL  NUII?

### f57r  ·  herbal

`f57r.1`  poeeockhey.odain.cheop.sheody.shocfhey.dy.sheep.sheody.[e:y]odam
→ MORROSŌARM  ONUI?  SAROM  PARONM  PAOS?ARM  NM  PARRM  PARONM  RONUS

`f57r.2`  daiir.air.chety.cheo,ckhy.chockhy.cheotey.sh,kchey.s.odaiin.shey
→ NUIIR  UIR  SARTM  SAROSŌAM  SAOSŌAM  SAROTRM  PAŌSARM  P  ONUII?  PARM

`f57r.3`  qokeeody.cheooky.qokeody.sheey.okeody.cheody.cheeody.cheekeody
→ COŌRRONM  SAROOŌM  COŌRONM  PARRM  OŌRONM  SARONM  SARRONM  SARRŌRONM

`f57r.4`  dchos.cheocthy.cheody.qot[ee:ch]ody.octhody.okeeody.chteody.cheody,s
→ NSAOP  SAROSTAM  SARONM  COTRRONM  OSTAONM  OŌRRONM  SATRONM  SARONMP

`f57r.5`  qok[ch:ee]o.daiin.cheeodam
→ COŌSAO  NUII?  SARRONUS

`f57r.6`  tcheodal.okam.chckhey.okchdy.doctho.opchey.dy.kedaiin.oforam
→ TSARONUL  OŌUS  SASŌARM  OŌSANM  NOSTAO  OMSARM  NM  ŌRNUII?  O?ORUS

`f57r.7`  daii[s:r].sheedy.qokeedy.chetey<->oteeod.shekey.tedy.okaldg
→ NUIIP  PARRNM  COŌRRNM  SARTRMOTRRON  PARŌRM  TRNM  OŌULN?

`f57r.8`  tair.sheedy.ochedy.{ckhhh}dy<->okchy.chedy.dal.qokedam
→ TUIR  PARRNM  OSARNM  SŌAAANMOŌSAM  SARNM  NUL  COŌRNUS

`f57r.9`  [a:o]dair.sheeo,ckhy.sar.al.daii[d:j]y<->dcheckhey.daiin.chedy.cthedy
→ UNUIR  PARROSŌAM  PUR  UL  NUIINMNSARSŌARM  NUII?  SARNM  STARNM

`f57r.10`  qoetchey.kedy.shedaiin<->s,cheos.ykeos.q{cthh}y.tcfhy
→ CORTSARM  ŌRNM  PARNUII?PSAROP  MŌROP  CSTAAM  TS?AM

`f57r.11`  dshedy.{ct}echy.cphedam
→ NPARNM  STRSAM  SMARNUS

### f57v  ·  unknown

`f57v.1`  dairal
→ NUIRUL

`f57v.2`  v.sal,y.soeos.vs.ar.okees.o.d.soefchees.l,g.sos.okey.defo.f.o.rkedam.sh.ofol.sar.ddal.yty.s.y.daiir.otey.dshdy.dkal[s:r].oty,pchchy.a.r.opaiin.dal.karody.v,r,okeey.daram.qokar.okal.okal.d.o.l.shkeal.dy,das.o.k.sher.s,aiin
→ ?  PULM  POROP  ?P  UR  OŌRRP  O  N  POR?SARRP  L?  POP  OŌRM  NR?O  ?  O  RŌRNUS  PA  O?OL  PUR  NNUL  MTM  P  M  NUIIR  OTRM  NPANM  NŌULP  OTMMSASAM  U  R  OMUII?  NUL  ŌURONM  ?ROŌRRM  NURUS  COŌUR  OŌUL  OŌUL  N  O  L  PAŌRUL  NMNUP  O  Ō  PARR  PUII?

`f57v.3`  o.l.[d:j].r.v.x.k.m.f.@169;v.t.r.@170;.@171;.y.I.@172;.o.l.d.r.v.x.k.m.f.@169;v.t.r.@170;.@171;.y.c.@172;.o.l.d.r.v.x.k.m.p.@169;v.t.r.@170;.@171;.y.c.@172;.o.l.d.r.v.x.k.m.p.@169;v.t.r.@170;.@171;.y.c.@172;
→ O  L  N  R  ?  ?  Ō  S  ?  ?  T  R  —  —  M  I  —  O  L  N  R  ?  ?  Ō  S  ?  ?  T  R  —  —  M  S  —  O  L  N  R  ?  ?  Ō  S  M  ?  T  R  —  —  M  S  —  O  L  N  R  ?  ?  Ō  S  M  ?  T  R  —  —  M  S  —

`f57v.4`  daiin.otey.of[che:eee]y.shes.o.d.okeeod.l.o.lkeeol.dkedar.yf.aros.s.y.chedaiin.k.eeety.x.deeodal.vo.tchor.{ch'}.kedar.dal.@172;.daiin.aiin.otal.daro.v
→ NUII?  OTRM  O?SARM  PARP  O  N  OŌRRON  L  O  LŌRROL  NŌRNUR  M?  UROP  P  M  SARNUII?  Ō  RRRTM  ?  NRRONUL  ?O  TSAOR  SA  ŌRNUR  NUL  —  NUII?  UII?  OTUL  NURO  ?

`f57v.5`  o.[v:a].l.r.m.aiin.d.@170;.c.f.[s:r].y.l.k.x.l.r.@171;,ar.o.r.[a:?].t.l.[s:r].d.y.dar.teodar.otodal.sheky.oteeody.x.[s:r].l
→ O  ?  L  R  S  UII?  N  —  S  ?  P  M  L  Ō  ?  L  R  UR  O  R  U  T  L  P  N  M  NUR  TRONUR  OTONUL  PARŌM  OTRRONM  ?  P  L

`f57v.6`  otodara[g:m]
→ OTONURU?

`f57v.7`  oparairdly
→ OMURUIRNLM

`f57v.8`  olkeedal
→ OLŌRRNUL

`f57v.9`  otardaly
→ OTURNULM

`f57v.10`  ark[a:o]ldy
→ URŌULNM

`f57v.11`  ara?arar
→ URUURUR

`f57v.12`  okeely
→ OŌRRLM

`f57v.13`  ocfhor,okear
→ OS?AOROŌRUR

### f58r  ·  stars

`f58r.1`  kor,cholfy.shofchy.otoralchy.chofchol.sholy.otaly.dal,m
→ ŌORSAOL?M  PAO?SAM  OTORULSAM  SAO?SAOL  PAOLM  OTULM  NULS

`f58r.2`  dshodal.or.ckhy.olchear.char.tal.ytal.ytar.olchokal
→ NPAONUL  OR  SŌAM  OLSARUR  SAUR  TUL  MTUL  MTUR  OLSAOŌUL

`f58r.3`  ykechod.dalaldam.ytam.choty.otchy.otaly.shoty.s
→ MŌRSAON  NULULNUS  MTUS  SAOTM  OTSAM  OTULM  PAOTM  P

`f58r.4`  dshor.sholar.aiin,shalom.shaly.dalchy.oteom.dal.sholala@210;
→ NPAOR  PAOLUR  UII?PAULOS  PAULM  NULSAM  OTROS  NUL  PAOLULU

`f58r.5`  qor.dchair,am.otar.otar.char.ar.al.char.ar,ary.ytalar.cham
→ COR  NSAUIRUS  OTUR  OTUR  SAUR  UR  UL  SAUR  URURM  MTULUR  SAUS

`f58r.6`  torchey.otaiin.chary.oteor,y.otal.dalchor.ykeey.choltam
→ TORSARM  OTUII?  SAURM  OTRORM  OTUL  NULSAOR  MŌRRM  SAOLTUS

`f58r.7`  saiin.cholkeey.dal.shom.sholteol.ytalody.otey.cheoly.o.tchy
→ PUII?  SAOLŌRRM  NUL  PAOS  PAOLTROL  MTULONM  OTRM  SAROLM  O  TSAM

`f58r.8`  toleeshal.oleeam.dalor.chy.oteodchy.yteochy.otey,kal,dy.alam
→ TOLRRPAUL  OLRRUS  NULOR  SAM  OTRONSAM  MTROSAM  OTRMŌULNM  ULUS

`f58r.9`  sholaiin.cheey.yteodaiin.qoar.aiin.arary.sheey.daiin.e,alam
→ PAOLUII?  SARRM  MTRONUII?  COUR  UII?  URURM  PARRM  NUII?  RULUS

`f58r.10`  tal.ar.am.shar.chepchey.otar.aldy.otal,cheam.qokaiin.ote.[s:r]y
→ TUL  UR  US  PAUR  SARMSARM  OTUR  ULNM  OTULSARUS  COŌUII?  OTR  PM

`f58r.11`  qocphody.qokalam.chairal.qo{ct}aiin.otalal.dalor.orar
→ COSMAONM  COŌULUS  SAUIRUL  COSTUII?  OTULUL  NULOR  ORUR

`f58r.12`  shoar,ar.choldal.otalchal.dal.choldy.okalys.airaldy.shar
→ PAOURUR  SAOLNUL  OTULSAUL  NUL  SAOLNM  OŌULMP  UIRULNM  PAUR

`f58r.13`  ytar.sheear.cheoldy.ykeol.cheal.cheody.chal.chaiin.ol.oly
→ MTUR  PARRUR  SAROLNM  MŌROL  SARUL  SARONM  SAUL  SAUII?  OL  OLM

`f58r.14`  sharam.okair.chekaiin.ytchaly.dalchal.ykal.okalal.oly.chal
→ PAURUS  OŌUIR  SARŌUII?  MTSAULM  NULSAUL  MŌUL  OŌULUL  OLM  SAUL

`f58r.15`  daiir.shal.qopaim.cholaly.dy.shedy
→ NUIIR  PAUL  COMUIS  SAOLULM  NM  PARNM

`f58r.16`  typchey.ar.air.ytashy.qotyshey.pchdy.dshaly.pydaly.choky,opy
→ TMMSARM  UR  UIR  MTUPAM  COTMPARM  MSANM  NPAULM  MMNULM  SAOŌMOMM

`f58r.17`  ysholshy.qotoly.daiin.ykal.dalchdy.qoky.dal.ytchody.s.olar,aly
→ MPAOLPAM  COTOLM  NUII?  MŌUL  NULSANM  COŌM  NUL  MTSAONM  P  OLURULM

`f58r.18`  darar.shol.cholraly.cholaiin.odaiin.chaly.dalar.aiin.okal.otal
→ NURUR  PAOL  SAOLRULM  SAOLUII?  ONUII?  SAULM  NULUR  UII?  OŌUL  OTUL

`f58r.19`  todal.qotey.chaly.dal.qokaldy.otary.okalal.{ch'}ees.chal.[o:a]chaly
→ TONUL  COTRM  SAULM  NUL  COŌULNM  OTURM  OŌULUL  SARRP  SAUL  OSAULM

`f58r.20`  ysheockhy.olchey.oleesey.alaiin.olkeal.daldy.otalar.ar.aroda[i:?]m
→ MPAROSŌAM  OLSARM  OLRRPRM  ULUII?  OLŌRUL  NULNM  OTULUR  UR  URONUIS

`f58r.21`  tcheos.ycheor.sheain.okey.qotaily.daiin.chy.cholkor.olkeol.oty
→ TSAROP  MSAROR  PARUI?  OŌRM  COTUILM  NUII?  SAM  SAOLŌOR  OLŌROL  OTM

`f58r.22`  dcholy.ytar.chol.dal.qoaiir.chalolky.osal.chotam.chal.olsee[g:m]
→ NSAOLM  MTUR  SAOL  NUL  COUIIR  SAULOLŌM  OPUL  SAOTUS  SAUL  OLPRR?

`f58r.23`  shol.[a:o]leedy.chotar.okeal.sheody.qokalchar.otal.choky.sar
→ PAOL  ULRRNM  SAOTUR  OŌRUL  PARONM  COŌULSAUR  OTUL  SAOŌM  PUR

`f58r.24`  tazain.oteeos.okeal.ar.otalor.cheoekar.cheky.otaka[s:r]
→ TU?UI?  OTRROP  OŌRUL  UR  OTULOR  SARORŌUR  SARŌM  OTUŌUP

`f58r.25`  oar.cheekey.oteeoaly.otar.alkar.or,aldar
→ OUR  SARRŌRM  OTRROULM  OTUR  ULŌUR  ORULNUR

`f58r.26`  kshar.shoky.opcheear.ofadain.opsheolaiin.opydaiin.podaiir
→ ŌPAUR  PAOŌM  OMSARRUR  O?UNUI?  OMPAROLUII?  OMMNUII?  MONUIIR

`f58r.27`  yteor.oty.chaltar.ar.sheeetchy.tal,al,chear.chear.chor,ar,am
→ MTROR  OTM  SAULTUR  UR  PARRRTSAM  TULULSARUR  SARUR  SAORURUS

`f58r.28`  yshealkair.odalaly.dalal.chy.s,air.shokar.olaldy.okalody
→ MPARULŌUIR  ONULULM  NULUL  SAM  PUIR  PAOŌUR  OLULNM  OŌULONM

`f58r.29`  odalar.cheor.sar.alol,daly.cheom.chor,ar,aldam.chal.cheal.[r:s],omy
→ ONULUR  SAROR  PUR  ULOLNULM  SAROS  SAORURULNUS  SAUL  SARUL  ROSM

`f58r.30`  ytor.ar.alom.qokalor.chdy.dair.chody.cheol.okolchy.otaldy
→ MTOR  UR  ULOS  COŌULOR  SANM  NUIR  SAONM  SAROL  OŌOLSAM  OTULNM

`f58r.31`  odshchol.taiin.okal,or.chol,ol,ekar.otarchol.chol.kam.qokal
→ ONPASAOL  TUII?  OŌULOR  SAOLOLRŌUR  OTURSAOL  SAOL  ŌUS  COŌUL

`f58r.32`  oqotaly.qokaiin.chtaldy.qoky.dar.al.chol,taly.qokaldy
→ OCOTULM  COŌUII?  SATULNM  COŌM  NUR  UL  SAOLTULM  COŌULNM

`f58r.33`  scho{cthh}y.dalols.qokalos.cheor.oekeody.qokaly.qokar.dy
→ PSAOSTAAM  NULOLP  COŌULOP  SAROR  ORŌRONM  COŌULM  COŌUR  NM

`f58r.34`  yssheol.chokey.dalol.shokalol.qokaly.kaldy.ytaipom
→ MPPAROL  SAOŌRM  NULOL  PAOŌULOL  COŌULM  ŌULNM  MTUIMOS

`f58r.35`  dto[s:r].sheol.qokor.sharal.ckhol.shol,ar.aiin.sheoctham
→ NTOP  PAROL  COŌOR  PAURUL  SŌAOL  PAOLUR  UII?  PAROSTAUS

`f58r.36`  skaiin.shokal.chockhy.qoky.chcthy.ykeeshy.shoekar
→ PŌUII?  PAOŌUL  SAOSŌAM  COŌM  SASTAM  MŌRRPAM  PAORŌUR

`f58r.37`  opolkeor.olchocfhy.cphol.chykaldy.cholols.chkaiin,olfcham
→ OMOLŌROR  OLSAOS?AM  SMAOL  SAMŌULNM  SAOLOLP  SAŌUII?OL?SAUS

`f58r.38`  s,ysheos.okaly.cheos.otey.ykar.ls.aiin.okaiin.ytolkal
→ PMPAROP  OŌULM  SAROP  OTRM  MŌUR  LP  UII?  OŌUII?  MTOLŌUL

`f58r.39`  dtshol.dytal.okar,olol.sheol.qockhy.qokaly.salol.dalam
→ NTPAOL  NMTUL  OŌUROLOL  PAROL  COSŌAM  COŌULM  PULOL  NULUS

`f58r.40`  y[r:?]oleeey.ar,airaly.pchody.tshaly.alols.ykaly.kar.aram
→ MROLRRRM  URUIRULM  MSAONM  TPAULM  ULOLP  MŌULM  ŌUR  URUS

`f58r.41`  dchol.chokal.saiin.dal.okal,s,alchey
→ NSAOL  SAOŌUL  PUII?  NUL  OŌULPULSARM

### f58v  ·  stars

`f58v.1`  tol.shokchy.opaiin.opaiin.chofaly.ypar.ypal.opal.opaldaiin
→ TOL  PAOŌSAM  OMUII?  OMUII?  SAO?ULM  MMUR  MMUL  OMUL  OMULNUII?

`f58v.2`  dair.or.{ch'h}aiin.tair.y.qotalody.s,aiin.okeody.qotair.ar.alor.orky
→ NUIR  OR  SAAUII?  TUIR  M  COTULONM  PUII?  OŌRONM  COTUIR  UR  ULOR  ORŌM

`f58v.3`  todal.qotain.sho{@246;k@191;@191;h}y.qokeol.okey.qokalchal.daly.ar.aim
→ TONUL  COTUI?  PAOŌAM  COŌROL  OŌRM  COŌULSAUL  NULM  UR  UIS

`f58v.4`  or,aiin.okair,y.dair,al.qokal.qokaiin.qokaly.okar.olkaly.okal
→ ORUII?  OŌUIRM  NUIRUL  COŌUL  COŌUII?  COŌULM  OŌUR  OLŌULM  OŌUL

`f58v.5`  faiir.ofas,ar.qotaiin.sholy.qotaiin.yqokaly.okal.qokaly.okaly
→ ?UIIR  O?UPUR  COTUII?  PAOLM  COTUII?  MCOŌULM  OŌUL  COŌULM  OŌULM

`f58v.6`  qokair.ar.aly.sho[r:s].daiin.choly.dal.ykaiin.org.fchey.okaly.oky
→ COŌUIR  UR  ULM  PAOR  NUII?  SAOLM  NUL  MŌUII?  OR?  ?SARM  OŌULM  OŌM

`f58v.7`  y.daiin.qokeey.qokar.lchedy.qokalor.sheols.oteor.aiin.cheky
→ M  NUII?  COŌRRM  COŌUR  LSARNM  COŌULOR  PAROLP  OTROR  UII?  SARŌM

`f58v.8`  taiin.ckhey.daldy.qokair.alar.ytal,aiin.otaiin.ykaiin.ykaly.dam
→ TUII?  SŌARM  NULNM  COŌUIR  ULUR  MTULUII?  OTUII?  MŌUII?  MŌULM  NUS

`f58v.9`  salal.qolaiin.chockhey.tcholy.qokaiin.qokaiinos.orcheey.olaly
→ PULUL  COLUII?  SAOSŌARM  TSAOLM  COŌUII?  COŌUII?OP  ORSARRM  OLULM

`f58v.10`  ykair.shey.key.ctholy.qotalom.qokals.qokaiin.okal.okaldy.ory
→ MŌUIR  PARM  ŌRM  STAOLM  COTULOS  COŌULP  COŌUII?  OŌUL  OŌULNM  ORM

`f58v.11`  tchol,shol.tor.qokair.or.y,ykaiin.dory.okaiir.chodaiin.otals
→ TSAOLPAOL  TOR  COŌUIR  OR  MMŌUII?  NORM  OŌUIIR  SAONUII?  OTULP

`f58v.12`  oreeey.cheekey.cheal.qokey.chedal.dy.tolair.opchey.poaly.cfhy
→ ORRRRM  SARRŌRM  SARUL  COŌRM  SARNUL  NM  TOLUIR  OMSARM  MOULM  S?AM

`f58v.13`  qoeear.alkeain.ytal.chos.alor.okal.chcthy.tal,{ckh'h}y.kar
→ CORRUR  ULŌRUI?  MTUL  SAOP  ULOR  OŌUL  SASTAM  TULSŌAAM  ŌUR

`f58v.14`  shar.air.alo[r:s].chol.oeear.sho.qotal.chol.tal,ar.tar.aropam
→ PAUR  UIR  ULOR  SAOL  ORRUR  PAO  COTUL  SAOL  TULUR  TUR  UROMUS

`f58v.15`  qot,oiin.okal.aral.s.air.qoal.talchos.okal.cho.ytam.dam
→ COTOII?  OŌUL  URUL  P  UIR  COUL  TULSAOP  OŌUL  SAO  MTUS  NUS

`f58v.16`  ykam.qokair.okaly.qokal.chaly.cheockhey.olaly.taldar,al
→ MŌUS  COŌUIR  OŌULM  COŌUL  SAULM  SAROSŌARM  OLULM  TULNURUL

`f58v.17`  daiin.alal.dal.qok[a:?]r.otal.chodol.qokeal.cheol.chos.okeeam
→ NUII?  ULUL  NUL  COŌUR  OTUL  SAONOL  COŌRUL  SAROL  SAOP  OŌRRUS

`f58v.18`  taiin.chal.sheal.qockhy.dar.aiin.ockhey.qokeey.qoaiin.aral
→ TUII?  SAUL  PARUL  COSŌAM  NUR  UII?  OSŌARM  COŌRRM  COUII?  URUL

`f58v.19`  okain.chokal.sheoldy.qokor.olkam.cheol.dar.chokeey.okalchy
→ OŌUI?  SAOŌUL  PAROLNM  COŌOR  OLŌUS  SAROL  NUR  SAOŌRRM  OŌULSAM

`f58v.20`  tolain.ar.ykeain.qokeey.otal.chol.okal.ar.{chh}ty.chkalarol
→ TOLUI?  UR  MŌRUI?  COŌRRM  OTUL  SAOL  OŌUL  UR  SAATM  SAŌULUROL

`f58v.21`  olain.olalor.odaiin.qetair.otal.qokal.da[ir:in].oi[?:sh]y.otam
→ OLUI?  OLULOR  ONUII?  CRTUIR  OTUL  COŌUL  NUIR  OIM  OTUS

`f58v.22`  okar.sheey.shekealy
→ OŌUR  PARRM  PARŌRULM

`f58v.23`  pchshy.sheoltey.shopalchedy.sheolkeal.qokar.aldaiin.qokalar.dal
→ MSAPAM  PAROLTRM  PAOMULSARNM  PAROLŌRUL  COŌUR  ULNUII?  COŌULUR  NUL

`f58v.24`  qokal.daiin.qokal.cham.qokalcheal.okor,air.ain,ar,als.okam.daly
→ COŌUL  NUII?  COŌUL  SAUS  COŌULSARUL  OŌORUIR  UI?URULP  OŌUS  NULM

`f58v.25`  qotain.okeor.sheey.qokeol.okeoly.qokaly.qokair,or,tas.ykal
→ COTUI?  OŌROR  PARRM  COŌROL  OŌROLM  COŌULM  COŌUIRORTUP  MŌUL

`f58v.26`  ykaly.qokal,ol.al.qokeos.okal.ar.okos.al.shekar.qokair,alam
→ MŌULM  COŌULOL  UL  COŌROP  OŌUL  UR  OŌOP  UL  PARŌUR  COŌUIRULUS

`f58v.27`  qokar.s.aiin.al.y.qokchedy.qo[e:?]kaly.odaiin.qokar.char,alaiinom
→ COŌUR  P  UII?  UL  M  COŌSARNM  CORŌULM  ONUII?  COŌUR  SAURULUII?OS

`f58v.28`  ycheockhy.okey.okal.otaly.okaldy.okeor.sheey
→ MSAROSŌAM  OŌRM  OŌUL  OTULM  OŌULNM  OŌROR  PARRM

`f58v.29`  polal.keeo.o,leeckhey.dalar.ykeeody.choar.ckhar.yfair,alam
→ MOLUL  ŌRRO  OLRRSŌARM  NULUR  MŌRRONM  SAOUR  SŌAUR  M?UIRULUS

`f58v.30`  daiin.sheo{ikh}y.ykey.sheky.qokal.qokeey.okain.okar.ol,dam
→ NUII?  PAROIŌAM  MŌRM  PARŌM  COŌUL  COŌRRM  OŌUI?  OŌUR  OLNUS

`f58v.31`  tcheor.chor.kar.okal.qokeey.qokal.shol.qokain.ar.oetalchg
→ TSAROR  SAOR  ŌUR  OŌUL  COŌRRM  COŌUL  PAOL  COŌUI?  UR  ORTULSA?

`f58v.32`  psheey.qoty.qokar.qokey.ky.ykar.cheal.otal.kol,olchedy
→ MPARRM  COTM  COŌUR  COŌRM  ŌM  MŌUR  SARUL  OTUL  ŌOLOLSARNM

`f58v.33`  qoa[ir:is].chol,ar.chey
→ COUIR  SAOLUR  SARM

`f58v.34`  tol,sheo.keo,ar.qofcheal.dar.a{iph}ey.opchal.shockhy.okaly
→ TOLPARO  ŌROUR  CO?SARUL  NUR  UIMARM  OMSAUL  PAOSŌAM  OŌULM

`f58v.35`  daiin.otain.okain.chey.okeey.qokeeos.olar.sheo.daly.dalychs
→ NUII?  OTUI?  OŌUI?  SARM  OŌRRM  COŌRROP  OLUR  PARO  NULM  NULMSAP

`f58v.36`  tcheody.oke[o:y]r.ockhy.qokal.okal,shokey.qokeey.dalar
→ TSARONM  OŌROR  OSŌAM  COŌUL  OŌULPAOŌRM  COŌRRM  NULUR

`f58v.37`  olkeey.okar.ar.choky.otair.otol.chokey.cheeky.dalar
→ OLŌRRM  OŌUR  UR  SAOŌM  OTUIR  OTOL  SAOŌRM  SARRŌM  NULUR

`f58v.38`  ykeeody.qokar.qoky.keey.qokol.okal.okor.cheky.sydy
→ MŌRRONM  COŌUR  COŌM  ŌRRM  COŌOL  OŌUL  OŌOR  SARŌM  PMNM

`f58v.39`  oshar.qokain.okam.shear.ch[er:?].sarols
→ OPAUR  COŌUI?  OŌUS  PARUR  SARR  PUROLP

### f65r  ·  herbal

`f65r.1`  otaim,dam.alam
→ OTUISNUS  ULUS

### f65v  ·  herbal

`f65v.1`  cphy.fchecfhy.dy<->dchepain.shety.qopy.fol.chpdy
→ SMAM  ?SARS?AM  NMNSARMUI?  PARTM  COMM  ?OL  SAMNM

`f65v.2`  daiin.sheek.l,ody<->yteo.qop[s:r].air.cheot[ee:ch]y.dal[o:a]m
→ NUII?  PARRŌ  LONMMTRO  COMP  UIR  SAROTRRM  NULOS

`f65v.3`  ytal.cheot.shky.y<->[s:?]as.cheody
→ MTUL  SAROT  PAŌM  MPUP  SARONM

`f65v.4`  toeedy.otar.shedy<->yteey.sheody.qok[es:?]d.yfchey
→ TORRNM  OTUR  PARNMMTRRM  PARONM  COŌRPN  M?SARM

`f65v.5`  dshedy.okeody.qokd<->shckhy.choky.chokeody.okey,dy
→ NPARNM  OŌRONM  COŌNPASŌAM  SAOŌM  SAOŌRONM  OŌRMNM

`f65v.6`  qo.ytchey.sh,{ckhh}cphy<->ykchedy.chedy.shckhdy
→ CO  MTSARM  PASŌAASMAMMŌSARNM  SARNM  PASŌANM

### f66r  ·  text/preface

`f66r.1`  rary
→ RURM

`f66r.2`  [r:s]als
→ RULP

`f66r.3`  qo[r:n]
→ COR

`f66r.4`  dary
→ NURM

`f66r.5`  ykeol
→ MŌROL

`f66r.6`  saly
→ PULM

`f66r.7`  salf
→ PUL?

`f66r.8`  fary
→ ?URM

`f66r.9`  qotesy
→ COTRPM

`f66r.10`  ykaly
→ MŌULM

`f66r.11`  doly
→ NOLM

`f66r.12`  saiin
→ PUII?

`f66r.13`  qokal
→ COŌUL

`f66r.14`  qolsa
→ COLPU

`f66r.15`  raral
→ RURUL

`f66r.16`  y
→ M

`f66r.17`  o
→ O

`f66r.18`  s
→ P

`f66r.19`  sh
→ PA

`f66r.20`  y
→ M

`f66r.21`  d
→ N

`f66r.22`  o
→ O

`f66r.23`  f
→ ?

`f66r.24`  @169;
→ —

`f66r.25`  x
→ ?

`f66r.26`  air
→ UIR

`f66r.27`  d
→ N

`f66r.28`  sh
→ PA

`f66r.29`  y
→ M

`f66r.30`  f
→ ?

`f66r.31`  f
→ ?

`f66r.32`  y
→ M

`f66r.33`  o
→ O

`f66r.34`  d
→ N

`f66r.35`  s
→ P

`f66r.36`  f
→ ?

`f66r.37`  c
→ S

`f66r.38`  @172;
→ —

`f66r.39`  x
→ ?

`f66r.40`  t
→ T

`f66r.41`  o
→ O

`f66r.42`  @195;
→ —

`f66r.43`  l
→ L

`f66r.44`  r
→ R

`f66r.45`  t
→ T

`f66r.46`  o
→ O

`f66r.47`  x
→ ?

`f66r.48`  p
→ M

`f66r.49`  d
→ N

`f66r.50`  pdaiin.oteedy.opchedy.chap.chefchy.shddy.ypches.cholpchd.okedals
→ MNUII?  OTRRNM  OMSARNM  SAUM  SAR?SAM  PANNM  MMSARP  SAOLMSAN  OŌRNULP

`f66r.51`  sair.shekey.qokeedar.okal.okedy.qokeedy.qokal.okedy.qokshd
→ PUIR  PARŌRM  COŌRRNUR  OŌUL  OŌRNM  COŌRRNM  COŌUL  OŌRNM  COŌPAN

`f66r.52`  ykshedy.chady.cthdy.qokees.cheeo.okcho,dy.chekeey.chedy.chckhy
→ MŌPARNM  SAUNM  STANM  COŌRRP  SARRO  OŌSAONM  SARŌRRM  SARNM  SASŌAM

`f66r.53`  shdy.qotedy.chdy.chedy.qotedal.chcpheor.ykady.dar.qotey,k[o:a]l,ar
→ PANM  COTRNM  SANM  SARNM  COTRNUL  SASMAROR  MŌUNM  NUR  COTRMŌOLUR

`f66r.54`  qokeeody.qokeody.qokeody.qokar.sheky.qokeeody.okedy.kodary
→ COŌRRONM  COŌRONM  COŌRONM  COŌUR  PARŌM  COŌRRONM  OŌRNM  ŌONURM

`f66r.55`  ykeeody.choekeey.okeody.chekeody.qokeey.dyky.chctho.rotaiin
→ MŌRRONM  SAORŌRRM  OŌRONM  SARŌRONM  COŌRRM  NMŌM  SASTAO  ROTUII?

`f66r.56`  dsheol.okaiin.sheodaiin
→ NPAROL  OŌUII?  PARONUII?

`f66r.57`  tocpheey.dol.kchody.qokeody.qokshy.qopaiin.dairykodas.okyd
→ TOSMARRM  NOL  ŌSAONM  COŌRONM  COŌPAM  COMUII?  NUIRMŌONUP  OŌMN

`f66r.58`  dsholdaiir.dalky.shky.qoky.shekair.choty.dar.okeey.shdy.ykol
→ NPAOLNUIIR  NULŌM  PAŌM  COŌM  PARŌUIR  SAOTM  NUR  OŌRRM  PANM  MŌOL

`f66r.59`  qo,cheky.shcthy.dalalshedy.cheta,r,sheod.shokaiir.ch{ckhh}y.da[r:s]d
→ COSARŌM  PASTAM  NULULPARNM  SARTURPARON  PAOŌUIIR  SASŌAAM  NURN

`f66r.60`  shor.sheodal.sholdy.qokchedy.qopchy.qoty,chedaiir.chees,kardy
→ PAOR  PARONUL  PAOLNM  COŌSARNM  COMSAM  COTMSARNUIIR  SARRPŌURNM

`f66r.61`  qokchey.qokaiir.cheky.daly.daiin.dal,shedy.chedy.lkar.ol.okedy
→ COŌSARM  COŌUIIR  SARŌM  NULM  NUII?  NULPARNM  SARNM  LŌUR  OL  OŌRNM

`f66r.62`  ol.cheeky.daiir.chky.axor.akar,{i'h},y.daiin
→ OL  SARRŌM  NUIIR  SAŌM  U?OR  UŌURIAM  NUII?

`f66r.63`  pchof.sholfordaiin.qotar.otalor.fchedy[r:s].chedy.dar.odair.ofaram
→ MSAO?  PAOL?ORNUII?  COTUR  OTULOR  ?SARNMR  SARNM  NUR  ONUIR  O?URUS

`f66r.64`  dalcheeeky.sheol.dairody.chekchy.shed.ykesho.l.lor.sheor,che[a:o]l
→ NULSARRRŌM  PAROL  NUIRONM  SARŌSAM  PARN  MŌRPAO  L  LOR  PARORSARUL

`f66r.65`  dor.shedy.okar.shedy.kcheody.chxar.daly.fchdar.cheor,aly.[r:s]y
→ NOR  PARNM  OŌUR  PARNM  ŌSARONM  SA?UR  NULM  ?SANUR  SARORULM  RM

`f66r.66`  shor.shckheody.dal,shedy.qokor,al,shes
→ PAOR  PASŌARONM  NULPARNM  COŌORULPARP

`f66r.67`  psheody.cfhol.shofol.okeody.qokaldy.ytarody.shedy.shedy.dair
→ MPARONM  S?AOL  PAO?OL  OŌRONM  COŌULNM  MTURONM  PARNM  PARNM  NUIR

`f66r.68`  sair,ol.daiin.daiin.dal.dol.cheody.dair,aly.dairal.dolarshy,dor
→ PUIROL  NUII?  NUII?  NUL  NOL  SARONM  NUIRULM  NUIRUL  NOLURPAMNOR

`f66r.69`  tosheo.qokaldy.oky.ol.kcheeky.qoky.dary.okees.oly
→ TOPARO  COŌULNM  OŌM  OL  ŌSARRŌM  COŌM  NURM  OŌRRP  OLM

`f66r.70`  todeeey.keody.chdy.keody.shedy.shekeefy.chdy.sheol.shol.kedy.daly
→ TONRRRM  ŌRONM  SANM  ŌRONM  PARNM  PARŌRR?M  SANM  PAROL  PAOL  ŌRNM  NULM

`f66r.71`  saiir.cheol.kal.sheody.chcthedy.dal.shol.qokeody.chody.kechody
→ PUIIR  SAROL  ŌUL  PARONM  SASTARNM  NUL  PAOL  COŌRONM  SAONM  ŌRSAONM

`f66r.72`  sshedy.oteedy.ykeeody.sheocthy.ol,ld,lshedy.chokeey.chekey.chey
→ PPARNM  OTRRNM  MŌRRONM  PAROSTAM  OLLNLPARNM  SAOŌRRM  SARŌRM  SARM

`f66r.73`  ysheeod.qoteeod.qotol,qoky.chckhedy.shey.dcheol.cheky.cheo,dor
→ MPARRON  COTRRON  COTOLCOŌM  SASŌARNM  PARM  NSAROL  SARŌM  SARONOR

`f66r.74`  ydaiin.shedy.otchedy.oteochey.tolchedy.lsheody.qoky,daiin.otam
→ MNUII?  PARNM  OTSARNM  OTROSARM  TOLSARNM  LPARONM  COŌMNUII?  OTUS

`f66r.75`  tcheo.sheor.oteody.lpchees,ol,ar.alkey.otey.ltsholy.shecthy.r,ol
→ TSARO  PAROR  OTRONM  LMSARRPOLUR  ULŌRM  OTRM  LTPAOLM  PARSTAM  ROL

`f66r.76`  daiin.sheol.qocthedy.qokedy.lchey.qokaly.shcthy.qotal.otchdy
→ NUII?  PAROL  COSTARNM  COŌRNM  LSARM  COŌULM  PASTAM  COTUL  OTSANM

`f66r.77`  qokey.ar.olkeol.qokal.cheoky.ykchdy.chody.sheody.qoky.ldy
→ COŌRM  UR  OLŌROL  COŌUL  SAROŌM  MŌSANM  SAONM  PARONM  COŌM  LNM

`f66r.78`  dor.aiin.sheeol.lshedy.lchedy.cheedy.shekol.dalol.lodaiin
→ NOR  UII?  PARROL  LPARNM  LSARNM  SARRNM  PARŌOL  NULOL  LONUII?

`f66r.79`  sheol.oteey,ldaiin.okalchedy.pchedy.kody.qotchedy.cphedy
→ PAROL  OTRRMLNUII?  OŌULSARNM  MSARNM  ŌONM  COTSARNM  SMARNM

`f66r.80`  daiin.shey.qoteoly.raiin.sheedy.shcthy.lkeol.qokol.dkar
→ NUII?  PARM  COTROLM  RUII?  PARRNM  PASTAM  LŌROL  COŌOL  NŌUR

`f66r.81`  lchey.lkeedy.chety.shekaly.shckhar
→ LSARM  LŌRRNM  SARTM  PARŌULM  PASŌAUR

`f66r.82`  otcheo,daiin.chty.ykees,cheg
→ OTSARONUII?  SATM  MŌRRPSAR?

### f66v  ·  herbal

`f66v.1`  okeodof.sheod.ychoopy.opch.dal.dor,sheefy.ytody.da[l:?]deam
→ OŌRONO?  PARON  MSAOOMM  OMSA  NUL  NORPARR?M  MTONM  NULNRUS

`f66v.2`  teodal.t[che:{chh}]dy.dshey.okshedy.okeedy.dcheeky.daldy.qotal.sy
→ TRONUL  TSARNM  NPARM  OŌPARNM  OŌRRNM  NSARRŌM  NULNM  COTUL  PM

`f66v.3`  ytos.s.or.sheeky.okechdy.ok[ee:ch]dal.dar.otal.chody.cheky
→ MTOP  P  OR  PARRŌM  OŌRSANM  OŌRRNUL  NUR  OTUL  SAONM  SARŌM

`f66v.4`  shokeshy.daiin.cheos.chety.dol.chckhy.dal.ko,dal.chekal.dal
→ PAOŌRPAM  NUII?  SAROP  SARTM  NOL  SASŌAM  NUL  ŌONUL  SARŌUL  NUL

`f66v.5`  shdy.shedefam.qokedy.chokal.dal
→ PANM  PARNR?US  COŌRNM  SAOŌUL  NUL

`f66v.6`  tchod.sheody.shckhed.chos.chor.sheo.keody.chepar.sheopam
→ TSAON  PARONM  PASŌARN  SAOP  SAOR  PARO  ŌRONM  SARMUR  PAROMUS

`f66v.7`  qokeos.sheody.chekeos.chody.kotody.qotchdy.chckhd.ytchdy
→ COŌROP  PARONM  SARŌROP  SAONM  ŌOTONM  COTSANM  SASŌAN  MTSANM

`f66v.8`  dchekeedy.cheody.qokchdy.qokol.keedy.cheky.chety.kody
→ NSARŌRRNM  SARONM  COŌSANM  COŌOL  ŌRRNM  SARŌM  SARTM  ŌONM

`f66v.9`  pody.sheody.chpadar.sheey.fchdly.cheoseesey.kchy.qofchal
→ MONM  PARONM  SAMUNUR  PARRM  ?SANLM  SAROPRRPRM  ŌSAM  CO?SAUL

`f66v.10`  dshal.keedy.qok,[o:y]r.okaiin.dol.kaldaiin.otal.dokal.okag
→ NPAUL  ŌRRNM  COŌOR  OŌUII?  NOL  ŌULNUII?  OTUL  NOŌUL  OŌU?

`f66v.11`  yteeod.aiin.shekeod.saiin.ykofar.otaiin.otar.ched[y:o].kar[{c'}:s]
→ MTRRON  UII?  PARŌRON  PUII?  MŌO?UR  OTUII?  OTUR  SARNM  ŌURS

`f66v.12`  qekar.okedy.cheky.dal.chekal.chckhy.kal.kal.dar.chk[ch:ee]ody
→ CRŌUR  OŌRNM  SARŌM  NUL  SARŌUL  SASŌAM  ŌUL  ŌUL  NUR  SAŌSAONM

`f66v.13`  ydees.shey.daiin.dalkal<->ykedaiin.shedar.ok[ch:ee]dy.oty
→ MNRRP  PARM  NUII?  NULŌULMŌRNUII?  PARNUR  OŌSANM  OTM

### f67r1  ·  astronomical

`f67r1.1`  teeodaiin.shey.epairody.osaiin.yteeoey.shey.epaiin.o.aiin
→ TRRONUII?  PARM  RMUIRONM  OPUII?  MTRRORM  PARM  RMUII?  O  UII?

`f67r1.2`  daiir.okeody.qoekeey.sar.oeteody.oteey.keey.keo.keeoda[l:?]
→ NUIIR  OŌRONM  CORŌRRM  PUR  ORTRONM  OTRRM  ŌRRM  ŌRO  ŌRRONUL

`f67r1.3`  ycheo.s.o,iim.[che:eee]os.aiin.okesoe.ar.am.shees.dalaiin.dam
→ MSARO  P  OIIS  SAROP  UII?  OŌRPOR  UR  US  PARRP  NULUII?  NUS

`f67r1.4`  cheodaiin.[ch:a]ekeey.s.ar.air.s,o,ar.cheey.dair.cthey
→ SARONUII?  SARŌRRM  P  UR  UIR  POUR  SARRM  NUIR  STARM

`f67r1.5`  soairol.shdy.chokeody.ykeedal.ol.oteodaiin.cho{ikh}edy.ot.chteokaiin.choteedy.otor.epchy.chpar.ar.sheees.deedy.soeteed.octheey.s.o.eokeot.y.choteoky.chockhy.okees.sor.aiin.daram.schdes.chdar.dar.dchschdy.dar.dar.ar.otardar.ykaros
→ POUIROL  PANM  SAOŌRONM  MŌRRNUL  OL  OTRONUII?  SAOIŌARNM  OT  SATROŌUII?  SAOTRRNM  OTOR  RMSAM  SAMUR  UR  PARRRP  NRRNM  PORTRRN  OSTARRM  P  O  ROŌROT  M  SAOTROŌM  SAOSŌAM  OŌRRP  POR  UII?  NURUS  PSANRP  SANUR  NUR  NSAPSANM  NUR  NUR  UR  OTURNUR  MŌUROP

`f67r1.6`  dair.al.cheol.dal.oekaiin.sol.daiin.eetees.saiin.ykeos.l.chy.otodaiin.chetejy.otar.dair.ar.chedar.okeedy.ot[e:i]odaiin.ychsy.chekeey.ot.dol.al.cheor.okeo,r.oiin.cheeky.ary.okeo,keds.oshey.shchey.chol.dair.dain.cho.dar.aldy
→ NUIR  UL  SAROL  NUL  ORŌUII?  POL  NUII?  RRTRRP  PUII?  MŌROP  L  SAM  OTONUII?  SARTR?M  OTUR  NUIR  UR  SARNUR  OŌRRNM  OTRONUII?  MSAPM  SARŌRRM  OT  NOL  UL  SAROR  OŌROR  OII?  SARRŌM  URM  OŌROŌRNP  OPARM  PASARM  SAOL  NUIR  NUI?  SAO  NUR  ULNM

`f67r1.7`  archeo,r.qoikeey.oteeos.cheockhey.oteochedy.okechdar.dararal.okeorar.sotey.dair.yteey.oteo.s.oteees.oteo.otee[s:e']y.sheokeey.oteodal.chokeed.sar.ain.y.oto.keedais.deeety.okeey.teodain.chekchy.dair.chparam
→ URSAROR  COIŌRRM  OTRROP  SAROSŌARM  OTROSARNM  OŌRSANUR  NURURUL  OŌRORUR  POTRM  NUIR  MTRRM  OTRO  P  OTRRRP  OTRO  OTRRPM  PAROŌRRM  OTRONUL  SAOŌRRN  PUR  UI?  M  OTO  ŌRRNUIP  NRRRTM  OŌRRM  TRONUI?  SARŌSAM  NUIR  SAMURUS

`f67r1.8`  otaldy
→ OTULNM

`f67r1.9`  otoky
→ OTOŌM

`f67r1.10`  seeaiir
→ PRRUIIR

`f67r1.11`  ykees.ary
→ MŌRRP  URM

`f67r1.12`  sosaiir
→ POPUIIR

`f67r1.13`  oteey.dar
→ OTRRM  NUR

`f67r1.14`  yto,daiir
→ MTONUIIR

`f67r1.15`  sheosam
→ PAROPUS

`f67r1.16`  ykeeody
→ MŌRRONM

`f67r1.17`  okeol.sal
→ OŌROL  PUL

`f67r1.18`  okeey.sar
→ OŌRRM  PUR

`f67r1.19`  dalary
→ NULURM

### f67r2  ·  astronomical

`f67r2.1`  ykshy.s.aram
→ MŌPAM  P  URUS

`f67r2.2`  ykecho.ols.eesydy
→ MŌRSAO  OLP  RRPMNM

`f67r2.3`  [{c'}:@164;]ey.shs.okar
→ SRM  PAP  OŌUR

`f67r2.4`  shekchy.sykos
→ PARŌSAM  PMŌOP

`f67r2.5`  ykeody.okchy
→ MŌRONM  OŌSAM

`f67r2.6`  dchetay
→ NSARTUM

`f67r2.7`  ykchy.kchey.ykchys
→ MŌSAM  ŌSARM  MŌSAMP

`f67r2.8`  chkchdar
→ SAŌSANUR

`f67r2.9`  ykar.ykaly
→ MŌUR  MŌULM

`f67r2.10`  lkshy,kchy.okar
→ LŌPAMŌSAM  OŌUR

`f67r2.11`  chky.chykchs.chy
→ SAŌM  SAMŌSAP  SAM

`f67r2.12`  ykees.ykchos
→ MŌRRP  MŌSAOP

`f67r2.13`  opodchol.s.ain.aldy
→ OMONSAOL  P  UI?  ULNM

`f67r2.14`  soeey.doiin.oldy
→ PORRM  NOII?  OLNM

`f67r2.15`  dolchsody
→ NOLSAPONM

`f67r2.16`  oda[eiin:iiin].okoes.oekain.y
→ ONURII?  OŌORP  ORŌUI?  M

`f67r2.17`  otchey.soraiir.dy
→ OTSARM  PORUIIR  NM

`f67r2.18`  qopchy.daiin.dal
→ COMSAM  NUII?  NUL

`f67r2.19`  ydchos.ain.ar.amy
→ MNSAOP  UI?  UR  USM

`f67r2.20`  chocfhy.saral
→ SAOS?AM  PURUL

`f67r2.21`  sain.am.ar
→ PUI?  US  UR

`f67r2.22`  okal
→ OŌUL

`f67r2.23`  oparchy.salsain
→ OMURSAM  PULPUI?

`f67r2.24`  sodar.ofar.ar
→ PONUR  O?UR  UR

`f67r2.25`  ydam
→ MNUS

`f67r2.26`  yteoor.yto.ykor
→ MTROOR  MTO  MŌOR

`f67r2.27`  okeo,r.aiin.am
→ OŌROR  UII?  US

`f67r2.28`  okain.a[m:g]
→ OŌUI?  US

`f67r2.29`  ytody.saiin
→ MTONM  PUII?

`f67r2.30`  ochol.olol
→ OSAOL  OLOL

`f67r2.31`  opcholdy
→ OMSAOLNM

`f67r2.32`  dosar.odas.air.alaiin
→ NOPUR  ONUP  UIR  ULUII?

`f67r2.33`  dokan.oear.odal
→ NOŌU?  ORUR  ONUL

`f67r2.34`  ofar.oeoldan
→ O?UR  OROLNU?

`f67r2.35`  chol.[g:d]iin.okol
→ SAOL  ?II?  OŌOL

`f67r2.36`  ytor.daiin.or
→ MTOR  NUII?  OR

`f67r2.37`  ytoaiin
→ MTOUII?

`f67r2.38`  otoldos.octhole
→ OTOLNOP  OSTAOLR

`f67r2.39`  sor.chedaiin.dy
→ POR  SARNUII?  NM

`f67r2.40`  yteos.oiin.og
→ MTROP  OII?  O?

`f67r2.41`  ytoeopchey.chekody
→ MTOROMSARM  SARŌONM

`f67r2.42`  sosho.chos.ockhy
→ POPAO  SAOP  OSŌAM

`f67r2.43`  daiin.aiin.os.qsg
→ NUII?  UII?  OP  CP?

`f67r2.44`  ofydy.sheody.aiin
→ O?MNM  PARONM  UII?

`f67r2.45`  ycheody.es.odaiiin
→ MSARONM  RP  ONUIII?

`f67r2.46`  yekees.oraly
→ MRŌRRP  ORULM

`f67r2.47`  yfain
→ M?UI?

`f67r2.48`  todaiin.dain.dy
→ TONUII?  NUI?  NM

`f67r2.49`  os,choer.aiin
→ OPSAORR  UII?

`f67r2.50`  choee[a:y].sal
→ SAORRU  PUL

`f67r2.51`  da[d:g]aiin
→ NUNUII?

`f67r2.52`  qotoear
→ COTORUR

`f67r2.53`  dchdar
→ NSANUR

`f67r2.54`  y,saldal
→ MPULNUL

`f67r2.55`  ytodal
→ MTONUL

`f67r2.56`  tol.daiin
→ TOL  NUII?

`f67r2.57`  otar,dy
→ OTURNM

`f67r2.58`  cho.dal,g
→ SAO  NUL?

`f67r2.59`  ytchodly
→ MTSAONLM

`f67r2.60`  octhys
→ OSTAMP

`f67r2.61`  ytokar
→ MTOŌUR

`f67r2.62`  otolor
→ OTOLOR

`f67r2.63`  okodar
→ OŌONUR

`f67r2.64`  s.air
→ P  UIR

`f67r2.65`  soe[a:o]r
→ PORUR

`f67r2.66`  cpheey
→ SMARRM

`f67r2.67`  okodar
→ OŌONUR

`f67r2.68`  oepchod
→ ORMSAON

`f67r2.69`  s.a{cthh}y
→ P  USTAAM

`f67r2.70`  osar
→ OPUR

`f67r2.71`  oran
→ ORU?

`f67r2.72`  dar.aldaiin.ydaiin.qkoy.ydaiin.qofair.ypair.ykoaiin.ydoly.ytalchos.oly.okey
→ NUR  ULNUII?  MNUII?  CŌOM  MNUII?  CO?UIR  MMUIR  MŌOUII?  MNOLM  MTULSAOP  OLM  OŌRM

`f67r2.73`  sshey.sy,shees.qeykeey.ykchey.ykchey.qokeochy.oaiin.okol.ar.olar
→ PPARM  PMPARRP  CRMŌRRM  MŌSARM  MŌSARM  COŌROSAM  OUII?  OŌOL  UR  OLUR

`f67r2.74`  yshey.qokeeody.cheos.oeeos.qockhy.chos.aiin.okeeody.qokoaiin.odain.ar.air.ay
→ MPARM  COŌRRONM  SAROP  ORROP  COSŌAM  SAOP  UII?  OŌRRONM  COŌOUII?  ONUI?  UR  UIR  UM

### f67v2  ·  unknown

`f67v2.1`  otchdy
→ OTSANM

`f67v2.2`  otararain
→ OTURURUI?

`f67v2.3`  tol.or.ain.am.otoly.sair.[g:m]
→ TOL  OR  UI?  US  OTOLM  PUIR  ?

`f67v2.4`  daiin.[t:k]aedaiin.ar.okor
→ NUII?  TURNUII?  UR  OŌOR

`f67v2.5`  okeey.keoy.salal
→ OŌRRM  ŌROM  PULUL

`f67v2.6`  ykaralam.olalade.odam
→ MŌURULUS  OLULUNR  ONUS

`f67v2.7`  taol.daig.sakar.dam
→ TUOL  NUI?  PUŌUR  NUS

`f67v2.8`  solair.cphey.solal.daly
→ POLUIR  SMARM  POLUL  NULM

`f67v2.9`  okeal.o?ol.ar.okaldam
→ OŌRUL  OOL  UR  OŌULNUS

`f67v2.10`  koain.opal.ol.of[o:y]lain.oar
→ ŌOUI?  OMUL  OL  O?OLUI?  OUR

`f67v2.11`  dcheeor.ochepalain
→ NSARROR  OSARMULUI?

`f67v2.12`  oeolales.ai[s:r]ar
→ OROLULRP  UIPUR

`f67v2.13`  okydseog.oeepoaly
→ OŌMNPRO?  ORRMOULM

`f67v2.14`  o?r.ykaly.char
→ OR  MŌULM  SAUR

`f67v2.15`  o.chekais.okolaim
→ O  SARŌUIP  OŌOLUIS

`f67v2.16`  okar.alet.olkao
→ OŌUR  ULRT  OLŌUO

`f67v2.17`  qokoaiin.ocfhhy
→ COŌOUII?  OS?AAM

`f67v2.18`  okeeey.oekchdy
→ OŌRRRM  ORŌSANM

`f67v2.19`  soaiin.dalam
→ POUII?  NULUS

`f67v2.20`  sary.okora[l:n]
→ PURM  OŌORUL

`f67v2.21`  oko???
→ OŌO

`f67v2.22`  okchos,am
→ OŌSAOPUS

### f67v1  ·  astronomical

`f67v1.1`  damamm
→ NUSUSS

`f67v1.2`  dairkal
→ NUIRŌUL

`f67v1.3`  okal.ary
→ OŌUL  URM

`f67v1.4`  dar.echkalal
→ NUR  RSAŌULUL

`f67v1.5`  okol.aldy
→ OŌOL  ULNM

`f67v1.6`  dchesykchy
→ NSARPMŌSAM

`f67v1.7`  ykeodar
→ MŌRONUR

`f67v1.8`  deeeoskol
→ NRRROPŌOL

`f67v1.9`  ockhosam
→ OSŌAOPUS

`f67v1.10`  kochardy
→ ŌOSAURNM

`f67v1.11`  ochodare
→ OSAONURR

`f67v1.12`  ols,aiiny
→ OLPUII?M

`f67v1.13`  otorkeol.orsheey.dary
→ OTORŌROL  ORPARRM  NURM

`f67v1.14`  okechey.cheody.cheky
→ OŌRSARM  SARONM  SARŌM

`f67v1.15`  otechodor.odcheey
→ OTRSAONOR  ONSARRM

`f67v1.16`  chockhey.chockhy
→ SAOSŌARM  SAOSŌAM

`f67v1.17`  yteeey.keeochy.dair.ockey
→ MTRRRM  ŌRROSAM  NUIR  OSŌRM

`f67v1.18`  keechey.chy.koldy
→ ŌRRSARM  SAM  ŌOLNM

`f67v1.19`  pchodaiin.otch.oekeey.dy
→ MSAONUII?  OTSA  ORŌRRM  NM

`f67v1.20`  dcheeos.qokeeeody.eeis.olcheeg
→ NSARROP  COŌRRRONM  RRIP  OLSARR?

`f67v1.21`  ykeeo.cheo.daiin.ypcheg.oty
→ MŌRRO  SARO  NUII?  MMSAR?  OTM

`f67v1.22`  opcheey.chso.cheey.chedaly
→ OMSARRM  SAPO  SARRM  SARNULM

`f67v1.23`  ykeeey.qokeey.olokeey.s
→ MŌRRRM  COŌRRM  OLOŌRRM  P

`f67v1.24`  osheey.keeody.cheedals
→ OPARRM  ŌRRONM  SARRNULP

`f67v1.25`  okar.shey.qokche[o:a]r.daiiin
→ OŌUR  PARM  COŌSAROR  NUIII?

`f67v1.26`  oeees.ote[ch:ee]y.o,keey
→ ORRRP  OTRSAM  OŌRRM

`f67v1.27`  okeeodaiin.saii.dairal
→ OŌRRONUII?  PUII  NUIRUL

`f67v1.28`  oksheeody.or.aral
→ OŌPARRONM  OR  URUL

`f67v1.29`  olar.aroky
→ OLUR  UROŌM

### f68r1  ·  astronomical

`f68r1.1`  shokchy.chteey.choteey.cphol.cheor.opcheeol.otor.choctheeey.okchoal
→ PAOŌSAM  SATRRM  SAOTRRM  SMAOL  SAROR  OMSARROL  OTOR  SAOSTARRRM  OŌSAOUL

`f68r1.2`  tochso.otchl.qokeeedy.cheey.cheeteey.yteody.chpor.cheokorchey.chod
→ TOSAPO  OTSAL  COŌRRRNM  SARRM  SARRTRRM  MTRONM  SAMOR  SAROŌORSARM  SAON

`f68r1.3`  ykor.shey.qocheey.chokal<->okeey.ror.eckhear.daram
→ MŌOR  PARM  COSARRM  SAOŌULOŌRRM  ROR  RSŌARUR  NURUS

`f68r1.4`  dchor.okaiiin
→ NSAOR  OŌUIII?

`f68r1.5`  yky
→ MŌM

`f68r1.6`  dary
→ NURM

`f68r1.7`  chkchykoly
→ SAŌSAMŌOLM

`f68r1.8`  okodaly
→ OŌONULM

`f68r1.9`  odchecthy
→ ONSARSTAM

`f68r1.10`  otcheody
→ OTSARONM

`f68r1.11`  okoaly
→ OŌOULM

`f68r1.12`  chocfhy
→ SAOS?AM

`f68r1.13`  octhey
→ OSTARM

`f68r1.14`  otshey
→ OTPARM

`f68r1.15`  otydy
→ OTMNM

`f68r1.16`  okear
→ OŌRUR

`f68r1.17`  cphocthy
→ SMAOSTAM

`f68r1.18`  ytchody
→ MTSAONM

`f68r1.19`  otys
→ OTMP

`f68r1.20`  olor
→ OLOR

`f68r1.21`  ockhy
→ OSŌAM

`f68r1.22`  ofcheor
→ O?SAROR

`f68r1.23`  otchdy
→ OTSANM

`f68r1.24`  otykchs
→ OTMŌSAP

`f68r1.25`  otol
→ OTOL

`f68r1.26`  otor
→ OTOR

`f68r1.27`  oiinar
→ OII?UR

`f68r1.28`  okoldy
→ OŌOLNM

`f68r1.29`  ykchdy
→ MŌSANM

`f68r1.30`  @167;oeeod{c@196;h}y
→ ORRONSAM

`f68r1.31`  ocphy
→ OSMAM

`f68r1.32`  okeeodal
→ OŌRRONUL

`f68r1.33`  okshor
→ OŌPAOR

`f68r1.34`  osdaiin
→ OPNUII?

`f68r1.35`  otochedy
→ OTOSARNM

`f68r1.36`  dolchedy
→ NOLSARNM

`f68r1.37`  oky.okchdy.okardy.q[?:k]ear.oygy
→ OŌM  OŌSANM  OŌURNM  CRUR  OM?M

### f68r2  ·  astronomical

`f68r2.1`  tsheeor.chor.sheal,dar.opchey.oeecthy.sheol.dokechy.otcheoly
→ TPARROR  SAOR  PARULNUR  OMSARM  ORRSTAM  PAROL  NOŌRSAM  OTSAROLM

`f68r2.2`  dchy.ykeechy.dchyky.okeeody.rcheodal.chokeey.cheor.oram
→ NSAM  MŌRRSAM  NSAMŌM  OŌRRONM  RSARONUL  SAOŌRRM  SAROR  ORUS

`f68r2.3`  tcheos.otchoky.okchol.okol.sheeor.chodchy.qokchdar
→ TSAROP  OTSAOŌM  OŌSAOL  OŌOL  PARROR  SAONSAM  COŌSANUR

`f68r2.4`  chor.chesy.or[ee:a]d.qoeeckhy.qockheol.qokeol.cheoal.dcholal
→ SAOR  SARPM  ORRRN  CORRSŌAM  COSŌAROL  COŌROL  SAROUL  NSAOLUL

`f68r2.5`  kcheoey.cheody<->sain.ykeody.chykchy
→ ŌSARORM  SARONMPUI?  MŌRONM  SAMŌSAM

`f68r2.6`  okeo.ok[a:?]r.ok[y:o].okozy.okaesy.qokool.chio.qoiol
→ OŌRO  OŌUR  OŌM  OŌO?M  OŌURPM  COŌOOL  SAIO  COIOL

`f68r2.7`  o@167;olch{c@133;h}y
→ OOLSASAM

`f68r2.8`  cheorol
→ SAROROL

`f68r2.9`  odaiin
→ ONUII?

`f68r2.10`  ochory
→ OSAORM

`f68r2.11`  shdar
→ PANUR

`f68r2.12`  dchol
→ NSAOL

`f68r2.13`  todaraiily
→ TONURUIILM

`f68r2.14`  olcheesey
→ OLSARRPRM

`f68r2.15`  okchor
→ OŌSAOR

`f68r2.16`  oteool
→ OTROOL

`f68r2.17`  oydchy
→ OMNSAM

`f68r2.18`  okeeeody
→ OŌRRRONM

`f68r2.19`  cholar
→ SAOLUR

`f68r2.20`  dcheoldy
→ NSAROLNM

`f68r2.21`  oteeear
→ OTRRRUR

`f68r2.22`  otoeeo
→ OTORRO

`f68r2.23`  ofcheody
→ O?SARONM

`f68r2.24`  otcheodar
→ OTSARONUR

`f68r2.25`  odair.chol
→ ONUIR  SAOL

`f68r2.26`  opocphor
→ OMOSMAOR

`f68r2.27`  otoshol
→ OTOPAOL

`f68r2.28`  chodar
→ SAONUR

`f68r2.29`  sheey
→ PARRM

`f68r2.30`  ok[eeee:eech]or
→ OŌRRRROR

`f68r2.31`  okey.okoaiin.okol.o,ky.oeeeo.r.okey.okeeol.cheo.o.@231;@232;@233;@234;
→ OŌRM  OŌOUII?  OŌOL  OŌM  ORRRO  R  OŌRM  OŌRROL  SARO  O  —

### f68r3  ·  astronomical

`f68r3.1`  odeed.oteedy,cheoteey.oshchey.chokol.cheody.chedy.oteodaiin.otchodal.sol.cheor.oteo.choteey.oeteody.opcheody.dchedy.daiin.oteeody.dascheedy.oteeody.qoeee{ct}{c@204;}g.dcheeo.okeodly.do.ls.oschaiin.cheockhedchy.chodal.cheod[a:y].chol,al.oteodched.okedy.qokeey.shoky.dol.daleeed.okeoeiiir
→ ONRRN  OTRRNMSAROTRRM  OPASARM  SAOŌOL  SARONM  SARNM  OTRONUII?  OTSAONUL  POL  SAROR  OTRO  SAOTRRM  ORTRONM  OMSARONM  NSARNM  NUII?  OTRRONM  NUPSARRNM  OTRRONM  CORRRSTS?  NSARRO  OŌRONLM  NO  LP  OPSAUII?  SAROSŌARNSAM  SAONUL  SARONU  SAOLUL  OTRONSARN  OŌRNM  COŌRRM  PAOŌM  NOL  NULRRRN  OŌRORIIIR

`f68r3.2`  toees.ykeo,she.qokolchey.qokchdy
→ TORRP  MŌROPAR  COŌOLSARM  COŌSANM

`f68r3.3`  tochedy.chocphy.qokchdy.dyl.okald
→ TOSARNM  SAOSMAM  COŌSANM  NML  OŌULN

`f68r3.4`  dchy,kchy.daiir.chok.ockhydar
→ NSAMŌSAM  NUIIR  SAOŌ  OSŌAMNUR

`f68r3.5`  qokol.chdchol.qoteey.che,kechy.okchdy
→ COŌOL  SANSAOL  COTRRM  SARŌRSAM  OŌSANM

`f68r3.6`  dchokchy.{c'hh}y.okey.oteos.okolshy
→ NSAOŌSAM  SAAM  OŌRM  OTROP  OŌOLPAM

`f68r3.7`  pchody.qokchy.dshol.d{c'y},o,tgolg?
→ MSAONM  COŌSAM  NPAOL  NSMOT?OL?

`f68r3.8`  keeoty.oteey.daiin.dcheeody.oteey
→ ŌRROTM  OTRRM  NUII?  NSARRONM  OTRRM

`f68r3.9`  dchey.qokeey.dcheey.daiir.otchal
→ NSARM  COŌRRM  NSARRM  NUIIR  OTSAUL

`f68r3.10`  dchol,day
→ NSAOLNUM

`f68r3.11`  doaro
→ NOURO

`f68r3.12`  oalcheol
→ OULSAROL

`f68r3.13`  okos
→ OŌOP

`f68r3.14`  otary
→ OTURM

`f68r3.15`  chky.oky
→ SAŌM  OŌM

`f68r3.16`  e.cphy
→ R  SMAM

`f68r3.17`  okolchy
→ OŌOLSAM

`f68r3.18`  o.cthyd
→ O  STAMN

`f68r3.19`  otydg
→ OTMN?

`f68r3.20`  darall
→ NURULL

`f68r3.21`  okchody
→ OŌSAONM

`f68r3.22`  otcheody.chokchy.okol.cheol.dar.cho.keol.dolaiin.okeol.oly
→ OTSARONM  SAOŌSAM  OŌOL  SAROL  NUR  SAO  ŌROL  NOLUII?  OŌROL  OLM

### f68v3  ·  unknown

`f68v3.1`  tchedy.chepchy.daiidy.shol.kcheoly.choteol.shol.s.chey.shodaiin.chetshedy.otsho.qooto.seeey
→ TSARNM  SARMSAM  NUIINM  PAOL  ŌSAROLM  SAOTROL  PAOL  P  SARM  PAONUII?  SARTPARNM  OTPAO  COOTO  PRRRM

`f68v3.2`  sshey.kcheol.sheey.qety.sheey.otchol.chal,sheey.daiin.sheody.qokol.aiir.chor.cheoty.oty
→ PPARM  ŌSAROL  PARRM  CRTM  PARRM  OTSAOL  SAULPARRM  NUII?  PARONM  COŌOL  UIIR  SAOR  SAROTM  OTM

`f68v3.3`  sho.chokar.sor.chor.cheky.daiin.dar.aiiin<->ytey.tol.cheeetchol.sam
→ PAO  SAOŌUR  POR  SAOR  SARŌM  NUII?  NUR  UIII?MTRM  TOL  SARRRTSAOL  PUS

`f68v3.4`  dcheey.qo{ckhh}y.chydy
→ NSARRM  COSŌAAM  SAMNM

`f68v3.5`  oky.otol.ees.choty.cheda[s:r].otchdy.s.ar.oekaiin.oteol.dar.cheo.dais.qoeeo,kaiin.okchey.dal.cheky.ykos.[y:q]akeg.s.ol.ay.ykoees.yty.dy.dy.chody.otol.ol,ees.oty.dar.qotay.otoy.chey.kodar.dar.sheody.shees.daiin.oteeoaly.oteeosol.ol.okol.olsey.tol.cheol.okeey.choekcheey.okchy.qokchshy.dchol.chshek
→ OŌM  OTOL  RRP  SAOTM  SARNUP  OTSANM  P  UR  ORŌUII?  OTROL  NUR  SARO  NUIP  CORROŌUII?  OŌSARM  NUL  SARŌM  MŌOP  MUŌR?  P  OL  UM  MŌORRP  MTM  NM  NM  SAONM  OTOL  OLRRP  OTM  NUR  COTUM  OTOM  SARM  ŌONUR  NUR  PARONM  PARRP  NUII?  OTRROULM  OTRROPOL  OL  OŌOL  OLPRM  TOL  SAROL  OŌRRM  SAORŌSARRM  OŌSAM  COŌSAPAM  NSAOL  SAPARŌ

`f68v3.6`  ocheal.qoeey.keody.cheoky.okeey.chody.dy.ote?m
→ OSARUL  CORRM  ŌRONM  SAROŌM  OŌRRM  SAONM  NM  OTRS

`f68v3.7`  r.al.chdail.schekol.okeody
→ R  UL  SANUIL  PSARŌOL  OŌRONM

`f68v3.8`  okeol.cheody.qoekeey.ocheky.eeody.okchdy.oko.okos
→ OŌROL  SARONM  CORŌRRM  OSARŌM  RRONM  OŌSANM  OŌO  OŌOP

`f68v3.9`  shoekechy.sheky.okolchey.okol[m:k]om
→ PAORŌRSAM  PARŌM  OŌOLSARM  OŌOLSOS

`f68v3.10`  qokeody.okeey.chekchy.chckhy.okal,ody.chedy
→ COŌRONM  OŌRRM  SARŌSAM  SASŌAM  OŌULONM  SARNM

`f68v3.11`  ycheeo.key.qokal.okeeg
→ MSARRO  ŌRM  COŌUL  OŌRR?

`f68v3.12`  ochey.chekchy.dkeeeg.cheekey.teokechey.saiir
→ OSARM  SARŌSAM  NŌRRR?  SARRŌRM  TROŌRSARM  PUIIR

`f68v3.13`  ydaiil.ol.chek.okchyd
→ MNUIIL  OL  SARŌ  OŌSAMN

`f68v3.14`  okosy.okchy.okol.choekey.okeoeeey.ol.yko[?n:in].otairo[s:r].orol.orkeeey.olkeeoly.ykeeol
→ OŌOPM  OŌSAM  OŌOL  SAORŌRM  OŌRORRRM  OL  MŌO?  OTUIROP  OROL  ORŌRRRM  OLŌRROLM  MŌRROL

`f68v3.15`  otodol
→ OTONOL

`f68v3.16`  opcholdg
→ OMSAOLN?

`f68v3.17`  roar.ykeol.darol.daly
→ ROUR  MŌROL  NUROL  NULM

`f68v3.18`  solaiin.{ckhh}y.olekeey.dy
→ POLUII?  SŌAAM  OLRŌRRM  NM

`f68v3.19`  ykeol.ctheepoey.dar
→ MŌROL  STARRMORM  NUR

### f68v2  ·  astronomical

`f68v2.1`  teeody.shcthey.psheody.shocthy.ykeody.shdy.shot.ytchy
→ TRRONM  PASTARM  MPARONM  PAOSTAM  MŌRONM  PANM  PAOT  MTSAM

`f68v2.2`  dchaiin.shey.dcheedy.qokeey.shckeey.dal.dy.sheetey.daldy
→ NSAUII?  PARM  NSARRNM  COŌRRM  PASŌRRM  NUL  NM  PARRTRM  NULNM

`f68v2.3`  qoeeey.shekeey.shkeey.s.alchey.cthy.shteody.qoteeody.dam
→ CORRRM  PARŌRRM  PAŌRRM  P  ULSARM  STAM  PATRONM  COTRRONM  NUS

`f68v2.4`  okeey.sheoy.keol.ycheety.okeody.shey.qokey.chol.chekody
→ OŌRRM  PAROM  ŌROL  MSARRTM  OŌRONM  PARM  COŌRM  SAOL  SARŌONM

`f68v2.5`  scheos.seekey.okey.chody<->okeos.cheo.sal,ar.oallchdm
→ PSAROP  PRRŌRM  OŌRM  SAONMOŌROP  SARO  PULUR  OULLSANS

`f68v2.6`  okeadaiin.ykeeody.shsdy.shyokeey.dalches.oko[s:r].cheky.otees.oteydy.okechoy.yteody.chetedy.cheda[d:m]y.[@150;:ch]eectheey.otychdy.oteey.cpheeo,dy.otey.[ch:ee]key.daiin.chey.da[iir:iis].oteeys.sar.o[ckhee:{ck}eee]y.dor,chy.okchy.qokeechy.dal.chy.chokeeey.sary
→ OŌRUNUII?  MŌRRONM  PAPNM  PAMOŌRRM  NULSARP  OŌOP  SARŌM  OTRRP  OTRMNM  OŌRSAOM  MTRONM  SARTRNM  SARNUNM  RRSTARRM  OTMSANM  OTRRM  SMARRONM  OTRM  SAŌRM  NUII?  SARM  NUIIR  OTRRMP  PUR  OSŌARRM  NORSAM  OŌSAM  COŌRRSAM  NUL  SAM  SAOŌRRRM  PURM

`f68v2.7`  otey.dalar
→ OTRM  NULUR

`f68v2.8`  otosey<->sary
→ OTOPRMPURM

`f68v2.9`  yshesas.ar.shy
→ MPARPUP  UR  PAM

`f68v2.10`  socths.chety
→ POSTAP  SARTM

`f68v2.11`  oteoys<->orasaly
→ OTROMPORUPULM

`f68v2.12`  yteody.chetey
→ MTRONM  SARTRM

`f68v2.13`  oteeos.alamchy
→ OTRROP  ULUSSAM

`f68v2.14`  otchdy<->chetal
→ OTSANMSARTUL

`f68v2.15`  adairchdy.aiin
→ UNUIRSANM  UII?

`f68v2.16`  dchedal.daiin
→ NSARNUL  NUII?

`f68v2.17`  ykeeepol<->ypchy
→ MŌRRRMOLMMSAM

`f68v2.18`  choteey.dary
→ SAOTRRM  NURM

### f68v1  ·  astronomical

`f68v1.1`  shes.ol.keey.shes.chteey.sheely.shes.yee[g:j].shokeolls.ees.aiir.ol.cho.aiin.ykeeykeey.ches.chotey.y,keey.shes.aiin.okeyteey.cthody.ches[o:y]kcho,teody.chockhy.otol.okeody.cheos.chkorchy.dy.dy.shety.oteey.dair.chotedy.chey.dal.daiin.dokeey
→ PARP  OL  ŌRRM  PARP  SATRRM  PARRLM  PARP  MRR?  PAOŌROLLP  RRP  UIIR  OL  SAO  UII?  MŌRRMŌRRM  SARP  SAOTRM  MŌRRM  PARP  UII?  OŌRMTRRM  STAONM  SARPOŌSAOTRONM  SAOSŌAM  OTOL  OŌRONM  SAROP  SAŌORSAM  NM  NM  PARTM  OTRRM  NUIR  SAOTRNM  SARM  NUL  NUII?  NOŌRRM

`f68v1.2`  chear.s.oteey.dain.dycheckhy.oteeos.oteol.okeo[r:s].okeeody.sho.ykeod.oteeol.okeeos.or.chos.or.o{cko}.aiin.chol.ykeey.sheo.s.cheoekeey.cheodaiir.cheekchey.chkeody.okchy.teeos.[sh:e'e].cheo,eky.okey.d?leed.s.aly.oteotey.otechs.opain
→ SARUR  P  OTRRM  NUI?  NMSARSŌAM  OTRROP  OTROL  OŌROR  OŌRRONM  PAO  MŌRON  OTRROL  OŌRROP  OR  SAOP  OR  OSŌO  UII?  SAOL  MŌRRM  PARO  P  SARORŌRRM  SARONUIIR  SARRŌSARM  SAŌRONM  OŌSAM  TRROP  PA  SARORŌM  OŌRM  NLRRN  P  ULM  OTROTRM  OTRSAP  OMUI?

`f68v1.3`  dair.apeeety.dy
→ NUIR  UMRRRTM  NM

`f68v1.4`  sair.aroy[s:r]er
→ PUIR  UROMPRR

`f68v1.5`  oteeor.ara[n:?]y
→ OTRROR  URU?M

`f68v1.6`  okechdaral
→ OŌRSANURUL

`f68v1.7`  otol.ches.otaly
→ OTOL  SARP  OTULM

`f68v1.8`  okeey.chek.chekeys
→ OŌRRM  SARŌ  SARŌRMP

`f68v1.9`  dar.shes.shokey
→ NUR  PARP  PAOŌRM

`f68v1.10`  oteodain.sam
→ OTRONUI?  PUS

### f69r  ·  unknown

`f69r.1`  tcheeos.shey.opaiin.chey.shey.qokeeyshdy.ol.ot.otal.sar
→ TSARROP  PARM  OMUII?  SARM  PARM  COŌRRMPANM  OL  OT  OTUL  PUR

`f69r.2`  daiin.shey.okaiin.shkechy.sheey.tey.chy.cthy.otol.cham
→ NUII?  PARM  OŌUII?  PAŌRSAM  PARRM  TRM  SAM  STAM  OTOL  SAUS

`f69r.3`  sheos,aiin.{c@178;}ar.choetey.okal.chy.ykar.ytchey.cheotam
→ PAROPUII?  SUR  SAORTRM  OŌUL  SAM  MŌUR  MTSARM  SAROTUS

`f69r.4`  ycheoraiin.ychey.otaiin.okchor.yty.chkal.shol
→ MSARORUII?  MSARM  OTUII?  OŌSAOR  MTM  SAŌUL  PAOL

`f69r.5`  oteos.ch[o:?]p.otaike
→ OTROP  SAOM  OTUIŌR

`f69r.6`  ar.odair.chtaly
→ UR  ONUIR  SATULM

`f69r.7`  oto.dar.archol
→ OTO  NUR  URSAOL

`f69r.8`  okeey.chey,dy
→ OŌRRM  SARMNM

`f69r.9`  dcho,char,ar
→ NSAOSAURUR

`f69r.10`  ytal.air.al
→ MTUL  UIR  UL

`f69r.11`  shy.chtairy
→ PAM  SATUIRM

`f69r.12`  yt.oetear
→ MT  ORTRUR

`f69r.13`  ytey.cholam
→ MTRM  SAOLUS

`f69r.14`  dair.ar.yteey.chdy
→ NUIR  UR  MTRRM  SANM

`f69r.15`  okair.os,air
→ OŌUIR  OPUIR

`f69r.16`  chytos.[o:a]ly
→ SAMTOP  OLM

`f69r.17`  chetar.araly
→ SARTUR  URULM

`f69r.18`  dair,alody
→ NUIRULONM

`f69r.19`  dal,daiin.otalam
→ NULNUII?  OTULUS

`f69r.20`  ytcheodytor
→ MTSARONMTOR

`f69r.21`  chodchy.chotal
→ SAONSAM  SAOTUL

`f69r.22`  okeo.sho.qotam
→ OŌRO  PAO  COTUS

`f69r.23`  okeodar.oteody
→ OŌRONUR  OTRONM

`f69r.24`  ykeeos.al,dair,dar
→ MŌRROP  ULNUIRNUR

`f69r.25`  ykeey.dal.oky
→ MŌRRM  NUL  OŌM

`f69r.26`  doly.dal.dar.chyky
→ NOLM  NUL  NUR  SAMŌM

`f69r.27`  okchol.qokol.daly
→ OŌSAOL  COŌOL  NULM

`f69r.28`  ykechody.otar
→ MŌRSAONM  OTUR

`f69r.29`  dary.dar.aloly
→ NURM  NUR  ULOLM

`f69r.30`  okeeocthy.okar.ar
→ OŌRROSTAM  OŌUR  UR

`f69r.31`  chey.ar.cthorary
→ SARM  UR  STAORURM

`f69r.32`  sair.chekey.sairam
→ PUIR  SARŌRM  PUIRUS

`f69r.33`  okeeo.dal.okar.a[r:s]
→ OŌRRO  NUL  OŌUR  UR

`f69r.34`  sol.aiir.okeytam
→ POL  UIIR  OŌRMTUS

`f69r.35`  okeos.ar,ald
→ OŌROP  URULN

`f69r.36`  docheeo.kody.sar
→ NOSARRO  ŌONM  PUR

`f69r.37`  dchokey.shkchodyal
→ NSAOŌRM  PAŌSAONMUL

`f69r.38`  chor.al.[a:y]lchy.ral
→ SAOR  UL  ULSAM  RUL

`f69r.39`  sair,al.okody.otedy
→ PUIRUL  OŌONM  OTRNM

`f69r.40`  okody.cheody.sar
→ OŌONM  SARONM  PUR

`f69r.41`  chokeod.okeey
→ SAOŌRON  OŌRRM

`f69r.42`  dkochy.cthody.dy
→ NŌOSAM  STAONM  NM

`f69r.43`  okoeese.daiikey.oees.chear,yteey.oteeodar.ch[y:o].okeeos.alaiin
→ OŌORRPR  NUIIŌRM  ORRP  SARURMTRRM  OTRRONUR  SAM  OŌRROP  ULUII?

`f69r.44`  y
→ M

`f69r.45`  d
→ N

`f69r.46`  o
→ O

`f69r.47`  l
→ L

`f69r.48`  s
→ P

`f69r.49`  e[d:g]
→ RN

### f69v  ·  unknown

`f69v.1`  dair.cheyky.otaza.sar,ar,chykar.okoirsh,ar.chetody.okeeos.o,tey.otokeeey.okeeody.okeey.doiir.{c@204;}teeo.y.chey.ot.y.okedy.chsdy.okeod.y.dy.choaiin.okar.okar.chol.chees.yto.odair.oty.oteeo.dar.o,eykeody.dchor.char
→ NUIR  SARMŌM  OTU?U  PURURSAMŌUR  OŌOIRPAUR  SARTONM  OŌRROP  OTRM  OTOŌRRRM  OŌRRONM  OŌRRM  NOIIR  STRRO  M  SARM  OT  M  OŌRNM  SAPNM  OŌRON  M  NM  SAOUII?  OŌUR  OŌUR  SAOL  SARRP  MTO  ONUIR  OTM  OTRRO  NUR  ORMŌRONM  NSAOR  SAUR

`f69v.2`  yka{c@204;}.chol.ykar.dal.ykady.[i:?]okeeor.cheey.choly.ykeeal.cheo[?:s].oaram.ockhy.sheey.aiin,y.daii[a:?]l.cheody.cheal.yetey.chear,y,dy.ykey.ch.y.dy.chol.ykar.ol,y.ykeeody,chey.dal,ody.airchy.choky.ychey.chey
→ MŌUS  SAOL  MŌUR  NUL  MŌUNM  IOŌRROR  SARRM  SAOLM  MŌRRUL  SARO  OURUS  OSŌAM  PARRM  UII?M  NUIIUL  SARONM  SARUL  MRTRM  SARURMNM  MŌRM  SA  M  NM  SAOL  MŌUR  OLM  MŌRRONMSARM  NULONM  UIRSAM  SAOŌM  MSARM  SARM

`f69v.3`  doair.otaldal.dair.@240;.chdy.otoar.ar,@240;,chy.qoteor.cho.qotair.chda.oteeal.cheor,ar,air.oteody.ytyd,a.dchy.otoly.okeodal.oteoarar.cheteese?r.dair.chey.okody.dal.oteey.oteey
→ NOUIR  OTULNUL  NUIR  —  SANM  OTOUR  URSAM  COTROR  SAO  COTUIR  SANU  OTRRUL  SARORURUIR  OTRONM  MTMNU  NSAM  OTOLM  OŌRONUL  OTROURUR  SARTRRPRR  NUIR  SARM  OŌONM  NUL  OTRRM  OTRRM

`f69v.4`  okeey,sar
→ OŌRRMPUR

`f69v.5`  okeo,dy
→ OŌRONM

`f69v.6`  ochoyk
→ OSAOMŌ

`f69v.7`  ykeey
→ MŌRRM

`f69v.8`  ytory
→ MTORM

`f69v.9`  oeesy
→ ORRPM

`f69v.10`  ytody
→ MTONM

`f69v.11`  okody
→ OŌONM

`f69v.12`  otody
→ OTONM

`f69v.13`  oke[a:o]l
→ OŌRUL

`f69v.14`  okeod
→ OŌRON

`f69v.15`  oteeys
→ OTRRMP

`f69v.16`  oteol
→ OTROL

`f69v.17`  ykeydy
→ MŌRMNM

`f69v.18`  okeod
→ OŌRON

`f69v.19`  saral
→ PURUL

`f69v.20`  saiir
→ PUIIR

`f69v.21`  okolar
→ OŌOLUR

`f69v.22`  ykeody
→ MŌRONM

`f69v.23`  sarydy
→ PURMNM

`f69v.24`  otchy
→ OTSAM

`f69v.25`  okeey,dy
→ OŌRRMNM

`f69v.26`  okey,[d:g]
→ OŌRMN

`f69v.27`  okeod
→ OŌRON

`f69v.28`  okodchy
→ OŌONSAM

`f69v.29`  okeody
→ OŌRONM

`f69v.30`  okchey[s:r]
→ OŌSARMP

`f69v.31`  oar.alys
→ OUR  ULMP

### f70r1  ·  unknown

`f70r1.1`  ???ooooooooolar.sasa
→ OOOOOOOOOLUR  PUPU

`f70r1.2`  oteody.choekeeos.alair,dy.okol.okeey.dasy.ot[a:o]rsheod.okchody.oteos.okes.okeys.[e:i]y.okchol.sairody.o.chopcheopchy.chol,air.shekchy.choteody.oteeshs.opcheody.otol.choky.chody.chotey.sheal,ar.ykeody.oteey.chedaiin.chotar.soly
→ OTRONM  SAORŌRROP  ULUIRNM  OŌOL  OŌRRM  NUPM  OTURPARON  OŌSAONM  OTROP  OŌRP  OŌRMP  RM  OŌSAOL  PUIRONM  O  SAOMSAROMSAM  SAOLUIR  PARŌSAM  SAOTRONM  OTRRPAP  OMSARONM  OTOL  SAOŌM  SAONM  SAOTRM  PARULUR  MŌRONM  OTRRM  SARNUII?  SAOTUR  POLM

`f70r1.3`  okeodar.chy.oteody.tochady.okchody.ytar.ytory.okeol.choly.yk,y.okchedy.chkal.ofchon.qokal.opolaiin.okeos.oty.dal.cheokeey,dal.cheo.al.oteeoky.chety.chodalar.okal.chear.aly.oteos,ar.os,al.okolair.dy
→ OŌRONUR  SAM  OTRONM  TOSAUNM  OŌSAONM  MTUR  MTORM  OŌROL  SAOLM  MŌM  OŌSARNM  SAŌUL  O?SAO?  COŌUL  OMOLUII?  OŌROP  OTM  NUL  SAROŌRRMNUL  SARO  UL  OTRROŌM  SARTM  SAONULUR  OŌUL  SARUR  ULM  OTROPUR  OPUL  OŌOLUIR  NM

`f70r1.4`  yfcheodly
→ M?SARONLM

`f70r1.5`  ytcheos,aly
→ MTSAROPULM

`f70r1.6`  otchy.dar.yky
→ OTSAM  NUR  MŌM

`f70r1.7`  opar.ykchy
→ OMUR  MŌSAM

`f70r1.8`  y,saikchy.dam
→ MPUIŌSAM  NUS

`f70r1.9`  otair,oroldy
→ OTUIROROLNM

`f70r1.10`  dchal.daim
→ NSAUL  NUIS

`f70r1.11`  yteody.sam
→ MTRONM  PUS

`f70r1.12`  okchy,daldy
→ OŌSAMNULNM

`f70r1.13`  tshey.ol.oteey.ched,ar.oteos.cheor.alal.otar.ar,y.oteodchey.keody.oteos,al.oteeed
→ TPARM  OL  OTRRM  SARNUR  OTROP  SAROR  ULUL  OTUR  URM  OTRONSARM  ŌRONM  OTROPUL  OTRRRN

`f70r1.14`  ykeal
→ MŌRUL

`f70r1.15`  okeody
→ OŌRONM

`f70r1.16`  otody
→ OTONM

`f70r1.17`  ypolol
→ MMOLOL

`f70r1.18`  chodal
→ SAONUL

`f70r1.19`  okasd
→ OŌUPN

### f70r2  ·  unknown

`f70r2.1`  otchey.sheol.chkey.shep.al.r.ar.chly.sheteal.aram
→ OTSARM  PAROL  SAŌRM  PARM  UL  R  UR  SALM  PARTRUL  URUS

`f70r2.2`  dair,cheey.s,cheotey.dshy.dam.chchet.al.yke{c'}y
→ NUIRSARRM  PSAROTRM  NPAM  NUS  SASART  UL  MŌRSM

`f70r2.3`  ykeeo.y.s.ald.shey.cthy.shekey.qokal,aiir.oteog
→ MŌRRO  M  P  ULN  PARM  STAM  PARŌRM  COŌULUIIR  OTRO?

`f70r2.4`  daiin.okeey.shoaiin.{ckhh}ey.otal.shshy.tal.dam
→ NUII?  OŌRRM  PAOUII?  SŌAARM  OTUL  PAPAM  TUL  NUS

`f70r2.5`  tal.cheeog.dal.chcthy.qotal.ddl[a:o]r.chal.dal
→ TUL  SARRO?  NUL  SASTAM  COTUL  NNLUR  SAUL  NUL

`f70r2.6`  ytar.ar.al.yol.al.aloees.ytaiir.otaldal
→ MTUR  UR  UL  MOL  UL  ULORRP  MTUIIR  OTULNUL

`f70r2.7`  daiin.daiin.she.tal.qokal.chol{ckhh}y.dy
→ NUII?  NUII?  PAR  TUL  COŌUL  SAOLSŌAAM  NM

`f70r2.8`  ytals.alal.dalam.dal.cthol.oparam
→ MTULP  ULUL  NULUS  NUL  STAOL  OMURUS

`f70r2.9`  dolshol.shol.shol.sho{cthh}y.dalal,y
→ NOLPAOL  PAOL  PAOL  PAOSTAAM  NULULM

`f70r2.10`  shokal.chol,kshody.tol.cheey.okal
→ PAOŌUL  SAOLŌPAONM  TOL  SARRM  OŌUL

`f70r2.11`  daiin.chotal.qokal.chol.chotals
→ NUII?  SAOTUL  COŌUL  SAOL  SAOTULP

`f70r2.12`  qokal.shkal.dal.shy.qokal.chdy
→ COŌUL  PAŌUL  NUL  PAM  COŌUL  SANM

`f70r2.13`  qotal,che,y.key.okechy.chdy.cham
→ COTULSARM  ŌRM  OŌRSAM  SANM  SAUS

`f70r2.14`  okaiin.ch{cthh}y.s.or.ary
→ OŌUII?  SASTAAM  P  OR  URM

`f70r2.15`  sal.air.am.shedy.chokal.cho{ikh}y.shokeey.choky.chol.dy.okeeal.o,teedy.dgr.dair,aiin.okees.okeear.ar,alekeey.ar,kam.oteoodalry.chekeoar.chokey.dar.dcheoky.otai.do{ith}y.dair.otchetchar.okear.okeeo.lal.kch[g:?].okar.ar,dar
→ PUL  UIR  US  PARNM  SAOŌUL  SAOIŌAM  PAOŌRRM  SAOŌM  SAOL  NM  OŌRRUL  OTRRNM  N?R  NUIRUII?  OŌRRP  OŌRRUR  URULRŌRRM  URŌUS  OTROONULRM  SARŌROUR  SAOŌRM  NUR  NSAROŌM  OTUI  NOITAM  NUIR  OTSARTSAUR  OŌRUR  OŌRRO  LUL  ŌSA?  OŌUR  URNUR

`f70r2.16`  otar.ar.chedal.oaral.aldaiin.ykeeedaiis.sheo.l,dar.chol.ykees.aiir,dl.cheey.[s:r]keeod.oteeodar.aiin.aral.daiir.sheedal.sheodaiin.choar.chol.chot[e:i]oly.cho.oteey.chotey.choeky.chedy.choteosam.oteodar.o{ckhh}
→ OTUR  UR  SARNUL  OURUL  ULNUII?  MŌRRRNUIIP  PARO  LNUR  SAOL  MŌRRP  UIIRNL  SARRM  PŌRRON  OTRRONUR  UII?  URUL  NUIIR  PARRNUL  PARONUII?  SAOUR  SAOL  SAOTROLM  SAO  OTRRM  SAOTRM  SAORŌM  SARNM  SAOTROPUS  OTRONUR  OSŌAA

`f70r2.17`  oches,air.chese.ctheey.sheeody.shopcho.yteody.ykaldy.oteeos.aiin.sh[e:?]y.shee.farar.aim.cheoteeodal.sho.choetchaldy.dal.aiir,ches.otesar.dalol.chtam.opaiir.chokeo.oteedy.oteeo.okol.chotal.otol,al.dl
→ OSARPUIR  SARPR  STARRM  PARRONM  PAOMSAO  MTRONM  MŌULNM  OTRROP  UII?  PARM  PARR  ?URUR  UIS  SAROTRRONUL  PAO  SAORTSAULNM  NUL  UIIRSARP  OTRPUR  NULOL  SATUS  OMUIIR  SAOŌRO  OTRRNM  OTRRO  OŌOL  SAOTUL  OTOLUL  NL

`f70r2.18`  otoy.ar,arodchedy.cheocphey.oteeos.ees.cheal.sheeey.okeedaly.cheeoekey.yk[ee:ei]d[{cr}:ar].oteey.s.al.s.air.oteody.oteody.dar.aiir.ody.cheeos,chey.daiin.otoeeseor.air.chedy.okodar.al.sho.chotol.dal,dy
→ OTOM  URURONSARNM  SAROSMARM  OTRROP  RRP  SARUL  PARRRM  OŌRRNULM  SARRORŌRM  MŌRRNSR  OTRRM  P  UL  P  UIR  OTRONM  OTRONM  NUR  UIIR  ONM  SARROPSARM  NUII?  OTORRPROR  UIR  SARNM  OŌONUR  UL  PAO  SAOTOL  NULNM

`f70r2.19`  oteesy.ol,chy.oteo.sal.ol.keey.oteol.choky.otcho[sh:ch]a
→ OTRRPM  OLSAM  OTRO  PUL  OL  ŌRRM  OTROL  SAOŌM  OTSAOPAU

### f70v2  ·  zodiac

`f70v2.1`  okcheo.dar.otey.ykeey.tchy.otsheo.oteotey.she[y:o].shecth.opcheoldair.dateey.sal.ody.choteey.choeteedy.oteoteotsho.yteos.alain.sheodaly.{c@162;h}o.aiin.cholkal.chokear.oteody.cholaiin.oteeoal.al.sheeos.okey.chol,dy.otees.cho.s.ola[r:n].otoaiin.oteeody.sos.todaiin.chokain.otalal.oteeam
→ OŌSARO  NUR  OTRM  MŌRRM  TSAM  OTPARO  OTROTRM  PARM  PARSTA  OMSAROLNUIR  NUTRRM  PUL  ONM  SAOTRRM  SAORTRRNM  OTROTROTPAO  MTROP  ULUI?  PARONULM  SAO  UII?  SAOLŌUL  SAOŌRUR  OTRONM  SAOLUII?  OTRROUL  UL  PARROP  OŌRM  SAOLNM  OTRRP  SAO  P  OLUR  OTOUII?  OTRRONM  POP  TONUII?  SAOŌUI?  OTULUL  OTRRUS

`f70v2.2`  otalalg
→ OTULUL?

`f70v2.3`  ykary
→ MŌURM

`f70v2.4`  otar?
→ OTUR

`f70v2.5`  oty
→ OTM

`f70v2.6`  oky.ody
→ OŌM  ONM

`f70v2.7`  oty.ar
→ OTM  UR

`f70v2.8`  okala
→ OŌULU

`f70v2.9`  otody
→ OTONM

`f70v2.10`  otald
→ OTULN

`f70v2.11`  otaldar
→ OTULNUR

`f70v2.12`  okody
→ OŌONM

`f70v2.13`  opysam
→ OMMPUS

`f70v2.14`  ch{ckhh}y
→ SASŌAAM

`f70v2.15`  otaly
→ OTULM

`f70v2.16`  otal.arar
→ OTUL  URUR

`f70v2.17`  otaldy
→ OTULNM

`f70v2.18`  okeoly
→ OŌROLM

`f70v2.19`  okydy
→ OŌMNM

`f70v2.20`  okee[s:r]
→ OŌRRP

`f70v2.21`  daii@197;amdy.otar.am.aral.otair,chedaiin.oteey.dair.shchey.daiin.chalaly.oteody.chotol.chedy.oteotey.oteeeor,ar.alody.daiir.oteedar.oteey.teey.dalal.cheoltey.oteedy.sheeteey.?okeeol.ykeeos.shey.ykair.arar.alos
→ NUIIUSNM  OTUR  US  URUL  OTUIRSARNUII?  OTRRM  NUIR  PASARM  NUII?  SAULULM  OTRONM  SAOTOL  SARNM  OTROTRM  OTRRRORUR  ULONM  NUIIR  OTRRNUR  OTRRM  TRRM  NULUL  SAROLTRM  OTRRNM  PARRTRRM  OŌRROL  MŌRROP  PARM  MŌUIR  URUR  ULOP

`f70v2.22`  otar.am
→ OTUR  US

`f70v2.23`  otar,al
→ OTURUL

`f70v2.24`  otalar
→ OTULUR

`f70v2.25`  otalam
→ OTULUS

`f70v2.26`  dolaram
→ NOLURUS

`f70v2.27`  okaram
→ OŌURUS

`f70v2.28`  oteosal
→ OTROPUL

`f70v2.29`  salols
→ PULOLP

`f70v2.30`  okaldal
→ OŌULNUL

`f70v2.31`  ykolaiin
→ MŌOLUII?

`f70v2.32`  otal.daly.oteoal.dal,aildy.otaiin.ar.oteey.shal.o.qoteeal.ar.al.otaiin.al.teodaiin.oteeo,cthey.oteeos.oteos.aiin.daim
→ OTUL  NULM  OTROUL  NULUILNM  OTUII?  UR  OTRRM  PAUL  O  COTRRUL  UR  UL  OTUII?  UL  TRONUII?  OTRROSTARM  OTRROP  OTROP  UII?  NUIS

`f70v2.33`  otolal
→ OTOLUL

### f70v1  ·  zodiac

`f70v1.1`  dalalody.oteoshey.okoksheo.shokey.raiin.otor.ochy.s.a[ir:is].cheody.cheey.oteo,[ch:ee]y.daiir.chcthy.dlal.oteodaiin.ykeody.oteody.sheo.daiin.oteedy.chetalchs.zar.shoteeody.okeeo,dal.cheody.okchoteees.oteeody.cheokeo.otaiin.shes.to,ar.oly.daly.sheal
→ NULULONM  OTROPARM  OŌOŌPARO  PAOŌRM  RUII?  OTOR  OSAM  P  UIR  SARONM  SARRM  OTROSAM  NUIIR  SASTAM  NLUL  OTRONUII?  MŌRONM  OTRONM  PARO  NUII?  OTRRNM  SARTULSAP  ?UR  PAOTRRONM  OŌRRONUL  SARONM  OŌSAOTRRRP  OTRRONM  SAROŌRO  OTUII?  PARP  TOUR  OLM  NULM  PARUL

`f70v1.2`  otalchy.tar.am.dy
→ OTULSAM  TUR  US  NM

`f70v1.3`  opchey.sal
→ OMSARM  PUL

`f70v1.4`  otakaizan
→ OTUŌUI?U?

`f70v1.5`  okalal
→ OŌULUL

`f70v1.6`  otaly
→ OTULM

`f70v1.7`  oalcheg
→ OULSAR?

`f70v1.8`  otchodals
→ OTSAONULP

`f70v1.9`  okolshy
→ OŌOLPAM

`f70v1.10`  otshshdy
→ OTPAPANM

`f70v1.11`  otal.ypsharal
→ OTUL  MMPAURUL

`f70v1.12`  daiin.okey.otodal.cheokeeo.okeodal.shol.olaiin.saiin.sheo.qokeeol.otchykey.chekeal.oteosaiin.chekey.okeolol.chees.o?eey.opotey.dal,al,s.otecheo.dal
→ NUII?  OŌRM  OTONUL  SAROŌRRO  OŌRONUL  PAOL  OLUII?  PUII?  PARO  COŌRROL  OTSAMŌRM  SARŌRUL  OTROPUII?  SARŌRM  OŌROLOL  SARRP  ORRM  OMOTRM  NULULP  OTRSARO  NUL

`f70v1.13`  okoly
→ OŌOLM

`f70v1.14`  otalaiin
→ OTULUII?

`f70v1.15`  oteo.alals.araly
→ OTRO  ULULP  URULM

`f70v1.16`  oteoeey.otal.okealar
→ OTRORRM  OTUL  OŌRULUR

`f70v1.17`  otear.araydy
→ OTRUR  URUMNM

### f71r  ·  zodiac

`f71r.1`  olkeeody.okody.okeeedy.oky,chy.okeodar.okeoky.oteody.oto.otol.oteeyar.yko,oar.aiin.oekeeey.okeo,keo,keody.okeodar,chy.s.aiin.otokeoar.or.ar.al.otol.al.shckhy.oteeeodar.oteody.otol,aiin.shoekey.solalald.cheeokeeo.[ch:?]oe[k:t]y.choly
→ OLŌRRONM  OŌONM  OŌRRRNM  OŌMSAM  OŌRONUR  OŌROŌM  OTRONM  OTO  OTOL  OTRRMUR  MŌOOUR  UII?  ORŌRRRM  OŌROŌROŌRONM  OŌRONURSAM  P  UII?  OTOŌROUR  OR  UR  UL  OTOL  UL  PASŌAM  OTRRRONUR  OTRONM  OTOLUII?  PAORŌRM  POLULULN  SARROŌRRO  SAORŌM  SAOLM

`f71r.2`  oteos.arar
→ OTROP  URUR

`f71r.3`  okldam
→ OŌLNUS

`f71r.4`  oteoaldy
→ OTROULNM

`f71r.5`  oteolar
→ OTROLUR

`f71r.6`  okeoaly
→ OŌROULM

`f71r.7`  otaleky
→ OTULRŌM

`f71r.8`  otalsar
→ OTULPUR

`f71r.9`  cheary
→ SARURM

`f71r.10`  oteotey.rary
→ OTROTRM  RURM

`f71r.11`  otalaly
→ OTULULM

`f71r.12`  oteody.oteos.o{ckhh}y.oteeschey.lsheotey.okalody.shs.shey.oteey.otechar.chek[a:?]l.okody.eeedy.oteodal.eeokol.lkchol.daiin.okeeees.ykees.al.ok[ee:a]y.otey.oteo,shaly.o
→ OTRONM  OTROP  OSŌAAM  OTRRPSARM  LPAROTRM  OŌULONM  PAP  PARM  OTRRM  OTRSAUR  SARŌUL  OŌONM  RRRNM  OTRONUL  RROŌOL  LŌSAOL  NUII?  OŌRRRRP  MŌRRP  UL  OŌRRM  OTRM  OTROPAULM  O

`f71r.13`  otolchdy
→ OTOLSANM

`f71r.14`  otoloaram
→ OTOLOURUS

`f71r.15`  oteeol
→ OTRROL

`f71r.16`  otolchd
→ OTOLSAN

`f71r.17`  otaldar
→ OTULNUR

`f71r.18`  oteeol.otal,chs.char.cheky.chotshy.okeeody.oteey.chekea'.okeol
→ OTRROL  OTULSAP  SAUR  SARŌM  SAOTPAM  OŌRRONM  OTRRM  SARŌRU  OŌROL

### f71v  ·  zodiac

`f71v.1`  osheo.parar.oteeodaiin.she.ateey.daiin.oteokeey.dal.al.oteey.teey,dy.otchy.keey.sheeo.ochey.?chey.otcheodal.sheealody.cheol.otar.okam.oteodar.chpchy.{cp}ar.al.aiin.oteoshar.okeodaly.oteey.teeey.oteey.keor.or.arol.cheols.okaikaly
→ OPARO  MURUR  OTRRONUII?  PAR  UTRRM  NUII?  OTROŌRRM  NUL  UL  OTRRM  TRRMNM  OTSAM  ŌRRM  PARRO  OSARM  SARM  OTSARONUL  PARRULONM  SAROL  OTUR  OŌUS  OTRONUR  SAMSAM  SMUR  UL  UII?  OTROPAUR  OŌRONULM  OTRRM  TRRRM  OTRRM  ŌROR  OR  UROL  SAROLP  OŌUIŌULM

`f71v.2`  char.arom
→ SAUR  UROS

`f71v.3`  chfaly
→ SA?ULM

`f71v.4`  okolar
→ OŌOLUR

`f71v.5`  otchody
→ OTSAONM

`f71v.6`  alcphy
→ ULSMAM

`f71v.7`  otaiin
→ OTUII?

`f71v.8`  okaraiin
→ OŌURUII?

`f71v.9`  otar.ar,aly
→ OTUR  URULM

`f71v.10`  opalar.am.dan
→ OMULUR  US  NU?

`f71v.11`  opalor.ar
→ OMULOR  UR

`f71v.12`  chal.oteeos.al.sheky.okalar,ar,okeo,dar.oty.oto,kaiin.chey.tal.otchr.chtos.cheor.shepchol.otor.sheo.shopcho.ar.aly.okeo.cheey.otal.al.shldy.otaly.okol.sheeor
→ SAUL  OTRROP  UL  PARŌM  OŌULURUROŌRONUR  OTM  OTOŌUII?  SARM  TUL  OTSAR  SATOP  SAROR  PARMSAOL  OTOR  PARO  PAOMSAO  UR  ULM  OŌRO  SARRM  OTUL  UL  PALNM  OTULM  OŌOL  PARROR

`f71v.13`  ofa{if}om
→ O?UI?OS

`f71v.14`  otalody
→ OTULONM

`f71v.15`  otalaiin
→ OTULUII?

`f71v.16`  otar.sh[a:o]r
→ OTUR  PAUR

`f71v.17`  sholshdy
→ PAOLPANM

`f71v.18`  okeey.okeosar.otaiin.chkeeal.okal.cheekaiin.okaiin.okchor.dar.oteey.kal
→ OŌRRM  OŌROPUR  OTUII?  SAŌRRUL  OŌUL  SARRŌUII?  OŌUII?  OŌSAOR  NUR  OTRRM  ŌUL

### f72r1  ·  zodiac

`f72r1.1`  oteeo.cthey.chlol.cheol.olcheor.al.oteey.chedal.oteedy.okeodaly.chol.chokeol.cheo?ky.okaiir.okeedy.sheoltey.cheor.aiin.ydal.okochey.sho.okalshey.shol.chalaiin.chekeol.kol.otos.ar.aiin.otam.otam.chotam.sal.okeo.dar.ar.a[d:j]al.dar.okeeas.aiin.oteey.okaiin
→ OTRRO  STARM  SALOL  SAROL  OLSAROR  UL  OTRRM  SARNUL  OTRRNM  OŌRONULM  SAOL  SAOŌROL  SAROŌM  OŌUIIR  OŌRRNM  PAROLTRM  SAROR  UII?  MNUL  OŌOSARM  PAO  OŌULPARM  PAOL  SAULUII?  SARŌROL  ŌOL  OTOP  UR  UII?  OTUS  OTUS  SAOTUS  PUL  OŌRO  NUR  UR  UNUL  NUR  OŌRRUP  UII?  OTRRM  OŌUII?

`f72r1.2`  oshod[a:o]dy
→ OPAONUNM

`f72r1.3`  chdaiirdainy
→ SANUIIRNUI?M

`f72r1.4`  oaiin,ar,ary
→ OUII?URURM

`f72r1.5`  okalam
→ OŌULUS

`f72r1.6`  ytalshdy
→ MTULPANM

`f72r1.7`  char.alif
→ SAUR  ULI?

`f72r1.8`  otaraldy
→ OTURULNM

`f72r1.9`  otaiin.otain
→ OTUII?  OTUI?

`f72r1.10`  otalef,ys.ainam
→ OTULR?MP  UI?US

`f72r1.11`  ochol,sharam
→ OSAOLPAURUS

`f72r1.12`  oteodar.ytey.otey.shetey.chokshor.okalal.otaiin.sheolaiin.otaiin.chetey.cheolor.oteo,teeody.otar.chokaiin.okaiin.al.alo.cheedy.otear,ar.cheky.chokal.otar.al,o,qokar
→ OTRONUR  MTRM  OTRM  PARTRM  SAOŌPAOR  OŌULUL  OTUII?  PAROLUII?  OTUII?  SARTRM  SAROLOR  OTROTRRONM  OTUR  SAOŌUII?  OŌUII?  UL  ULO  SARRNM  OTRURUR  SARŌM  SAOŌUL  OTUR  ULOCOŌUR

`f72r1.13`  ofaralar
→ O?URULUR

`f72r1.14`  otchoshy
→ OTSAOPAM

`f72r1.15`  otchdal
→ OTSANUL

`f72r1.16`  okeey.ary
→ OŌRRM  URM

`f72r1.17`  otainy
→ OTUI?M

`f72r1.18`  okeeols.aroly.okees.alaiin.okeor.chol.o.oteos.aiin.chal.otaiin.[a:o]tchor.chckhy
→ OŌRROLP  UROLM  OŌRRP  ULUII?  OŌROR  SAOL  O  OTROP  UII?  SAUL  OTUII?  UTSAOR  SASŌAM

### f72r2  ·  zodiac

`f72r2.1`  ofchdamy
→ O?SANUSM

`f72r2.2`  oklairdy
→ OŌLUIRNM

`f72r2.3`  okaram
→ OŌURUS

`f72r2.4`  okairy
→ OŌUIRM

`f72r2.5`  okealar
→ OŌRULUR

`f72r2.6`  oteos.aiin.okeo,daiin.okeey.cheo.keodal.chol.okeol.ol{ckhh}y.oteeykeey.tey.okalaiin.okalchal,chey.al.o.keey.daiin.otar.al.chotaiin.otchey.qoeeeo,s.[ckh:?]al.chekaiin.otaiin.chy.d.r.aiin.al.y.{chh}o.chekaiin.okedal.qokeodal.saiin.otois.otees
→ OTROP  UII?  OŌRONUII?  OŌRRM  SARO  ŌRONUL  SAOL  OŌROL  OLSŌAAM  OTRRMŌRRM  TRM  OŌULUII?  OŌULSAULSARM  UL  O  ŌRRM  NUII?  OTUR  UL  SAOTUII?  OTSARM  CORRROP  SŌAUL  SARŌUII?  OTUII?  SAM  N  R  UII?  UL  M  SAAO  SARŌUII?  OŌRNUL  COŌRONUL  PUII?  OTOIP  OTRRP

`f72r2.7`  otaraldy
→ OTURULNM

`f72r2.8`  okalar
→ OŌULUR

`f72r2.9`  okal
→ OŌUL

`f72r2.10`  okaly
→ OŌULM

`f72r2.11`  okal
→ OŌUL

`f72r2.12`  okeey.ary
→ OŌRRM  URM

`f72r2.13`  oteeary
→ OTRRURM

`f72r2.14`  otair,dy
→ OTUIRNM

`f72r2.15`  okaircham
→ OŌUIRSAUS

`f72r2.16`  okeal
→ OŌRUL

`f72r2.17`  otar{cr}
→ OTURSR

`f72r2.18`  okaly
→ OŌULM

`f72r2.19`  orary
→ ORURM

`f72r2.20`  okyd
→ OŌMN

`f72r2.21`  otolam
→ OTOLUS

`f72r2.22`  oteey.tey.teodal.chokaly.ol.cheol.ol.aiin.oteo,daiin.shokal.otey.otaiin.otaly,dal.okaly.dalchdy.{ch'}eteeey.okal.shey.qoteeody.sheycthy.chotal,chas.otoees.aiin
→ OTRRM  TRM  TRONUL  SAOŌULM  OL  SAROL  OL  UII?  OTRONUII?  PAOŌUL  OTRM  OTUII?  OTULMNUL  OŌULM  NULSANM  SARTRRRM  OŌUL  PARM  COTRRONM  PARMSTAM  SAOTULSAUP  OTORRP  UII?

`f72r2.23`  otal
→ OTUL

`f72r2.24`  ralal
→ RULUL

`f72r2.25`  okam
→ OŌUS

`f72r2.26`  otalshy
→ OTULPAM

`f72r2.27`  okaldy
→ OŌULNM

`f72r2.28`  chosar
→ SAOPUR

`f72r2.29`  otam
→ OTUS

`f72r2.30`  ainaly
→ UI?ULM

`f72r2.31`  okarcham
→ OŌURSAUS

`f72r2.32`  otoar.air,aloy.oka[iin:ii?].otees.chs.chchs,ar.aly.taly.dar.otchey.okaiin.olaiin.@211;y
→ OTOUR  UIRULOM  OŌUII?  OTRRP  SAP  SASAPUR  ULM  TULM  NUR  OTSARM  OŌUII?  OLUII?  M

### f72r3  ·  zodiac

`f72r3.1`  okeey.chekoy.oteo.ykeey.chedaiin.okeeol.cheeor.chocthar.ar.oteody.oteedy.okeolaiin.oteey.okarar.???.???teo.sheol.al.alaiiin.okeos.alaiin.okor.o,keodar.okee.s,ar,aiin.chekackhy.chokees.oteedy.chekar.okar,choly.ches,os.oiin.okeeey.cheey.ches.okeody.chealdy.shocthy.choteey.sheoly.{oh}eol.sheey.chorain
→ OŌRRM  SARŌOM  OTRO  MŌRRM  SARNUII?  OŌRROL  SARROR  SAOSTAUR  UR  OTRONM  OTRRNM  OŌROLUII?  OTRRM  OŌURUR  —  TRO  PAROL  UL  ULUIII?  OŌROP  ULUII?  OŌOR  OŌRONUR  OŌRR  PURUII?  SARŌUSŌAM  SAOŌRRP  OTRRNM  SARŌUR  OŌURSAOLM  SARPOP  OII?  OŌRRRM  SARRM  SARP  OŌRONM  SARULNM  PAOSTAM  SAOTRRM  PAROLM  OAROL  PARRM  SAORUI?

`f72r3.2`  olkalaiin
→ OLŌULUII?

`f72r3.3`  olalsy
→ OLULPM

`f72r3.4`  oraiinam
→ ORUII?US

`f72r3.5`  osarsheeeo
→ OPURPARRRO

`f72r3.6`  oto@192;aiin
→ OTOUII?

`f72r3.7`  opoiiin[o:?]in.al,[ch:a]es
→ OMOIII?OI?  ULSARP

`f72r3.8`  ypaiin.alaly
→ MMUII?  ULULM

`f72r3.9`  oteey,daiin
→ OTRRMNUII?

`f72r3.10`  oeeodaiin
→ ORRONUII?

`f72r3.11`  ofsholdy
→ O?PAOLNM

`f72r3.12`  opoeey.okaiin
→ OMORRM  OŌUII?

`f72r3.13`  ykolairol
→ MŌOLUIROL

`f72r3.14`  otochedy.otey.o,koey.sheedy.oteodar.ykeolol.y,air.oteos.cheo,l,aiin.ykeeoly.otaiin.shear.oiiin.oral.o,tealy.cheokeor.oteody.o{ck}es.otees,chteos,doteey.sosor.oteol.shol.cheeg.okeody.{ch'}eol.shey.sheysy.shoteey.cheor.yoeteey.okeeol.chy.okeeo.ykoly
→ OTOSARNM  OTRM  OŌORM  PARRNM  OTRONUR  MŌROLOL  MUIR  OTROP  SAROLUII?  MŌRROLM  OTUII?  PARUR  OIII?  ORUL  OTRULM  SAROŌROR  OTRONM  OSŌRP  OTRRPSATROPNOTRRM  POPOR  OTROL  PAOL  SARR?  OŌRONM  SAROL  PARM  PARMPM  PAOTRRM  SAROR  MORTRRM  OŌRROL  SAM  OŌRRO  MŌOLM

`f72r3.15`  oralkam
→ ORULŌUS

`f72r3.16`  ytairal
→ MTUIRUL

`f72r3.17`  oeee[s:r]aiin
→ ORRRPUII?

`f72r3.18`  ory
→ ORM

`f72r3.19`  ochey,fydy
→ OSARM?MNM

`f72r3.20`  of???.o.eeesaly
→ O?  O  RRRPULM

`f72r3.21`  ykaraiin.airal
→ MŌURUII?  UIRUL

`f72r3.22`  okalar
→ OŌULUR

`f72r3.23`  orara
→ ORURU

`f72r3.24`  olaiin.ola{ikh}y
→ OLUII?  OLUIŌAM

`f72r3.25`  olfsheoral
→ OL?PARORUL

`f72r3.26`  oteey.[a:?]rary.eee[r:s],che@212;shees.opcholalaiin.oteeor.am.sheal.o[k:t]aipchy.oteees,ar.am.olaiin.otedar.olol.choty.oteol.sheshdy.chedy.chedy.dy.shes.eedy.sheol.shy,ckhol
→ OTRRM  URURM  RRRRSARPARRP  OMSAOLULUII?  OTRROR  US  PARUL  OŌUIMSAM  OTRRRPUR  US  OLUII?  OTRNUR  OLOL  SAOTM  OTROL  PARPANM  SARNM  SARNM  NM  PARP  RRNM  PAROL  PAMSŌAOL

`f72r3.27`  opalal
→ OMULUL

`f72r3.28`  yfary
→ M?URM

`f72r3.29`  oraiiral
→ ORUIIRUL

`f72r3.30`  ytoar.shar
→ MTOUR  PAUR

`f72r3.31`  octho
→ OSTAO

`f72r3.32`  aral
→ URUL

`f72r3.33`  oletal
→ OLRTUL

`f72r3.34`  okeos.aiin,olaiin.oraiin.octheolarl.okeeody.oteos.aiin,koly
→ OŌROP  UII?OLUII?  ORUII?  OSTAROLURL  OŌRRONM  OTROP  UII?ŌOLM

### f72v3  ·  zodiac

`f72v3.1`  soees,otchs.otedar.oteody.oteodal.oteos.oteokchd?.oteody.sheokeey.sheody.shedykeal.ckhodys.okoleeolar.okeey.shedy.otey,sho.shol.teody.okolshey.ykeed?y.y.okechdy.olaiin.shokeedy.chol.choepchey.teey,teody.ches.okechedy.otechol.cheor.cheey.daiin.oyteeedar.???.shecthy.otycheedy.oteeoly.chokary
→ PORRPOTSAP  OTRNUR  OTRONM  OTRONUL  OTROP  OTROŌSAN  OTRONM  PAROŌRRM  PARONM  PARNMŌRUL  SŌAONMP  OŌOLRROLUR  OŌRRM  PARNM  OTRMPAO  PAOL  TRONM  OŌOLPARM  MŌRRNM  M  OŌRSANM  OLUII?  PAOŌRRNM  SAOL  SAORMSARM  TRRMTRONM  SARP  OŌRSARNM  OTRSAOL  SAROR  SARRM  NUII?  OMTRRRNUR  —  PARSTAM  OTMSARRNM  OTRROLM  SAOŌURM

`f72v3.2`  ocham
→ OSAUS

`f72v3.3`  orchey
→ ORSARM

`f72v3.4`  okam
→ OŌUS

`f72v3.5`  okey
→ OŌRM

`f72v3.6`  otcheody
→ OTSARONM

`f72v3.7`  okyeeshy
→ OŌMRRPAM

`f72v3.8`  [{c'y}:??]ofaiin
→ SMO?UII?

`f72v3.9`  okaly
→ OŌULM

`f72v3.10`  ot[o:a]ly
→ OTOLM

`f72v3.11`  ofalals
→ O?ULULP

`f72v3.12`  sheeos.o{cfhh}y
→ PARROP  OS?AAM

`f72v3.13`  daiin,chepy
→ NUII?SARMM

`f72v3.14`  oteey.deeal
→ OTRRM  NRRUL

`f72v3.15`  chealpy
→ SARULMM

`f72v3.16`  okeeol
→ OŌRROL

`f72v3.17`  okaly
→ OŌULM

`f72v3.18`  okaldy
→ OŌULNM

`f72v3.19`  okeolyd
→ OŌROLMN

`f72v3.20`  ototeey.r.chlyiintee.or.oteey.oteeody.cheokey.okeoekol.oteor.aiin.yoleeedy.okeos,alyshy.okeey.okeeey.okeedaly.cholainy.okedy.chees,y.okeeol.chey.otey.oldy.chdy,del.okeeoloky.oty.aiin.chas.oteey.okea???
→ OTOTRRM  R  SALMII?TRR  OR  OTRRM  OTRRONM  SAROŌRM  OŌRORŌOL  OTROR  UII?  MOLRRRNM  OŌROPULMPAM  OŌRRM  OŌRRRM  OŌRRNULM  SAOLUI?M  OŌRNM  SARRPM  OŌRROL  SARM  OTRM  OLNM  SANMNRL  OŌRROLOŌM  OTM  UII?  SAUP  OTRRM  OŌRU

`f72v3.21`  choleey
→ SAOLRRM

`f72v3.22`  oky
→ OŌM

`f72v3.23`  ch{cthh}y
→ SASTAAM

`f72v3.24`  laly
→ LULM

`f72v3.25`  oeedy
→ ORRNM

`f72v3.26`  odairan
→ ONUIRU?

`f72v3.27`  okary
→ OŌURM

`f72v3.28`  oeesaiin
→ ORRPUII?

`f72v3.29`  oteesed
→ OTRRPRN

`f72v3.30`  opal
→ OMUL

`f72v3.31`  otaly
→ OTULM

`f72v3.32`  otaly,yty
→ OTULMMTM

`f72v3.33`  okesee[s:r],ar,chkeeol.okeolaiin.chalal.ykeeodarar.oleeody,shedy.solar.aldy.oteor.cheor
→ OŌRPRRPURSAŌRROL  OŌROLUII?  SAULUL  MŌRRONURUR  OLRRONMPARNM  POLUR  ULNM  OTROR  SAROR

### f72v2  ·  zodiac

`f72v2.1`  otos,chs.oty.oteos.oty.chotey.dchy.chopchy.otychal.ctheo,l,shey.tchol,s.choraiin.cheka{iph}y.oteeos,aly.okeedy.cheockhy.ar?k?aly.che??.okedl.okedy.sheos.okeeor.cheey.okeey.teey.cheeey.okeolol.sheeoeky.oekeeo,r,aiin.olalka[in:ir].okolsaiin
→ OTOPSAP  OTM  OTROP  OTM  SAOTRM  NSAM  SAOMSAM  OTMSAUL  STAROLPARM  TSAOLP  SAORUII?  SARŌUIMAM  OTRROPULM  OŌRRNM  SAROSŌAM  URŌULM  SAR  OŌRNL  OŌRNM  PAROP  OŌRROR  SARRM  OŌRRM  TRRM  SARRRM  OŌROLOL  PARRORŌM  ORŌRRORUII?  OLULŌUI?  OŌOLPUII?

`f72v2.2`  oeedey
→ ORRNRM

`f72v2.3`  oeeodaiin
→ ORRONUII?

`f72v2.4`  okeoram
→ OŌRORUS

`f72v2.5`  air,aim
→ UIRUIS

`f72v2.6`  oshesy
→ OPARPM

`f72v2.7`  oke[a:o]ry
→ OŌRURM

`f72v2.8`  cheoetey
→ SARORTRM

`f72v2.9`  cheol[d:?]y
→ SAROLNM

`f72v2.10`  sheoeky
→ PARORŌM

`f72v2.11`  oteodar
→ OTRONUR

`f72v2.12`  ofchdysd
→ O?SANMPN

`f72v2.13`  oteoyd
→ OTROMN

`f72v2.14`  yteody
→ MTRONM

`f72v2.15`  okeody
→ OŌRONM

`f72v2.16`  okeoldy
→ OŌROLNM

`f72v2.17`  ykeeor
→ MŌRROR

`f72v2.18`  opaiina[m:r]
→ OMUII?US

`f72v2.19`  cheoldy
→ SAROLNM

`f72v2.20`  oteesody.otey.oteeos.sheoty.yteeg.dchsaiin.shol.okeees.air,am,shey.qokeodal.oteotey.oteoldy.oteal,chedy.chotalal.okal,cheol.sar,aiin.cheokealy.sardy.otol.chekar.alteol.oltar,ar
→ OTRRPONM  OTRM  OTRROP  PAROTM  MTRR?  NSAPUII?  PAOL  OŌRRRP  UIRUSPARM  COŌRONUL  OTROTRM  OTROLNM  OTRULSARNM  SAOTULUL  OŌULSAROL  PURUII?  SAROŌRULM  PURNM  OTOL  SARŌUR  ULTROL  OLTURUR

`f72v2.21`  okaiin[:y]
→ OŌUII?

`f72v2.22`  ockhol
→ OSŌAOL

`f72v2.23`  oeedy
→ ORRNM

`f72v2.24`  opalg
→ OMUL?

`f72v2.25`  okeeom
→ OŌRROS

`f72v2.26`  olkar
→ OLŌUR

`f72v2.27`  oeedaly
→ ORRNULM

`f72v2.28`  cheosy
→ SAROPM

`f72v2.29`  ofcheay
→ O?SARUM

`f72v2.30`  yteedy
→ MTRRNM

`f72v2.31`  o[n:r]aiin
→ O?UII?

`f72v2.32`  okeorar
→ OŌRORUR

`f72v2.33`  otaiin.otshedy.chokeedy.otes,al,al,ar.chetolain.sheodaly.sheokey.okealy.rary
→ OTUII?  OTPARNM  SAOŌRRNM  OTRPULULUR  SARTOLUI?  PARONULM  PAROŌRM  OŌRULM  RURM

### f72v1  ·  zodiac

`f72v1.1`  oteos.alar.otar.air.chpaly.oteody.okchesal.otear.alshey.oleealy.sh?tey.oteos.alal.dals,alchol.ytolaiin.ydaiin.chotar.y,tal.oto.shoty.otey.okchedaly.chdar,y.s,ar,otedy.otorar.shedy.opsheytey.opairaly.choshydy.otar.cheedy.otaraiin.cheeky.okolar.ychey.otechety
→ OTROP  ULUR  OTUR  UIR  SAMULM  OTRONM  OŌSARPUL  OTRUR  ULPARM  OLRRULM  PATRM  OTROP  ULUL  NULPULSAOL  MTOLUII?  MNUII?  SAOTUR  MTUL  OTO  PAOTM  OTRM  OŌSARNULM  SANURM  PUROTRNM  OTORUR  PARNM  OMPARMTRM  OMUIRULM  SAOPAMNM  OTUR  SARRNM  OTURUII?  SARRŌM  OŌOLUR  MSARM  OTRSARTM

`f72v1.2`  oeeoty
→ ORROTM

`f72v1.3`  octhy
→ OSTAM

`f72v1.4`  oteoly
→ OTROLM

`f72v1.5`  okeoly
→ OŌROLM

`f72v1.6`  oeees
→ ORRRP

`f72v1.7`  o{cfh'h}y
→ OS?AAM

`f72v1.8`  oees
→ ORRP

`f72v1.9`  okeeoly
→ OŌRROLM

`f72v1.10`  odal
→ ONUL

`f72v1.11`  aiinod
→ UII?ON

`f72v1.12`  od[?:ch]dy
→ ONNM

`f72v1.13`  oteod
→ OTRON

`f72v1.14`  yteod
→ MTRON

`f72v1.15`  ok[?:ch]ody
→ OŌONM

`f72v1.16`  okal
→ OŌUL

`f72v1.17`  ytaly
→ MTULM

`f72v1.18`  oeeeos
→ ORRROP

`f72v1.19`  oteofy
→ OTRO?M

`f72v1.20`  cheoepy
→ SARORMM

`f72v1.21`  ykeedy
→ MŌRRNM

`f72v1.22`  otar,ar.otol,topar.oteolaiin.ofa[r:s]al.otshedy.ofalar.alshdy.chpar,aiin.okaly.oka?.yaly.opcheolfy.opar.cheo{ck}ey.otolopaiin.shaldy.chepchy.otey.tea[n:r]
→ OTURUR  OTOLTOMUR  OTROLUII?  O?URUL  OTPARNM  O?ULUR  ULPANM  SAMURUII?  OŌULM  OŌU  MULM  OMSAROL?M  OMUR  SAROSŌRM  OTOLOMUII?  PAULNM  SARMSAM  OTRM  TRU?

`f72v1.23`  oeeoly
→ ORROLM

`f72v1.24`  okydy
→ OŌMNM

`f72v1.25`  okeey
→ OŌRRM

`f72v1.26`  oiiny
→ OII?M

`f72v1.27`  oeey
→ ORRM

`f72v1.28`  okedy
→ OŌRNM

`f72v1.29`  ypaim
→ MMUIS

`f72v1.30`  okalair
→ OŌULUIR

`f72v1.31`  oeeody
→ ORRONM

`f72v1.32`  okeol
→ OŌROL

`f72v1.33`  otalal.dalal.ykeols.oteo,r,aiin.yotoam.oteey.saiin.oteeos,am
→ OTULUL  NULUL  MŌROLP  OTRORUII?  MOTOUS  OTRRM  PUII?  OTRROPUS

### f73r  ·  zodiac

`f73r.1`  otaly
→ OTULM

`f73r.2`  chockhy
→ SAOSŌAM

`f73r.3`  otedy
→ OTRNM

`f73r.4`  yteeody
→ MTRRONM

`f73r.5`  ypolcheey.salchedal.chepchey.daraly.oteos,air,ar.oteosdal.chot[oe:ee]y.soteees,alshey.[{oh}:ch]es.al,chees.che[o:a]ly.jeiii?.choteey.cheteey.cheteeeos,aiin.chetchody.chedar.ar.cheteey.ote{co}s,ar.airalor.shetee.yteey.cheody.ykeydam.oteos.alar.alcheky
→ MMOLSARRM  PULSARNUL  SARMSARM  NURULM  OTROPUIRUR  OTROPNUL  SAOTORM  POTRRRPULPARM  OARP  ULSARRP  SAROLM  ?RIII  SAOTRRM  SARTRRM  SARTRRROPUII?  SARTSAONM  SARNUR  UR  SARTRRM  OTRSOPUR  UIRULOR  PARTRR  MTRRM  SARONM  MŌRMNUS  OTROP  ULUR  ULSARŌM

`f73r.6`  otaly
→ OTULM

`f73r.7`  okeody
→ OŌRONM

`f73r.8`  oteedyl
→ OTRRNML

`f73r.9`  [y:o]keedy
→ MŌRRNM

`f73r.10`  okeey
→ OŌRRM

`f73r.11`  okeedy
→ OŌRRNM

`f73r.12`  ykeeory
→ MŌRRORM

`f73r.13`  oteeosy
→ OTRROPM

`f73r.14`  shekal
→ PARŌUL

`f73r.15`  oteedyy
→ OTRRNMM

`f73r.16`  oked[a:o]l
→ OŌRNUL

`f73r.17`  chdy
→ SANM

`f73r.18`  dalshey
→ NULPARM

`f73r.19`  opaiin
→ OMUII?

`f73r.20`  okeos
→ OŌROP

`f73r.21`  otey
→ OTRM

`f73r.22`  oteey.dar.al.opaiin.olalaiin.s.air,am.chopchedy.chdar.oram.otareees.olteey.okees.otar,chey.oteas,ochor.oparchey.daiin.qocheey.s,cheey.dal.cheesy
→ OTRRM  NUR  UL  OMUII?  OLULUII?  P  UIRUS  SAOMSARNM  SANUR  ORUS  OTURRRRP  OLTRRM  OŌRRP  OTURSARM  OTRUPOSAOR  OMURSARM  NUII?  COSARRM  PSARRM  NUL  SARRPM

`f73r.23`  okary
→ OŌURM

`f73r.24`  okeeody
→ OŌRRONM

`f73r.25`  oyteedy
→ OMTRRNM

`f73r.26`  oky
→ OŌM

`f73r.27`  chefy
→ SAR?M

`f73r.28`  otal
→ OTUL

`f73r.29`  chek
→ SARŌ

`f73r.30`  ar
→ UR

`f73r.31`  kar
→ ŌUR

`f73r.32`  okeeos
→ OŌRROP

`f73r.33`  osaiin.chedain.oteey.chedaly.okechs.chepcheesaly.oteodal
→ OPUII?  SARNUI?  OTRRM  SARNULM  OŌRSAP  SARMSARRPULM  OTRONUL

### f73v  ·  zodiac

`f73v.1`  okol
→ OŌOL

`f73v.2`  oteody
→ OTRONM

`f73v.3`  oteedy
→ OTRRNM

`f73v.4`  eeeody
→ RRRONM

`f73v.5`  otoar.ykeody.okodeey.qopchey.opaiin.qoteedy.dpy.otedy,shedy.qokeody.cheor,al.okegal.oteody.shedy.otesalod.air,chy.ykeesaly.y.keoly,dys.opchey.dy.toly.chfaikchy.ytedar.eeey.qokeey.oty.yteedy.choldy.qokalaiin.ykaipy.orary
→ OTOUR  MŌRONM  OŌONRRM  COMSARM  OMUII?  COTRRNM  NMM  OTRNMPARNM  COŌRONM  SARORUL  OŌR?UL  OTRONM  PARNM  OTRPULON  UIRSAM  MŌRRPULM  M  ŌROLMNMP  OMSARM  NM  TOLM  SA?UIŌSAM  MTRNUR  RRRM  COŌRRM  OTM  MTRRNM  SAOLNM  COŌULUII?  MŌUIMM  ORURM

`f73v.6`  okeody
→ OŌRONM

`f73v.7`  sheol
→ PAROL

`f73v.8`  odees
→ ONRRP

`f73v.9`  ee[r:n]y
→ RRRM

`f73v.10`  okeor
→ OŌROR

`f73v.11`  ofals
→ O?ULP

`f73v.12`  ykeody
→ MŌRONM

`f73v.13`  oteody
→ OTRONM

`f73v.14`  ypaiin
→ MMUII?

`f73v.15`  yfaiin,y
→ M?UII?M

`f73v.16`  ofcheesy
→ O?SARRPM

`f73v.17`  oraiiny
→ ORUII?M

`f73v.18`  ykeeody
→ MŌRRONM

`f73v.19`  okeos
→ OŌROP

`f73v.20`  ykeear
→ MŌRRUR

`f73v.21`  qokeoly
→ COŌROLM

`f73v.22`  oteoto[s:r].alshy.oteolain.chokeedam.otody.qoty.shedy.chdy.tchol.oteody.cheytey.choty.o[k:t]ey,dy.okecholy.otey.chodaiin.chey.okeedy.saly.ar.daly
→ OTROTOP  ULPAM  OTROLUI?  SAOŌRRNUS  OTONM  COTM  PARNM  SANM  TSAOL  OTRONM  SARMTRM  SAOTM  OŌRMNM  OŌRSAOLM  OTRM  SAONUII?  SARM  OŌRRNM  PULM  UR  NULM

`f73v.23`  otedy
→ OTRNM

`f73v.24`  eeed
→ RRRN

`f73v.25`  oky
→ OŌM

`f73v.26`  oia?
→ OIU

`f73v.27`  okal
→ OŌUL

`f73v.28`  ykey
→ MŌRM

`f73v.29`  ykeee
→ MŌRRR

`f73v.30`  okeod
→ OŌRON

`f73v.31`  ykey
→ MŌRM

`f73v.32`  ypal
→ MMUL

`f73v.33`  otedchor.alar.olkcho.otolam.o,kees,char,y.ytaly.alaly.otaram
→ OTRNSAOR  ULUR  OLŌSAO  OTOLUS  OŌRRPSAURM  MTULM  ULULM  OTURUS

### f75r  ·  balneological

`f75r.1`  kchedykary<->okeey.qokar.shyk,chedy.qotar.shedy
→ ŌSARNMŌURMOŌRRM  COŌUR  PAMŌSARNM  COTUR  PARNM

`f75r.2`  dain.shey.ly<->ssheol.qol{chh}dy.chedykar.chekeedy.ror
→ NUI?  PARM  LMPPAROL  COLSAANM  SARNMŌUR  SARŌRRNM  ROR

`f75r.3`  qokain.chal<->orchey.qey.kain.sheeky.ltain.olkar.or
→ COŌUI?  SAULORSARM  CRM  ŌUI?  PARRŌM  LTUI?  OLŌUR  OR

`f75r.4`  dackhy.lkamo<->ykeey.lshey.kal.dy.shey.ok.shey.qokeedy
→ NUSŌAM  LŌUSOMŌRRM  LPARM  ŌUL  NM  PARM  OŌ  PARM  COŌRRNM

`f75r.5`  shey,kar.chey<->ckhey.r.ain.ol.olsheedy.qokeey.qoky
→ PARMŌUR  SARMSŌARM  R  UI?  OL  OLPARRNM  COŌRRM  COŌM

`f75r.6`  pcheykeeor.olky<->dar.okey.qokain.chcthy.qokeedy.qoky
→ MSARMŌRROR  OLŌMNUR  OŌRM  COŌUI?  SASTAM  COŌRRNM  COŌM

`f75r.7`  pchedy.qokshdy<->ytain.chedy.qokar.chy.lol.chedy.qoky
→ MSARNM  COŌPANMMTUI?  SARNM  COŌUR  SAM  LOL  SARNM  COŌM

`f75r.8`  sor.chey.qokardy<->dsheckhy.qokain.chckhy.lshedy.okeedy
→ POR  SARM  COŌURNMNPARSŌAM  COŌUI?  SASŌAM  LPARNM  OŌRRNM

`f75r.9`  qokchdy.chcthy.lo<->qokedy.qokan.checkhy.qokar.olchedy.sal
→ COŌSANM  SASTAM  LOCOŌRNM  COŌU?  SARSŌAM  COŌUR  OLSARNM  PUL

`f75r.10`  dshor.qotar.chdy<->shey.qokain.chckhy.dy.otey.tedy.lchedy
→ NPAOR  COTUR  SANMPARM  COŌUI?  SASŌAM  NM  OTRM  TRNM  LSARNM

`f75r.11`  qokeedy.qokair.oly<->qokeedy.dy.qokal.okar.shedy.dor.chekam
→ COŌRRNM  COŌUIR  OLMCOŌRRNM  NM  COŌUL  OŌUR  PARNM  NOR  SARŌUS

`f75r.12`  ssheckhy.qokal.oly<->shey.r.ol.cheey.shey.dy,olshedy.qoky
→ PPARSŌAM  COŌUL  OLMPARM  R  OL  SARRM  PARM  NMOLPARNM  COŌM

`f75r.13`  pchedy.keedy.qokedy<->qokedy.qokedy.qokedy.qokain.olshedy
→ MSARNM  ŌRRNM  COŌRNMCOŌRNM  COŌRNM  COŌRNM  COŌUI?  OLPARNM

`f75r.14`  sain.al,keishy.qokain,dy<->olshedy.qokain.chckhy.qokain.otar,aly
→ PUI?  ULŌRIPAM  COŌUI?NMOLPARNM  COŌUI?  SASŌAM  COŌUI?  OTURULM

`f75r.15`  sain.qokain.qolkeeoly<->saiin.chedy<->sol.or.shedy.okchdy.qoky
→ PUI?  COŌUI?  COLŌRROLMPUII?  SARNMPOL  OR  PARNM  OŌSANM  COŌM

`f75r.16`  dshedy.qokar.sheedy.lch<->shokain.chy<->okshedy.qokain.chedy
→ NPARNM  COŌUR  PARRNM  LSAPAOŌUI?  SAMOŌPARNM  COŌUI?  SARNM

`f75r.17`  pchedar.shepchy.lshedary<->dal<->shal<->shy,kol.shedy.qokam
→ MSARNUR  PARMSAM  LPARNURMNULPAULPAMŌOL  PARNM  COŌUS

`f75r.18`  sol.sheedy.qol.shedy.qol<->otain.char.sar.oly
→ POL  PARRNM  COL  PARNM  COLOTUI?  SAUR  PUR  OLM

`f75r.19`  qokshedy.qol,shey.qoky<->shey.{ith}ey.qokain.ar
→ COŌPARNM  COLPARM  COŌMPARM  ITARM  COŌUI?  UR

`f75r.20`  ry,shey.qor.chey.lchey,lo<->ydain.shey.qokain
→ RMPARM  COR  SARM  LSARMLOMNUI?  PARM  COŌUI?

`f75r.21`  oqokain.chey.qckhsy.or<->ysheor.ol.lor.am
→ OCOŌUI?  SARM  CSŌAPM  ORMPAROR  OL  LOR  US

`f75r.22`  odar,shey.qokain.chedy<->or,shey.kar.chedy,sar
→ ONURPARM  COŌUI?  SARNMORPARM  ŌUR  SARNMPUR

`f75r.23`  pchey,kshey.qokeey.qokal<->sshey.qol.chedyqokam
→ MSARMŌPARM  COŌRRM  COŌULPPARM  COL  SARNMCOŌUS

`f75r.24`  qokain.olkeey.qolkary<->sain.checthy.lor.ol
→ COŌUI?  OLŌRRM  COLŌURMPUI?  SARSTAM  LOR  OL

`f75r.25`  sain.shckhy.qokeedy.shy.dy<->qokeedy.lchedy.ram
→ PUI?  PASŌAM  COŌRRNM  PAM  NMCOŌRRNM  LSARNM  RUS

`f75r.26`  dain.ol.sheol.dain.ol.qoly<->dar,ajy
→ NUI?  OL  PAROL  NUI?  OL  COLMNURU?M

`f75r.27`  pdalshor.shtol.qoty.pshar.shedy.okaldy<->dar.otar.otody.dy.rol
→ MNULPAOR  PATOL  COTM  MPAUR  PARNM  OŌULNMNUR  OTUR  OTONM  NM  ROL

`f75r.28`  tchedy.pchedy.qokeey.sol.oldair.shecthy.qol<->l.sheedy.qokeedy.lolchedy
→ TSARNM  MSARNM  COŌRRM  POL  OLNUIR  PARSTAM  COLL  PARRNM  COŌRRNM  LOLSARNM

`f75r.29`  dain.chkal.dy.lo,lkaiin.ol.okeedyqol.dain.olchey.qokeedy.chedy.qotan
→ NUI?  SAŌUL  NM  LOLŌUII?  OL  OŌRRNMCOL  NUI?  OLSARM  COŌRRNM  SARNM  COTU?

`f75r.30`  qo,dain.cheeky.qokey.qokain.cheky.qokal.dain.chedy.o,kalol,shedy.okar,olom
→ CONUI?  SARRŌM  COŌRM  COŌUI?  SARŌM  COŌUL  NUI?  SARNM  OŌULOLPARNM  OŌUROLOS

`f75r.31`  dshedy.qokey.chckhy.qokar.shedy.chey.qoked.qokedy.daldy
→ NPARNM  COŌRM  SASŌAM  COŌUR  PARNM  SARM  COŌRN  COŌRNM  NULNM

`f75r.32`  polshy.dal.shedy.qokain.dar.chsdy.shedy.qotar.shedy.ldy
→ MOLPAM  NUL  PARNM  COŌUI?  NUR  SAPNM  PARNM  COTUR  PARNM  LNM

`f75r.33`  qokeey.l,shedy.qo,l.chedy.qokain.chcthedy.ltedy.darom
→ COŌRRM  LPARNM  COL  SARNM  COŌUI?  SASTARNM  LTRNM  NUROS

`f75r.34`  s,olkedy.okal.dar.oty.okar.otar.ol,kain.oltedy
→ POLŌRNM  OŌUL  NUR  OTM  OŌUR  OTUR  OLŌUI?  OLTRNM

`f75r.35`  qokain.sheety.qokain.dar.dar.shedy.qoka[in:r].oldy
→ COŌUI?  PARRTM  COŌUI?  NUR  NUR  PARNM  COŌUI?  OLNM

`f75r.36`  sol.keedy.qokeedy.qokey.okar.otar.dardardy
→ POL  ŌRRNM  COŌRRNM  COŌRM  OŌUR  OTUR  NURNURNM

`f75r.37`  qokedy.dy.sheety.qokedy.qokeedy.qokechdy.lol
→ COŌRNM  NM  PARRTM  COŌRNM  COŌRRNM  COŌRSANM  LOL

`f75r.38`  qokeedy.qokeedy.qokedy.qokedy.qokeedy.ldy
→ COŌRRNM  COŌRRNM  COŌRNM  COŌRNM  COŌRRNM  LNM

`f75r.39`  yshedy.qokeedy.qokeedy.olkeedy.otey.koldy
→ MPARNM  COŌRRNM  COŌRRNM  OLŌRRNM  OTRM  ŌOLNM

`f75r.40`  dar.shedy.qokain.shedy.dal,keedy.rshedy
→ NUR  PARNM  COŌUI?  PARNM  NULŌRRNM  RPARNM

`f75r.41`  sokeedy.qokeedy.oteedy.qoky.dy,keedy.sy
→ POŌRRNM  COŌRRNM  OTRRNM  COŌM  NMŌRRNM  PM

`f75r.42`  dshedy.qokedy.qokeedy.qoteey.qoteedy.d[o:a]r
→ NPARNM  COŌRNM  COŌRRNM  COTRRM  COTRRNM  NOR

`f75r.43`  yshedy.chekar.oldy.qokain.chkar.otar,oldy
→ MPARNM  SARŌUR  OLNM  COŌUI?  SAŌUR  OTUROLNM

`f75r.44`  dchedy.sain.okedy.qokedy.otedy.okoldy.otar.otam.olaiin.ch<->dar.dy
→ NSARNM  PUI?  OŌRNM  COŌRNM  OTRNM  OŌOLNM  OTUR  OTUS  OLUII?  SANUR  NM

`f75r.45`  sshedy.shckhy.qokey.okedy.sarol.oty.otedy.qotedy.otedy.okaiin
→ PPARNM  PASŌAM  COŌRM  OŌRNM  PUROL  OTM  OTRNM  COTRNM  OTRNM  OŌUII?

`f75r.46`  qokey.qokedy.sheol.qokedy.dain.shedy.otol,chedy.ol[o:a]r
→ COŌRM  COŌRNM  PAROL  COŌRNM  NUI?  PARNM  OTOLSARNM  OLOR

`f75r.47`  sal.okeedy
→ PUL  OŌRRNM

`f75r.48`  daly.ychey
→ NULM  MSARM

`f75r.49`  sols.dara
→ POLP  NURU

`f75r.50`  ychty
→ MSATM

`f75r.51`  saino
→ PUI?O

`f75r.52`  saldy
→ PULNM

`f75r.53`  dainy
→ NUI?M

### f75v  ·  balneological

`f75v.1`  pchedar.opchedy.qokedy.opchedy.qopdy<->dain.chetas.ch{cphh}y.qotam
→ MSARNUR  OMSARNM  COŌRNM  OMSARNM  COMNMNUI?  SARTUP  SASMAAM  COTUS

`f75v.2`  s
→ P

`f75v.3`  sor.sheky.qokain.okal.dal.olchedy<->daiin.chckhy.lkar.chckhy,rom
→ POR  PARŌM  COŌUI?  OŌUL  NUL  OLSARNMNUII?  SASŌAM  LŌUR  SASŌAMROS

`f75v.4`  l
→ L

`f75v.5`  dl.shckhy.kain.olchey.qokain.dalyrd<->dl,shedy.qoteedy.cthedy.loly
→ NL  PASŌAM  ŌUI?  OLSARM  COŌUI?  NULMRNNLPARNM  COTRRNM  STARNM  LOLM

`f75v.6`  l
→ L

`f75v.7`  qokchdy.qokal.dal.ol.chety.lchdy<->shedy.ched.otedy.qotedy.otar
→ COŌSANM  COŌUL  NUL  OL  SARTM  LSANMPARNM  SARN  OTRNM  COTRNM  OTUR

`f75v.8`  o
→ O

`f75v.9`  r
→ R

`f75v.10`  qokeed.chedy,ky.okedy.lchedy.dar,ody<->dchedy.dar.olchedy.otedy.qoky
→ COŌRRN  SARNMŌM  OŌRNM  LSARNM  NURONMNSARNM  NUR  OLSARNM  OTRNM  COŌM

`f75v.11`  s
→ P

`f75v.12`  qokedy.rshey.qol.chey.ol.chey.keed<->sol.key.dy,kedy.qokal.dar.oly
→ COŌRNM  RPARM  COL  SARM  OL  SARM  ŌRRNPOL  ŌRM  NMŌRNM  COŌUL  NUR  OLM

`f75v.13`  ocheain.cheedy.qokal.dain.sheeky.qoky<->sshedy.tedy.otedy.tedy.taral
→ OSARUI?  SARRNM  COŌUL  NUI?  PARRŌM  COŌMPPARNM  TRNM  OTRNM  TRNM  TURUL

`f75v.14`  qol.sheckhy.qokedy.qokedy.qokaly<->sor,chedy.qoky.olshty.qokydy
→ COL  PARSŌAM  COŌRNM  COŌRNM  COŌULMPORSARNM  COŌM  OLPATM  COŌMNM

`f75v.15`  sal.ol.olain.olkey.olshed.qokaly<->qokar.chedy.qokain.ty.lshdy,qo
→ PUL  OL  OLUI?  OLŌRM  OLPARN  COŌULMCOŌUR  SARNM  COŌUI?  TM  LPANMCO

`f75v.16`  odchedy.qolshdy.shokshdy.qokain.?<->or.shedy.qolol,keedy.qokalom
→ ONSARNM  COLPANM  PAOŌPANM  COŌUI?  OR  PARNM  COLOLŌRRNM  COŌULOS

`f75v.17`  sal.shed,ykain.qokain.sheckhy.ld<->saiin.ckhy.lshedy
→ PUL  PARNMŌUI?  COŌUI?  PARSŌAM  LNPUII?  SŌAM  LPARNM

`f75v.18`  okshy
→ OŌPAM

`f75v.19`  saral
→ PURUL

`f75v.20`  dokal
→ NOŌUL

`f75v.21`  darol
→ NUROL

`f75v.22`  daldy
→ NULNM

`f75v.23`  dal,shd
→ NULPAN

`f75v.24`  dalkar
→ NULŌUR

`f75v.25`  qokal
→ COŌUL

`f75v.26`  dly
→ NLM

`f75v.27`  ory
→ ORM

`f75v.28`  oty
→ OTM

`f75v.29`  lchy
→ LSAM

`f75v.30`  dary
→ NURM

`f75v.31`  dal
→ NUL

`f75v.32`  daldy
→ NULNM

`f75v.33`  qoted
→ COTRN

`f75v.34`  rkal
→ RŌUL

`f75v.35`  ykedy
→ MŌRNM

`f75v.36`  olkchy
→ OLŌSAM

`f75v.37`  otoly
→ OTOLM

`f75v.38`  tolsheor.qokal.dar.olked.orol.kchey.okain.olchey.okar.sheky.dedy.kedy
→ TOLPAROR  COŌUL  NUR  OLŌRN  OROL  ŌSARM  OŌUI?  OLSARM  OŌUR  PARŌM  NRNM  ŌRNM

`f75v.39`  qoqokeey.olkain.qol,sheedy.qokeor.sheedy.qokal.or.chey.qokar.ol.aiin
→ COCOŌRRM  OLŌUI?  COLPARRNM  COŌROR  PARRNM  COŌUL  OR  SARM  COŌUR  OL  UII?

`f75v.40`  dlshedy.qokain.dal.qol.qol.ol.sheedy.cheey.dol.ol,sheey.qokain.olol
→ NLPARNM  COŌUI?  NUL  COL  COL  OL  PARRNM  SARRM  NOL  OLPARRM  COŌUI?  OLOL

`f75v.41`  sal.shedy.qokain.shey.qoin.ol,shey.ol.shey.qoky.qol,cheey.chl.or,sheolo
→ PUL  PARNM  COŌUI?  PARM  COI?  OLPARM  OL  PARM  COŌM  COLSARRM  SAL  ORPAROLO

`f75v.42`  o,l.sheey.qolshey.qokain.okaiin.charor
→ OL  PARRM  COLPARM  COŌUI?  OŌUII?  SAUROR

`f75v.43`  pokain.okeedy.or.chesy.solshey.qokeey.qotedy.olkedy.chey,tal.dy.qol
→ MOŌUI?  OŌRRNM  OR  SARPM  POLPARM  COŌRRM  COTRNM  OLŌRNM  SARMTUL  NM  COL

`f75v.44`  olshees.ol,sheckhy.qokain.ol.chedy.qol.chedy.qol,keey.qolchedy.chealy
→ OLPARRP  OLPARSŌAM  COŌUI?  OL  SARNM  COL  SARNM  COLŌRRM  COLSARNM  SARULM

`f75v.45`  yshey.qokar.olchedy.qor.oiin.okeedy.qokeed.qokeey.qokeey.otey.qoky.dy
→ MPARM  COŌUR  OLSARNM  COR  OII?  OŌRRNM  COŌRRN  COŌRRM  COŌRRM  OTRM  COŌM  NM

`f75v.46`  ychey.qotain.sheckhy.qokedy.qokedy.lsheckhy.qokain.dal.tol.olchedy
→ MSARM  COTUI?  PARSŌAM  COŌRNM  COŌRNM  LPARSŌAM  COŌUI?  NUL  TOL  OLSARNM

`f75v.47`  qokain.olshey.qokain.dar.ol.shedy.qokedy.qokeedy.qotar.olshedy.oldy
→ COŌUI?  OLPARM  COŌUI?  NUR  OL  PARNM  COŌRNM  COŌRRNM  COTUR  OLPARNM  OLNM

`f75v.48`  qokear.chedy.shckhy.dol.ycheedy.saino.ol.cheedy.qokar.otar.dal.daiin
→ COŌRUR  SARNM  PASŌAM  NOL  MSARRNM  PUI?O  OL  SARRNM  COŌUR  OTUR  NUL  NUII?

`f75v.49`  por.shey.okain.chedy.qolsheol.olchedy
→ MOR  PARM  OŌUI?  SARNM  COLPAROL  OLSARNM

`f75v.50`  otal.opal
→ OTUL  OMUL

`f75v.51`  okeey.lol
→ OŌRRM  LOL

`f75v.52`  olol
→ OLOL

`f75v.53`  ytedy
→ MTRNM

`f75v.54`  otedy
→ OTRNM

`f75v.55`  oteey
→ OTRRM

`f75v.56`  qotedy
→ COTRNM

`f75v.57`  okedy.qek,y,tedar.oly
→ OŌRNM  CRŌMTRNUR  OLM

`f75v.58`  s,alchedy.solkedy
→ PULSARNM  POLŌRNM

`f75v.59`  qokeedy.qok[o:a]l.olkol
→ COŌRRNM  COŌOL  OLŌOL

`f75v.60`  kolkedy.qokedy.qoky.lpchdy.qotchdy.lol
→ ŌOLŌRNM  COŌRNM  COŌM  LMSANM  COTSANM  LOL

`f75v.61`  oksheyqolkeey.lchdy.soiin.ol.otchdy
→ OŌPARMCOLŌRRM  LSANM  POII?  OL  OTSANM

`f75v.62`  ykeechy.qokeedy.daiin.ol.olsheey.qoly
→ MŌRRSAM  COŌRRNM  NUII?  OL  OLPARRM  COLM

`f75v.63`  oteey.qol,chey.qokey.oldy.olyly
→ OTRRM  COLSARM  COŌRM  OLNM  OLMLM

`f75v.64`  sshey.qol.dy.qokar.shey.ldy
→ PPARM  COL  NM  COŌUR  PARM  LNM

`f75v.65`  qokal.dain.dain.o,qoky.daiin
→ COŌUL  NUI?  NUI?  OCOŌM  NUII?

`f75v.66`  okal.sheedy.qoteedy.qokchy,ly
→ OŌUL  PARRNM  COTRRNM  COŌSAMLM

`f75v.67`  ykeedy.qokain.otain.shety
→ MŌRRNM  COŌUI?  OTUI?  PARTM

`f75v.68`  o,cthey.shedy.otol.chckhey.ldy
→ OSTARM  PARNM  OTOL  SASŌARM  LNM

`f75v.69`  okeshey.olkedy.olkedy.qol,chey
→ OŌRPARM  OLŌRNM  OLŌRNM  COLSARM

`f75v.70`  qokey.olchedy.otey.orol
→ COŌRM  OLSARNM  OTRM  OROL

### f76r  ·  text/preface

`f76r.1`  potchokor.chcfhdy.opshdy.qolp.chcphy.chcphdy.opshey.qofshy.opchdy.sain.as,y
→ MOTSAOŌOR  SAS?ANM  OMPANM  COLM  SASMAM  SASMANM  OMPARM  CO?PAM  OMSANM  PUI?  UPM

`f76r.2`  dshedy.qotddyar.cthar.chep.dain.okain.qokeor.shedy.qol.ain.sheals,qokeey
→ NPARNM  COTNNMUR  STAUR  SARM  NUI?  OŌUI?  COŌROR  PARNM  COL  UI?  PARULPCOŌRRM

`f76r.3`  yshey.qokeey.qokey.qokeed.okedy.shky.qotedy.otedy.shol,qoty.ol,chedy.aiiny
→ MPARM  COŌRRM  COŌRM  COŌRRN  OŌRNM  PAŌM  COTRNM  OTRNM  PAOLCOTM  OLSARNM  UII?M

`f76r.4`  s
→ P

`f76r.5`  qokedy.qokeey.or,or.or.chkorol.otey.qokedy.lkedy.chdy.qokchdy.qokal.chdam
→ COŌRNM  COŌRRM  OROR  OR  SAŌOROL  OTRM  COŌRNM  LŌRNM  SANM  COŌSANM  COŌUL  SANUS

`f76r.6`  solchedy.qokeedy.qopchedy.qokeeo.rol.shedy.qokedy.sheey.okees.al.al.chedain.dar
→ POLSARNM  COŌRRNM  COMSARNM  COŌRRO  ROL  PARNM  COŌRNM  PARRM  OŌRRP  UL  UL  SARNUI?  NUR

`f76r.7`  d
→ N

`f76r.8`  qoaiin.ches.okeedal.qoked.qokeey.shedy.chey.lkeedy.okey.dar.aiin.chekain.oldy
→ COUII?  SARP  OŌRRNUL  COŌRN  COŌRRM  PARNM  SARM  LŌRRNM  OŌRM  NUR  UII?  SARŌUI?  OLNM

`f76r.9`  shed.al,shckhy.[r:s],ain.chcphedy.ain.olkeey.lkar.ain.otchy.lkain.chedy.dar.daly
→ PARN  ULPASŌAM  RUI?  SASMARNM  UI?  OLŌRRM  LŌUR  UI?  OTSAM  LŌUI?  SARNM  NUR  NULM

`f76r.10`  q
→ C

`f76r.11`  qotedshedy.qorain.oteedy.chedy.ol.chdy.raiiin.chekain.dain.chckhy,sal.oty
→ COTRNPARNM  CORUI?  OTRRNM  SARNM  OL  SANM  RUIII?  SARŌUI?  NUI?  SASŌAMPUL  OTM

`f76r.12`  solshedy.qool.qctheed.shdy.qa.ol.keey.dain.saiin.s.ar.shedy.qokeor,okeedy
→ POLPARNM  COOL  CSTARRN  PANM  CU  OL  ŌRRM  NUI?  PUII?  P  UR  PARNM  COŌROROŌRRNM

`f76r.13`  qokeedy.checthy.chckhey.okal.okaiin.sheckhey.okeedy.otey.dal.y,kal.chedy,sar
→ COŌRRNM  SARSTAM  SASŌARM  OŌUL  OŌUII?  PARSŌARM  OŌRRNM  OTRM  NUL  MŌUL  SARNMPUR

`f76r.14`  s
→ P

`f76r.15`  chorshedy.qoked.okees,al.ar.aiin.ar,ain.chckheed,lchedy.shedy.qolair.chedy
→ SAORPARNM  COŌRN  OŌRRPUL  UR  UII?  URUI?  SASŌARRNLSARNM  PARNM  COLUIR  SARNM

`f76r.16`  qotes.chedy.shckhy.qokeey.okeey.kain.checkhy.qokeedy.qotey.qotain.chekair
→ COTRP  SARNM  PASŌAM  COŌRRM  OŌRRM  ŌUI?  SARSŌAM  COŌRRNM  COTRM  COTUI?  SARŌUIR

`f76r.17`  chey.chckh.shey.qeeey.chol.lkain.shedy.qokeedy.okain.chedy.okeed.qokaloro
→ SARM  SASŌA  PARM  CRRRM  SAOL  LŌUI?  PARNM  COŌRRNM  OŌUI?  SARNM  OŌRRN  COŌULORO

`f76r.18`  o
→ O

`f76r.19`  dcheedy.qolchey.qokeey.qokeey.chedy.qokar.shedy.shedy.lshedy.qolchedy.otedyl
→ NSARRNM  COLSARM  COŌRRM  COŌRRM  SARNM  COŌUR  PARNM  PARNM  LPARNM  COLSARNM  OTRNML

`f76r.20`  dshedy.qo.chedy.lchedy.qokey.qolchey.qotain.chckhy.shckhy.lchar.okar.alchdy
→ NPARNM  CO  SARNM  LSARNM  COŌRM  COLSARM  COTUI?  SASŌAM  PASŌAM  LSAUR  OŌUR  ULSANM

`f76r.21`  qokch[s:?]dy.okeey,lchedy.qo.olain.ot.shedy.qotaly.dar.sain.shedy.oleeed
→ COŌSAPNM  OŌRRMLSARNM  CO  OLUI?  OT  PARNM  COTULM  NUR  PUI?  PARNM  OLRRRN

`f76r.22`  l
→ L

`f76r.23`  sheedy.qokedy.chedy.chedy.qokain.chckhy.olchy.l,ain.shedy.olaiin.chedy,qokey
→ PARRNM  COŌRNM  SARNM  SARNM  COŌUI?  SASŌAM  OLSAM  LUI?  PARNM  OLUII?  SARNMCOŌRM

`f76r.24`  dalshedy.qol,sheedy.qokaldy.chepy.dain.alolor.olain.chedy.shecthy.qokey.lor
→ NULPARNM  COLPARRNM  COŌULNM  SARMM  NUI?  ULOLOR  OLUI?  SARNM  PARSTAM  COŌRM  LOR

`f76r.25`  qoloin.chey.qokeey.lchedy.chckhy.chey,ky.chey.qolal.lklchey.lchedy.chey.llaiir,y
→ COLOI?  SARM  COŌRRM  LSARNM  SASŌAM  SARMŌM  SARM  COLUL  LŌLSARM  LSARNM  SARM  LLUIIRM

`f76r.26`  shedal.shey.qokey.qolchedy.qolain.ain.chey.qokaiin.okain.cheedy.lchey,l,oly.dy
→ PARNUL  PARM  COŌRM  COLSARNM  COLUI?  UI?  SARM  COŌUII?  OŌUI?  SARRNM  LSARMLOLM  NM

`f76r.27`  k
→ Ō

`f76r.28`  soin.sheey.chear.ol,aiin.chodaiin.qokaiin.chey.qokalchey.dal,chdy.dal.ytal
→ POI?  PARRM  SARUR  OLUII?  SAONUII?  COŌUII?  SARM  COŌULSARM  NULSANM  NUL  MTUL

`f76r.29`  qokar.shedy.shedy.qokar.shedy.qokain.dar.shey.lshcthy.okar.okain.y,laiin,y
→ COŌUR  PARNM  PARNM  COŌUR  PARNM  COŌUI?  NUR  PARM  LPASTAM  OŌUR  OŌUI?  MLUII?M

`f76r.30`  darchey.cheolchey.shcthy.chedy.qo.qokey.dalaiin.sheeky.qokain.olky.sain.chy
→ NURSARM  SAROLSARM  PASTAM  SARNM  CO  COŌRM  NULUII?  PARRŌM  COŌUI?  OLŌM  PUI?  SAM

`f76r.31`  r
→ R

`f76r.32`  che[o:a],r.ain.okaiin.dain.chey.dalshedy.qokaiin.che[o:a]l.shy.chedy.rain.chedy.shy
→ SAROR  UI?  OŌUII?  NUI?  SARM  NULPARNM  COŌUII?  SAROL  PAM  SARNM  RUI?  SARNM  PAM

`f76r.33`  qokedy.lkey.kal.shedy.qopchey.qo,l,pchedy.okchy.chckhy.shey.lol.r,ol.sheey.dar
→ COŌRNM  LŌRM  ŌUL  PARNM  COMSARM  COLMSARNM  OŌSAM  SASŌAM  PARM  LOL  ROL  PARRM  NUR

`f76r.34`  cheor.shey.qoolkal,shedy.shedy.shey.shedy.ollchy.shlches.shcthy.sain.oly
→ SAROR  PARM  COOLŌULPARNM  PARNM  PARM  PARNM  OLLSAM  PALSARP  PASTAM  PUI?  OLM

`f76r.35`  sain.shedy.lshey.qokal.chcthy.okeolor.cheol.otar.chedy.qol.chcthy.chckhy
→ PUI?  PARNM  LPARM  COŌUL  SASTAM  OŌROLOR  SAROL  OTUR  SARNM  COL  SASTAM  SASŌAM

`f76r.36`  qok[a:o]l.shedy.sheol.cheol.alshy.chol,chdy.talor.ol,alor.chol.okeor,ar,o.oly
→ COŌUL  PARNM  PAROL  SAROL  ULPAM  SAOLSANM  TULOR  OLULOR  SAOL  OŌRORURO  OLM

`f76r.37`  s
→ P

`f76r.38`  oteey.lchey.chey.olsheol.qokal.chal
→ OTRRM  LSARM  SARM  OLPAROL  COŌUL  SAUL

`f76r.39`  polalchdy.pshedy.opchedy.qokas.yksheol.qokeedy.oty,lshed.chpsheedy.ytal
→ MOLULSANM  MPARNM  OMSARNM  COŌUP  MŌPAROL  COŌRRNM  OTMLPARN  SAMPARRNM  MTUL

`f76r.40`  qolchey.shckhy.qokey.lchy.opchey.dain.shdy.qokedar.olchdy.sor.oty.dy.lchedy
→ COLSARM  PASŌAM  COŌRM  LSAM  OMSARM  NUI?  PANM  COŌRNUR  OLSANM  POR  OTM  NM  LSARNM

`f76r.41`  sain.ar.okedy.lcheey.qokey.shckhy.otedy.qokal.shey,qoky.dain.chedy.qokchd[y:a]l
→ PUI?  UR  OŌRNM  LSARRM  COŌRM  PASŌAM  OTRNM  COŌUL  PARMCOŌM  NUI?  SARNM  COŌSANML

`f76r.42`  dain.chey.lsh.daiin.chey.lchedy.qol[a:o]in.qotal.shedy.dy.shecthy.otalam
→ NUI?  SARM  LPA  NUII?  SARM  LSARNM  COLUI?  COTUL  PARNM  NM  PARSTAM  OTULUS

`f76r.43`  sor.shey.qokey.qokar.sheeoldy.chol.oly.chaly.lol.chdy
→ POR  PARM  COŌRM  COŌUR  PARROLNM  SAOL  OLM  SAULM  LOL  SANM

`f76r.44`  poleedaran.shckhy.qoty.ykar.alol.lkaiin.ol,shedy.otain.okar.opar.kolpy
→ MOLRRNURU?  PASŌAM  COTM  MŌUR  ULOL  LŌUII?  OLPARNM  OTUI?  OŌUR  OMUR  ŌOLMM

`f76r.45`  y,shedy.qo.or.okain.shey.qokaiin.okeedy.qochy.as.[o:a]in.sheey.chckhy
→ MPARNM  CO  OR  OŌUI?  PARM  COŌUII?  OŌRRNM  COSAM  UP  OI?  PARRM  SASŌAM

`f76r.46`  dain.shear.okedy.otedy.okedy.lchedy.chedy.okar.chedy.otarain
→ NUI?  PARUR  OŌRNM  OTRNM  OŌRNM  LSARNM  SARNM  OŌUR  SARNM  OTURUI?

`f76r.47`  dain.chckhy.[o:a]r,aiin.sheey.qockhey.olchdar.sheey.otedy.olain.oky
→ NUI?  SASŌAM  ORUII?  PARRM  COSŌARM  OLSANUR  PARRM  OTRNM  OLUI?  OŌM

`f76r.48`  saiin.shckhy.lkeedy.qoky.okain.ytain.oteedy.okedor.shedy.qokal
→ PUII?  PASŌAM  LŌRRNM  COŌM  OŌUI?  MTUI?  OTRRNM  OŌRNOR  PARNM  COŌUL

`f76r.49`  saiin.olaiin.oky.shol.sain.oky.l,kar.chedy.lkar.al.loral
→ PUII?  OLUII?  OŌM  PAOL  PUI?  OŌM  LŌUR  SARNM  LŌUR  UL  LORUL

`f76r.50`  [p:f]chedy.@174;.sal.dol.shdy.olkedy.qokaiin.otal.rory
→ MSARNM  —  PUL  NOL  PANM  OLŌRNM  COŌUII?  OTUL  RORM

`f76r.51`  qkor.shedy.shey.keedy.sal.raiin.opchdy.dar,chedy.qopchedy.ro[r:s]ol
→ CŌOR  PARNM  PARM  ŌRRNM  PUL  RUII?  OMSANM  NURSARNM  COMSARNM  ROROL

`f76r.52`  olsheed.qokedy.qokeedy.qokedy.lkedy.lsheedy.okar.shedy.otain
→ OLPARRN  COŌRNM  COŌRRNM  COŌRNM  LŌRNM  LPARRNM  OŌUR  PARNM  OTUI?

`f76r.53`  saiin.qol.shedy.ol.chedor.chal.shed.qoteedy.dshdy.okal.chedyl
→ PUII?  COL  PARNM  OL  SARNOR  SAUL  PARN  COTRRNM  NPANM  OŌUL  SARNML

`f76r.54`  dal,or,chedy.qolaiin.okedal.olchedy.chdol.olchedy.choly.aiin,y
→ NULORSARNM  COLUII?  OŌRNUL  OLSARNM  SANOL  OLSARNM  SAOLM  UII?M

`f76r.55`  sain.sheey.or.ar.al.solshey.okeedy.ldaiin.checkhey.okedalor
→ PUI?  PARRM  OR  UR  UL  POLPARM  OŌRRNM  LNUII?  SARSŌARM  OŌRNULOR

`f76r.56`  qokaiin.ol.shedy.qokeey.or.shdy
→ COŌUII?  OL  PARNM  COŌRRM  OR  PANM

### f76v  ·  balneological

`f76v.1`  polarar.okor.opcheey.yteey.opchaly.lshedy.qofchdal.lkodol<->opa,korols
→ MOLURUR  OŌOR  OMSARRM  MTRRM  OMSAULM  LPARNM  CO?SANUL  LŌONOLOMUŌOROLP

`f76v.2`  sshedy.keedy.cholkeeey.otedor.okor.shedy.chedy.qokeedy.oly<->shey.qoyky
→ PPARNM  ŌRRNM  SAOLŌRRRM  OTRNOR  OŌOR  PARNM  SARNM  COŌRRNM  OLMPARM  COMŌM

`f76v.3`  dchedy.qokeedy.oteedy.chedaiin.chey.qokeedy.olkedy.ror<->oteedy.okal
→ NSARNM  COŌRRNM  OTRRNM  SARNUII?  SARM  COŌRRNM  OLŌRNM  ROROTRRNM  OŌUL

`f76v.4`  salkeey.sor.shecthy.daiin.okor.chpchedy.{cp}chy.oty.olor<->otchy.r,alchl
→ PULŌRRM  POR  PARSTAM  NUII?  OŌOR  SAMSARNM  SMSAM  OTM  OLOROTSAM  RULSAL

`f76v.5`  s.otain.okain.chcthedy.qoteed.y.kedy.okedy.chedy<->otedy.teyteg
→ P  OTUI?  OŌUI?  SASTARNM  COTRRN  M  ŌRNM  OŌRNM  SARNMOTRNM  TRMTR?

`f76v.6`  qotees.olkeey.okeedy.qoeeedy.chckhey.sheor.aiin.otar<->cheedy.lchedy
→ COTRRP  OLŌRRM  OŌRRNM  CORRRNM  SASŌARM  PAROR  UII?  OTURSARRNM  LSARNM

`f76v.7`  doteey.qo.okaiin.oteedy.otedy.cheolchdy.okeedy.otedy.qokedy.okedar.da
→ NOTRRM  CO  OŌUII?  OTRRNM  OTRNM  SAROLSANM  OŌRRNM  OTRNM  COŌRNM  OŌRNUR  NU

`f76v.8`  qokeedy.ochedy.roiin.sheedy.qokeedy.okeedy.olor.okeedy.qolkchey.r,[o:a]l
→ COŌRRNM  OSARNM  ROII?  PARRNM  COŌRRNM  OŌRRNM  OLOR  OŌRRNM  COLŌSARM  ROL

`f76v.9`  sheor.chey.ral.cheey.r.al.cheedy
→ PAROR  SARM  RUL  SARRM  R  UL  SARRNM

`f76v.10`  cphdor.shedal.qopchdy.dshedy.shedy.tchedy.lsheetal.shecphy.daiin.dy
→ SMANOR  PARNUL  COMSANM  NPARNM  PARNM  TSARNM  LPARRTUL  PARSMAM  NUII?  NM

`f76v.11`  cheor.sheedy.daiin.oekeedy.qokeey.qokedy.oteedy.shedy.qokedy.shedam
→ SAROR  PARRNM  NUII?  ORŌRRNM  COŌRRM  COŌRNM  OTRRNM  PARNM  COŌRNM  PARNUS

`f76v.12`  solsheol.sheey.lteedy.qokeedy.qotal.chedy.checthy.otedeey.qokol.chedy.deey
→ POLPAROL  PARRM  LTRRNM  COŌRRNM  COTUL  SARNM  SARSTAM  OTRNRRM  COŌOL  SARNM  NRRM

`f76v.13`  saiin.sheedy.qol.sheedy.okeeedy.qoteedy.chedy.qotedy.oleeedy.qoteedy.lo
→ PUII?  PARRNM  COL  PARRNM  OŌRRRNM  COTRRNM  SARNM  COTRNM  OLRRRNM  COTRRNM  LO

`f76v.14`  qokeedy.qol.cheedy.otedy.cthedy.otedy.qoteedy.shcthedy.qoeekeedy.deedy
→ COŌRRNM  COL  SARRNM  OTRNM  STARNM  OTRNM  COTRRNM  PASTARNM  CORRŌRRNM  NRRNM

`f76v.15`  tchedy.lsheedy.chedal.chedy.checthey
→ TSARNM  LPARRNM  SARNUL  SARNM  SARSTARM

`f76v.16`  polshdal.otedair.opshedal.qokedy.shedy.fschedal.tsheokeedy.oshepols
→ MOLPANUL  OTRNUIR  OMPARNUL  COŌRNM  PARNM  ?PSARNUL  TPAROŌRRNM  OPARMOLP

`f76v.17`  sar.olkeey.shokaiin.sheolol.otedy.qekchdy.qoeeedy.qokedy.lkedy.chdy
→ PUR  OLŌRRM  PAOŌUII?  PAROLOL  OTRNM  CRŌSANM  CORRRNM  COŌRNM  LŌRNM  SANM

`f76v.18`  lshey.qockhedy.qodeey.qolkeedy.qokedy.chol.chedchey.daiin.olkedy
→ LPARM  COSŌARNM  CONRRM  COLŌRRNM  COŌRNM  SAOL  SARNSARM  NUII?  OLŌRNM

`f76v.19`  or,as.sheey.otar.shedy.otchedy.checkhey.olchedy.checkhy.checkhy.lky
→ ORUP  PARRM  OTUR  PARNM  OTSARNM  SARSŌARM  OLSARNM  SARSŌAM  SARSŌAM  LŌM

`f76v.20`  dol.sheetey.qokedy.ol.checkhy.lshedy.qokeedy.cheedy.qokeedy.shl.loiii@175;
→ NOL  PARRTRM  COŌRNM  OL  SARSŌAM  LPARNM  COŌRRNM  SARRNM  COŌRRNM  PAL  LOIII

`f76v.21`  cthedy.oteol.chdar.chckhy.chees.s[a:o]lkchdy.chey.lcheedy.lchedy.qoteedy
→ STARNM  OTROL  SANUR  SASŌAM  SARRP  PULŌSANM  SARM  LSARRNM  LSARNM  COTRRNM

`f76v.22`  sol,shey.qotedy.chey.dytey.teedy.lchey.qokedy.chedy.lal,chedy.lchedy
→ POLPARM  COTRNM  SARM  NMTRM  TRRNM  LSARM  COŌRNM  SARNM  LULSARNM  LSARNM

`f76v.23`  dchedy.qokeedy.qotchy.qokol.shedy.shedy.chedy.olched[?:r].shetey.saiin
→ NSARNM  COŌRRNM  COTSAM  COŌOL  PARNM  PARNM  SARNM  OLSARN  PARTRM  PUII?

`f76v.24`  qokeey.lsheey.dal.lchedy.olshey
→ COŌRRM  LPARRM  NUL  LSARNM  OLPARM

`f76v.25`  psheoldy.opalshedy.qokshedy.qokedy.dor.shey.opchedy.dal.so,fcham
→ MPAROLNM  OMULPARNM  COŌPARNM  COŌRNM  NOR  PARM  OMSARNM  NUL  PO?SAUS

`f76v.26`  dshol.qokaiin.ches.daiin.checkhy.oteoldy.qokeey.chckhy.lar,aly
→ NPAOL  COŌUII?  SARP  NUII?  SARSŌAM  OTROLNM  COŌRRM  SASŌAM  LURULM

`f76v.27`  daiin.shckhey.qokeedy.saiin.chek.ain.r.ain.o.kan.chl[a:o]iiin
→ NUII?  PASŌARM  COŌRRNM  PUII?  SARŌ  UI?  R  UI?  O  ŌU?  SALUIII?

`f76v.28`  saiin.sheckhy.cheolchey.qokedy.sair.sheckhy.l,keedy.lchedy
→ PUII?  PARSŌAM  SAROLSARM  COŌRNM  PUIR  PARSŌAM  LŌRRNM  LSARNM

`f76v.29`  sar.sheedy.qokeedy.qolkey.lchdy.schees.shees.al,ches.okaiin.alaldy
→ PUR  PARRNM  COŌRRNM  COLŌRM  LSANM  PSARRP  PARRP  ULSARP  OŌUII?  ULULNM

`f76v.30`  tchedy.lshees,aiin.chees.tchy.rshed.chkaiin.sheky.shtal,cheedy.lsan
→ TSARNM  LPARRPUII?  SARRP  TSAM  RPARN  SAŌUII?  PARŌM  PATULSARRNM  LPU?

`f76v.31`  sair.shekaiiin.shets.aiiin.shety.otey.okaiin.otedy.qotar.chedy
→ PUIR  PARŌUIII?  PARTP  UIII?  PARTM  OTRM  OŌUII?  OTRNM  COTUR  SARNM

`f76v.32`  tain.sheey.qotain.chedy.qokaiin.chedy.taiin.chckhedy.otol.oty
→ TUI?  PARRM  COTUI?  SARNM  COŌUII?  SARNM  TUII?  SASŌARNM  OTOL  OTM

`f76v.33`  saiin.otaiin.shckhedy
→ PUII?  OTUII?  PASŌARNM

`f76v.34`  sakaiin.okeedy.chedy.qotain.cphey.opcheey.oty,saiin.otary
→ PUŌUII?  OŌRRNM  SARNM  COTUI?  SMARM  OMSARRM  OTMPUII?  OTURM

`f76v.35`  ychees.alchedy.qokeedy.lshedy.tolchedy.lchedy.qoky.saiin.olor
→ MSARRP  ULSARNM  COŌRRNM  LPARNM  TOLSARNM  LSARNM  COŌM  PUII?  OLOR

`f76v.36`  daiin.cheol.teey.lshety.okeey.qeedy
→ NUII?  SAROL  TRRM  LPARTM  OŌRRM  CRRNM

`f76v.37`  qoeedy.lchedy.chees.ol,oiiin.chchky.shekeey.qokey.qoky.saiin,sy
→ CORRNM  LSARNM  SARRP  OLOIII?  SASAŌM  PARŌRRM  COŌRM  COŌM  PUII?PM

`f76v.38`  saiin.chedy,shedy.qokeedy.lol,saiiin.qokain.chey.r.al.r.aiin.dl
→ PUII?  SARNMPARNM  COŌRRNM  LOLPUIII?  COŌUI?  SARM  R  UL  R  UII?  NL

`f76v.39`  sshey.lshedy.qokaiin.shedy.okedy.san,ol,keedy.sor.qoky,dedy
→ PPARM  LPARNM  COŌUII?  PARNM  OŌRNM  PU?OLŌRRNM  POR  COŌMNRNM

`f76v.40`  sol,shedy.qoky.daiin.shedy.chey.qokaiin.cheedy.qo.char,aiin
→ POLPARNM  COŌM  NUII?  PARNM  SARM  COŌUII?  SARRNM  CO  SAURUII?

`f76v.41`  sol.shey.chedy.qokedy.chedy.qol.r.aiin.shedy
→ POL  PARM  SARNM  COŌRNM  SARNM  COL  R  UII?  PARNM

### f77r  ·  balneological

`f77r.1`  darchdar
→ NURSANUR

`f77r.2`  olkchs
→ OLŌSAP

`f77r.3`  otedy
→ OTRNM

`f77r.4`  otork
→ OTORŌ

`f77r.5`  otol
→ OTOL

`f77r.6`  dchdy
→ NSANM

`f77r.7`  soral
→ PORUL

`f77r.8`  dotedy
→ NOTRNM

`f77r.9`  poldarais,ol.qokol.chey.qopchedy.qopchedy.dylches.olkedy.loly
→ MOLNURUIPOL  COŌOL  SARM  COMSARNM  COMSARNM  NMLSARP  OLŌRNM  LOLM

`f77r.10`  tolchd,ar.shey.qotaiin.qotedy.qokol.chdy.qokain.chetey.sal
→ TOLSANUR  PARM  COTUII?  COTRNM  COŌOL  SANM  COŌUI?  SARTRM  PUL

`f77r.11`  qoteedy.qokaiin.shedy.chol.shedy.shcthey.qokeedy.oteedy.cham
→ COTRRNM  COŌUII?  PARNM  SAOL  PARNM  PASTARM  COŌRRNM  OTRRNM  SAUS

`f77r.12`  solteedy.qoteedy.qodeedy.chedaiin.chedy.shedaiin.she[a:o]lol.ched
→ POLTRRNM  COTRRNM  CONRRNM  SARNUII?  SARNM  PARNUII?  PARULOL  SARN

`f77r.13`  qokeedy.qol,sheedy.shol.tedy.chedy.lsheedy.qokedy.qolal.chedy
→ COŌRRNM  COLPARRNM  PAOL  TRNM  SARNM  LPARRNM  COŌRNM  COLUL  SARNM

`f77r.14`  sokcheey.sain.sheeol.qoteedy.qokaiin.shedy.qokeedy.qotedy
→ POŌSARRM  PUI?  PARROL  COTRRNM  COŌUII?  PARNM  COŌRRNM  COTRNM

`f77r.15`  qokeedy.shedy.qotol.shedy.qokaiin.sheety.qokeed,y.lchedy,lol
→ COŌRRNM  PARNM  COTOL  PARNM  COŌUII?  PARRTM  COŌRRNM  LSARNMLOL

`f77r.16`  sshedy.qotaiin.chedy.qokaiin.shedy.qolcheedy.qokeedy.lol
→ PPARNM  COTUII?  SARNM  COŌUII?  PARNM  COLSARRNM  COŌRRNM  LOL

`f77r.17`  qoteedy.qoteedy.qokedy.sheed.qeey.saiin.sheety.qokeedy,lol
→ COTRRNM  COTRRNM  COŌRNM  PARRN  CRRM  PUII?  PARRTM  COŌRRNMLOL

`f77r.18`  daiin.cheedy.lshey.qo,l,or.chees.sheckhedy.qol.cheedy.qotaiin
→ NUII?  SARRNM  LPARM  COLOR  SARRP  PARSŌARNM  COL  SARRNM  COTUII?

`f77r.19`  qokeedy.lchey.lsheey.qokeedy.qokeedy.qokar.qokeey.laiin.chey
→ COŌRRNM  LSARM  LPARRM  COŌRRNM  COŌRRNM  COŌUR  COŌRRM  LUII?  SARM

`f77r.20`  qotain.sheal.qokeedy.qoteey.qokain.sheey.qotedy.dalchedy
→ COTUI?  PARUL  COŌRRNM  COTRRM  COŌUI?  PARRM  COTRNM  NULSARNM

`f77r.21`  chedaiin.shedy.qokeedy.qokedy.qokeey.chedy.shear.olaiiny
→ SARNUII?  PARNM  COŌRRNM  COŌRNM  COŌRRM  SARNM  PARUR  OLUII?M

`f77r.22`  qoteedy.al.lchedy.r.oin.chy.chedaiin.cheey.okedy.qoky
→ COTRRNM  UL  LSARNM  R  OI?  SAM  SARNUII?  SARRM  OŌRNM  COŌM

`f77r.23`  sheoky.qokaiin.chedy.lchedy.olshedy.qokeedy.chedy.qok[a:o]l
→ PAROŌM  COŌUII?  SARNM  LSARNM  OLPARNM  COŌRRNM  SARNM  COŌUL

`f77r.24`  daiin.dol,shor.cphey.lfcheal.shear.qolchy
→ NUII?  NOLPAOR  SMARM  L?SARUL  PARUR  COLSAM

`f77r.25`  otedy.qokar,shedy.qokal.shedar.dal,chedy.daror
→ OTRNM  COŌURPARNM  COŌUL  PARNUR  NULSARNM  NUROR

`f77r.26`  qoteedy.qokeedy.qokaiin.chcthy.lchedy.qokaly
→ COTRRNM  COŌRRNM  COŌUII?  SASTAM  LSARNM  COŌULM

`f77r.27`  solchedy.qokain.okaiin.shedy.qokeedy.qotedy
→ POLSARNM  COŌUI?  OŌUII?  PARNM  COŌRRNM  COTRNM

`f77r.28`  olchey.qotey.qokain.olcheedy.sar.lom
→ OLSARM  COTRM  COŌUI?  OLSARRNM  PUR  LOS

`f77r.29`  saiin.cheeol.qokeedy.qokeedy.qotal
→ PUII?  SARROL  COŌRRNM  COŌRRNM  COTUL

`f77r.30`  qokaiin.chckhey.sa,iin.qolkain.cheeky.lol
→ COŌUII?  SASŌARM  PUII?  COLŌUI?  SARRŌM  LOL

`f77r.31`  qokain.chckhy.qokeey.qotedy.qotedy.qotary
→ COŌUI?  SASŌAM  COŌRRM  COTRNM  COTRNM  COTURM

`f77r.32`  qor.ain.cheol.ol.chealor.cheey.qet[eiiin:aiin].d[a:y]ry
→ COR  UI?  SAROL  OL  SARULOR  SARRM  CRTRIII?  NURM

`f77r.33`  daiin.chedy.qol,keedy.qoteeedy.sar.oiiiin.cheety.dy
→ NUII?  SARNM  COLŌRRNM  COTRRRNM  PUR  OIIII?  SARRTM  NM

`f77r.34`  qokaiin.shedy.chedy.qolchedy.qokaiin.qokaiin.checkhy.raiin
→ COŌUII?  PARNM  SARNM  COLSARNM  COŌUII?  COŌUII?  SARSŌAM  RUII?

`f77r.35`  solkeey.okaiin.chedy.qokain.sheedy.qokaiin.chedaiin.chealy
→ POLŌRRM  OŌUII?  SARNM  COŌUI?  PARRNM  COŌUII?  SARNUII?  SARULM

`f77r.36`  dshedy.pchedy.qotain.chedy.d[o:a]lchl.qokeedy.qokol,olchey
→ NPARNM  MSARNM  COTUI?  SARNM  NOLSAL  COŌRRNM  COŌOLOLSARM

`f77r.37`  teeolain.chey.qoteedy.qokain.cheedy.cheey.lchedy
→ TRROLUI?  SARM  COTRRNM  COŌUI?  SARRNM  SARRM  LSARNM

`f77r.38`  pol.shedy.qoeedy.qokaiin.chcphey.qol.ltaiin.shedy.qol
→ MOL  PARNM  CORRNM  COŌUII?  SASMARM  COL  LTUII?  PARNM  COL

`f77r.39`  olaiin.cheey.sheckhey.lsheey.qykaiin.sheedy.laiin
→ OLUII?  SARRM  PARSŌARM  LPARRM  CMŌUII?  PARRNM  LUII?

`f77r.40`  daiiin.ol,eeedy.okaiin.sheeol.qotaiin.shody.qoty
→ NUIII?  OLRRRNM  OŌUII?  PARROL  COTUII?  PAONM  COTM

`f77r.41`  daiin,sh.qolchey.qotedy.qotal.r,ain.chl.s.arol
→ NUII?PA  COLSARM  COTRNM  COTUL  RUI?  SAL  P  UROL

`f77r.42`  qokeedy.qotedy.qokeedy.qokeedy.qokeey.[s:r],aiin.al
→ COŌRRNM  COTRNM  COŌRRNM  COŌRRNM  COŌRRM  PUII?  UL

`f77r.43`  d,chee,ol.cheedy.qotaiin.qoteedy.qotedy.raiin
→ NSARROL  SARRNM  COTUII?  COTRRNM  COTRNM  RUII?

`f77r.44`  sheey.qepchedy.qol.cheedy.qokear.cheey.loly.dy
→ PARRM  CRMSARNM  COL  SARRNM  COŌRUR  SARRM  LOLM  NM

`f77r.45`  qokaiin.ches.lchear.dal.chr.sl,s,ain.ol.raiin.lod
→ COŌUII?  SARP  LSARUR  NUL  SAR  PLPUI?  OL  RUII?  LON

`f77r.46`  daiin.chlchpsheey.tal.cheol.dag.as,otey.daiin
→ NUII?  SALSAMPARRM  TUL  SAROL  NU?  UPOTRM  NUII?

`f77r.47`  ysheey.dal.saiis[o:a]l.sal.dalo.tain.dary.dalo
→ MPARRM  NUL  PUIIPOL  PUL  NULO  TUI?  NURM  NULO

`f77r.48`  sodar.oloky
→ PONUR  OLOŌM

`f77r.49`  otchdy
→ OTSANM

`f77r.50`  otolaiin,o
→ OTOLUII?O

### f77v  ·  balneological

`f77v.1`  okain.y,kal
→ OŌUI?  MŌUL

`f77v.2`  otol.shedy
→ OTOL  PARNM

`f77v.3`  olkeedal
→ OLŌRRNUL

`f77v.4`  otolor
→ OTOLOR

`f77v.5`  [o:a]rchedal
→ ORSARNUL

`f77v.6`  qetedy.shedy.qotol.odal.chal.dar.qopshedy.qotedy.qotedy.qokedy.dal
→ CRTRNM  PARNM  COTOL  ONUL  SAUL  NUR  COMPARNM  COTRNM  COTRNM  COŌRNM  NUL

`f77v.7`  olshedy.qolsheedy.qy,r{oh}r.ycheedy.okedy.lshedy.chs.shdal.chedy.qolky
→ OLPARNM  COLPARRNM  CMROAR  MSARRNM  OŌRNM  LPARNM  SAP  PANUL  SARNM  COLŌM

`f77v.8`  qokeeey.shedy.qokeedy.qodykey.qokedy.rsheedy.taiiin.sheol.teedy.yry
→ COŌRRRM  PARNM  COŌRRNM  CONMŌRM  COŌRNM  RPARRNM  TUIII?  PAROL  TRRNM  MRM

`f77v.9`  dcheol.kshey.qolchshy.cheol.olchedy.ol.chs.ol,sheedy.qokedy.chedy
→ NSAROL  ŌPARM  COLSAPAM  SAROL  OLSARNM  OL  SAP  OLPARRNM  COŌRNM  SARNM

`f77v.10`  tchedar.alain.checkhy.sal.shedy.qokal.chedy.qokedy.qol.shedy.lol
→ TSARNUR  ULUI?  SARSŌAM  PUL  PARNM  COŌUL  SARNM  COŌRNM  COL  PARNM  LOL

`f77v.11`  qockhy.dol,chdy.dsheedal.qokal.chedy.dal,shedy.qokeedy.dal.olchy
→ COSŌAM  NOLSANM  NPARRNUL  COŌUL  SARNM  NULPARNM  COŌRRNM  NUL  OLSAM

`f77v.12`  lchedy.shedal.qokedy.okal.chedy.qokal.shedy.chedy.qol.chdy.lam
→ LSARNM  PARNUL  COŌRNM  OŌUL  SARNM  COŌUL  PARNM  SARNM  COL  SANM  LUS

`f77v.13`  sor.sheol.chdy.qokeedy.dar.shedy.chedy.qokal.chedy.qokey.lshedy.dal
→ POR  PAROL  SANM  COŌRRNM  NUR  PARNM  SARNM  COŌUL  SARNM  COŌRM  LPARNM  NUL

`f77v.14`  darcheedal.qeedy.qeedeey.olchey.lchey.qedy.or,cheey.qol.rar.ar
→ NURSARRNUL  CRRNM  CRRNRRM  OLSARM  LSARM  CRNM  ORSARRM  COL  RUR  UR

`f77v.15`  qol,kaiin.shey
→ COLŌUII?  PARM

`f77v.16`  tedal.daiin.okaiin.shedy.qokedy.qokain.otedy.dasy
→ TRNUL  NUII?  OŌUII?  PARNM  COŌRNM  COŌUI?  OTRNM  NUPM

`f77v.17`  olchedy.qol,shedy.qokchedy.qokeey.daiin.olol
→ OLSARNM  COLPARNM  COŌSARNM  COŌRRM  NUII?  OLOL

`f77v.18`  qokaiin.sheol.ekedy.qokey.qokal.dal.daly
→ COŌUII?  PAROL  RŌRNM  COŌRM  COŌUL  NUL  NULM

`f77v.19`  qoraiin.shey.qokaiin.chal,aiiin.chedy.qol
→ CORUII?  PARM  COŌUII?  SAULUIII?  SARNM  COL

`f77v.20`  daiin.salchedy.qokedy.qokal.shed,keoly
→ NUII?  PULSARNM  COŌRNM  COŌUL  PARNŌROLM

`f77v.21`  qokal.salchedy.shey.fchor.qotas,olky.darory
→ COŌUL  PULSARNM  PARM  ?SAOR  COTUPOLŌM  NURORM

`f77v.22`  dalchey.qol.chedy.oqokain.olkaiin.chckhy.qokal.dar
→ NULSARM  COL  SARNM  OCOŌUI?  OLŌUII?  SASŌAM  COŌUL  NUR

`f77v.23`  qokal.chees.ol.shedy.doraiin.ol.qoky.ches.ol,dal
→ COŌUL  SARRP  OL  PARNM  NORUII?  OL  COŌM  SARP  OLNUL

`f77v.24`  daiin.sheekey.qokeedy.daiin.dail.qokedy.qokedy.[r:s]ol
→ NUII?  PARRŌRM  COŌRRNM  NUII?  NUIL  COŌRNM  COŌRNM  ROL

`f77v.25`  lchor.oiiin.shedy.qokaiin.saiin.dal.sheedy.qokeedy.[r:s]al
→ LSAOR  OIII?  PARNM  COŌUII?  PUII?  NUL  PARRNM  COŌRRNM  RUL

`f77v.26`  dairol.shedy.rchy.sheor.qokedy.qoky.chckhy.qokchy.ldol
→ NUIROL  PARNM  RSAM  PAROR  COŌRNM  COŌM  SASŌAM  COŌSAM  LNOL

`f77v.27`  tshedy.qokain.chedal.fchedy.cheky.sain.chedy.qokain.ol
→ TPARNM  COŌUI?  SARNUL  ?SARNM  SARŌM  PUI?  SARNM  COŌUI?  OL

`f77v.28`  ychedy.qokedy.qoked.ol,sheor.olchdy
→ MSARNM  COŌRNM  COŌRN  OLPAROR  OLSANM

`f77v.29`  tch[a:y]dchy.lshedy.daly.dal.dsheedy.pcheol.lfol.ol,cheedy.qoty
→ TSAUNSAM  LPARNM  NULM  NUL  NPARRNM  MSAROL  L?OL  OLSARRNM  COTM

`f77v.30`  shey.ol.sheey.qokedy.lchedy.qokaiin.dal.daiin.chedy
→ PARM  OL  PARRM  COŌRNM  LSARNM  COŌUII?  NUL  NUII?  SARNM

`f77v.31`  qoa[s:r].shedy.qokaiin.shcthy.qotedy.rchr.oltedy.lchy
→ COUP  PARNM  COŌUII?  PASTAM  COTRNM  RSAR  OLTRNM  LSAM

`f77v.32`  ycheey.qolshedy.qokalchedy.qokaiin.checkhy.qokal
→ MSARRM  COLPARNM  COŌULSARNM  COŌUII?  SARSŌAM  COŌUL

`f77v.33`  qokaiin.cheky.rar.chedy.qokal.dar.y.qotal.dal.rain
→ COŌUII?  SARŌM  RUR  SARNM  COŌUL  NUR  M  COTUL  NUL  RUI?

`f77v.34`  solkchedy.shar.ytal.dy.dychedy.lkchey.qokedy.rched
→ POLŌSARNM  PAUR  MTUL  NM  NMSARNM  LŌSARM  COŌRNM  RSARN

`f77v.35`  tcho[r:s],sheey.qokain.qokain.sheol.qokeedy.qokal.dary
→ TSAORPARRM  COŌUI?  COŌUI?  PAROL  COŌRRNM  COŌUL  NURM

`f77v.36`  qotchy.qokal.shedy.qokedy.lchedy.qokedy.qol.raiin.chey
→ COTSAM  COŌUL  PARNM  COŌRNM  LSARNM  COŌRNM  COL  RUII?  SARM

`f77v.37`  schedy.qotar.sarolsheedy.qokain.cheey.roiin.daiin.shey
→ PSARNM  COTUR  PUROLPARRNM  COŌUI?  SARRM  ROII?  NUII?  PARM

`f77v.38`  toldal.shedy.qokedy.qokain.dolcheedy.[r:s]olchedy.qokedy
→ TOLNUL  PARNM  COŌRNM  COŌUI?  NOLSARRNM  ROLSARNM  COŌRNM

`f77v.39`  dcheol.kchedy.so{ikh}ey.qokal.qokal.shedy.sholdy.qotal.dar
→ NSAROL  ŌSARNM  POIŌARM  COŌUL  COŌUL  PARNM  PAOLNM  COTUL  NUR

`f77v.40`  qokeey.rol.chdor.cheey.qokaiin.saiin.shedy.qokeedy.qokam
→ COŌRRM  ROL  SANOR  SARRM  COŌUII?  PUII?  PARNM  COŌRRNM  COŌUS

`f77v.41`  chedy.lchedy.lkaiin.dy.qokal.dar.chdain.ldchey.ol,raiin.oldy
→ SARNM  LSARNM  LŌUII?  NM  COŌUL  NUR  SANUI?  LNSARM  OLRUII?  OLNM

`f77v.42`  tcheey.qokeey.qokal.lchedy.cheolkaiin.okol
→ TSARRM  COŌRRM  COŌUL  LSARNM  SAROLŌUII?  OŌOL

`f77v.43`  saroral
→ PURORUL

`f77v.44`  okalo
→ OŌULO

`f77v.45`  o?eoedu
→ ORORN?

### f78r  ·  balneological

`f78r.1`  okchdldlo
→ OŌSANLNLO

`f78r.2`  okchdy
→ OŌSANM

`f78r.3`  tshedor.shedy.qopchedy.qokedy.dy,qokol.oky
→ TPARNOR  PARNM  COMSARNM  COŌRNM  NMCOŌOL  OŌM

`f78r.4`  qokeedy.qokedy.shedy.tchedy.otar.olkedy.dam
→ COŌRRNM  COŌRNM  PARNM  TSARNM  OTUR  OLŌRNM  NUS

`f78r.5`  qckhedy.cheky.dol.chedy.qokedy.qokain.olkedy
→ CSŌARNM  SARŌM  NOL  SARNM  COŌRNM  COŌUI?  OLŌRNM

`f78r.6`  yteedy.qotal.dol,shedy.qokedar.chcthey.otor.dor.or
→ MTRRNM  COTUL  NOLPARNM  COŌRNUR  SASTARM  OTOR  NOR  OR

`f78r.7`  qokal.otedy.qokedy.qokedy.dal.qokedy.qokedy.s,@176;am
→ COŌUL  OTRNM  COŌRNM  COŌRNM  NUL  COŌRNM  COŌRNM  PUS

`f78r.8`  dshedy.qokedy.okar.qokedy.shedy.ykedy.shedy.qoky
→ NPARNM  COŌRNM  OŌUR  COŌRNM  PARNM  MŌRNM  PARNM  COŌM

`f78r.9`  schedy.keedy.qokedy.chckhd.qokain.chedy.qotedy.dy
→ PSARNM  ŌRRNM  COŌRNM  SASŌAN  COŌUI?  SARNM  COTRNM  NM

`f78r.10`  dshedy.deedy.qokeedy.otedy.otal.tedy.otey.ol[o:a]iin
→ NPARNM  NRRNM  COŌRRNM  OTRNM  OTUL  TRNM  OTRM  OLOII?

`f78r.11`  qoky.okeedy.sheety.qoteedy.otey.shckhedy.sokol.or
→ COŌM  OŌRRNM  PARRTM  COTRRNM  OTRM  PASŌARNM  POŌOL  OR

`f78r.12`  dor.shekedy.qokol.kechdy.otedy.ol.tedy.chckhedy
→ NOR  PARŌRNM  COŌOL  ŌRSANM  OTRNM  OL  TRNM  SASŌARNM

`f78r.13`  qokedy.ol,kedy.qokain.okedy.kedy.tol,dy.qot[ee:ch]dy,dy
→ COŌRNM  OLŌRNM  COŌUI?  OŌRNM  ŌRNM  TOLNM  COTRRNMNM

`f78r.14`  sor.checkhy.or.chckhdy.dol.kedy.qokededy.qokan.ol
→ POR  SARSŌAM  OR  SASŌANM  NOL  ŌRNM  COŌRNRNM  COŌU?  OL

`f78r.15`  dchckhedy.qokchdy.qokedy.okedy.dal,or.okeed.olkain
→ NSASŌARNM  COŌSANM  COŌRNM  OŌRNM  NULOR  OŌRRN  OLŌUI?

`f78r.16`  qokol.oted.okain.ched.ar.alory
→ COŌOL  OTRN  OŌUI?  SARN  UR  ULORM

`f78r.17`  soiin.kar.kedy.pche'y.tchdoltdy
→ POII?  ŌUR  ŌRNM  MSARM  TSANOLTNM

`f78r.18`  o,l,chedy.qokain.dar.ar.okain
→ OLSARNM  COŌUI?  NUR  UR  OŌUI?

`f78r.19`  y.che[s:?].aiin.okeedy.qokain.chl
→ M  SARP  UII?  OŌRRNM  COŌUI?  SAL

`f78r.20`  sol,shedy.dalshdy.qokychdy
→ POLPARNM  NULPANM  COŌMSANM

`f78r.21`  lchedy.qokain.cheeky.lokedy
→ LSARNM  COŌUI?  SARRŌM  LOŌRNM

`f78r.22`  yched.qokain.daiin.chckhdy.lr
→ MSARN  COŌUI?  NUII?  SASŌANM  LR

`f78r.23`  sain.sheor.olkchdy.roiin.okeedy
→ PUI?  PAROR  OLŌSANM  ROII?  OŌRRNM

`f78r.24`  qokeedy.kedy.qokeey.qokedy.olol
→ COŌRRNM  ŌRNM  COŌRRM  COŌRNM  OLOL

`f78r.25`  sokeedy.keol.lorain.olkeey.raiin
→ POŌRRNM  ŌROL  LORUI?  OLŌRRM  RUII?

`f78r.26`  sol,shey.kary.or,shedy.qeedar.ain,anl
→ POLPARM  ŌURM  ORPARNM  CRRNUR  UI?U?L

`f78r.27`  daiin.chckhal.daiil,aldy
→ NUII?  SASŌAUL  NUIILULNM

`f78r.28`  @176;orain.ol.qokeedy.kchol.tchal,olkee.yfchey.ofchedy.taly
→ ORUI?  OL  COŌRRNM  ŌSAOL  TSAULOLŌRR  M?SARM  O?SARNM  TULM

`f78r.29`  ssheky.ol,kedy.chckhy.dain.oty.qokor.oky.dain.chy.ol
→ PPARŌM  OLŌRNM  SASŌAM  NUI?  OTM  COŌOR  OŌM  NUI?  SAM  OL

`f78r.30`  qokeedy.qokey.daiin.olkain.dal.chedy.ololdal.chcht[y:?].tedy
→ COŌRRNM  COŌRM  NUII?  OLŌUI?  NUL  SARNM  OLOLNUL  SASATM  TRNM

`f78r.31`  solkeedy.sheckhy.qokedy.otal,shedy.otar.olchedy.cthdy
→ POLŌRRNM  PARSŌAM  COŌRNM  OTULPARNM  OTUR  OLSARNM  STANM

`f78r.32`  qokedy.ckhdy.qokain.chedy.dalky.lkain.ykeedy.okaly.dy
→ COŌRNM  SŌANM  COŌUI?  SARNM  NULŌM  LŌUI?  MŌRRNM  OŌULM  NM

`f78r.33`  ytedy.daiin.ykedy.y,olsheey.qokeey.okal.ol,keedy.dyky
→ MTRNM  NUII?  MŌRNM  MOLPARRM  COŌRRM  OŌUL  OLŌRRNM  NMŌM

`f78r.34`  dshedy.qokeedy.qopchedy.qokaly.dar.okaiin.o,keeal.am
→ NPARNM  COŌRRNM  COMSARNM  COŌULM  NUR  OŌUII?  OŌRRUL  US

`f78r.35`  y.sain.checkhy.qokain.cheeky.daiin.daiin.y,tees.ol,y
→ M  PUI?  SARSŌAM  COŌUI?  SARRŌM  NUII?  NUII?  MTRRP  OLM

`f78r.36`  qotchedy.lchedy.lchedykedy.qol<->saiin.ckhain.or
→ COTSARNM  LSARNM  LSARNMŌRNM  COLPUII?  SŌAUI?  OR

`f78r.37`  osal.ol.s.aiin.shee'.aiin.oly
→ OPUL  OL  P  UII?  PARR  UII?  OLM

`f78r.38`  sar,aiin.oteedy.ol.aiin.chedy
→ PURUII?  OTRRNM  OL  UII?  SARNM

`f78r.39`  qotaiin.qokaiin.o[t:k]edy.l,keedy
→ COTUII?  COŌUII?  OTRNM  LŌRRNM

`f78r.40`  shedy.qol.shedy.qokaiin.d,@206;ol
→ PARNM  COL  PARNM  COŌUII?  NOL

`f78r.41`  ykain.chdar.chedy.qokain.dy
→ MŌUI?  SANUR  SARNM  COŌUI?  NM

`f78r.42`  dain.chfaiin.opaly.kotaly
→ NUI?  SA?UII?  OMULM  ŌOTULM

`f78r.43`  lchedy.pchedy.qokaiin.d[a:o]r
→ LSARNM  MSARNM  COŌUII?  NUR

`f78r.44`  dar,alo{ifh}y
→ NURULOI?AM

`f78r.45`  dchedaly
→ NSARNULM

`f78r.46`  otarodla'y<->orory
→ OTURONLUMORORM

`f78r.47`  okaral
→ OŌURUL

### f78v  ·  balneological

`f78v.1`  @177;ykedy.olfchedy.qokedy.spchy.chedy.rol.dor.ofchedy.qokedy
→ MŌRNM  OL?SARNM  COŌRNM  PMSAM  SARNM  ROL  NOR  O?SARNM  COŌRNM

`f78v.2`  olshedy.qokedy.rshedy.cthdy.otedy.kedy.dal,dal.dol.oty.dal
→ OLPARNM  COŌRNM  RPARNM  STANM  OTRNM  ŌRNM  NULNUL  NOL  OTM  NUL

`f78v.3`  qokedy.chety.qolshedy.okedy.dol,eesolchey.qotedy.ol,dam
→ COŌRNM  SARTM  COLPARNM  OŌRNM  NOLRRPOLSARM  COTRNM  OLNUS

`f78v.4`  ol,chy.lshdy.lcheckhy.ol.keedy.lcheckhey.l,olkedykain,ol
→ OLSAM  LPANM  LSARSŌAM  OL  ŌRRNM  LSARSŌARM  LOLŌRNMŌUI?OL

`f78v.5`  qor.olkeey.olkain.ol.chsey.ol.cheeky.dar.okal.dal.olchedy
→ COR  OLŌRRM  OLŌUI?  OL  SAPRM  OL  SARRŌM  NUR  OŌUL  NUL  OLSARNM

`f78v.6`  ety.okeey.or.{ch'}eey.ykeey.lchey.qokain.okedy.qokedy,qol
→ RTM  OŌRRM  OR  SARRM  MŌRRM  LSARM  COŌUI?  OŌRNM  COŌRNMCOL

`f78v.7`  otor.y,shedy.otedy.shedy.qokeedy.qokedy.otar.otedy
→ OTOR  MPARNM  OTRNM  PARNM  COŌRRNM  COŌRNM  OTUR  OTRNM

`f78v.8`  qokedy.otedy.qokain.oteedy.qokeedy.dar.okedy.dkedy.dain
→ COŌRNM  OTRNM  COŌUI?  OTRRNM  COŌRRNM  NUR  OŌRNM  NŌRNM  NUI?

`f78v.9`  y,cheolk,o,lkeedy.qokedy.ol,chedol.okeedy.qotedy.rorarol
→ MSAROLŌOLŌRRNM  COŌRNM  OLSARNOL  OŌRRNM  COTRNM  RORUROL

`f78v.10`  dshedy.qokedy.or,shedy.pchedy.qoke[@166;:ee]dy.okedy.opchedy
→ NPARNM  COŌRNM  ORPARNM  MSARNM  COŌRNM  OŌRNM  OMSARNM

`f78v.11`  qol.chedy.qol.okeey.ykal.ol.chdy.qokain.chcthy.daiin
→ COL  SARNM  COL  OŌRRM  MŌUL  OL  SANM  COŌUI?  SASTAM  NUII?

`f78v.12`  sheor.ol.qokaiin.shckhy.otaly.qolsheey.qokal,sain
→ PAROR  OL  COŌUII?  PASŌAM  OTULM  COLPARRM  COŌULPUI?

`f78v.13`  dchokol.chedy.qokedy.qokey.qol.chedy.qokeedy.lchey
→ NSAOŌOL  SARNM  COŌRNM  COŌRM  COL  SARNM  COŌRRNM  LSARM

`f78v.14`  qolkeshdy.qol.shedy.olkedy.okol,chedy.qokain.dal
→ COLŌRPANM  COL  PARNM  OLŌRNM  OŌOLSARNM  COŌUI?  NUL

`f78v.15`  cheey.qolchedy.qokey.or.cheef.chckhey.tedy.qokedy.ls
→ SARRM  COLSARNM  COŌRM  OR  SARR?  SASŌARM  TRNM  COŌRNM  LP

`f78v.16`  lshey.r,shedy.d,qokedy.okey.lchedy.qokdy.daiin.oly
→ LPARM  RPARNM  NCOŌRNM  OŌRM  LSARNM  COŌNM  NUII?  OLM

`f78v.17`  qol.sheedy.qol.lcheol.lchdy.dchdy.da.qar.olkal.dy
→ COL  PARRNM  COL  LSAROL  LSANM  NSANM  NU  CUR  OLŌUL  NM

`f78v.18`  chedy.shckhy.qokedy.dal.lshckhy.qol,qol.oteedy.qor
→ SARNM  PASŌAM  COŌRNM  NUL  LPASŌAM  COLCOL  OTRRNM  COR

`f78v.19`  lchedy.ol.chedar.shedy.lor.shedaldy.orain
→ LSARNM  OL  SARNUR  PARNM  LOR  PARNULNM  ORUI?

`f78v.20`  qofcheol.opchedy.qokain.op,chedy,lchey.cphar.ol.okalor
→ CO?SAROL  OMSARNM  COŌUI?  OMSARNMLSARM  SMAUR  OL  OŌULOR

`f78v.21`  chedy.lshedy.olshedy.otaiin.ol.qokar.shedy.yteedy
→ SARNM  LPARNM  OLPARNM  OTUII?  OL  COŌUR  PARNM  MTRRNM

`f78v.22`  [o:y]kol.shey.ol.shedy.okal.okchey.okeol.ol,chedy.qol
→ OŌOL  PARM  OL  PARNM  OŌUL  OŌSARM  OŌROL  OLSARNM  COL

`f78v.23`  qol.chedy.okeshy.qoteedy.okeedy.ol,shedy.qokedy,dy
→ COL  SARNM  OŌRPAM  COTRRNM  OŌRRNM  OLPARNM  COŌRNMNM

`f78v.24`  ytaiin.shedy.ol.sheedy.olshdy.shey.kshdy.shol.kedy
→ MTUII?  PARNM  OL  PARRNM  OLPANM  PARM  ŌPANM  PAOL  ŌRNM

`f78v.25`  teeol.olkeshey.qolcheol.ol.or.sheckhedy<->or.ol.sham
→ TRROL  OLŌRPARM  COLSAROL  OL  OR  PARSŌARNMOR  OL  PAUS

`f78v.26`  qokaiin.or.sheedy.otain.ol.shedy.sol.fchedy.otaldy
→ COŌUII?  OR  PARRNM  OTUI?  OL  PARNM  POL  ?SARNM  OTULNM

`f78v.27`  lol.kar.shr.r.ol.ols.sheey.ol.chedy.oltar.olkaiin
→ LOL  ŌUR  PAR  R  OL  OLP  PARRM  OL  SARNM  OLTUR  OLŌUII?

`f78v.28`  olkain.shey.qokey.okar.ol.oteedy.chcthy.los.aiin,d
→ OLŌUI?  PARM  COŌRM  OŌUR  OL  OTRRNM  SASTAM  LOP  UII?N

`f78v.29`  lchedy.otchey.qol.chedy.lr.al.s.aiiin.ol.shedy.ary
→ LSARNM  OTSARM  COL  SARNM  LR  UL  P  UIII?  OL  PARNM  URM

`f78v.30`  sal.shol.sain.sheety.or.oiiin.okal.oltal.qokar.ary
→ PUL  PAOL  PUI?  PARRTM  OR  OIII?  OŌUL  OLTUL  COŌUR  URM

`f78v.31`  sor,ar,or.dchor.otaiin.otain.ytedy.olshdy.sholkal
→ PORUROR  NSAOR  OTUII?  OTUI?  MTRNM  OLPANM  PAOLŌUL

`f78v.32`  lol.cheor.sheol.dy.qokar.otalor
→ LOL  SAROR  PAROL  NM  COŌUR  OTULOR

### f79r  ·  balneological

`f79r.1`  torain.shedy,pchor.or.shek.otarpchdy.opcholor.otal.shedy
→ TORUI?  PARNMMSAOR  OR  PARŌ  OTURMSANM  OMSAOLOR  OTUL  PARNM

`f79r.2`  qoteedy.lshdy.otchedy.olshey.olshee.qol,sheey.qoteey.loly
→ COTRRNM  LPANM  OTSARNM  OLPARM  OLPARR  COLPARRM  COTRRM  LOLM

`f79r.3`  yshealdy.rshedy.qoteedy.chckhey.qo,y.chey.lchey.qokeey.rchedy
→ MPARULNM  RPARNM  COTRRNM  SASŌARM  COM  SARM  LSARM  COŌRRM  RSARNM

`f79r.4`  teey.dar.qotar,sheds.sheekeey.qokeey.okey.qolshy.olchey.qoky.ol
→ TRRM  NUR  COTURPARNP  PARRŌRRM  COŌRRM  OŌRM  COLPAM  OLSARM  COŌM  OL

`f79r.5`  qokal.shedy.chcthy.or,chear.salchey.qol.shal.chey,l,cheol.chol,chy
→ COŌUL  PARNM  SASTAM  ORSARUR  PULSARM  COL  PAUL  SARMLSAROL  SAOLSAM

`f79r.6`  shol.okar.ol,olkeey.qokey.sain.olcheey.qol.chey
→ PAOL  OŌUR  OLOLŌRRM  COŌRM  PUI?  OLSARRM  COL  SARM

`f79r.7`  polchedy.qokar.shey.qokl.ol.cheey.qokain.chey.qoty.qokar
→ MOLSARNM  COŌUR  PARM  COŌL  OL  SARRM  COŌUI?  SARM  COTM  COŌUR

`f79r.8`  qokol.cheedy.qokal.shed.ykchedy.chcthy.yoky.qokal.cholo
→ COŌOL  SARRNM  COŌUL  PARN  MŌSARNM  SASTAM  MOŌM  COŌUL  SAOLO

`f79r.9`  saiin.shedy.psheedy.qokar.sheol.qolchey.qoty.qokal.qokam
→ PUII?  PARNM  MPARRNM  COŌUR  PAROL  COLSARM  COTM  COŌUL  COŌUS

`f79r.10`  qokshedy.qokain.cheor.okol.sheeol.qote{cr}y.choty.otechys
→ COŌPARNM  COŌUI?  SAROR  OŌOL  PARROL  COTRSRM  SAOTM  OTRSAMP

`f79r.11`  sho{ikh}y.chedy.tshey.dshdy.otch[a:?]r.shek.chcthy.otal.ory
→ PAOIŌAM  SARNM  TPARM  NPANM  OTSAUR  PARŌ  SASTAM  OTUL  ORM

`f79r.12`  qokchy.qotchey.ldain.shedy.qotaiin.sal
→ COŌSAM  COTSARM  LNUI?  PARNM  COTUII?  PUL

`f79r.13`  pshorol.shckhy.qotshdy.qokaldy.opchedy.qotar.or,aiin,ol
→ MPAOROL  PASŌAM  COTPANM  COŌULNM  OMSARNM  COTUR  ORUII?OL

`f79r.14`  saral.qokain.checkhy.qotal.qol.cheey.chey.dain.chedy,qol
→ PURUL  COŌUI?  SARSŌAM  COTUL  COL  SARRM  SARM  NUI?  SARNMCOL

`f79r.15`  qokl.shey.qokal.chedy.okol.dyty.r.aiin.ol.sheol.lchey
→ COŌL  PARM  COŌUL  SARNM  OŌOL  NMTM  R  UII?  OL  PAROL  LSARM

`f79r.16`  shain.shckhy.qoly.kshedy.otal.sheey.qokain.shey.qokam
→ PAUI?  PASŌAM  COLM  ŌPARNM  OTUL  PARRM  COŌUI?  PARM  COŌUS

`f79r.17`  qokaiin.shy.lsheey.ls,air.or.aror.otaiin.ches.olol.ol
→ COŌUII?  PAM  LPARRM  LPUIR  OR  UROR  OTUII?  SARP  OLOL  OL

`f79r.18`  solor.olshey.qokaiin.chey.qokain.otain.otain.otal,ol,dam
→ POLOR  OLPARM  COŌUII?  SARM  COŌUI?  OTUI?  OTUI?  OTULOLNUS

`f79r.19`  sol,cheey.chol.sain.oral.shey.qokain.sheyky.sho[t:k]y.oly
→ POLSARRM  SAOL  PUI?  ORUL  PARM  COŌUI?  PARMŌM  PAOTM  OLM

`f79r.20`  y.shal.y,chedar.o{ikh}y.scthey.tal.chear
→ M  PAUL  MSARNUR  OIŌAM  PSTARM  TUL  SARUR

`f79r.21`  pol.shar.sharpchey.otshey.okaos.aiin.okshey.dalkeeeyry
→ MOL  PAUR  PAURMSARM  OTPARM  OŌUOP  UII?  OŌPARM  NULŌRRRMRM

`f79r.22`  lchey.dal,sheedy.efchedy.otain.shey.qofchey.ol.dorchedchey
→ LSARM  NULPARRNM  R?SARNM  OTUI?  PARM  CO?SARM  OL  NORSARNSARM

`f79r.23`  da[s:r].shear.qotaiin.ol.lkain.otchedy.or.olkl.o.tshedy.otory
→ NUP  PARUR  COTUII?  OL  LŌUI?  OTSARNM  OR  OLŌL  O  TPARNM  OTORM

`f79r.24`  qokshedy.qolkeey.qolkeedy.qokedy.otain.otchey.okain.y
→ COŌPARNM  COLŌRRM  COLŌRRNM  COŌRNM  OTUI?  OTSARM  OŌUI?  M

`f79r.25`  cholchey.qotshy.qol,shey.qokar.shedy.oteey.chcthy
→ SAOLSARM  COTPAM  COLPARM  COŌUR  PARNM  OTRRM  SASTAM

`f79r.26`  polaiin.olteedy.qotchey.dykeedy.qokchdy.opchedy.shol.ory
→ MOLUII?  OLTRRNM  COTSARM  NMŌRRNM  COŌSANM  OMSARNM  PAOL  ORM

`f79r.27`  qokeedy.sheey.kas.cheey.olkaiin.ol.ory.cholor.oty.oky
→ COŌRRNM  PARRM  ŌUP  SARRM  OLŌUII?  OL  ORM  SAOLOR  OTM  OŌM

`f79r.28`  y.dolsheey.qokain.o,dain.yteey.chyteey.otoldy,lchey
→ M  NOLPARRM  COŌUI?  ONUI?  MTRRM  SAMTRRM  OTOLNMLSARM

`f79r.29`  lcheey.qochey.qody.qokal.olor.okchd.dchol.dchy.oly
→ LSARRM  COSARM  CONM  COŌUL  OLOR  OŌSAN  NSAOL  NSAM  OLM

`f79r.30`  y,shedy.qotal.ysheey.olor
→ MPARNM  COTUL  MPARRM  OLOR

`f79r.31`  polshey.oltshedy.sheol.ykeey.okeey.cheor,sheedy.ol
→ MOLPARM  OLTPARNM  PAROL  MŌRRM  OŌRRM  SARORPARRNM  OL

`f79r.32`  sol.cheedy.qoteedy.okaiin.ol,olaiin.shey.daiin.ch?[y:?].ol
→ POL  SARRNM  COTRRNM  OŌUII?  OLOLUII?  PARM  NUII?  SAM  OL

`f79r.33`  daiin.shedy.qotshedy.oteeedy.oteedy.chey.qoka[in:i?].ol
→ NUII?  PARNM  COTPARNM  OTRRRNM  OTRRNM  SARM  COŌUI?  OL

`f79r.34`  lcheol,kchedy.qotas.sheey.teol.oteedy
→ LSAROLŌSARNM  COTUP  PARRM  TROL  OTRRNM

`f79r.35`  polchedy.shedy.qoteedy.qotain.ody.chckhes.otal
→ MOLSARNM  PARNM  COTRRNM  COTUI?  ONM  SASŌARP  OTUL

`f79r.36`  sol.sheeol.ol.cheey.o[s:d].sheky.sheol.or.shear.oly
→ POL  PARROL  OL  SARRM  OP  PARŌM  PAROL  OR  PARUR  OLM

`f79r.37`  lcheol.ol.ol,sheey.olsheey.sholkeey.okchey.dain
→ LSAROL  OL  OLPARRM  OLPARRM  PAOLŌRRM  OŌSARM  NUI?

`f79r.38`  pol.olkeeey.sheol.qokeey
→ MOL  OLŌRRRM  PAROL  COŌRRM

`f79r.39`  polkeey.qokol.otshdy.olky.orkor.she{cphh}edy.olkal
→ MOLŌRRM  COŌOL  OTPANM  OLŌM  ORŌOR  PARSMAARNM  OLŌUL

`f79r.40`  y,shedy.qokched.oltchey.otchot[a:o]r.ol.okaiin.chckhy
→ MPARNM  COŌSARN  OLTSARM  OTSAOTUR  OL  OŌUII?  SASŌAM

`f79r.41`  qokain.shedy.qotain.oteedy.chkain.ol.ol.chedy.oly
→ COŌUI?  PARNM  COTUI?  OTRRNM  SAŌUI?  OL  OL  SARNM  OLM

`f79r.42`  sain.ok[a:?]io.chedy.lkchedy.aiin.okain.oly.cheedy
→ PUI?  OŌUIO  SARNM  LŌSARNM  UII?  OŌUI?  OLM  SARRNM

`f79r.43`  y,shey.qokain.cheol.qoky.daiin.chka[g:m].ar.cheedy.ldy
→ MPARM  COŌUI?  SAROL  COŌM  NUII?  SAŌU?  UR  SARRNM  LNM

`f79r.44`  ody.aran.okeey.dar,cheory
→ ONM  URU?  OŌRRM  NURSARORM

### f79v  ·  balneological

`f79v.1`  poldshedy.olkory.qotolol.otaldy.[y:o]tedol,or.olorol
→ MOLNPARNM  OLŌORM  COTOLOL  OTULNM  MTRNOLOR  OLOROL

`f79v.2`  qoteedy.qokchey.qoty.lshey.qokain.shey.qorchedy
→ COTRRNM  COŌSARM  COTM  LPARM  COŌUI?  PARM  CORSARNM

`f79v.3`  dolsheol.okchy.qokain.sheedy.qokshedy.qokeedy.otaram
→ NOLPAROL  OŌSAM  COŌUI?  PARRNM  COŌPARNM  COŌRRNM  OTURUS

`f79v.4`  qokeedy.qokeedy.qotain.sol.chedy.rchey.qoky.lchedy
→ COŌRRNM  COŌRRNM  COTUI?  POL  SARNM  RSARM  COŌM  LSARNM

`f79v.5`  qolkeedy.qokedy.qotal.saiin.ory.qokedy.oteedy.lcheam
→ COLŌRRNM  COŌRNM  COTUL  PUII?  ORM  COŌRNM  OTRRNM  LSARUS

`f79v.6`  ycheckhey.r.ain.chedy.qokain.chedy.ol,shedy.dar,ytam
→ MSARSŌARM  R  UI?  SARNM  COŌUI?  SARNM  OLPARNM  NURMTUS

`f79v.7`  qokshey.qokeedy.qol,kedy.qokeedy.qokain.solchedy
→ COŌPARM  COŌRRNM  COLŌRNM  COŌRRNM  COŌUI?  POLSARNM

`f79v.8`  ychedy.qotey.okedy.tedyol.sheedy.qokeey.qoteedy.lol
→ MSARNM  COTRM  OŌRNM  TRNMOL  PARRNM  COŌRRM  COTRRNM  LOL

`f79v.9`  sar.ol.sheey.qokeedy.qokechey.qol
→ PUR  OL  PARRM  COŌRRNM  COŌRSARM  COL

`f79v.10`  pchedy.lsheckhedy.qokeey.qokaiin.olky.opchedy,pchedy
→ MSARNM  LPARSŌARNM  COŌRRM  COŌUII?  OLŌM  OMSARNMMSARNM

`f79v.11`  olcheey.lchedy.qolkeedy.qokain.chckhy.otar.olkam
→ OLSARRM  LSARNM  COLŌRRNM  COŌUI?  SASŌAM  OTUR  OLŌUS

`f79v.12`  pshdy.ofchdy.qokedy.qoteedy.qokedy.qoltedy.qotedy.oky
→ MPANM  O?SANM  COŌRNM  COTRRNM  COŌRNM  COLTRNM  COTRNM  OŌM

`f79v.13`  dain.ar.olshey.dytain.qokain.checthy.okeedy.qokeedy.ror
→ NUI?  UR  OLPARM  NMTUI?  COŌUI?  SARSTAM  OŌRRNM  COŌRRNM  ROR

`f79v.14`  qokeey.qokedy.okeey.qokol.sheedy.qokeedy.rolchey.qokeedy
→ COŌRRM  COŌRNM  OŌRRM  COŌOL  PARRNM  COŌRRNM  ROLSARM  COŌRRNM

`f79v.15`  yteedy.qokeedy.qokain.olkeey.cheokain.dy,teey.qokain
→ MTRRNM  COŌRRNM  COŌUI?  OLŌRRM  SAROŌUI?  NMTRRM  COŌUI?

`f79v.16`  dol.sheey.qol.olkshey.qokeedy.olkeedy.qol.okaiin.oly
→ NOL  PARRM  COL  OLŌPARM  COŌRRNM  OLŌRRNM  COL  OŌUII?  OLM

`f79v.17`  qol.sheey.chol.ol.dar.qokaiin.cheekey.qoky.otain.oram
→ COL  PARRM  SAOL  OL  NUR  COŌUII?  SARRŌRM  COŌM  OTUI?  ORUS

`f79v.18`  qokain.sheey.qokeey.teey.oteey.lcheey.qokeey.olkeedy.rchey
→ COŌUI?  PARRM  COŌRRM  TRRM  OTRRM  LSARRM  COŌRRM  OLŌRRNM  RSARM

`f79v.19`  ykail,shy.qolar,shey.qokedy.qokedy.qokedy.dar.olkain.cham
→ MŌUILPAM  COLURPARM  COŌRNM  COŌRNM  COŌRNM  NUR  OLŌUI?  SAUS

`f79v.20`  dchedy.lchey.qety.shedy.okain,ykees,olkey.oty.shey.qoly
→ NSARNM  LSARM  CRTM  PARNM  OŌUI?MŌRRPOLŌRM  OTM  PARM  COLM

`f79v.21`  dshey.qokal.sheedy.sheky.orain.otshdy.dain.cther.aror
→ NPARM  COŌUL  PARRNM  PARŌM  ORUI?  OTPANM  NUI?  STARR  UROR

`f79v.22`  tshey.ykeey.r,ch,[?:k]ain.oroiiin
→ TPARM  MŌRRM  RSAUI?  OROIII?

`f79v.23`  tolkey.okar.ol.okaiin.otylor.qokol.okeedy.dalary
→ TOLŌRM  OŌUR  OL  OŌUII?  OTMLOR  COŌOL  OŌRRNM  NULURM

`f79v.24`  ycheear.o.oiin.oeedy.qotain.chedy.qokeey.oteey.qokeey,lol
→ MSARRUR  O  OII?  ORRNM  COTUI?  SARNM  COŌRRM  OTRRM  COŌRRMLOL

`f79v.25`  qokeey.ol.olshdy.qotain.oteedy.olkain.otshey.sain.ol
→ COŌRRM  OL  OLPANM  COTUI?  OTRRNM  OLŌUI?  OTPARM  PUI?  OL

`f79v.26`  ykeedy.okaiin.dykaiin.otedy.dkeey,tar.ol.otol.oiiiny
→ MŌRRNM  OŌUII?  NMŌUII?  OTRNM  NŌRRMTUR  OL  OTOL  OIII?M

`f79v.27`  odchey.kar.akain.opar.otain.olkey
→ ONSARM  ŌUR  UŌUI?  OMUR  OTUI?  OLŌRM

`f79v.28`  pchey.ksheol.qokain.ofchedy.otalshdy.olkair.otaiin.okeedy
→ MSARM  ŌPAROL  COŌUI?  O?SARNM  OTULPANM  OLŌUIR  OTUII?  OŌRRNM

`f79v.29`  dain.sheyteedy.lk[y:a].opchedy.qotedy.otey.tal.dain.oteey.oty
→ NUI?  PARMTRRNM  LŌM  OMSARNM  COTRNM  OTRM  TUL  NUI?  OTRRM  OTM

`f79v.30`  qokain.sheeky.okar,okey.qokey.tedy.skain.oteedy,qoky
→ COŌUI?  PARRŌM  OŌUROŌRM  COŌRM  TRNM  PŌUI?  OTRRNMCOŌM

`f79v.31`  yshees.aiin.o.ykeedy.qokeedy.qokar.oteedy.roltain
→ MPARRP  UII?  O  MŌRRNM  COŌRRNM  COŌUR  OTRRNM  ROLTUI?

`f79v.32`  olkeey.ol,or.ocheey.ol.ol,o,keeedy.checkhy.aror
→ OLŌRRM  OLOR  OSARRM  OL  OLOŌRRRNM  SARSŌAM  UROR

`f79v.33`  por,ar,or.yteey.teey.okar.oshey.qoky,chey.okeey.ldy.oral
→ MORUROR  MTRRM  TRRM  OŌUR  OPARM  COŌMSARM  OŌRRM  LNM  ORUL

`f79v.34`  ykeeey.qokeey.lshey.qoky,tchedy.orsheedy.otain.sheor.oly
→ MŌRRRM  COŌRRM  LPARM  COŌMTSARNM  ORPARRNM  OTUI?  PAROR  OLM

`f79v.35`  qor.cheey.kain.chl.ol.otol.dain.otain.ol.oteedy.qokan
→ COR  SARRM  ŌUI?  SAL  OL  OTOL  NUI?  OTUI?  OL  OTRRNM  COŌU?

`f79v.36`  ysheey.ol,shey.oltshsey.sheepshey
→ MPARRM  OLPARM  OLTPAPRM  PARRMPARM

`f79v.37`  pol.ol.shal,kain.okeey.lkeey.qokal.otchsdy.okeshdy
→ MOL  OL  PAULŌUI?  OŌRRM  LŌRRM  COŌUL  OTSAPNM  OŌRPANM

`f79v.38`  olkeeey.qokeey.okeedy.shedy.qokeey.okain.sheckhdy.dag
→ OLŌRRRM  COŌRRM  OŌRRNM  PARNM  COŌRRM  OŌUI?  PARSŌANM  NU?

`f79v.39`  qokeedy.ykeey.sheey.or.or.aiin.yefaiin.ch{cthh}y.dor.yty
→ COŌRRNM  MŌRRM  PARRM  OR  OR  UII?  MR?UII?  SASTAAM  NOR  MTM

`f79v.40`  qokees.aiin.okain.ol.oiin.qokoin.sheky.qokeedy.qokar.ol
→ COŌRRP  UII?  OŌUI?  OL  OII?  COŌOI?  PARŌM  COŌRRNM  COŌUR  OL

`f79v.41`  yshedy.qokeey.okain.ol,keey.daldy.chedy.raiin.orain
→ MPARNM  COŌRRM  OŌUI?  OLŌRRM  NULNM  SARNM  RUII?  ORUI?

`f79v.42`  okchedy.qokain.sheky.chedy.ol,ain,y,daral
→ OŌSARNM  COŌUI?  PARŌM  SARNM  OLUI?MNURUL

### f80r  ·  balneological

`f80r.1`  toroly
→ TOROLM

`f80r.2`  olchdy
→ OLSANM

`f80r.3`  okaly
→ OŌULM

`f80r.4`  okolo
→ OŌOLO

`f80r.5`  okary
→ OŌURM

`f80r.6`  opor
→ OMOR

`f80r.7`  olky
→ OLŌM

`f80r.8`  otalshedy
→ OTULPARNM

`f80r.9`  okar
→ OŌUR

`f80r.10`  okan
→ OŌU?

`f80r.11`  pdol.fshedy.{q@207;}polkain.octhor.okchdy.qokeedy.qopcheol<->olkoiin.y,darshey
→ MNOL  ?PARNM  CMOLŌUI?  OSTAOR  OŌSANM  COŌRRNM  COMSAROLOLŌOII?  MNURPARM

`f80r.12`  dykshy.ol,otchedy.qokain.qotain.chckhey.qokain.okal.qotain.okedy.qo,l,r
→ NMŌPAM  OLOTSARNM  COŌUI?  COTUI?  SASŌARM  COŌUI?  OŌUL  COTUI?  OŌRNM  COLR

`f80r.13`  tchedy.qotair.cheol.qokal.qokal.cheety.qokaiin.qokar.qokain.chedy.qokam
→ TSARNM  COTUIR  SAROL  COŌUL  COŌUL  SARRTM  COŌUII?  COŌUR  COŌUI?  SARNM  COŌUS

`f80r.14`  solkain.shl.lky.chcthy.qokain.qotchy.qotal.dy.chckhy.lchey.qotar.otal
→ POLŌUI?  PAL  LŌM  SASTAM  COŌUI?  COTSAM  COTUL  NM  SASŌAM  LSARM  COTUR  OTUL

`f80r.15`  qokedy.qokeedy.checkhy.olchedy.qokain.chey.qokechckhy.otar.cheoltain.sy
→ COŌRNM  COŌRRNM  SARSŌAM  OLSARNM  COŌUI?  SARM  COŌRSASŌAM  OTUR  SAROLTUI?  PM

`f80r.16`  solchedy.qokeedy.qokar.ol.chedy.qokain.shecthy.qokeedy.saltar.chkain.oty
→ POLSARNM  COŌRRNM  COŌUR  OL  SARNM  COŌUI?  PARSTAM  COŌRRNM  PULTUR  SAŌUI?  OTM

`f80r.17`  solky.sheckhy.sheky.shkeol.qokar.sheky.chetain.ol.olkar.okain.sheky.qokal.da[?:y]
→ POLŌM  PARSŌAM  PARŌM  PAŌROL  COŌUR  PARŌM  SARTUI?  OL  OLŌUR  OŌUI?  PARŌM  COŌUL  NU

`f80r.18`  paiin.sheol.qokain.chety.qokeedy.qokar.shcthy.qotol.shecthy.qokain.olkam
→ MUII?  PAROL  COŌUI?  SARTM  COŌRRNM  COŌUR  PASTAM  COTOL  PARSTAM  COŌUI?  OLŌUS

`f80r.19`  dcheol.shedy.qok[ee:a]l.qotaiin.chtal.schcthy.qokal.chcthy.qokain.okain.oloky
→ NSAROL  PARNM  COŌRRL  COTUII?  SATUL  PSASTAM  COŌUL  SASTAM  COŌUI?  OŌUI?  OLOŌM

`f80r.20`  qoteedy,keey.qokain.chckhy.qoty.dalched.otain.shedy.qokair.shey.dalom
→ COTRRNMŌRRM  COŌUI?  SASŌAM  COTM  NULSARN  OTUI?  PARNM  COŌUIR  PARM  NULOS

`f80r.21`  shedy.qokey.shckhey.qotar.chckhy.otol.teol.sheol.qotal.oltain.chcthy
→ PARNM  COŌRM  PASŌARM  COTUR  SASŌAM  OTOL  TROL  PAROL  COTUL  OLTUI?  SASTAM

`f80r.22`  qokeedy.qol.shecthy.qokalkeol.qoky.qokal.shedy.sal.olkain.shey.qokl
→ COŌRRNM  COL  PARSTAM  COŌULŌROL  COŌM  COŌUL  PARNM  PUL  OLŌUI?  PARM  COŌL

`f80r.23`  yshey.l.shey,kaiin.lor.aiiin.shcthy.pchey,ty.ol.keedy,tar.oky.lar
→ MPARM  L  PARMŌUII?  LOR  UIII?  PASTAM  MSARMTM  OL  ŌRRNMTUR  OŌM  LUR

`f80r.24`  lol.chey.[r:?]chy.r,ol.dain.oty.qoty.otalor.sheckhy.olkeey.ral.chedy[o:a]r
→ LOL  SARM  RSAM  ROL  NUI?  OTM  COTM  OTULOR  PARSŌAM  OLŌRRM  RUL  SARNMOR

`f80r.25`  dar.sheal.cheeky.okain.sol.lshedy.dol.checthy.orol.eeesal.olo.teol.ory
→ NUR  PARUL  SARRŌM  OŌUI?  POL  LPARNM  NOL  SARSTAM  OROL  RRRPUL  OLO  TROL  ORM

`f80r.26`  lchol.dar.shecthy.otedy.qol.olcheedy.opcheeky.qotchy.qokaiin.otair.olky
→ LSAOL  NUR  PARSTAM  OTRNM  COL  OLSARRNM  OMSARRŌM  COTSAM  COŌUII?  OTUIR  OLŌM

`f80r.27`  lol.shar.otaiin.olkaiin.ol.olkain.oraiin.olor.checthy.olor
→ LOL  PAUR  OTUII?  OLŌUII?  OL  OLŌUI?  ORUII?  OLOR  SARSTAM  OLOR

`f80r.28`  pcheolkal.dal.korchy.qotey.qoty.rchedy.qokal.olkolshedy.chty
→ MSAROLŌUL  NUL  ŌORSAM  COTRM  COTM  RSARNM  COŌUL  OLŌOLPARNM  SATM

`f80r.29`  okchey.qoky.chedy.qokain.shedy.qol.sheey.qokal.dar,ary
→ OŌSARM  COŌM  SARNM  COŌUI?  PARNM  COL  PARRM  COŌUL  NURURM

`f80r.30`  dshedy.qokal.chcthy.qokain.shedy.okaiin.shey.dainol
→ NPARNM  COŌUL  SASTAM  COŌUI?  PARNM  OŌUII?  PARM  NUI?OL

`f80r.31`  qokal.checthy.sol.chey.okalol.okaly.qokeedy.oly
→ COŌUL  SARSTAM  POL  SARM  OŌULOL  OŌULM  COŌRRNM  OLM

`f80r.32`  solchey.qoky.r.cheykain.sheckhy.qokain.okain.ol
→ POLSARM  COŌM  R  SARMŌUI?  PARSŌAM  COŌUI?  OŌUI?  OL

`f80r.33`  solchey.qokeey.lkar.otal.olkeey.okain.shecthy.ol
→ POLSARM  COŌRRM  LŌUR  OTUL  OLŌRRM  OŌUI?  PARSTAM  OL

`f80r.34`  {c@132;h}{c@133;h}ey.rcheky.shepchedy.qokar.ol.qockhey.olchey.qokedy.koroiin.y
→ SASARM  RSARŌM  PARMSARNM  COŌUR  OL  COSŌARM  OLSARM  COŌRNM  ŌOROII?  M

`f80r.35`  olkeey.l,sheol.qokeey.shedy.qol.shedy.qokain.shey.qoty.qokain.qokady
→ OLŌRRM  LPAROL  COŌRRM  PARNM  COL  PARNM  COŌUI?  PARM  COTM  COŌUI?  COŌUNM

`f80r.36`  qokeey.rchey.tain.oteey.qokain.shekaiin.sheckhy.qolshey.qokain.ol.lom
→ COŌRRM  RSARM  TUI?  OTRRM  COŌUI?  PARŌUII?  PARSŌAM  COLPARM  COŌUI?  OL  LOS

`f80r.37`  sol.olkeeey.otar.orchey.qokeey.ltalor.olor.qokaiin.ol.shey.qotor,alom
→ POL  OLŌRRRM  OTUR  ORSARM  COŌRRM  LTULOR  OLOR  COŌUII?  OL  PARM  COTORULOS

`f80r.38`  sor.olky.qoty,ty,tor.sheyky.t,otol.opchedy.qokain.sheky.qokain.ol
→ POR  OLŌM  COTMTMTOR  PARMŌM  TOTOL  OMSARNM  COŌUI?  PARŌM  COŌUI?  OL

`f80r.39`  qokeedy.qokail.oteey.otain.shedy.ykeey.rar.[a:o]lshees
→ COŌRRNM  COŌUIL  OTRRM  OTUI?  PARNM  MŌRRM  RUR  ULPARRP

`f80r.40`  torolshsdy.opchey.shepchy.qotain.shcthy.qokedy.daly
→ TOROLPAPNM  OMSARM  PARMSAM  COTUI?  PASTAM  COŌRNM  NULM

`f80r.41`  tolkain.otal.chedy.qokar.ol.shedy.checkhy.or,oly
→ TOLŌUI?  OTUL  SARNM  COŌUR  OL  PARNM  SARSŌAM  OROLM

`f80r.42`  y,cheeytal.checthy.qokain.qokain.checthy.qokain.ol
→ MSARRMTUL  SARSTAM  COŌUI?  COŌUI?  SARSTAM  COŌUI?  OL

`f80r.43`  sor.sheckhy.qokar.checkhy.okain.sheckhy.qokeey.ly
→ POR  PARSŌAM  COŌUR  SARSŌAM  OŌUI?  PARSŌAM  COŌRRM  LM

`f80r.44`  qokain.shckhy.qokolkain.chedy.qokain.checthy.lor
→ COŌUI?  PASŌAM  COŌOLŌUI?  SARNM  COŌUI?  SARSTAM  LOR

`f80r.45`  okain.shedy.qokan.chedy.qotain.cheky.lteey.lolom
→ OŌUI?  PARNM  COŌU?  SARNM  COTUI?  SARŌM  LTRRM  LOLOS

`f80r.46`  qokain.cheey.olkain.shedy.qokain.orol.s
→ COŌUI?  SARRM  OLŌUI?  PARNM  COŌUI?  OROL  P

`f80r.47`  polchy.efaloir.okain.okaiin.cheey,kaiin.ylor.olkeey.qokal
→ MOLSAM  R?ULOIR  OŌUI?  OŌUII?  SARRMŌUII?  MLOR  OLŌRRM  COŌUL

`f80r.48`  sal.shy.loiin.cheey.qotl.shety.sheoky.qokaiin.cheey.ram
→ PUL  PAM  LOII?  SARRM  COTL  PARTM  PAROŌM  COŌUII?  SARRM  RUS

`f80r.49`  t[iiin:ain].chey.ral,k[ar:ir].chey.lkl.ol.shees.okaiin.olky,oklor
→ TIII?  SARM  RULŌUR  SARM  LŌL  OL  PARRP  OŌUII?  OLŌMOŌLOR

`f80r.50`  lol.chey.saiin.shety.okaiiin.sheor.tchey.lkaiin.okainy
→ LOL  SARM  PUII?  PARTM  OŌUIII?  PAROR  TSARM  LŌUII?  OŌUI?M

`f80r.51`  talkl.ol.s,al.cheoly.daiin.otaly.otain.chey.lkain.olom
→ TULŌL  OL  PUL  SAROLM  NUII?  OTULM  OTUI?  SARM  LŌUI?  OLOS

`f80r.52`  sol,tl.shey.qoklcheey.lkaiin.ol.olor.aiin,y,daiin.cheol,kain
→ POLTL  PARM  COŌLSARRM  LŌUII?  OL  OLOR  UII?MNUII?  SAROLŌUI?

`f80r.53`  lol.eey.lchey.qokal.cheol.lchor.otlol
→ LOL  RRM  LSARM  COŌUL  SAROL  LSAOR  OTLOL

### f80v  ·  balneological

`f80v.1`  pchedy.dolfchedy.qokeedy.qotedy.qotolfchedy.roly
→ MSARNM  NOL?SARNM  COŌRRNM  COTRNM  COTOL?SARNM  ROLM

`f80v.2`  tshedy.qotedy.olkain.otal.chckhy.qoky.daiin.doly
→ TPARNM  COTRNM  OLŌUI?  OTUL  SASŌAM  COŌM  NUII?  NOLM

`f80v.3`  schedy.qolchedy.qokaiin.chcthy.otaiin.sheeky.qol
→ PSARNM  COLSARNM  COŌUII?  SASTAM  OTUII?  PARRŌM  COL

`f80v.4`  qokedy.qokar.qokain.chedy.qol.qol.she{ctyh}y.qoly
→ COŌRNM  COŌUR  COŌUI?  SARNM  COL  COL  PARSTMAM  COLM

`f80v.5`  okeedy.chedy.olkeedy.o{ith}y.qokaiin.shckhy.qotain,ol
→ OŌRRNM  SARNM  OLŌRRNM  OITAM  COŌUII?  PASŌAM  COTUI?OL

`f80v.6`  tcheol.kedy.pcheol.kain.shedy.qokaiin.otey.qokedy.chedy
→ TSAROL  ŌRNM  MSAROL  ŌUI?  PARNM  COŌUII?  OTRM  COŌRNM  SARNM

`f80v.7`  polshol.tchey.qokol.shedy.qotshey.saly.kchey.stolpchy
→ MOLPAOL  TSARM  COŌOL  PARNM  COTPARM  PULM  ŌSARM  PTOLMSAM

`f80v.8`  olteedy.qokaiin.shedy.qokain.sheol.qokchdy.qokchdy.qoty,dy
→ OLTRRNM  COŌUII?  PARNM  COŌUI?  PAROL  COŌSANM  COŌSANM  COTMNM

`f80v.9`  tchdy.qol.tol,tal.taldain.chckhy.qokal.dol.checthy.qokal,ly
→ TSANM  COL  TOLTUL  TULNUI?  SASŌAM  COŌUL  NOL  SARSTAM  COŌULLM

`f80v.10`  sol,sheey.qokaiin.shcthy.dolshedy.qokal.shecthy.qotainol
→ POLPARRM  COŌUII?  PASTAM  NOLPARNM  COŌUL  PARSTAM  COTUI?OL

`f80v.11`  tol,sheedy.qokar.olky.rorcheey.sheckhy.qotain.chedy.rol
→ TOLPARRNM  COŌUR  OLŌM  RORSARRM  PARSŌAM  COTUI?  SARNM  ROL

`f80v.12`  ycheol,kain.shey.qokain.chedy.qokol.olkain.sh{cthh}y,l
→ MSAROLŌUI?  PARM  COŌUI?  SARNM  COŌOL  OLŌUI?  PASTAAML

`f80v.13`  lor.ar.ol.olor.chey.koldy
→ LOR  UR  OL  OLOR  SARM  ŌOLNM

`f80v.14`  tshedy.qokain.shedy.qokas.otal.qopshedy.qoty.lchedy.qopalor
→ TPARNM  COŌUI?  PARNM  COŌUP  OTUL  COMPARNM  COTM  LSARNM  COMULOR

`f80v.15`  qotaiin.chty.lchedy.s,aly,tol.chey.qoteedy.otal.dain.ol,dal
→ COTUII?  SATM  LSARNM  PULMTOL  SARM  COTRRNM  OTUL  NUI?  OLNUL

`f80v.16`  cheol.key.qotar.dy.qotal.dy.keedy.qokain.oty.loldy,tal
→ SAROL  ŌRM  COTUR  NM  COTUL  NM  ŌRRNM  COŌUI?  OTM  LOLNMTUL

`f80v.17`  solcheol.qokaiin.shecthy.qokal.cheol,dy.qotlolkal.chedyr
→ POLSAROL  COŌUII?  PARSTAM  COŌUL  SAROLNM  COTLOLŌUL  SARNMR

`f80v.18`  ychedy.qol.okaiin.olkedy.or.okain
→ MSARNM  COL  OŌUII?  OLŌRNM  OR  OŌUI?

`f80v.19`  psheoldy.dkshey.qokopy.ror.[o:a]por.olpo{ikh}y.oltydy
→ MPAROLNM  NŌPARM  COŌOMM  ROR  OMOR  OLMOIŌAM  OLTMNM

`f80v.20`  ysheeyqorar.ol.cheey.daiin.shey.qokaiin.ol.okaiin
→ MPARRMCORUR  OL  SARRM  NUII?  PARM  COŌUII?  OL  OŌUII?

`f80v.21`  tar,kain.okal.y,rchey.qokal.olor,aiin.okal.otam
→ TURŌUI?  OŌUL  MRSARM  COŌUL  OLORUII?  OŌUL  OTUS

`f80v.22`  dchedy.qokal.ol.chey.dal.or.shedy.lshedy
→ NSARNM  COŌUL  OL  SARM  NUL  OR  PARNM  LPARNM

`f80v.23`  polteshol.opy.shey.qopshedy.qoteedy.qotol.shy.kolshd.qoky
→ MOLTRPAOL  OMM  PARM  COMPARNM  COTRRNM  COTOL  PAM  ŌOLPAN  COŌM

`f80v.24`  yshedy.qokeey.qokey.qoty.qotol.otaiin.ol.chedy.qoky.daiin
→ MPARNM  COŌRRM  COŌRM  COTM  COTOL  OTUII?  OL  SARNM  COŌM  NUII?

`f80v.25`  lshedy.qoty.olol.cheey.qokain.okalchy.tal.or.checthy,sar
→ LPARNM  COTM  OLOL  SARRM  COŌUI?  OŌULSAM  TUL  OR  SARSTAMPUR

`f80v.26`  qoty.cheyqytaiin.chey.lchedy.shedy.olchey
→ COTM  SARMCMTUII?  SARM  LSARNM  PARNM  OLSARM

`f80v.27`  pshol.kain.olkar.shey.qokain.dal.oltaiin.okain.shal.qoty
→ MPAOL  ŌUI?  OLŌUR  PARM  COŌUI?  NUL  OLTUII?  OŌUI?  PAUL  COTM

`f80v.28`  olcheol.qokain.or.al.chain.qokain.ol.kaiin.okeedy.qokey,ly
→ OLSAROL  COŌUI?  OR  UL  SAUI?  COŌUI?  OL  ŌUII?  OŌRRNM  COŌRMLM

`f80v.29`  qokain.olkain.olkain.ol.keeol
→ COŌUI?  OLŌUI?  OLŌUI?  OL  ŌRROL

`f80v.30`  pol.or.olkain.o{ikh}y.qokaiin.okain.okar.shey.qolky
→ MOL  OR  OLŌUI?  OIŌAM  COŌUII?  OŌUI?  OŌUR  PARM  COLŌM

`f80v.31`  qol.ol,oiin.olkain.ol.chedy.qokain.olshey.qokain
→ COL  OLOII?  OLŌUI?  OL  SARNM  COŌUI?  OLPARM  COŌUI?

`f80v.32`  s,olkain.shol.kair.or.arolkeedy.olky.qolkain.shedy
→ POLŌUI?  PAOL  ŌUIR  OR  UROLŌRRNM  OLŌM  COLŌUI?  PARNM

`f80v.33`  qokeedy.qoker.olkain.olshedy.qokey.qokeey.tchcthy.lom
→ COŌRRNM  COŌRR  OLŌUI?  OLPARNM  COŌRM  COŌRRM  TSASTAM  LOS

`f80v.34`  dol,sheyr.shey.olshey.cthor.ylchdy.olkain.shcthy.qoly
→ NOLPARMR  PARM  OLPARM  STAOR  MLSANM  OLŌUI?  PASTAM  COLM

`f80v.35`  tol.oltain.olkar.y.qol.qol.kain.okiin.ol,kain.shey,ldy
→ TOL  OLTUI?  OLŌUR  M  COL  COL  ŌUI?  OŌII?  OLŌUI?  PARMLNM

`f80v.36`  soin.okain.sheor.ol.shey.daly.olshedy.olal,shedy.lchy
→ POI?  OŌUI?  PAROR  OL  PARM  NULM  OLPARNM  OLULPARNM  LSAM

`f80v.37`  polshdy.qokeedy.shky.ololchey
→ MOLPANM  COŌRRNM  PAŌM  OLOLSARM

`f80v.38`  polkedy.lsheckhy.olky.ot.olkchy.rchey.qcthy.rchey.ral
→ MOLŌRNM  LPARSŌAM  OLŌM  OT  OLŌSAM  RSARM  CSTAM  RSARM  RUL

`f80v.39`  sol.aiin.chey.qokain.ches.ol.chckhy.qokeedy.tchdy.aral
→ POL  UII?  SARM  COŌUI?  SARP  OL  SASŌAM  COŌRRNM  TSANM  URUL

`f80v.40`  qokain.ol.cheeor.olar.chey.t[ch:?]ar.ol.chedy.qotal.olchedy
→ COŌUI?  OL  SARROR  OLUR  SARM  TSAUR  OL  SARNM  COTUL  OLSARNM

`f80v.41`  tor.arol,ar.shckhy.lkol.otol.chedy.qokain.chckhy,qokal
→ TOR  UROLUR  PASŌAM  LŌOL  OTOL  SARNM  COŌUI?  SASŌAMCOŌUL

`f80v.42`  pol.ol,aiin.olkal,shar.shedy.qokol.chdy.ldol.dar.al
→ MOL  OLUII?  OLŌULPAUR  PARNM  COŌOL  SANM  LNOL  NUR  UL

`f80v.43`  sor.ain.shkain.shar.okshey.dalar.shokal.dy
→ POR  UI?  PAŌUI?  PAUR  OŌPARM  NULUR  PAOŌUL  NM

`f80v.44`  qokal.orol
→ COŌUL  OROL

### f81r  ·  balneological

`f81r.1`  polchoy.qokedy.shol.opchedy.olpchedy.ofshdy.oly
→ MOLSAOM  COŌRNM  PAOL  OMSARNM  OLMSARNM  O?PANM  OLM

`f81r.2`  dchey.lshl.alched.qokol.chol.otar,chedy.oky
→ NSARM  LPAL  ULSARN  COŌOL  SAOL  OTURSARNM  OŌM

`f81r.3`  qotey.l,chees.olkal.ol,chedy.okar.shedy
→ COTRM  LSARRP  OLŌUL  OLSARNM  OŌUR  PARNM

`f81r.4`  dchedy.qokain.ol.ol.chcthy.ykeedy,al
→ NSARNM  COŌUI?  OL  OL  SASTAM  MŌRRNMUL

`f81r.5`  qol.cheol.okeey.ol.ol.olaiin.ol.or,ain
→ COL  SAROL  OŌRRM  OL  OL  OLUII?  OL  ORUI?

`f81r.6`  sar.ol,eses.oteey.shor.qokeey.ol
→ PUR  OLRPRP  OTRRM  PAOR  COŌRRM  OL

`f81r.7`  dshees.okain.chcthy.otey.okain
→ NPARRP  OŌUI?  SASTAM  OTRM  OŌUI?

`f81r.8`  pchedy.qokeey.oty.qotey.oteey.oly
→ MSARNM  COŌRRM  OTM  COTRM  OTRRM  OLM

`f81r.9`  qoteesy.qotedy.qokeedy.chcphey
→ COTRRPM  COTRNM  COŌRRNM  SASMARM

`f81r.10`  chol.dain.otedy.cheey.qotain.ly
→ SAOL  NUI?  OTRNM  SARRM  COTUI?  LM

`f81r.11`  olsheol.olkedy.sheckhedy.oltedy
→ OLPAROL  OLŌRNM  PARSŌARNM  OLTRNM

`f81r.12`  ychedy.tedy.ol.sheedy.qokeey.loly
→ MSARNM  TRNM  OL  PARRNM  COŌRRM  LOLM

`f81r.13`  dchol.shedy.qotedy.qol.chedy.chetyry
→ NSAOL  PARNM  COTRNM  COL  SARNM  SARTMRM

`f81r.14`  qokechedy.qolsheedy.or,ain.arol.oeeedy
→ COŌRSARNM  COLPARRNM  ORUI?  UROL  ORRRNM

`f81r.15`  sain.ol.cheedy.qokeedy.otedy
→ PUI?  OL  SARRNM  COŌRRNM  OTRNM

`f81r.16`  polchdy.qopchol.qokor.olpchedy.opol.oraisy
→ MOLSANM  COMSAOL  COŌOR  OLMSARNM  OMOL  ORUIPM

`f81r.17`  y,checthy.okeedy.shey.qokedy.ol.ochedar
→ MSARSTAM  OŌRRNM  PARM  COŌRNM  OL  OSARNUR

`f81r.18`  osheedy.shedy.ol.shedy.okeedy.oror
→ OPARRNM  PARNM  OL  PARNM  OŌRRNM  OROR

`f81r.19`  qokedy.sheedy.chedy.qoteedy.olam
→ COŌRNM  PARRNM  SARNM  COTRRNM  OLUS

`f81r.20`  qopchedy.qol.chedy.qokeey.odaiin.rain.daly
→ COMSARNM  COL  SARNM  COŌRRM  ONUII?  RUI?  NULM

`f81r.21`  dshedy.qokal.olkeey.oteey.olshey.otey,lol
→ NPARNM  COŌUL  OLŌRRM  OTRRM  OLPARM  OTRMLOL

`f81r.22`  qotal.chedy.qol.ol.daiin.ol,chedar.ol.oly
→ COTUL  SARNM  COL  OL  NUII?  OLSARNUR  OL  OLM

`f81r.23`  [ch:sh]ey.okain.sheckhy.soiin.chey.lchey
→ SARM  OŌUI?  PARSŌAM  POII?  SARM  LSARM

`f81r.24`  par,ody.shecphy.cheol.qotaldar.otedy.oly
→ MURONM  PARSMAM  SAROL  COTULNUR  OTRNM  OLM

`f81r.25`  sar.shedy.qol,otain.okair.okal.chedy.dy
→ PUR  PARNM  COLOTUI?  OŌUIR  OŌUL  SARNM  NM

`f81r.26`  pchedy.qokey.oteol.qol.sheor.shedy.qcthdys
→ MSARNM  COŌRM  OTROL  COL  PAROR  PARNM  CSTANMP

`f81r.27`  sol.chedy.qokedy.olkedy.dol.qokchedy
→ POL  SARNM  COŌRNM  OLŌRNM  NOL  COŌSARNM

`f81r.28`  qokesdy.chedy.qokar.chey.taiin.otey.lchl
→ COŌRPNM  SARNM  COŌUR  SARM  TUII?  OTRM  LSAL

`f81r.29`  y,sheedy.shy.chey.l,chcthy.ytar.olkaiin.ol
→ MPARRNM  PAM  SARM  LSASTAM  MTUR  OLŌUII?  OL

`f81r.30`  l.shedy.qokedy.sor.olkar.ol,kaiin.olkshdy
→ L  PARNM  COŌRNM  POR  OLŌUR  OLŌUII?  OLŌPANM

`f81r.31`  sol,shedy.ol.lchedy.shedy.shy.olkedy.ches.ar.or.oraiiin
→ POLPARNM  OL  LSARNM  PARNM  PAM  OLŌRNM  SARP  UR  OR  ORUIII?

### f81v  ·  balneological

`f81v.1`  par.shey.keedy.shekal.dal.dar.ol,pchedy.shek,dain.ofalsheky
→ MUR  PARM  ŌRRNM  PARŌUL  NUL  NUR  OLMSARNM  PARŌNUI?  O?ULPARŌM

`f81v.2`  qokedy.okaiin.kair.okal.sar.ol.kain.olkain.al.ol.rol.dl
→ COŌRNM  OŌUII?  ŌUIR  OŌUL  PUR  OL  ŌUI?  OLŌUI?  UL  OL  ROL  NL

`f81v.3`  saiin.daiin.olkeedy.okedy.dykain.shek.chdy.dalal.oldy
→ PUII?  NUII?  OLŌRRNM  OŌRNM  NMŌUI?  PARŌ  SANM  NULUL  OLNM

`f81v.4`  qokaiin.okain.cheeky.dy.ol,kaiin.dain.dy.daiin.chcthy
→ COŌUII?  OŌUI?  SARRŌM  NM  OLŌUII?  NUI?  NM  NUII?  SASTAM

`f81v.5`  okaiin.daiin.otain.chckhy.okeedy.qoky.kar.daiin.okar
→ OŌUII?  NUII?  OTUI?  SASŌAM  OŌRRNM  COŌM  ŌUR  NUII?  OŌUR

`f81v.6`  qokain.okaiin.ol,chedy.cheol.lky.l.s.aiin.okain.daldy
→ COŌUI?  OŌUII?  OLSARNM  SAROL  LŌM  L  P  UII?  OŌUI?  NULNM

`f81v.7`  olor,ol.sheckhal.daiin.qokeedal.daiin.chckhy.schedy.qol
→ OLOROL  PARSŌAUL  NUII?  COŌRRNUL  NUII?  SASŌAM  PSARNM  COL

`f81v.8`  ykol.or,shedy.sheedy.qolkeedy.daiin.dkain.cphedy.oldy
→ MŌOL  ORPARNM  PARRNM  COLŌRRNM  NUII?  NŌUI?  SMARNM  OLNM

`f81v.9`  yar,olchey,kaiin.okeey.daiin.olor.checkhy.daiidy
→ MUROLSARMŌUII?  OŌRRM  NUII?  OLOR  SARSŌAM  NUIINM

`f81v.10`  polshy.[a:o]shyteed.qop.okeedy.otedy.okshedy.qoty.dairam
→ MOLPAM  UPAMTRRN  COM  OŌRRNM  OTRNM  OŌPARNM  COTM  NUIRUS

`f81v.11`  [y:?]shey.qokeey.okeey.oky.ykeey.qoky.oky.lky.olchy.ky.dsholyd
→ MPARM  COŌRRM  OŌRRM  OŌM  MŌRRM  COŌM  OŌM  LŌM  OLSAM  ŌM  NPAOLMN

`f81v.12`  qol.ol.chdy.shedy.qokedy.ytedy.chetedy.lkedey.ytedy
→ COL  OL  SANM  PARNM  COŌRNM  MTRNM  SARTRNM  LŌRNRM  MTRNM

`f81v.13`  ykeshey.dch[s:]ed,ytedy.ytedy.dar.ykeda{iph}y.qoty.ykedy.okal
→ MŌRPARM  NSAPRNMTRNM  MTRNM  NUR  MŌRNUIMAM  COTM  MŌRNM  OŌUL

`f81v.14`  dshedy.ykeedy.sheeky.daiin.okedy.qokeed.qokedy.lchpchdy
→ NPARNM  MŌRRNM  PARRŌM  NUII?  OŌRNM  COŌRRN  COŌRNM  LSAMSANM

`f81v.15`  qokal.chedy.ol.sheey.salshcthdy.qofchedy.r.chedy.ltary
→ COŌUL  SARNM  OL  PARRM  PULPASTANM  CO?SARNM  R  SARNM  LTURM

`f81v.16`  lor.shedy.qoeedy.ol.chy.rshdy.lshedy.dar.chdy.pchdy
→ LOR  PARNM  CORRNM  OL  SAM  RPANM  LPARNM  NUR  SANM  MSANM

`f81v.17`  sshkchdy.chedy.ol.shedy.qolchedy.qokain.{ch'}ckhy.dl.ral
→ PPAŌSANM  SARNM  OL  PARNM  COLSARNM  COŌUI?  SASŌAM  NL  RUL

`f81v.18`  qokchdy.chey.ol.cheky.ol.shedy.qokedy.qokedy.chckhy.qoky
→ COŌSANM  SARM  OL  SARŌM  OL  PARNM  COŌRNM  COŌRNM  SASŌAM  COŌM

`f81v.19`  solkeey.ol.shedy.qokar.shckhy.d{ch'}edy.qokar.qokal.dol,chy
→ POLŌRRM  OL  PARNM  COŌUR  PASŌAM  NSARNM  COŌUR  COŌUL  NOLSAM

`f81v.20`  qocthey.chekal.chedy.qokedy.lshety.qoldy.ltedy.qotain
→ COSTARM  SARŌUL  SARNM  COŌRNM  LPARTM  COLNM  LTRNM  COTUI?

`f81v.21`  lsho.qokey.lshedy.lshedy.chedy.qolky.lchedal.qol.otar
→ LPAO  COŌRM  LPARNM  LPARNM  SARNM  COLŌM  LSARNUL  COL  OTUR

`f81v.22`  qokal.qol.oiin.cheey.dal.lchedy.chedy.salchtedytar
→ COŌUL  COL  OII?  SARRM  NUL  LSARNM  SARNM  PULSATRNMTUR

`f81v.23`  shol.qe[t:k]chy.ykaiin.olkain.shedy.qoky.dchedy.rol.olcthdy
→ PAOL  CRTSAM  MŌUII?  OLŌUI?  PARNM  COŌM  NSARNM  ROL  OLSTANM

`f81v.24`  ytey.okchedy.qokal.okeey.qol.cheedy.sal.teol.dchdy.ly
→ MTRM  OŌSARNM  COŌUL  OŌRRM  COL  SARRNM  PUL  TROL  NSANM  LM

`f81v.25`  oshedy.qotedy.sh[o:a]l.chedy.y,shchey.ol,chey.qol,chedy,tchd.oky
→ OPARNM  COTRNM  PAOL  SARNM  MPASARM  OLSARM  COLSARNMTSAN  OŌM

`f81v.26`  [?:q]ol.checholtar.oiin.okedy.dal.shey.olkeol.olkeedy.okeol
→ OL  SARSAOLTUR  OII?  OŌRNM  NUL  PARM  OLŌROL  OLŌRRNM  OŌROL

`f81v.27`  dsheol.oiiin.olkeedy.tedy.cheky.shckhedy.chal
→ NPAROL  OIII?  OLŌRRNM  TRNM  SARŌM  PASŌARNM  SAUL

`f81v.28`  otain.olkal
→ OTUI?  OLŌUL

### f82r  ·  balneological

`f82r.1`  qosheedy.qokeol.daiin.shckhy<->okeeor.cheey.daiin.shey
→ COPARRNM  COŌROL  NUII?  PASŌAMOŌRROR  SARRM  NUII?  PARM

`f82r.2`  dchedy.qolchedy.qokain.dy<->qokeedy.qokal.lcheckhy.lched
→ NSARNM  COLSARNM  COŌUI?  NMCOŌRRNM  COŌUL  LSARSŌAM  LSARN

`f82r.3`  qokeey.lcheckhedy.qokaly<->solkaiin.chckhy.qokaiin
→ COŌRRM  LSARSŌARNM  COŌULMPOLŌUII?  SASŌAM  COŌUII?

`f82r.4`  qokaiin.octheol.chkeey.ldy<->oteey.qokal.sheckhy.qoky
→ COŌUII?  OSTAROL  SAŌRRM  LNMOTRRM  COŌUL  PARSŌAM  COŌM

`f82r.5`  sol.lkchedy.qokeedy.qokal<->cthol.chedy.qoteedy.qokal
→ POL  LŌSARNM  COŌRRNM  COŌULSTAOL  SARNM  COTRRNM  COŌUL

`f82r.6`  sar.shedy.qol.shedaiin.sheckhy.okal.sheky.qotaiin.chedol
→ PUR  PARNM  COL  PARNUII?  PARSŌAM  OŌUL  PARŌM  COTUII?  SARNOL

`f82r.7`  dshedy.sotaiin.qokar.shedy.solshedy.qokeey.qoky.ls.cheey
→ NPARNM  POTUII?  COŌUR  PARNM  POLPARNM  COŌRRM  COŌM  LP  SARRM

`f82r.8`  qekeey.sheedy.qokedy.lcho,r.cheey.qokey.qotal.chedy.qoteor
→ CRŌRRM  PARRNM  COŌRNM  LSAOR  SARRM  COŌRM  COTUL  SARNM  COTROR

`f82r.9`  ssholshecthy.qokaiin.chkedy.rchey.dairchey.qokaiin
→ PPAOLPARSTAM  COŌUII?  SAŌRNM  RSARM  NUIRSARM  COŌUII?

`f82r.10`  orolda[ir:in]
→ OROLNUIR

`f82r.11`  kolchdy.qokedy.qopol.qotedor.chopchedy.qotal,chedy.kam
→ ŌOLSANM  COŌRNM  COMOL  COTRNOR  SAOMSARNM  COTULSARNM  ŌUS

`f82r.12`  otedy.qodched.olqo.dar.checkho,lolol.okal.okarchedy
→ OTRNM  CONSARN  OLCO  NUR  SARSŌAOLOLOL  OŌUL  OŌURSARNM

`f82r.13`  tcheol.olchedy.qokeedy.qotedy.chedar.cheey.lchey.solarol
→ TSAROL  OLSARNM  COŌRRNM  COTRNM  SARNUR  SARRM  LSARM  POLUROL

`f82r.14`  r,olchy.qokal.chey.qokain.deeedy.qokeey.qokaiin.olchedy
→ ROLSAM  COŌUL  SARM  COŌUI?  NRRRNM  COŌRRM  COŌUII?  OLSARNM

`f82r.15`  kedy.lchedy.qokedy.qok[ee:ch]dy.lkeedy.qokaiin.dy.daiin.chdy,dy
→ ŌRNM  LSARNM  COŌRNM  COŌRRNM  LŌRRNM  COŌUII?  NM  NUII?  SANMNM

`f82r.16`  qokeedy.lchedy.qokeedy.cheey.r.or.ol.s,aiin.chey.ra{cty}.dam
→ COŌRRNM  LSARNM  COŌRRNM  SARRM  R  OR  OL  PUII?  SARM  RUSTM  NUS

`f82r.17`  dshedy.qoteey.chedy.qokeeey.qokedy.lteedy.qokeedy.ralchey
→ NPARNM  COTRRM  SARNM  COŌRRRM  COŌRNM  LTRRNM  COŌRRNM  RULSARM

`f82r.18`  polched.otain.shedy.shedy.dal.chedar.qokeey.ykeey.l,s,araiin,ory
→ MOLSARN  OTUI?  PARNM  PARNM  NUL  SARNUR  COŌRRM  MŌRRM  LPURUII?ORM

`f82r.19`  okain.char.okain.qokeedy.lchy
→ OŌUI?  SAUR  OŌUI?  COŌRRNM  LSAM

`f82r.20`  posalshy.qokedy.cphal.shedy.sheol,keeedy.lkaiin.shedy.qoly
→ MOPULPAM  COŌRNM  SMAUL  PARNM  PAROLŌRRRNM  LŌUII?  PARNM  COLM

`f82r.21`  daiin.cheoky.lkedy.salshey.daiin.chey.qol.chedy.qokeey.dal
→ NUII?  SAROŌM  LŌRNM  PULPARM  NUII?  SARM  COL  SARNM  COŌRRM  NUL

`f82r.22`  qokaiin.cheor.sheey.qokaiin.shckhey.qol,keeedy.qokeeey.ra[s:r]y
→ COŌUII?  SAROR  PARRM  COŌUII?  PASŌARM  COLŌRRRNM  COŌRRRM  RUPM

`f82r.23`  cheey.qcthey.qokeey.lcheey.daiin.chey.qokeeedy.lchedy.lar
→ SARRM  CSTARM  COŌRRM  LSARRM  NUII?  SARM  COŌRRRNM  LSARNM  LUR

`f82r.24`  qokeedy.lcheedy.qokeoy.sal.raiin.qokeey.lkeey.qokeey.raiin.ydy
→ COŌRRNM  LSARRNM  COŌROM  PUL  RUII?  COŌRRM  LŌRRM  COŌRRM  RUII?  MNM

`f82r.25`  dol.qoesedy.sheea'l.sheedy.lshed.qockhey.lchedy.lar.sheey.ry
→ NOL  CORPRNM  PARRUL  PARRNM  LPARN  COSŌARM  LSARNM  LUR  PARRM  RM

`f82r.26`  tshey.qokeedy.cheal.lchedar.ches.aiin.oteey.qokaiin.okey
→ TPARM  COŌRRNM  SARUL  LSARNUR  SARP  UII?  OTRRM  COŌUII?  OŌRM

`f82r.27`  pchedy.rsheal.daldy.qokeedy.rshedy.qoteedy.qokeedy.lochedy
→ MSARNM  RPARUL  NULNM  COŌRRNM  RPARNM  COTRRNM  COŌRRNM  LOSARNM

`f82r.28`  qokoiin.shedy.qokeedy.qotaiin.chcthey.qoteeol,chey.qokaiin.oly
→ COŌOII?  PARNM  COŌRRNM  COTUII?  SASTARM  COTRROLSARM  COŌUII?  OLM

`f82r.29`  d,cheey.lchedy.qokeedy.lchedy.rchedy.ok{chh}y.qotedy.qoty.qoty
→ NSARRM  LSARNM  COŌRRNM  LSARNM  RSARNM  OŌSAAM  COTRNM  COTM  COTM

`f82r.30`  qoteey.raiin.cheol.qoteey.shedy.qokeey.lshedy.qokeedy.rag
→ COTRRM  RUII?  SAROL  COTRRM  PARNM  COŌRRM  LPARNM  COŌRRNM  RU?

`f82r.31`  cheol.ol.rsheedy.lchedy.qoty.lcheeor.qokain.cheedy.lched
→ SAROL  OL  RPARRNM  LSARNM  COTM  LSARROR  COŌUI?  SARRNM  LSARN

`f82r.32`  taiin.shedaiin.chckhey.lchey.lcheckhy.sheey.lr.chey.rain
→ TUII?  PARNUII?  SASŌARM  LSARM  LSARSŌAM  PARRM  LR  SARM  RUI?

`f82r.33`  sain.ol,cheol.{ikh}ey.cheor.chey
→ PUI?  OLSAROL  IŌARM  SAROR  SARM

`f82r.34`  okor
→ OŌOR

`f82r.35`  darol
→ NUROL

`f82r.36`  okal
→ OŌUL

`f82r.37`  okaldy
→ OŌULNM

`f82r.38`  darary
→ NURURM

`f82r.39`  okaira[d:j]y
→ OŌUIRUNM

`f82r.40`  sororl
→ PORORL

`f82r.41`  olk[o:a]ky
→ OLŌOŌM

`f82r.42`  sokoly
→ POŌOLM

`f82r.43`  dolol
→ NOLOL

`f82r.44`  olaiin
→ OLUII?

`f82r.45`  okeear
→ OŌRRUR

### f82v  ·  balneological

`f82v.1`  otechdy
→ OTRSANM

`f82v.2`  otedy
→ OTRNM

`f82v.3`  daiinoty
→ NUII?OTM

`f82v.4`  otedal
→ OTRNUL

`f82v.5`  tokol.olfchedy.qokeedy.qokedal.shol.qotal.otdal,dal.olshedy
→ TOŌOL  OL?SARNM  COŌRRNM  COŌRNUL  PAOL  COTUL  OTNULNUL  OLPARNM

`f82v.6`  qokedy.lshedy.qotol.dol,shedy.shedy,dy.darotedy.chetedy.lokam
→ COŌRNM  LPARNM  COTOL  NOLPARNM  PARNMNM  NUROTRNM  SARTRNM  LOŌUS

`f82v.7`  dair.o,l,chedy.qotedy.qotedy.chsdy.qotal.qoty.qokal.qokedy.lo
→ NUIR  OLSARNM  COTRNM  COTRNM  SAPNM  COTUL  COTM  COŌUL  COŌRNM  LO

`f82v.8`  qokain.sheol.qoteedy.chedy.qokey.qokedy.qokol.chedy.chedy.lchy
→ COŌUI?  PAROL  COTRRNM  SARNM  COŌRM  COŌRNM  COŌOL  SARNM  SARNM  LSAM

`f82v.9`  solshedy.lchedy.dolshedy.qokal.sheckhy.shey.teeol.oteedy.qokedy
→ POLPARNM  LSARNM  NOLPARNM  COŌUL  PARSŌAM  PARM  TRROL  OTRRNM  COŌRNM

`f82v.10`  qotey.qokal.shoky.qokal.chedy.qotalchedy
→ COTRM  COŌUL  PAOŌM  COŌUL  SARNM  COTULSARNM

`f82v.11`  pcheol.dar.qokeey.cheeky.qokal.dal.shedy.pchdy.rol.qotedy.rol
→ MSAROL  NUR  COŌRRM  SARRŌM  COŌUL  NUL  PARNM  MSANM  ROL  COTRNM  ROL

`f82v.12`  dal.shol.dar.ol,qoky.qol.chedy.qokar.qoteytyqoky.chcthy.qoky
→ NUL  PAOL  NUR  OLCOŌM  COL  SARNM  COŌUR  COTRMTMCOŌM  SASTAM  COŌM

`f82v.13`  tchedy.qocthes.qokar.chckhy.qokain.cholkaiin.chckhdy.qokoldy
→ TSARNM  COSTARP  COŌUR  SASŌAM  COŌUI?  SAOLŌUII?  SASŌANM  COŌOLNM

`f82v.14`  dalchedy.lchey.rol.rol.cheey.s,ain.shey
→ NULSARNM  LSARM  ROL  ROL  SARRM  PUI?  PARM

`f82v.15`  tar.sheckhy.qokal.qokain.cheol.tedy.rchedy.pchedy.rsheol.dal
→ TUR  PARSŌAM  COŌUL  COŌUI?  SAROL  TRNM  RSARNM  MSARNM  RPAROL  NUL

`f82v.16`  qokedy.lchey.cheey.raiin.shes.qokchey.qokain.okal.dy.lchedam
→ COŌRNM  LSARM  SARRM  RUII?  PARP  COŌSARM  COŌUI?  OŌUL  NM  LSARNUS

`f82v.17`  or,ain.shedy.qok,char.okai.qokeedy.rcheey.qotedy.chtedy.rches,aly
→ ORUI?  PARNM  COŌSAUR  OŌUI  COŌRRNM  RSARRM  COTRNM  SATRNM  RSARPULM

`f82v.18`  ykeedy.qokeedy.chedy.qokar.okeey.lkedy.qokal.olkeedy.qokeedy.oky
→ MŌRRNM  COŌRRNM  SARNM  COŌUR  OŌRRM  LŌRNM  COŌUL  OLŌRRNM  COŌRRNM  OŌM

`f82v.19`  qokol.chedy.cheal.chedy.oty,chdy.dy.checkhy.otal,chl,s
→ COŌOL  SARNM  SARUL  SARNM  OTMSANM  NM  SARSŌAM  OTULSALP

`f82v.20`  tolsheol.qokedy.qolkedy.rshedy.qokedy.rsheedar.oinoly
→ TOLPAROL  COŌRNM  COLŌRNM  RPARNM  COŌRNM  RPARRNUR  OI?OLM

`f82v.21`  dain.chey.qokeeey.qoky.okaiin.okain.olkain.otain.okar,aly
→ NUI?  SARM  COŌRRRM  COŌM  OŌUII?  OŌUI?  OLŌUI?  OTUI?  OŌURULM

`f82v.22`  qokain.chedy.qolkshey.qotal.shey.qokain.ol,checkhy.ly
→ COŌUI?  SARNM  COLŌPARM  COTUL  PARM  COŌUI?  OLSARSŌAM  LM

`f82v.23`  yshedy.qolchey.qolaiin.otain.olkeedy.qotshedy.oll
→ MPARNM  COLSARM  COLUII?  OTUI?  OLŌRRNM  COTPARNM  OLL

`f82v.24`  dshedy.qokaiin.olchedy.qokal.shedy.qotal.dytar,y,l@152;l
→ NPARNM  COŌUII?  OLSARNM  COŌUL  PARNM  COTUL  NMTURMLL

`f82v.25`  qok.sheol.kechey.qoty.ral.tchdarol.sheytchdy.qokal
→ COŌ  PAROL  ŌRSARM  COTM  RUL  TSANUROL  PARMTSANM  COŌUL

`f82v.26`  saiin.shey.qokol.chol.qol.sheedy.qokal.shedy.qokaiin
→ PUII?  PARM  COŌOL  SAOL  COL  PARRNM  COŌUL  PARNM  COŌUII?

`f82v.27`  qokain.sheal.qolchedy.qokaiir.olkaiin.shedy
→ COŌUI?  PARUL  COLSARNM  COŌUIIR  OLŌUII?  PARNM

`f82v.28`  tchal.olkair.sheeky.qolchey.qokar.shey.qokain.otshedy
→ TSAUL  OLŌUIR  PARRŌM  COLSARM  COŌUR  PARM  COŌUI?  OTPARNM

`f82v.29`  daiin.chey.qoky.shedy.qokaiin.olkeedy.qokechedy.qotar
→ NUII?  SARM  COŌM  PARNM  COŌUII?  OLŌRRNM  COŌRSARNM  COTUR

`f82v.30`  pol.olor.chey.qokain.shedy.qokaiin.olchesy.ol.r.aindar
→ MOL  OLOR  SARM  COŌUI?  PARNM  COŌUII?  OLSARPM  OL  R  UI?NUR

`f82v.31`  qokeey.r,ain.chey.qolkain.oky.otaly.qokal,{i'h},olshalsy
→ COŌRRM  RUI?  SARM  COLŌUI?  OŌM  OTULM  COŌULIAOLPAULPM

`f82v.32`  sar.al.loraiin.chey.qokain.o,roiiin
→ PUR  UL  LORUII?  SARM  COŌUI?  OROIII?

`f82v.33`  qody.shar.a{ith}y.qokchey.kchey.olkain.opchedy.qfol.shty.oral
→ CONM  PAUR  UITAM  COŌSARM  ŌSARM  OLŌUI?  OMSARNM  C?OL  PATM  ORUL

`f82v.34`  yckhey.qokain.cheky.otaiin.olor.okain.qolkeey.qotar.olkain
→ MSŌARM  COŌUI?  SARŌM  OTUII?  OLOR  OŌUI?  COLŌRRM  COTUR  OLŌUI?

`f82v.35`  cthor.chey.qsain.qokeey.qokain.otain.otal.okeedy.qokal.dym
→ STAOR  SARM  CPUI?  COŌRRM  COŌUI?  OTUI?  OTUL  OŌRRNM  COŌUL  NMS

`f82v.36`  saiin.shey.qokeedy.qokar.sheecthey.qokaiin.daltedy.rcheald
→ PUII?  PARM  COŌRRNM  COŌUR  PARRSTARM  COŌUII?  NULTRNM  RSARULN

`f82v.37`  sol.chey.r.alchey.chol.olkol.chckhy.dalchckhy.olkain.olkeeyr
→ POL  SARM  R  ULSARM  SAOL  OLŌOL  SASŌAM  NULSASŌAM  OLŌUI?  OLŌRRMR

`f82v.38`  pcheol.shedy.qokaiin.sholdy
→ MSAROL  PARNM  COŌUII?  PAOLNM

`f82v.39`  olkeedy
→ OLŌRRNM

`f82v.40`  okalchy
→ OŌULSAM

`f82v.41`  okain
→ OŌUI?

`f82v.42`  ok[a:e]oky
→ OŌUOŌM

`f82v.43`  okedor
→ OŌRNOR

`f82v.44`  okol
→ OŌOL

`f82v.45`  okoldy
→ OŌOLNM

`f82v.46`  olkol
→ OLŌOL

`f82v.47`  otedol
→ OTRNOL

`f82v.48`  oteedy
→ OTRRNM

### f83r  ·  balneological

`f83r.1`  tchedy.lpchedy.op{ch'}edy.chepol.pchedar.shedy.qopchedy
→ TSARNM  LMSARNM  OMSARNM  SARMOL  MSARNUR  PARNM  COMSARNM

`f83r.2`  sol.cheey.qokaiin.shol.lchs.shey.qoteedy.rches.ar.chedy.dor
→ POL  SARRM  COŌUII?  PAOL  LSAP  PARM  COTRRNM  RSARP  UR  SARNM  NOR

`f83r.3`  olkeedy.qotal.chkeedy.chey.daiin.chey.lchedy.qokaiin.qotal.dar
→ OLŌRRNM  COTUL  SAŌRRNM  SARM  NUII?  SARM  LSARNM  COŌUII?  COTUL  NUR

`f83r.4`  qokshedy.chedy.qokedy.chkedy.daiin.shetar.shedy.qekaiin.chedy
→ COŌPARNM  SARNM  COŌRNM  SAŌRNM  NUII?  PARTUR  PARNM  CRŌUII?  SARNM

`f83r.5`  d{ch'}eey.qotaiin.checkhy.qoty.che[g:d].shedy.qokeey.rchedy.qoteedy.lo
→ NSARRM  COTUII?  SARSŌAM  COTM  SAR?  PARNM  COŌRRM  RSARNM  COTRRNM  LO

`f83r.6`  schedy.chedchy.qokal.olchedy.qokaiin.chedy.qokeedy.lchedy.qoky
→ PSARNM  SARNSAM  COŌUL  OLSARNM  COŌUII?  SARNM  COŌRRNM  LSARNM  COŌM

`f83r.7`  solshed.lsheedy.qeeedy.qoky.o,qol.rsheedy.qokedy.qoteedy.qoteedy
→ POLPARN  LPARRNM  CRRRNM  COŌM  OCOL  RPARRNM  COŌRNM  COTRRNM  COTRRNM

`f83r.8`  pchedal.otedy.shecthedchy.qoky.chedy.chary
→ MSARNUL  OTRNM  PARSTARNSAM  COŌM  SARNM  SAURM

`f83r.9`  pchor.checphedy.qokedy.lsheedy.qokchdy.r.shedkedy.qopshdy,qopy
→ MSAOR  SARSMARNM  COŌRNM  LPARRNM  COŌSANM  R  PARNŌRNM  COMPANMCOMM

`f83r.10`  olkeey.rchs.cheeb.ols.aiin.skal.dain.cthal,s,aiin.chky.lal.sam
→ OLŌRRM  RSAP  SARR?  OLP  UII?  PŌUL  NUI?  STAULPUII?  SAŌM  LUL  PUS

`f83r.11`  sor.shedy.qokaiin.chkain.shcthey.qokedy.okair.sheedy.lchedy.lo
→ POR  PARNM  COŌUII?  SAŌUI?  PASTARM  COŌRNM  OŌUIR  PARRNM  LSARNM  LO

`f83r.12`  qockhol.sheckhy.otal.qokeal.sheckhdy.{ck}al.okedy.qokedy.qokal
→ COSŌAOL  PARSŌAM  OTUL  COŌRUL  PARSŌANM  SŌUL  OŌRNM  COŌRNM  COŌUL

`f83r.13`  salcheol.tar.shedy.s,altedy.sair.qokedy.q{cphh}edy.lchcphedy.ldar
→ PULSAROL  TUR  PARNM  PULTRNM  PUIR  COŌRNM  CSMAARNM  LSASMARNM  LNUR

`f83r.14`  qokchedy.qokeedy.shedy.qokshedy.dal.lchedy.qokaiin.shcthy.dal.sy
→ COŌSARNM  COŌRRNM  PARNM  COŌPARNM  NUL  LSARNM  COŌUII?  PASTAM  NUL  PM

`f83r.15`  saiin.shedal.shecthy.chey,tal.shcthy.dalchdy.qotchedy.lchedy
→ PUII?  PARNUL  PARSTAM  SARMTUL  PASTAM  NULSANM  COTSARNM  LSARNM

`f83r.16`  tchedy.qokchdy.cheedar.chldaiin.chedy.qokain.checthy.chealror
→ TSARNM  COŌSANM  SARRNUR  SALNUII?  SARNM  COŌUI?  SARSTAM  SARULROR

`f83r.17`  dche[o:?]kedy.lkeed.shckhey.ytaiin.shechy.schety
→ NSAROŌRNM  LŌRRN  PASŌARM  MTUII?  PARSAM  PSARTM

`f83r.18`  pdalshdy.shocphedy.otor.shedy.opshedy.otshdy.qokedol.shdy.soldy
→ MNULPANM  PAOSMARNM  OTOR  PARNM  OMPARNM  OTPANM  COŌRNOL  PANM  POLNM

`f83r.19`  sar.shedaiin.ockhey.sain.ched.shedy.qetal.dal.shedy.shey.lchedy
→ PUR  PARNUII?  OSŌARM  PUI?  SARN  PARNM  CRTUL  NUL  PARNM  PARM  LSARNM

`f83r.20`  solkeedy.qoteedy.qokeey.qokedy.sol.cheeety.qokedy.qoky.saiin
→ POLŌRRNM  COTRRNM  COŌRRM  COŌRNM  POL  SARRRTM  COŌRNM  COŌM  PUII?

`f83r.21`  solkeedy.qokedy.otedy.sol,chedy.lkedy.qokchedy.qokedy.chckhdy.sar
→ POLŌRRNM  COŌRNM  OTRNM  POLSARNM  LŌRNM  COŌSARNM  COŌRNM  SASŌANM  PUR

`f83r.22`  schedair.otchedy.qokeedy.chedain.chedy.qotedaiin.otaiin.otedy.ldy
→ PSARNUIR  OTSARNM  COŌRRNM  SARNUI?  SARNM  COTRNUII?  OTUII?  OTRNM  LNM

`f83r.23`  tchedy.qotedy.qokal.shedy.qokedy.shecthedy.shecthy.otor.chedy
→ TSARNM  COTRNM  COŌUL  PARNM  COŌRNM  PARSTARNM  PARSTAM  OTOR  SARNM

`f83r.24`  soiiin.checthy.chety.otaiin.olsaly.shedy
→ POIII?  SARSTAM  SARTM  OTUII?  OLPULM  PARNM

`f83r.25`  qokeedy.qolchey.qokeey.qokedy.chedy.otal
→ COŌRRNM  COLSARM  COŌRRM  COŌRNM  SARNM  OTUL

`f83r.26`  otchey.qokeey.qoky.tol.shedy.qokylddy
→ OTSARM  COŌRRM  COŌM  TOL  PARNM  COŌMLNNM

`f83r.27`  dain.chedy.qokeedy.shckhedy.shckhedy
→ NUI?  SARNM  COŌRRNM  PASŌARNM  PASŌARNM

`f83r.28`  saiin.cheeky.sheey.qokedy.shedy.oldy
→ PUII?  SARRŌM  PARRM  COŌRNM  PARNM  OLNM

`f83r.29`  salche'dy.cheey.qody.kesd.oldy
→ PULSARNM  SARRM  CONM  ŌRPN  OLNM

`f83r.30`  s,okeedy.qokeedy.qoky.saii@208;
→ POŌRRNM  COŌRRNM  COŌM  PUII

`f83r.31`  techedy.qotchedy.okeedy,ldy
→ TRSARNM  COTSARNM  OŌRRNMLNM

`f83r.32`  [?:s]cheol.qokchedy.lchedy.qokey
→ SAROL  COŌSARNM  LSARNM  COŌRM

`f83r.33`  sy.s,aiin.sheekchy.qokey.sain
→ PM  PUII?  PARRŌSAM  COŌRM  PUI?

`f83r.34`  shky.lchedy.dolshed.qokchy
→ PAŌM  LSARNM  NOLPARN  COŌSAM

`f83r.35`  saiin.cheky.okeeol.okain.chdy
→ PUII?  SARŌM  OŌRROL  OŌUI?  SANM

`f83r.36`  so[r:s],aiin.shy.shey.lshedy,qoky
→ PORUII?  PAM  PARM  LPARNMCOŌM

`f83r.37`  sol.lkedy.lchedy.qokol.shedy
→ POL  LŌRNM  LSARNM  COŌOL  PARNM

`f83r.38`  or.chey.qockhey.dairydy
→ OR  SARM  COSŌARM  NUIRMNM

`f83r.39`  qokain.shey.kain.chckhal
→ COŌUI?  PARM  ŌUI?  SASŌAUL

`f83r.40`  solchedy.olchedy.chedaiin
→ POLSARNM  OLSARNM  SARNUII?

`f83r.41`  solkey.lchedy.qolkain.dal
→ POLŌRM  LSARNM  COLŌUI?  NUL

`f83r.42`  sol.ol.chcthdy.l.chedy.lchdy
→ POL  OL  SASTANM  L  SARNM  LSANM

`f83r.43`  daiin.sheol.chedy.qotal.sar
→ NUII?  PAROL  SARNM  COTUL  PUR

`f83r.44`  skar.shedy
→ PŌUR  PARNM

`f83r.45`  chtorol
→ SATOROL

`f83r.46`  olsaiin
→ OLPUII?

`f83r.47`  otchdy.qokchdy.shedal
→ OTSANM  COŌSANM  PARNUL

`f83r.48`  dal.cheol.lol.chdal.aiin
→ NUL  SAROL  LOL  SANUL  UII?

`f83r.49`  sol.daiiin.chedy
→ POL  NUIII?  SARNM

`f83r.50`  sasoldal
→ PUPOLNUL

`f83r.51`  darolsy
→ NUROLPM

`f83r.52`  solkeey.qekey.raly.ol
→ POLŌRRM  CRŌRM  RULM  OL

`f83r.53`  solchkal.cheol.qotar.ol
→ POLSAŌUL  SAROL  COTUR  OL

`f83r.54`  daiin.ol.dain.chey.ldalor
→ NUII?  OL  NUI?  SARM  LNULOR

`f83r.55`  sol.rtain.cthal
→ POL  RTUI?  STAUL

### f83v  ·  balneological

`f83v.1`  poldaky.dalol.otedy.chtair.opchedy.qotal.chedy.chepchedy.opchey
→ MOLNUŌM  NULOL  OTRNM  SATUIR  OMSARNM  COTUL  SARNM  SARMSARNM  OMSARM

`f83v.2`  dol.shedy.qokedy.shedy.qotedar.checthedy.qokedy.qotal.chey.dar
→ NOL  PARNM  COŌRNM  PARNM  COTRNUR  SARSTARNM  COŌRNM  COTUL  SARM  NUR

`f83v.3`  qotain.chcthy.dal,olkedy.shedy.qotaldy.qokaiin.dair.shedy.oteey
→ COTUI?  SASTAM  NULOLŌRNM  PARNM  COTULNM  COŌUII?  NUIR  PARNM  OTRRM

`f83v.4`  dain.sheedy.oteeody.doldy.qotedy.qokeedy.qokedar.sheoldy.qol,oly
→ NUI?  PARRNM  OTRRONM  NOLNM  COTRNM  COŌRRNM  COŌRNUR  PAROLNM  COLOLM

`f83v.5`  qokal.shedy.qotain.chedy.chedol.daiin.otaiin.shedy.qokeedy.okaiin
→ COŌUL  PARNM  COTUI?  SARNM  SARNOL  NUII?  OTUII?  PARNM  COŌRRNM  OŌUII?

`f83v.6`  chedy.qoteedy.otalshedy.sol.chl.?es.okeol.shedy.qokolchedy.qokal
→ SARNM  COTRRNM  OTULPARNM  POL  SAL  RP  OŌROL  PARNM  COŌOLSARNM  COŌUL

`f83v.7`  qokeey.oteey.qokalol.chedy.dy.dol.qokal.olkshedy.qokeedy.qokal
→ COŌRRM  OTRRM  COŌULOL  SARNM  NM  NOL  COŌUL  OLŌPARNM  COŌRRNM  COŌUL

`f83v.8`  rolkeedy.qokaiin.okaiin.ched.okchey
→ ROLŌRRNM  COŌUII?  OŌUII?  SARN  OŌSARM

`f83v.9`  ololary
→ OLOLURM

`f83v.10`  okarchy
→ OŌURSAM

`f83v.11`  pchedar.shedal.qokar.shedal<->okchdy.qokedy.okail.shedy.qoky.lsheg
→ MSARNUR  PARNUL  COŌUR  PARNULOŌSANM  COŌRNM  OŌUIL  PARNM  COŌM  LPAR?

`f83v.12`  daiin.shckhy.qoeeo.lldar.cheey.qoal.qokeedy.olkar.sheedy.qokain.olal
→ NUII?  PASŌAM  CORRO  LLNUR  SARRM  COUL  COŌRRNM  OLŌUR  PARRNM  COŌUI?  OLUL

`f83v.13`  qol,chey.qo.lched.qolky.qokal.chedy.chedy.daiin.chckhy.cheor.ol.lal
→ COLSARM  CO  LSARN  COLŌM  COŌUL  SARNM  SARNM  NUII?  SASŌAM  SAROR  OL  LUL

`f83v.14`  salched.qol,shedy.qolchedy.qolchdy.qol.rchedy.cheol,qokeor.sholdy
→ PULSARN  COLPARNM  COLSARNM  COLSANM  COL  RSARNM  SAROLCOŌROR  PAOLNM

`f83v.15`  qokaiin.cheol.shey.qokeey.cheol.dal.cheeaiin.olkeedy.qokal.chaloly
→ COŌUII?  SAROL  PARM  COŌRRM  SAROL  NUL  SARRUII?  OLŌRRNM  COŌUL  SAULOLM

`f83v.16`  daiin.qokal.sheckhey.qokeey.chal.qokeey.qokaiin.chedy.sar.al
→ NUII?  COŌUL  PARSŌARM  COŌRRM  SAUL  COŌRRM  COŌUII?  SARNM  PUR  UL

`f83v.17`  qokain.cheeal.qokaiin.sheol.qokear.cheedy.olcheey.qokal.qoka[?:n]y
→ COŌUI?  SARRUL  COŌUII?  PAROL  COŌRUR  SARRNM  OLSARRM  COŌUL  COŌUM

`f83v.18`  s,olkeedy.qokeedy.qokeedy.saiin.okaiin.chedy.qokeedy.qolkeedy
→ POLŌRRNM  COŌRRNM  COŌRRNM  PUII?  OŌUII?  SARNM  COŌRRNM  COLŌRRNM

`f83v.19`  qolchedy.qolteedy.qokeedy.qokal.okaiin.chear.checkhy.dal.checkhdy
→ COLSARNM  COLTRRNM  COŌRRNM  COŌUL  OŌUII?  SARUR  SARSŌAM  NUL  SARSŌANM

`f83v.20`  tocthey.cheor.olol.cheol.tedy.sheckhal.sheeckhy.cheal
→ TOSTARM  SAROR  OLOL  SAROL  TRNM  PARSŌAUL  PARRSŌAM  SARUL

`f83v.21`  qokeed.qokaiin.sheolkain.sheol.olkeedy,l,shedy
→ COŌRRN  COŌUII?  PAROLŌUI?  PAROL  OLŌRRNMLPARNM

`f83v.22`  char.qokar.cheolkain.shckhey.qokal.cheor,ols
→ SAUR  COŌUR  SAROLŌUI?  PASŌARM  COŌUL  SAROROLP

`f83v.23`  qol,aiiin.chckhedy.sheol.qokaiin.shckhy.lchey
→ COLUIII?  SASŌARNM  PAROL  COŌUII?  PASŌAM  LSARM

`f83v.24`  ol,cheedy.qokeedy.qokain.dalshal.shldy.lor
→ OLSARRNM  COŌRRNM  COŌUI?  NULPAUL  PALNM  LOR

`f83v.25`  y.shey.otechd.ar.okol.dal.shedy.qokaly
→ M  PARM  OTRSAN  UR  OŌOL  NUL  PARNM  COŌULM

`f83v.26`  sal.chear.shey.qokar.shedy.qokain.ollchy
→ PUL  SARUR  PARM  COŌUR  PARNM  COŌUI?  OLLSAM

`f83v.27`  dsheol.cheol.shedy.qokaiin.cheeky.lols
→ NPAROL  SAROL  PARNM  COŌUII?  SARRŌM  LOLP

`f83v.28`  qol.shol.cheedy.qol.oqo.qokain.olsheam
→ COL  PAOL  SARRNM  COL  OCO  COŌUI?  OLPARUS

`f83v.29`  ol.cheal.shedy.chey,tal.shedal.dalshdy
→ OL  SARUL  PARNM  SARMTUL  PARNUL  NULPANM

`f83v.30`  qokaiin.chedy.qokal.otal,chedy.qotals
→ COŌUII?  SARNM  COŌUL  OTULSARNM  COTULP

`f83v.31`  oy[ch:sh]ey.qol.qokal.chedy,qoty
→ OMSARM  COL  COŌUL  SARNMCOTM

`f83v.32`  qol.olain.sheol.qo.qokal.sheol
→ COL  OLUI?  PAROL  CO  COŌUL  PAROL

`f83v.33`  shey.opchey.cthey.ol{oh}y
→ PARM  OMSARM  STARM  OLOAM

`f83v.34`  okchdy
→ OŌSANM

`f83v.35`  okaiin
→ OŌUII?

### f84r  ·  balneological

`f84r.1`  ololal
→ OLOLUL

`f84r.2`  or.shekar
→ OR  PARŌUR

`f84r.3`  ydy
→ MNM

`f84r.4`  okedy
→ OŌRNM

`f84r.5`  loly
→ LOLM

`f84r.6`  doiir
→ NOIIR

`f84r.7`  olshy
→ OLPAM

`f84r.8`  otedy
→ OTRNM

`f84r.9`  lkol
→ LŌOL

`f84r.10`  okolshy
→ OŌOLPAM

`f84r.11`  otoly
→ OTOLM

`f84r.12`  dshedy
→ NPARNM

`f84r.13`  kol.chedy.qokeey.otedy.dytedy.okeedy.olshed.opshed.ykshedy.qotedy.opoly
→ ŌOL  SARNM  COŌRRM  OTRNM  NMTRNM  OŌRRNM  OLPARN  OMPARN  MŌPARNM  COTRNM  OMOLM

`f84r.14`  tol.or,sheey.chckhdy.schckhy.dal.y,shedy.otedy.qol.or.ol.eedy.qokeey.or,oly
→ TOL  ORPARRM  SASŌANM  PSASŌAM  NUL  MPARNM  OTRNM  COL  OR  OL  RRNM  COŌRRM  OROLM

`f84r.15`  qokeey.dar.shedy.qokedy.qokeedy.qokedy.chedy.okain.chey.qokedy.dar.olardy
→ COŌRRM  NUR  PARNM  COŌRNM  COŌRRNM  COŌRNM  SARNM  OŌUI?  SARM  COŌRNM  NUR  OLURNM

`f84r.16`  tor.shedytedy.o'l.ol,cheol.shedy.shckhy.qokal.olkedy
→ TOR  PARNMTRNM  OL  OLSAROL  PARNM  PASŌAM  COŌUL  OLŌRNM

`f84r.17`  pchol.cphol.sol,teol.tedy.qotedy.qokeedy.qokeey.ol,keedy.teyqokedy.qopor.oly
→ MSAOL  SMAOL  POLTROL  TRNM  COTRNM  COŌRRNM  COŌRRM  OLŌRRNM  TRMCOŌRNM  COMOR  OLM

`f84r.18`  otchy.olshedy.qokedy.shedy.okedy.shckhy.chckhy.olchey.schey.dal.chckhy.ral
→ OTSAM  OLPARNM  COŌRNM  PARNM  OŌRNM  PASŌAM  SASŌAM  OLSARM  PSARM  NUL  SASŌAM  RUL

`f84r.19`  qokey.sol.yqokain.qolkeey.qotedy.qokain.shedy.salchedy
→ COŌRM  POL  MCOŌUI?  COLŌRRM  COTRNM  COŌUI?  PARNM  PULSARNM

`f84r.20`  psholpchcfhdy.qokeedy.dy.qokedy.daiin.shckhedy.qokaiin.checthy.dar.checthy.am
→ MPAOLMSAS?ANM  COŌRRNM  NM  COŌRNM  NUII?  PASŌARNM  COŌUII?  SARSTAM  NUR  SARSTAM  US

`f84r.21`  qokaiin.chol.cheky.okal,y,chey.okal.chedy,tor,y.otshedy.qokey.l,shedy
→ COŌUII?  SAOL  SARŌM  OŌULMSARM  OŌUL  SARNMTORM  OTPARNM  COŌRM  LPARNM

`f84r.22`  qotchsdy.ykeedy.qokal.ol.shedy.qokedy.qokeedy.qokeedy.chedy.raiin.chey.otar,dar
→ COTSAPNM  MŌRRNM  COŌUL  OL  PARNM  COŌRNM  COŌRRNM  COŌRRNM  SARNM  RUII?  SARM  OTURNUR

`f84r.23`  dar.sheor.shcthy.qokeor.qotedy.rshedy.qolchey.oteey.qol.shedy.ol.dain.ol,or
→ NUR  PAROR  PASTAM  COŌROR  COTRNM  RPARNM  COLSARM  OTRRM  COL  PARNM  OL  NUI?  OLOR

`f84r.24`  pol.tar.shedy,qokedy.okal.shey.qokar,chckhy.otchey.qokchedy.chey.qokaiin
→ MOL  TUR  PARNMCOŌRNM  OŌUL  PARM  COŌURSASŌAM  OTSARM  COŌSARNM  SARM  COŌUII?

`f84r.25`  pchedy.qotchedy.otaiiin.chcthy.shedy.otedy.qoty.qotedy.ol,okedy.otedy.ram
→ MSARNM  COTSARNM  OTUIII?  SASTAM  PARNM  OTRNM  COTM  COTRNM  OLOŌRNM  OTRNM  RUS

`f84r.26`  qotol.sh{cthh}y.oty.dar.shcthy.schdy.qokeedy.olkey
→ COTOL  PASTAAM  OTM  NUR  PASTAM  PSANM  COŌRRNM  OLŌRM

`f84r.27`  p[a:o]lchd.@146;chedy.shcthy.olky.dar.opalkaiin.o,qofchedy.or,aiiin.ofoly.oroly
→ MULSAN  SARNM  PASTAM  OLŌM  NUR  OMULŌUII?  OCO?SARNM  ORUIII?  O?OLM  OROLM

`f84r.28`  sar.ol.olaiin.y,qol,y,qor.or.ckhedy.chkedy.okain.shedy.qokolchedy.olain
→ PUR  OL  OLUII?  MCOLMCOR  OR  SŌARNM  SAŌRNM  OŌUI?  PARNM  COŌOLSARNM  OLUI?

`f84r.29`  qokeedy.okeey.dar.olchedy.qsolkeedy.rar.checkhy.otar.chedy.olchcthy.lor
→ COŌRRNM  OŌRRM  NUR  OLSARNM  CPOLŌRRNM  RUR  SARSŌAM  OTUR  SARNM  OLSASTAM  LOR

`f84r.30`  dchdy.qokedy.ol,chckhy.olchdy.sar,or.ykeedy.chetey.rain.shedy.shekam
→ NSANM  COŌRNM  OLSASŌAM  OLSANM  PUROR  MŌRRNM  SARTRM  RUI?  PARNM  PARŌUS

`f84r.31`  ykchdar.or.arar.shedy.qokal.daiin.shedy.olkedy.qokedy.qoky.chedy.daiin
→ MŌSANUR  OR  URUR  PARNM  COŌUL  NUII?  PARNM  OLŌRNM  COŌRNM  COŌM  SARNM  NUII?

`f84r.32`  qotar.ytedy.tedy.dar.olkedy.qotedy.shckhy.chtol.tedy.dar.or,oly
→ COTUR  MTRNM  TRNM  NUR  OLŌRNM  COTRNM  PASŌAM  SATOL  TRNM  NUR  OROLM

`f84r.33`  shol.tchdy,tedy.ykain.shey.cheol,y,tedy.ol,kedy.okedar.ol,keed,ol,ary
→ PAOL  TSANMTRNM  MŌUI?  PARM  SAROLMTRNM  OLŌRNM  OŌRNUR  OLŌRRNOLURM

`f84r.34`  dsheyteey.sor.ol.shedy.daraldy.otedaiin.shckhchy.chckhy.daiin,aryly
→ NPARMTRRM  POR  OL  PARNM  NURULNM  OTRNUII?  PASŌASAM  SASŌAM  NUII?URMLM

`f84r.35`  qokal.daiin.dain.otey.cheor.air.shckhy.or,air,oro
→ COŌUL  NUII?  NUI?  OTRM  SAROR  UIR  PASŌAM  ORUIRORO

`f84r.36`  shey.dar.shey.dain.aiin.shedy.orol,ykar.okedy.qoky.chedy.okedar.chey.alol
→ PARM  NUR  PARM  NUI?  UII?  PARNM  OROLMŌUR  OŌRNM  COŌM  SARNM  OŌRNUR  SARM  ULOL

`f84r.37`  qoteedy.qokol.otedy.shedy.qokeedy.dal,ol,dam
→ COTRRNM  COŌOL  OTRNM  PARNM  COŌRRNM  NULOLNUS

`f84r.38`  s,or,olchdy.lshedy.qokchy.dol.otedy.ytchor,olky
→ POROLSANM  LPARNM  COŌSAM  NOL  OTRNM  MTSAOROLŌM

`f84r.39`  dshedy.sheedy.qokedy.chedy.teedy.qokeedy
→ NPARNM  PARRNM  COŌRNM  SARNM  TRRNM  COŌRRNM

`f84r.40`  qokeedy.dkedy.olshedy.qokal.shckhy.olkeedy
→ COŌRRNM  NŌRNM  OLPARNM  COŌUL  PASŌAM  OLŌRRNM

`f84r.41`  dsheedy.oteedy.qotar.chekar.orshedy.saiin
→ NPARRNM  OTRRNM  COTUR  SARŌUR  ORPARNM  PUII?

`f84r.42`  okaiin.otchdy.qokain.shedy.qokeey.qotedy
→ OŌUII?  OTSANM  COŌUI?  PARNM  COŌRRM  COTRNM

`f84r.43`  qokain.otchedy.skeey.rcheky.dal.okeedy
→ COŌUI?  OTSARNM  PŌRRM  RSARŌM  NUL  OŌRRNM

`f84r.44`  ykedy.qotedy.chcthy.ol,chcthy.dar.ar,ory
→ MŌRNM  COTRNM  SASTAM  OLSASTAM  NUR  URORM

`f84r.45`  yteolchedy.qokor.shekedy.okedy.{cthh}y.dam
→ MTROLSARNM  COŌOR  PARŌRNM  OŌRNM  STAAM  NUS

`f84r.46`  d[ch:?]edy.qokedy.ar.oror.okedy.okedy
→ NSARNM  COŌRNM  UR  OROR  OŌRNM  OŌRNM

`f84r.47`  otaly
→ OTULM

### f84v  ·  balneological

`f84v.1`  otdy.dar.chdy.dar,oram
→ OTNM  NUR  SANM  NURORUS

`f84v.2`  soiin.okeeey.sol.okaly
→ POII?  OŌRRRM  POL  OŌULM

`f84v.3`  kor.shedy.otedy.qotedy.otedar.cfhdarol
→ ŌOR  PARNM  OTRNM  COTRNM  OTRNUR  S?ANUROL

`f84v.4`  oteey.qoteey.okey.chetain.sheeky.daiin,al
→ OTRRM  COTRRM  OŌRM  SARTUI?  PARRŌM  NUII?UL

`f84v.5`  qokeey.oteedy.shedy.qokeed,or.okeedy.ry
→ COŌRRM  OTRRNM  PARNM  COŌRRNOR  OŌRRNM  RM

`f84v.6`  ykeedy.qoeedy.olkeey.sheky.qokeey
→ MŌRRNM  CORRNM  OLŌRRM  PARŌM  COŌRRM

`f84v.7`  poiin.ol,kedy.okedy.qoky.ok[ch:ee]dy.qokey
→ MOII?  OLŌRNM  OŌRNM  COŌM  OŌSANM  COŌRM

`f84v.8`  qokedy.okedy.qokeedy.okeedy.shedy.qoky
→ COŌRNM  OŌRNM  COŌRRNM  OŌRRNM  PARNM  COŌM

`f84v.9`  {ch'}eol.qolchey.okeedy.saiin.okeedy.chkeedy
→ SAROL  COLSARM  OŌRRNM  PUII?  OŌRRNM  SAŌRRNM

`f84v.10`  qoteed.otedy.sheedy.qokeedy.qoeedy.okeedy.dam
→ COTRRN  OTRNM  PARRNM  COŌRRNM  CORRNM  OŌRRNM  NUS

`f84v.11`  {ch'}edy.qoeedy.ol.cheey.daiin.chckhedy.dain.dy.daiin
→ SARNM  CORRNM  OL  SARRM  NUII?  SASŌARNM  NUI?  NM  NUII?

`f84v.12`  qokees.qokedy.otedy.shedy.qokedy.dol.olkeedy.dol.teedam
→ COŌRRP  COŌRNM  OTRNM  PARNM  COŌRNM  NOL  OLŌRRNM  NOL  TRRNUS

`f84v.13`  shedol.chedy.okedy.otal.chckhedy.qotedy.dokedy.dol.lkeey.qokydy
→ PARNOL  SARNM  OŌRNM  OTUL  SASŌARNM  COTRNM  NOŌRNM  NOL  LŌRRM  COŌMNM

`f84v.14`  dshey.olkeey.dol.ol.otedy.okedy.okedy.qokedy.dal.dar.ol.chedy.sain
→ NPARM  OLŌRRM  NOL  OL  OTRNM  OŌRNM  OŌRNM  COŌRNM  NUL  NUR  OL  SARNM  PUI?

`f84v.15`  qokshedy.qokeed,y,daiin.checthy.okal.ol.kedy.chedy.dolkedy.okedam
→ COŌPARNM  COŌRRNMNUII?  SARSTAM  OŌUL  OL  ŌRNM  SARNM  NOLŌRNM  OŌRNUS

`f84v.16`  soiiin.ol.chedy.qol.tedy.shey.qokedy.qokey.dol,y.ol,shedy.qokedy
→ POIII?  OL  SARNM  COL  TRNM  PARM  COŌRNM  COŌRM  NOLM  OLPARNM  COŌRNM

`f84v.17`  qokeey.otol.chedy.daiin.dol.sheedy.chedy.okedy.r,kchdy.kol.koldy
→ COŌRRM  OTOL  SARNM  NUII?  NOL  PARRNM  SARNM  OŌRNM  RŌSANM  ŌOL  ŌOLNM

`f84v.18`  dsheey.qokeedy.ykedy.qokor.shedy.qoky.dol.shckhy.qokain.ol.koldy
→ NPARRM  COŌRRNM  MŌRNM  COŌOR  PARNM  COŌM  NOL  PASŌAM  COŌUI?  OL  ŌOLNM

`f84v.19`  solkes.olokar.sheky.shkol.qokar.chdy.tal,shedy.okar.okedy.shedy,dy
→ POLŌRP  OLOŌUR  PARŌM  PAŌOL  COŌUR  SANM  TULPARNM  OŌUR  OŌRNM  PARNMNM

`f84v.20`  tolshy.qoky.qokedy.shedy.qoteedy
→ TOLPAM  COŌM  COŌRNM  PARNM  COTRRNM

`f84v.21`  pcholshedy.shtol.okedy.opcholor.kchdy.ofched,y,r.aiin.cfheey.ols
→ MSAOLPARNM  PATOL  OŌRNM  OMSAOLOR  ŌSANM  O?SARNMR  UII?  S?ARRM  OLP

`f84v.22`  oshey.tedy.okain.shey.qokedy.kchdy.okedy.okey.dy.okedy.olshdy
→ OPARM  TRNM  OŌUI?  PARM  COŌRNM  ŌSANM  OŌRNM  OŌRM  NM  OŌRNM  OLPANM

`f84v.23`  qokeey.olkaiin.okol.shedy.cthy,korol.oror
→ COŌRRM  OLŌUII?  OŌOL  PARNM  STAMŌOROL  OROR

`f84v.24`  y,cheey.okeedy.olkain.olchey.saiin.oly
→ MSARRM  OŌRRNM  OLŌUI?  OLSARM  PUII?  OLM

`f84v.25`  qokain.okain.olol.okal,chedy.chedy
→ COŌUI?  OŌUI?  OLOL  OŌULSARNM  SARNM

`f84v.26`  ol.qokar.shdy.qol.otedy.olchedy
→ OL  COŌUR  PANM  COL  OTRNM  OLSARNM

`f84v.27`  y.or.shedy.qolkeedy.olchedy.olkal
→ M  OR  PARNM  COLŌRRNM  OLSARNM  OLŌUL

`f84v.28`  dal.shedy.qokedy.shedy.dain.daiin
→ NUL  PARNM  COŌRNM  PARNM  NUI?  NUII?

`f84v.29`  sain.shedy.qokeey.daiin.okedy.oldy
→ PUI?  PARNM  COŌRRM  NUII?  OŌRNM  OLNM

`f84v.30`  qokey.ol.keed.qokedy.qokey.qokeoly
→ COŌRM  OL  ŌRRN  COŌRNM  COŌRM  COŌROLM

`f84v.31`  chal.daiin.otal.chdy.otal.chckhor.aly
→ SAUL  NUII?  OTUL  SANM  OTUL  SASŌAOR  ULM

`f84v.32`  qokedy.shey.kal.okedy.yfchedy.tedy.lolor
→ COŌRNM  PARM  ŌUL  OŌRNM  M?SARNM  TRNM  LOLOR

`f84v.33`  shedy.qokey.qokedy.chey.dar.okey.okeshy.olchy
→ PARNM  COŌRM  COŌRNM  SARM  NUR  OŌRM  OŌRPAM  OLSAM

`f84v.34`  qokain.ol.chedy.alchey.s,al.or.chdy.dchey.okey.lchy
→ COŌUI?  OL  SARNM  ULSARM  PUL  OR  SANM  NSARM  OŌRM  LSAM

`f84v.35`  shor.ol.okain.shedy.olshedy.tol,okeedy.chedy.okedy.lol
→ PAOR  OL  OŌUI?  PARNM  OLPARNM  TOLOŌRRNM  SARNM  OŌRNM  LOL

`f84v.36`  qokey.sol,kedy.okey.lkain.shey.shes.ol.shedy.qokeey.ror
→ COŌRM  POLŌRNM  OŌRM  LŌUI?  PARM  PARP  OL  PARNM  COŌRRM  ROR

`f84v.37`  chckhy.qokaiin.shey.dain.qokeey.daiin.okaiin.qokal.dys
→ SASŌAM  COŌUII?  PARM  NUI?  COŌRRM  NUII?  OŌUII?  COŌUL  NMP

`f84v.38`  qokchey.qokeedy.okedy.dolor.ol.chedy.oteol.olol
→ COŌSARM  COŌRRNM  OŌRNM  NOLOR  OL  SARNM  OTROL  OLOL

`f84v.39`  lshedy.qol.aiin.okey.olchey.lchey.olshedy.shckhy.soly
→ LPARNM  COL  UII?  OŌRM  OLSARM  LSARM  OLPARNM  PASŌAM  POLM

`f84v.40`  yteedar.olkeey.olchey.qokey.lkeoldy.daiin,olkedy.ykaiin
→ MTRRNUR  OLŌRRM  OLSARM  COŌRM  LŌROLNM  NUII?OLŌRNM  MŌUII?

`f84v.41`  sor.otes.doltedy.otol.chedy
→ POR  OTRP  NOLTRNM  OTOL  SARNM

`f84v.42`  okar
→ OŌUR

`f84v.43`  ydairol
→ MNUIROL

`f84v.44`  ychckhy
→ MSASŌAM

`f84v.45`  dshedy
→ NPARNM

`f84v.46`  okchdy
→ OŌSANM

`f84v.47`  solchey
→ POLSARM

`f84v.48`  dair,oldy
→ NUIROLNM

`f84v.49`  darchy
→ NURSAM

`f84v.50`  y{c'th}y
→ MSTAM

`f84v.51`  ochedy
→ OSARNM

### f85r1  ·  text/preface

`f85r1.1`  pdsheody.shdol.shey.otchdy.dshedy.soeeedy.dchefoey.sair.shedy.sodair,shey
→ MNPARONM  PANOL  PARM  OTSANM  NPARNM  PORRRNM  NSAR?ORM  PUIR  PARNM  PONUIRPARM

`f85r1.2`  yoiin.cheey.qocthdy.otedy.dol.ar,aiin.okshd.okchedy.otedy.chckhdy.otam
→ MOII?  SARRM  COSTANM  OTRNM  NOL  URUII?  OŌPAN  OŌSARNM  OTRNM  SASŌANM  OTUS

`f85r1.3`  tarar.otedy.opcheey.ykdair.chy.qotedy.qokchdy.otedy.cheol.saiin.otedam
→ TURUR  OTRNM  OMSARRM  MŌNUIR  SAM  COTRNM  COŌSANM  OTRNM  SAROL  PUII?  OTRNUS

`f85r1.4`  odeedaiin.qokechy.daiin.chekchy.olshedy.qokeedy.doltshdy.otar.otchdy.ols
→ ONRRNUII?  COŌRSAM  NUII?  SARŌSAM  OLPARNM  COŌRRNM  NOLTPANM  OTUR  OTSANM  OLP

`f85r1.5`  tchedy.kchedy.qodaiin.olkeedy.oraiin.olshedy.okchy.kedy.tedy.tdam
→ TSARNM  ŌSARNM  CONUII?  OLŌRRNM  ORUII?  OLPARNM  OŌSAM  ŌRNM  TRNM  TNUS

`f85r1.6`  roraiin.shey.pchey.qokeey.chor.ol.shedy
→ RORUII?  PARM  MSARM  COŌRRM  SAOR  OL  PARNM

`f85r1.7`  pchedy.oraiin.shefchdy.qopar.sheedy.qokedy.qotchedy.kchdar.ypchdy,ldo
→ MSARNM  ORUII?  PAR?SANM  COMUR  PARRNM  COŌRNM  COTSARNM  ŌSANUR  MMSANMLNO

`f85r1.8`  daiin.chckhdy.qotchdy.opchsd.qokchdy.otchy.qodal.daiin.dal.shdar.oram
→ NUII?  SASŌANM  COTSANM  OMSAPN  COŌSANM  OTSAM  CONUL  NUII?  NUL  PANUR  ORUS

`f85r1.9`  tsheed.lchey.qokeshy.da[ir:in].shedar.sheol.qo,[ar:iir].chofchdy.qotd{c@178;}y.ofar
→ TPARRN  LSARM  COŌRPAM  NUIR  PARNUR  PAROL  COUR  SAO?SANM  COTNSM  O?UR

`f85r1.10`  dair.chotaiin.cheod.cheolkeedy
→ NUIR  SAOTUII?  SARON  SAROLŌRRNM

`f85r1.11`  pdar.ol.shdair.qopcheedy.dal.chdal.chor.shefshoro.raiin.dolor.aiin.opakam
→ MNUR  OL  PANUIR  COMSARRNM  NUL  SANUL  SAOR  PAR?PAORO  RUII?  NOLOR  UII?  OMUŌUS

`f85r1.12`  tdain.okeody.lchdy.lkor.oeeseary.dar.shedaiin.oto.daiin.dlar.am
→ TNUI?  OŌRONM  LSANM  LŌOR  ORRPRURM  NUR  PARNUII?  OTO  NUII?  NLUR  US

`f85r1.13`  rsheodar.qocth[y:o].kar.okaiin.ykeeeody.qotal.ol,s,aiin.ol.daldy.shody
→ RPARONUR  COSTAM  ŌUR  OŌUII?  MŌRRRONM  COTUL  OLPUII?  OL  NULNM  PAONM

`f85r1.14`  daror.sheedy.keody.oteody.s,ar.aiin.cheedy.otaiin.dar.al.odaiiin
→ NUROR  PARRNM  ŌRONM  OTRONM  PUR  UII?  SARRNM  OTUII?  NUR  UL  ONUIII?

`f85r1.15`  qokeeodaiin.chey.okaiin.okal.al.dl.sheokey.cheokaiin.ol,keeo.dal.olky
→ COŌRRONUII?  SARM  OŌUII?  OŌUL  UL  NL  PAROŌRM  SAROŌUII?  OLŌRRO  NUL  OLŌM

`f85r1.16`  shoiin.qokar.okar,y,cheey
→ PAOII?  COŌUR  OŌURMSARRM

`f85r1.17`  polky.shey.olkedaiin.shor.cphedy.dair.sh{cphh}y.opchey.shtor.aiinsham
→ MOLŌM  PARM  OLŌRNUII?  PAOR  SMARNM  NUIR  PASMAAM  OMSARM  PATOR  UII?PAUS

`f85r1.18`  olkeey.otchey.qokedy.qodaiin.ch{ctah}y.checphey.otshey.qokshey.schdy.dam
→ OLŌRRM  OTSARM  COŌRNM  CONUII?  SASTUAM  SARSMARM  OTPARM  COŌPARM  PSANM  NUS

`f85r1.19`  okchy.okchdy.otchedy.dam.lam
→ OŌSAM  OŌSANM  OTSARNM  NUS  LUS

`f85r1.20`  pcheo,y,kshedy.qocphdy.qofol.shdaldy.dairar.cheeteey.otchedy.qokchdy.dy
→ MSAROMŌPARNM  COSMANM  CO?OL  PANULNM  NUIRUR  SARRTRRM  OTSARNM  COŌSANM  NM

`f85r1.21`  daiir.cheody.oraiin.ol.okaiin.cheocthey.olor.otedy.qotaiin.chor.chedy
→ NUIIR  SARONM  ORUII?  OL  OŌUII?  SAROSTARM  OLOR  OTRNM  COTUII?  SAOR  SARNM

`f85r1.22`  ydair.tar.chedy.oraiin.ychedy.okedy
→ MNUIR  TUR  SARNM  ORUII?  MSARNM  OŌRNM

`f85r1.23`  pchdaiin.shodaiin.shofshedy.yteody.ypar.ches.aiin.chol,dy.qopar.shetam
→ MSANUII?  PAONUII?  PAO?PARNM  MTRONM  MMUR  SARP  UII?  SAOLNM  COMUR  PARTUS

`f85r1.24`  tedair.ykeedy.dain.cheedy.qokar.chedy.okar.shee[k:t]eey.qokedy.olchedy
→ TRNUIR  MŌRRNM  NUI?  SARRNM  COŌUR  SARNM  OŌUR  PARRŌRRM  COŌRNM  OLSARNM

`f85r1.25`  schedaiir.oteody.chcthdy.qokaiin.ykchedy
→ PSARNUIIR  OTRONM  SASTANM  COŌUII?  MŌSARNM

`f85r1.26`  pchdair.or.shshdar.qopchedy.opchdy.qofchdy.dar.s.aiin.chcphdy.dar,or,daiin
→ MSANUIR  OR  PAPANUR  COMSARNM  OMSANM  CO?SANM  NUR  P  UII?  SASMANM  NURORNUII?

`f85r1.27`  ychedy.shetshdy.qotar.okedy.qokal.saiin.ol,karar.odeeeg
→ MSARNM  PARTPANM  COTUR  OŌRNM  COŌUL  PUII?  OLŌURUR  ONRRR?

`f85r1.28`  kchedar.yteol.okchdy.q[e:o]kedy.otor.odor.ar.chedy.otechdy.dal,cphedy
→ ŌSARNUR  MTROL  OŌSANM  CRŌRNM  OTOR  ONOR  UR  SARNM  OTRSANM  NULSMARNM

`f85r1.29`  oees.aiin.ol,keeody.or,s.cheey.qokchdy.qotol.okar.otar.otchy.okam
→ ORRP  UII?  OLŌRRONM  ORP  SARRM  COŌSANM  COTOL  OŌUR  OTUR  OTSAM  OŌUS

`f85r1.30`  dorchdy.o[r:s]aiin.okeder.chcthy.okedy.chdy.chdy.otal.otchdy.otalom
→ NORSANM  ORUII?  OŌRNRR  SASTAM  OŌRNM  SANM  SANM  OTUL  OTSANM  OTULOS

`f85r1.31`  podaiin.shdar.ypchdar.dar.ypchdy.qopol.dar.keshar.dchdal.chol,air,y
→ MONUII?  PANUR  MMSANUR  NUR  MMSANM  COMOL  NUR  ŌRPAUR  NSANUL  SAOLUIRM

`f85r1.32`  ytor.chol.shdy,tody.qotchdy.otchol.chees.or.eeodaiin.or.aral.olkam
→ MTOR  SAOL  PANMTONM  COTSANM  OTSAOL  SARRP  OR  RRONUII?  OR  URUL  OLŌUS

`f85r1.33`  raraiiin.shey.osaiin.otar.ytar.otedy.or.aiin.otar.olar.olkeedy
→ RURUIII?  PARM  OPUII?  OTUR  MTUR  OTRNM  OR  UII?  OTUR  OLUR  OLŌRRNM

`f85r1.34`  ysheedy.ksheey.qokor.or.chod.lkchedy.qotody.qokar.shty.otarar
→ MPARRNM  ŌPARRM  COŌOR  OR  SAON  LŌSARNM  COTONM  COŌUR  PATM  OTURUR

`f85r1.35`  s,ar,chedar.olpchdy.otol.otchedy
→ PURSARNUR  OLMSANM  OTOL  OTSARNM

### f85r2  ·  unknown

`f85r2.1`  odeedy.otedy.opaees.ar.chcthy.otchdy.otody.otar.chepaiin.otodar.otodaiin.opaiin.otaiin.qopchas.otchedy.olkaiin.odar.aloees.otchedy.qotedaiin.odar.octhody.shedaiin.olaiin.olfor.daiin.ol.lkech[ch:?].os.aiin.oteedy.dar.otees.opaiin.chcphdar
→ ONRRNM  OTRNM  OMURRP  UR  SASTAM  OTSANM  OTONM  OTUR  SARMUII?  OTONUR  OTONUII?  OMUII?  OTUII?  COMSAUP  OTSARNM  OLŌUII?  ONUR  ULORRP  OTSARNM  COTRNUII?  ONUR  OSTAONM  PARNUII?  OLUII?  OL?OR  NUII?  OL  LŌRSASA  OP  UII?  OTRRNM  NUR  OTRRP  OMUII?  SASMANUR

`f85r2.2`  sain.or.or,aiin.opchdy
→ PUI?  OR  ORUII?  OMSANM

`f85r2.3`  qotor.sheedy.shodaiin.olfar,ary
→ COTOR  PARRNM  PAONUII?  OL?URURM

`f85r2.4`  dair.sheo.oraiin.chol,daiin
→ NUIR  PARO  ORUII?  SAOLNUII?

`f85r2.5`  ockhdar.olkar.shoral
→ OSŌANUR  OLŌUR  PAORUL

`f85r2.6`  roseer
→ ROPRRR

`f85r2.7`  pchedeey.olkey.qokedy.sheos.fcheey
→ MSARNRRM  OLŌRM  COŌRNM  PAROP  ?SARRM

`f85r2.8`  otchedy.chotey.qocthey.oteey.ol.oloqorain
→ OTSARNM  SAOTRM  COSTARM  OTRRM  OL  OLOCORUI?

`f85r2.9`  daiin.qotaiin.tchedy.otedy.qotchdy.chckhey
→ NUII?  COTUII?  TSARNM  OTRNM  COTSANM  SASŌARM

`f85r2.10`  ytchedy,qodar.qotedar.qokar.qotchd.qotom
→ MTSARNMCONUR  COTRNUR  COŌUR  COTSAN  COTOS

`f85r2.11`  soiis,aiin.shedaiin.chok{co}m
→ POIIPUII?  PARNUII?  SAOŌSOS

`f85r2.12`  otchs.shedor.chey,sorain
→ OTSAP  PARNOR  SARMPORUI?

`f85r2.13`  or.shedy.tedy.sodaiiin.chy
→ OR  PARNM  TRNM  PONUIII?  SAM

`f85r2.14`  ytedar.chz[s:r].aiin.arody
→ MTRNUR  SA?P  UII?  URONM

`f85r2.15`  ypshedy.dar.chedy.or,am
→ MMPARNM  NUR  SARNM  ORUS

`f85r2.16`  oteey.qodaiin.odain.an.chey
→ OTRRM  CONUII?  ONUI?  U?  SARM

`f85r2.17`  orar.oldar.ain
→ ORUR  OLNUR  UI?

`f85r2.18`  okees.olaiin.qokal.chdy.sary
→ OŌRRP  OLUII?  COŌUL  SANM  PURM

`f85r2.19`  qokshedy.qodain.chckhy.ykeedy.chedy
→ COŌPARNM  CONUI?  SASŌAM  MŌRRNM  SARNM

`f85r2.20`  or,aiin.ckhed[a:y].or.ain.olchey.qokal.shedy
→ ORUII?  SŌARNU  OR  UI?  OLSARM  COŌUL  PARNM

`f85r2.21`  qokeody.qoekedy.dody.shedy.qodaiin
→ COŌRONM  CORŌRNM  NONM  PARNM  CONUII?

`f85r2.22`  los,ar.shedy.qokshey.qose?y.or.aiin,og
→ LOPUR  PARNM  COŌPARM  COPRM  OR  UII?O?

`f85r2.23`  ol.lcheol.chol.ol.sheoly
→ OL  LSAROL  SAOL  OL  PAROLM

`f85r2.24`  okees.ochar.oted[o:a]r.ochedy.otody.olchedy.oteedo.ar.or.airol.otees.ar.aram
→ OŌRRP  OSAUR  OTRNOR  OSARNM  OTONM  OLSARNM  OTRRNO  UR  OR  UIROL  OTRRP  UR  URUS

### f86v4  ·  unknown

`f86v4.1`  opos.os.sheody.pch???ar.odsheo.qody.cheepchdy.lpchedy.olkar.shdar.dchdor.qopcher,ches.os,eeedar.odaiin.pcheodar.chdair.orarorchy.shar.opchsey.otedy.ch{cphh}y.chedy.sarshed.odar.sheey.scheor.al.cheefar.shetchy.qoteol.otor.shar.qoteshy.do???.ofor.arar.dl
→ OMOP  OP  PARONM  MSAUR  ONPARO  CONM  SARRMSANM  LMSARNM  OLŌUR  PANUR  NSANOR  COMSARRSARP  OPRRRNUR  ONUII?  MSARONUR  SANUIR  ORURORSAM  PAUR  OMSAPRM  OTRNM  SASMAAM  SARNM  PURPARN  ONUR  PARRM  PSAROR  UL  SARR?UR  PARTSAM  COTROL  OTOR  PAUR  COTRPAM  NO  O?OR  URUR  NL

`f86v4.2`  oeeey.[o:y].daiin.otedaiin.otedy.oteey.chedaiin.octhedy.chy.shedaiin.chotaiin.oraiin.otodeee[?:o].ar.yteeody.oteedaraiin.shedaiin.chdar.shedy.qotedaiin.chedy.tchdy.chetdy.chedy.qotar.chedy.chckhy.daiin.otedy.seeedy.yteey.sam
→ ORRRM  O  NUII?  OTRNUII?  OTRNM  OTRRM  SARNUII?  OSTARNM  SAM  PARNUII?  SAOTUII?  ORUII?  OTONRRR  UR  MTRRONM  OTRRNURUII?  PARNUII?  SANUR  PARNM  COTRNUII?  SARNM  TSANM  SARTNM  SARNM  COTUR  SARNM  SASŌAM  NUII?  OTRNM  PRRRNM  MTRRM  PUS

`f86v4.3`  tchey.dair,alody.shes.qeeor.or.odarchdy.chdy.orcheos.o[s:r],ain.or.otee[d:?].chedees.oteedy.qoty.otedy.shedy.otedy.dar,shd.shy,y.schdy.chdeedy.dodar.oiin.or.oiin.sar,orchedy.qotchdy.dchdes.ar.sheody.opcho.fcheom
→ TSARM  NUIRULONM  PARP  CRROR  OR  ONURSANM  SANM  ORSAROP  OPUI?  OR  OTRRN  SARNRRP  OTRRNM  COTM  OTRNM  PARNM  OTRNM  NURPAN  PAMM  PSANM  SANRRNM  NONUR  OII?  OR  OII?  PURORSARNM  COTSANM  NSANRP  UR  PARONM  OMSAO  ?SAROS

`f86v4.4`  pchedar.ar.o{cp}or.otees.oes.a[iir:iin].olkeor.dar.ain.desy.doeedey.opchedy.shedaiin.dar.otedy.dain.otey.dam.otedy.daiin.chocthy.dtedair.chody.sheos.otedos.qokechy.pchdeedy.dan.ol.dol.oty.sho.pol.otoldyl
→ MSARNUR  UR  OSMOR  OTRRP  ORP  UIIR  OLŌROR  NUR  UI?  NRPM  NORRNRM  OMSARNM  PARNUII?  NUR  OTRNM  NUI?  OTRM  NUS  OTRNM  NUII?  SAOSTAM  NTRNUIR  SAONM  PAROP  OTRNOP  COŌRSAM  MSANRRNM  NU?  OL  NOL  OTM  PAO  MOL  OTOLNML

`f86v4.5`  pcheodar.oedy.qokeol.qoeol<->oqokeol.dar.ol.olair,am
→ MSARONUR  ORNM  COŌROL  COROLOCOŌROL  NUR  OL  OLUIRUS

`f86v4.6`  ycheoltar.ol.ol,sheey.qokey.or.aiin.sheeor.sar.al.ol.sheey.qockheey
→ MSAROLTUR  OL  OLPARRM  COŌRM  OR  UII?  PARROR  PUR  UL  OL  PARRM  COSŌARRM

`f86v4.7`  tol,sh,s,or.aiin.ol.keeod.lcheody.okedy.qokeody.qoain.a?
→ TOLPAPOR  UII?  OL  ŌRRON  LSARONM  OŌRNM  COŌRONM  COUI?  U

`f86v4.8`  daiin.ol,keedy.otar.olshedy.okol,aiin.okal,cheockhy.sho{cthh}y.daiin
→ NUII?  OLŌRRNM  OTUR  OLPARNM  OŌOLUII?  OŌULSAROSŌAM  PAOSTAAM  NUII?

`f86v4.9`  dar.oleey.ol.yy
→ NUR  OLRRM  OL  MM

### f86v6  ·  text/preface

`f86v6.1`  pcheypchdar.op[o:a]r{c@179;h}y.ches,aiin.ofy.chedy.otedalol.orairody.qotchdaiin.qopy
→ MSARMMSANUR  OMORSAM  SARPUII?  O?M  SARNM  OTRNULOL  ORUIRONM  COTSANUII?  COMM

`f86v6.2`  ochody.chol.chey.qotchdy.kchdy.qopchd.chpchy.qopchy.qoky.chedy.qokol.lray
→ OSAONM  SAOL  SARM  COTSANM  ŌSANM  COMSAN  SAMSAM  COMSAM  COŌM  SARNM  COŌOL  LRUM

`f86v6.3`  qolchy.olkeedy.chdal,chedy.chor.ar.arody.qokchdy.chdal.okar.chdy.otaiin
→ COLSAM  OLŌRRNM  SANULSARNM  SAOR  UR  URONM  COŌSANM  SANUL  OŌUR  SANM  OTUII?

`f86v6.4`  dshor.shdy.shor.ol,aiin.olkeedy.shdal.oteor.chdar.l,karchees.olkar.dalam
→ NPAOR  PANM  PAOR  OLUII?  OLŌRRNM  PANUL  OTROR  SANUR  LŌURSARRP  OLŌUR  NULUS

`f86v6.5`  tar.lol.chol.olkar.daiin.chear.or.otshey.qokar.opchey.taiky.qotar
→ TUR  LOL  SAOL  OLŌUR  NUII?  SARUR  OR  OTPARM  COŌUR  OMSARM  TUIŌM  COTUR

`f86v6.6`  daiin.sheol,keear.or.chedy.ar,sheeeb.qotain.odaiin.olkeshar.qokar.or
→ NUII?  PAROLŌRRUR  OR  SARNM  URPARRR?  COTUI?  ONUII?  OLŌRPAUR  COŌUR  OR

`f86v6.7`  qokaiin.y,lchedor.or.aiin.ol,or.olkal.or.shedy.qokal.s,ar.archey.dy
→ COŌUII?  MLSARNOR  OR  UII?  OLOR  OLŌUL  OR  PARNM  COŌUL  PUR  URSARM  NM

`f86v6.8`  ykaiin.odaiin.chal.sair.ytar.chody.ldaly.chdal.ykchedy.ltchedy.dar
→ MŌUII?  ONUII?  SAUL  PUIR  MTUR  SAONM  LNULM  SANUL  MŌSARNM  LTSARNM  NUR

`f86v6.9`  dshor.ykaiin.dar.sheey.qokol.cheol.otar.ar.aiiin.qoteeos.aiin
→ NPAOR  MŌUII?  NUR  PARRM  COŌOL  SAROL  OTUR  UR  UIII?  COTRROP  UII?

`f86v6.10`  sarar.ykaiin.soldam.sheol.qckhy.dalor.olaiin.olkaiin.qodar.o@185;y
→ PURUR  MŌUII?  POLNUS  PAROL  CSŌAM  NULOR  OLUII?  OLŌUII?  CONUR  OM

`f86v6.11`  qokaiin.olkeey.qokeor.or.cheeaiin.yteedy.qoko.lchdol.or.chcphar.ar
→ COŌUII?  OLŌRRM  COŌROR  OR  SARRUII?  MTRRNM  COŌO  LSANOL  OR  SASMAUR  UR

`f86v6.12`  ykeealor.qokal.otar.ykairolky
→ MŌRRULOR  COŌUL  OTUR  MŌUIROLŌM

`f86v6.13`  {c@132;h}ol{c@133;h}y.qopaiin.yfchdy.cpholkaiin.cholfchy.qopar.aroiiin.opchedy.opoly
→ SAOLSAM  COMUII?  M?SANM  SMAOLŌUII?  SAOL?SAM  COMUR  UROIII?  OMSARNM  OMOLM

`f86v6.14`  ykchy.cholkaiin.chey.ykeedy.okal.or.chcfhy.lkey.okar.dar.ol,a[in:iin]
→ MŌSAM  SAOLŌUII?  SARM  MŌRRNM  OŌUL  OR  SAS?AM  LŌRM  OŌUR  NUR  OLUI?

`f86v6.15`  shol.shotaiin.shckhor.olaiin.chdy.qokain.odaiiin.cheor.ol,kaiin.chey
→ PAOL  PAOTUII?  PASŌAOR  OLUII?  SANM  COŌUI?  ONUIII?  SAROR  OLŌUII?  SARM

`f86v6.16`  taiin.okaiin.qokaiin.ykeey.otain.chey.okam.qokar.qokain.okaiin
→ TUII?  OŌUII?  COŌUII?  MŌRRM  OTUI?  SARM  OŌUS  COŌUR  COŌUI?  OŌUII?

`f86v6.17`  par.or,aiin.dar.aiiin.qckhear.sho{ifh}y.qotedy.opchdy.olain.ar.alkar.am
→ MUR  ORUII?  NUR  UIII?  CSŌARUR  PAOI?AM  COTRNM  OMSANM  OLUI?  UR  ULŌUR  US

`f86v6.18`  ytaiin.ytair.dalol.ytal.dar,aiiin.chol.olkchey.lkar.otal.qotardam
→ MTUII?  MTUIR  NULOL  MTUL  NURUIII?  SAOL  OLŌSARM  LŌUR  OTUL  COTURNUS

`f86v6.19`  pol.sheopchey.pchecfhey.or.aiiin.qokaiin.cholkar
→ MOL  PAROMSARM  MSARS?ARM  OR  UIII?  COŌUII?  SAOLŌUR

`f86v6.20`  pdaiiiy.otol,podaiin.ocphey.opchor.olkshed.qofod.opdaiin.[o:a]dar.dairody
→ MNUIIIM  OTOLMONUII?  OSMARM  OMSAOR  OLŌPARN  CO?ON  OMNUII?  ONUR  NUIRONM

`f86v6.21`  oreeey.lkeeor.daiin.olteody.tar.otyteeodaiin.yty.sheey.tar.ar.am,ody
→ ORRRRM  LŌRROR  NUII?  OLTRONM  TUR  OTMTRRONUII?  MTM  PARRM  TUR  UR  USONM

`f86v6.22`  lshechy.tshy.qokeedy.kain.ytaiin.chees.tairoar.qotar.ta{ikh}y.d,amom
→ LPARSAM  TPAM  COŌRRNM  ŌUI?  MTUII?  SARRP  TUIROUR  COTUR  TUIŌAM  NUSOS

`f86v6.23`  qokar.olkedy.otor.chedy.qokar.opchedy.dar.ykar,ar.dair.ain.ol.keodar
→ COŌUR  OLŌRNM  OTOR  SARNM  COŌUR  OMSARNM  NUR  MŌURUR  NUIR  UI?  OL  ŌRONUR

`f86v6.24`  chey,keody.choty.dal.ody.qokeedy.pchedy.ytsh[y:q],tody.dal,tchedy.qokar.oly
→ SARMŌRONM  SAOTM  NUL  ONM  COŌRRNM  MSARNM  MTPAMTONM  NULTSARNM  COŌUR  OLM

`f86v6.25`  yteedy.qokar.olkar.qodar.ykaiin.or,okeeeey.ofchedy.qokaiin.araram
→ MTRRNM  COŌUR  OLŌUR  CONUR  MŌUII?  OROŌRRRRM  O?SARNM  COŌUII?  URURUS

`f86v6.26`  saiin.shor.shekaiin.chedy.cholkeog.qokchy.orchcthy.olteedydar.otar.aim
→ PUII?  PAOR  PARŌUII?  SARNM  SAOLŌRO?  COŌSAM  ORSASTAM  OLTRRNMNUR  OTUR  UIS

`f86v6.27`  alshdr.lkar.dal.kshd.shdar.shedy,qody.sheey.qotedy.olkeey.qokchdy.ramshy
→ ULPANR  LŌUR  NUL  ŌPAN  PANUR  PARNMCONM  PARRM  COTRNM  OLŌRRM  COŌSANM  RUSPAM

`f86v6.28`  qokaiin.qokar.okar.qotar.lor.qokchdy.dar.shey.d,y,tshedy.qotol.dytshy.dy
→ COŌUII?  COŌUR  OŌUR  COTUR  LOR  COŌSANM  NUR  PARM  NMTPARNM  COTOL  NMTPAM  NM

`f86v6.29`  dchedy.chcthdy.shol.oky.ytaiin.ykaiin.chedy.dy,dal.shdaiin
→ NSARNM  SASTANM  PAOL  OŌM  MTUII?  MŌUII?  SARNM  NMNUL  PANUII?

`f86v6.30`  polkeey.tshed.qopchey.paroiin.chefchy.qopar.qopchedy.qopydaiin.qopary
→ MOLŌRRM  TPARN  COMSARM  MUROII?  SAR?SAM  COMUR  COMSARNM  COMMNUII?  COMURM

`f86v6.31`  dair.chepy.qokaiin.olkar.olkchdy.okar,al.dar.olkchey.otytam.orom
→ NUIR  SARMM  COŌUII?  OLŌUR  OLŌSANM  OŌURUL  NUR  OLŌSARM  OTMTUS  OROS

`f86v6.32`  qokeey.qoeear.chsey.oky.qokar.or,chey.qotar.ol,kchedy.qokaiin.am
→ COŌRRM  CORRUR  SAPRM  OŌM  COŌUR  ORSARM  COTUR  OLŌSARNM  COŌUII?  US

`f86v6.33`  dar.olkaiin.ydy.lkchedy.okeeeykeey.dl.ld.lo,l.sheey.qokshey,taiin.g
→ NUR  OLŌUII?  MNM  LŌSARNM  OŌRRRMŌRRM  NL  LN  LOL  PARRM  COŌPARMTUII?  ?

`f86v6.34`  soraiin.ar.shey.qoteody.or.aiiin.oeey.ldaiiin.or.oro.ol,kaiiin
→ PORUII?  UR  PARM  COTRONM  OR  UIII?  ORRM  LNUIII?  OR  ORO  OLŌUIII?

`f86v6.35`  sar.aiin.otar.cheody.qotaiin.qokaiin.ol.tey.qokaiin.okar.ol
→ PUR  UII?  OTUR  SARONM  COTUII?  COŌUII?  OL  TRM  COŌUII?  OŌUR  OL

`f86v6.36`  dairal.daiin.qokar.chol,tal.cthdy.qokeey.lkaiin.olkaiin.araiin
→ NUIRUL  NUII?  COŌUR  SAOLTUL  STANM  COŌRRM  LŌUII?  OLŌUII?  URUII?

`f86v6.37`  lshar.[o:y]kar.qoeedy.qotar.otal.olky.qokal.ol.kaiin.octhear.lo
→ LPAUR  OŌUR  CORRNM  COTUR  OTUL  OLŌM  COŌUL  OL  ŌUII?  OSTARUR  LO

`f86v6.38`  poiin.otal,kal.toror.olaiin.okeockhey.olkeey.qoedy.lkaiin.oltam
→ MOII?  OTULŌUL  TOROR  OLUII?  OŌROSŌARM  OLŌRRM  CORNM  LŌUII?  OLTUS

`f86v6.39`  y,aiin,dar.otol.qokain.qoky.lkor.dal.oraiin.cheoty.qotaiin.olkam
→ MUII?NUR  OTOL  COŌUI?  COŌM  LŌOR  NUL  ORUII?  SAROTM  COTUII?  OLŌUS

`f86v6.40`  daiin.ar.qotal.tshdy.otar.shcthdy.qokol.chotal,kar.ol,kar.alky
→ NUII?  UR  COTUL  TPANM  OTUR  PASTANM  COŌOL  SAOTULŌUR  OLŌUR  ULŌM

`f86v6.41`  qokaiin.octhy.oltchey.qotal.lkalol.sheol.qotaiin.ytain.ytody
→ COŌUII?  OSTAM  OLTSARM  COTUL  LŌULOL  PAROL  COTUII?  MTUI?  MTONM

`f86v6.42`  otaiin.qokain.otal.otal.lt.al.lkar.chdy.qotol.qokain
→ OTUII?  COŌUI?  OTUL  OTUL  LT  UL  LŌUR  SANM  COTOL  COŌUI?

`f86v6.43`  qokaiin.choty.ytaiin.chokain.chocthy.chy,taiin.okaiin.okan
→ COŌUII?  SAOTM  MTUII?  SAOŌUI?  SAOSTAM  SAMTUII?  OŌUII?  OŌU?

`f86v6.44`  shor.qoky.chorolk.chokaiin.qoal,kaiin.qoaiin.or.aiiin.ykedy
→ PAOR  COŌM  SAOROLŌ  SAOŌUII?  COULŌUII?  COUII?  OR  UIII?  MŌRNM

`f86v6.45`  paiin.otar.otolkshy.qokshey.ar.otalky.chear.ai[o:a]dam
→ MUII?  OTUR  OTOLŌPAM  COŌPARM  UR  OTULŌM  SARUR  UIONUS

### f86v5  ·  text/preface

`f86v5.1`  pshdal.choky.sheody.lfchy.fyshey.qoty.opy.ypar.o,raiin.ytor.aiin.opy
→ MPANUL  SAOŌM  PARONM  L?SAM  ?MPARM  COTM  OMM  MMUR  ORUII?  MTOR  UII?  OMM

`f86v5.2`  losair.yteody.qokar.shy.qokar.shor.qopchol.tal.ol.ytol.otam.otam
→ LOPUIR  MTRONM  COŌUR  PAM  COŌUR  PAOR  COMSAOL  TUL  OL  MTOL  OTUS  OTUS

`f86v5.3`  shedy.chdy.qokar.okeeey.sheokaiin.cheoky.oteeodail.otaiin.otain
→ PARNM  SANM  COŌUR  OŌRRRM  PAROŌUII?  SAROŌM  OTRRONUIL  OTUII?  OTUI?

`f86v5.4`  ypchesy.oky.sheeey.qoty.qotaiin.sail.chepy.ltedy.dar.olkar.am
→ MMSARPM  OŌM  PARRRM  COTM  COTUII?  PUIL  SARMM  LTRNM  NUR  OLŌUR  US

`f86v5.5`  daiin.or.otol.otshey.otal.olkey.chcthody.ytar.dal.ar.okary
→ NUII?  OR  OTOL  OTPARM  OTUL  OLŌRM  SASTAONM  MTUR  NUL  UR  OŌURM

`f86v5.6`  olkeedy.shety.ytar.ytaiin.shdam.araiiin.ytaiin
→ OLŌRRNM  PARTM  MTUR  MTUII?  PANUS  URUIII?  MTUII?

`f86v5.7`  pdaiin.qoteedy.opchey.qopor.otol.kshdy.qopcheey.shdar,fchcfhy
→ MNUII?  COTRRNM  OMSARM  COMOR  OTOL  ŌPANM  COMSARRM  PANUR?SAS?AM

`f86v5.8`  octhal.shckhy.otshey.opor.shey.tor,ar.otar.aiin.chdy.tarcheeg
→ OSTAUL  PASŌAM  OTPARM  OMOR  PARM  TORUR  OTUR  UII?  SANM  TURSARR?

`f86v5.9`  lkaiiin.otain.r.al.ykain.chaiin.y,tal.ykaiin.otal.ar,alkam
→ LŌUIII?  OTUI?  R  UL  MŌUI?  SAUII?  MTUL  MŌUII?  OTUL  URULŌUS

`f86v5.10`  ykar.olkal.kar,shedy.shor.qokar.chor.or.ykaiin.otam.ytam
→ MŌUR  OLŌUL  ŌURPARNM  PAOR  COŌUR  SAOR  OR  MŌUII?  OTUS  MTUS

`f86v5.11`  taral.okar.octhey.sal.kaiin.ytal.chey.otal.aiiin.olkam
→ TURUL  OŌUR  OSTARM  PUL  ŌUII?  MTUL  SARM  OTUL  UIII?  OLŌUS

`f86v5.12`  poraiiidy.otshs.al.ar,shey.tair.sheody.qopchesy.lfar.air.amod
→ MORUIIINM  OTPAP  UL  URPARM  TUIR  PARONM  COMSARPM  L?UR  UIR  USON

`f86v5.13`  daiin.shar.otam.ytaiin.otal.teody.cthy.or.aiin.otar,aiiin
→ NUII?  PAUR  OTUS  MTUII?  OTUL  TRONM  STAM  OR  UII?  OTURUIII?

`f86v5.14`  qoar.aiiin.al.ody.ar.aiin.qokeeey.cheey.qotaiin.ykar.acthy
→ COUR  UIII?  UL  ONM  UR  UII?  COŌRRRM  SARRM  COTUII?  MŌUR  USTAM

`f86v5.15`  ykar.ar.alody.or.eees.aiin.okar.qokaiin.ykar.ar.ol.chsky
→ MŌUR  UR  ULONM  OR  RRRP  UII?  OŌUR  COŌUII?  MŌUR  UR  OL  SAPŌM

`f86v5.16`  dcheytain.qoka.daiin.ykalkain.ykar.al,kaiin.dalkalytam
→ NSARMTUI?  COŌU  NUII?  MŌULŌUI?  MŌUR  ULŌUII?  NULŌULMTUS

`f86v5.17`  ockhedy.ched.y,taiin.ykaiin.qotal.yshey.otaiin.olkam
→ OSŌARNM  SARN  MTUII?  MŌUII?  COTUL  MPARM  OTUII?  OLŌUS

`f86v5.18`  poldaiin.shea.teraiin.otcho.lkaiin.os.al.ody.qotar.ytedy.daiin
→ MOLNUII?  PARU  TRRUII?  OTSAO  LŌUII?  OP  UL  ONM  COTUR  MTRNM  NUII?

`f86v5.19`  ycheeytydaiin.ykeeo,chey.shckhy.shoky.oty.oty.otain.olkchdy
→ MSARRMTMNUII?  MŌRROSARM  PASŌAM  PAOŌM  OTM  OTM  OTUI?  OLŌSANM

`f86v5.20`  ychor.ar.aiin.ytaly.otaiin.ykaiin.otal.ytar.aiin.ytaiiil
→ MSAOR  UR  UII?  MTULM  OTUII?  MŌUII?  OTUL  MTUR  UII?  MTUIIIL

`f86v5.21`  oar.ar,aiin.okaiin.yteey.ytaiin.qokees.aiin.yteey.qotey.lkey
→ OUR  URUII?  OŌUII?  MTRRM  MTUII?  COŌRRP  UII?  MTRRM  COTRM  LŌRM

`f86v5.22`  ykaiin.ykeey.ykal.chod,aiin.oeey.teodkaiin.otodaiin.okain
→ MŌUII?  MŌRRM  MŌUL  SAONUII?  ORRM  TRONŌUII?  OTONUII?  OŌUI?

`f86v5.23`  ykaiin.or,aiin.okol.chokar.sheol.qokar.cheey.or,aiin.ody
→ MŌUII?  ORUII?  OŌOL  SAOŌUR  PAROL  COŌUR  SARRM  ORUII?  ONM

`f86v5.24`  oar.aiin.ykain.okal.kchody.chckhy.otaiin.olkar.otaiin
→ OUR  UII?  MŌUI?  OŌUL  ŌSAONM  SASŌAM  OTUII?  OLŌUR  OTUII?

`f86v5.25`  sair.kain.ar,alosheey.qoeey.lkesy
→ PUIR  ŌUI?  URULOPARRM  CORRM  LŌRPM

`f86v5.26`  pochor.aiir.shoar.pshody.shody.qopchy.ocfhdy.dar.olpshy.dam.shey
→ MOSAOR  UIIR  PAOUR  MPAONM  PAONM  COMSAM  OS?ANM  NUR  OLMPAM  NUS  PARM

`f86v5.27`  pchor.ypchor.aiin.otar.shody.pchykar.ytar.odar.oeees.aral.om
→ MSAOR  MMSAOR  UII?  OTUR  PAONM  MSAMŌUR  MTUR  ONUR  ORRRP  URUL  OS

`f86v5.28`  odaiin.o,al.kar.ar.or.ytdar,qokeeey.teo,dy,tey,tar.a[?:n].ytarar
→ ONUII?  OUL  ŌUR  UR  OR  MTNURCOŌRRRM  TRONMTRMTUR  U  MTURUR

`f86v5.29`  ysheoar.qoteody.qokar.shody.qokal.tchey.ytchy.tal.tar
→ MPAROUR  COTRONM  COŌUR  PAONM  COŌUL  TSARM  MTSAM  TUL  TUR

`f86v5.30`  odaiin.otchees.chey.chodaiin.shedy.otal.kchol.shy.olkeeeary
→ ONUII?  OTSARRP  SARM  SAONUII?  PARNM  OTUL  ŌSAOL  PAM  OLŌRRRURM

`f86v5.31`  tol.kaiin.ytchdy.chol.ytedy.ytain.qodaiin.ytody.ykeshy.ar
→ TOL  ŌUII?  MTSANM  SAOL  MTRNM  MTUI?  CONUII?  MTONM  MŌRPAM  UR

`f86v5.32`  dshey.ytchy.dy.qotal.shdy.or.aiin.chody.chey.ol.teody.aiin
→ NPARM  MTSAM  NM  COTUL  PANM  OR  UII?  SAONM  SARM  OL  TRONM  UII?

`f86v5.33`  qokeey.ol,kaiin.ol.kain.olkeedy.qopcheey.oty.daiin.otam
→ COŌRRM  OLŌUII?  OL  ŌUI?  OLŌRRNM  COMSARRM  OTM  NUII?  OTUS

`f86v5.34`  oteey.ol.tey.choaiin.ysheedy.ychedy.ytaiin.otam.aiin
→ OTRRM  OL  TRM  SAOUII?  MPARRNM  MSARNM  MTUII?  OTUS  UII?

`f86v5.35`  ychey.or.aiin.ytair.ytaim.otal.shod.qokchy.qoody.s,aim
→ MSARM  OR  UII?  MTUIR  MTUIS  OTUL  PAON  COŌSAM  COONM  PUIS

`f86v5.36`  shody.qoty.chody.ytody.olkey.otoloty.oltal.oky.dam
→ PAONM  COTM  SAONM  MTONM  OLŌRM  OTOLOTM  OLTUL  OŌM  NUS

`f86v5.37`  dchol.chedy.qotain.otaiin.ol.cheody.olkeeody.oreeeg
→ NSAOL  SARNM  COTUI?  OTUII?  OL  SARONM  OLŌRRONM  ORRRR?

`f86v5.38`  sol.odaiin.ykeeshy.ytchey.lchody.ykar.shey.ytaiin
→ POL  ONUII?  MŌRRPAM  MTSARM  LSAONM  MŌUR  PARM  MTUII?

`f86v5.39`  yteody.chedy.qoteey.octhy.dy
→ MTRONM  SARNM  COTRRM  OSTAM  NM

### f86v3  ·  unknown

`f86v3.1`  tchedy.qokeedy.qoedy.qopchy.raiin.olpchey.qokaiin
→ TSARNM  COŌRRNM  CORNM  COMSAM  RUII?  OLMSARM  COŌUII?

`f86v3.2`  rain.ychedy.qoeeey.otair.cheody.ytain.q[y:o],kaiin
→ RUI?  MSARNM  CORRRM  OTUIR  SARONM  MTUI?  CMŌUII?

`f86v3.3`  taiin.ytaiin.ytaiin.ytaiin.or.ar.yta[s:r].am
→ TUII?  MTUII?  MTUII?  MTUII?  OR  UR  MTUP  US

`f86v3.4`  ykaiin.qoeedy.q[a:o]r.aiin.yteeey.ar.aiin.ar.am
→ MŌUII?  CORRNM  CUR  UII?  MTRRRM  UR  UII?  UR  US

`f86v3.5`  y{ch'}eey.qotaiin.chdy.yp{ch'}eor.ytain.otain.ytam
→ MSARRM  COTUII?  SANM  MMSAROR  MTUI?  OTUI?  MTUS

`f86v3.6`  daiinls,aiin.chcthy.ykaiin.ykaiin.chdar.ar,aiin
→ NUII?LPUII?  SASTAM  MŌUII?  MŌUII?  SANUR  URUII?

`f86v3.7`  sain.ytaiin.ytapy.odeeey.dal.dair.ytam
→ PUI?  MTUII?  MTUMM  ONRRRM  NUL  NUIR  MTUS

`f86v3.8`  sor,aiin.otey.otair
→ PORUII?  OTRM  OTUIR

`f86v3.9`  tchol.olkey.cfhy,aiin.opchedy.okchedy.or,acheody.shol.shedy.yteey.daiin.dady
→ TSAOL  OLŌRM  S?AMUII?  OMSARNM  OŌSARNM  ORUSARONM  PAOL  PARNM  MTRRM  NUII?  NUNM

`f86v3.10`  ychey.olkeeey.qotchedy.qokeey.qotchedar.sheedy.qokaiin.qokedy.ykaiin.qotaiior.am
→ MSARM  OLŌRRRM  COTSARNM  COŌRRM  COTSARNUR  PARRNM  COŌUII?  COŌRNM  MŌUII?  COTUIIOR  US

`f86v3.11`  tcheod.oteey.yteeody.chdy.chedos.shedy.cheos.[ol:?]s.aiir.sheey.ytee{ch'}eey.oteeodam
→ TSARON  OTRRM  MTRRONM  SANM  SARNOP  PARNM  SAROP  OLP  UIIR  PARRM  MTRRSARRM  OTRRONUS

`f86v3.12`  yteedy.ykeey.daim.choaiin.checkhy.{c'y}keeeochy.tcheey.otodaiin.opaiin.otchey.otam
→ MTRRNM  MŌRRM  NUIS  SAOUII?  SARSŌAM  SMŌRRROSAM  TSARRM  OTONUII?  OMUII?  OTSARM  OTUS

`f86v3.13`  osheey.orsheey.tcheody.qokain.qodaiin.olkar.chedaiin.y.chedy.qokady.cholkain
→ OPARRM  ORPARRM  TSARONM  COŌUI?  CONUII?  OLŌUR  SARNUII?  M  SARNM  COŌUNM  SAOLŌUI?

`f86v3.14`  ar.aiin.shodain.shor.chalkar.shekshol.okchor
→ UR  UII?  PAONUI?  PAOR  SAULŌUR  PARŌPAOL  OŌSAOR

`f86v3.15`  tshd{ch'}ey.dalkshdy.shocfhy.saiin.or.airody<->chedaly
→ TPANSARM  NULŌPANM  PAOS?AM  PUII?  OR  UIRONMSARNULM

`f86v3.16`  dcheody.skeeody.qokshey.cheodain.ykched<->sar,aldy
→ NSARONM  PŌRRONM  COŌPARM  SARONUI?  MŌSARNPURULNM

`f86v3.17`  dsheody.qokchey.dal.or.odaiin.sar
→ NPARONM  COŌSARM  NUL  OR  ONUII?  PUR

`f86v3.18`  pchedaiin.dchedy.qokchdy.qopchol.shol<->sheody.solkam
→ MSARNUII?  NSARNM  COŌSANM  COMSAOL  PAOLPARONM  POLŌUS

`f86v3.19`  dchey.otain.olkechy.qokam.chol.kchdy.chol.tchdy.dar,aiindy
→ NSARM  OTUI?  OLŌRSAM  COŌUS  SAOL  ŌSANM  SAOL  TSANM  NURUII?NM

`f86v3.20`  lshodair.ykcho.dar.chody.ykeeody.qochey.chckhey.lkar,ary
→ LPAONUIR  MŌSAO  NUR  SAONM  MŌRRONM  COSARM  SASŌARM  LŌURURM

`f86v3.21`  dshedy.kshey.tchdy.shdy.ralkchedy.ytchol.qoty.okshy.tam
→ NPARNM  ŌPARM  TSANM  PANM  RULŌSARNM  MTSAOL  COTM  OŌPAM  TUS

`f86v3.22`  ytchdy.dar.sholor.alor
→ MTSANM  NUR  PAOLOR  ULOR

`f86v3.23`  tshedal.ypchey.shdy.qopcheeody.opchdy.olfchey.ypchey.qotaiin
→ TPARNUL  MMSARM  PANM  COMSARRONM  OMSANM  OL?SARM  MMSARM  COTUII?

`f86v3.24`  dshedy.qokeey.qotee[?:y].shedy.qokaiin.chdy.otar.otaiin.ykaiin
→ NPARNM  COŌRRM  COTRR  PARNM  COŌUII?  SANM  OTUR  OTUII?  MŌUII?

`f86v3.25`  qodaiin.y,ochedy.qotchey.qoky.daiin.chdy.oteedy.qoty.daiin.am
→ CONUII?  MOSARNM  COTSARM  COŌM  NUII?  SANM  OTRRNM  COTM  NUII?  US

`f86v3.26`  shor.yteey.oteedy.shedaiin.sheey.otaiin.ytaiin.otodar.aiin
→ PAOR  MTRRM  OTRRNM  PARNUII?  PARRM  OTUII?  MTUII?  OTONUR  UII?

`f86v3.27`  teeos.aiin.yteey.qoteey.otchey.qoteeody.cheeor.cheedaiin
→ TRROP  UII?  MTRRM  COTRRM  OTSARM  COTRRONM  SARROR  SARRNUII?

`f86v3.28`  ycheeody.daii[s:r].oteey.qoedy.oteey.olteey
→ MSARRONM  NUIIP  OTRRM  CORNM  OTRRM  OLTRRM

`f86v3.29`  toeeedchy.okchey.qokchedy.shedy.ytcheodar
→ TORRRNSAM  OŌSARM  COŌSARNM  PARNM  MTSARONUR

`f86v3.30`  ytchey.yteey.chdal.or.cheey.daiin.cheokaii[@175;:m]
→ MTSARM  MTRRM  SANUL  OR  SARRM  NUII?  SAROŌUII

`f86v3.31`  tchedy.chy.tchey.otchedy.qokal.oeedy.lkam
→ TSARNM  SAM  TSARM  OTSARNM  COŌUL  ORRNM  LŌUS

`f86v3.32`  oees.aiiin.yteeedy.chedy.qotaiin.cheody
→ ORRP  UIII?  MTRRRNM  SARNM  COTUII?  SARONM

`f86v3.33`  ytchey.otaiin.kshd.qotar.chear.or,am
→ MTSARM  OTUII?  ŌPAN  COTUR  SARUR  ORUS

`f86v3.34`  yteeo,dy.chedy.qokal.yteey.qokar.am
→ MTRRONM  SARNM  COŌUL  MTRRM  COŌUR  US

`f86v3.35`  dcheey.teeody.oty.otchedy.daiiraii[@175;:m]
→ NSARRM  TRRONM  OTM  OTSARNM  NUIIRUII

`f86v3.36`  ykeeedy.qoteey.qodaiin.okeeey
→ MŌRRRNM  COTRRM  CONUII?  OŌRRRM

### f87r  ·  herbal

`f87r.1`  poalshsal.shocphor.ypcho.cpheo.saiin.oteodal.saiin
→ MOULPAPUL  PAOSMAOR  MMSAO  SMARO  PUII?  OTRONUL  PUII?

`f87r.2`  dcheeckhos.chety.cthodal.yteodam.cphecthy.syty
→ NSARRSŌAOP  SARTM  STAONUL  MTRONUS  SMARSTAM  PMTM

`f87r.3`  tchor.oteedy.ykeey.{cthh}ody.keos.sheekchey.saiidy
→ TSAOR  OTRRNM  MŌRRM  STAAONM  ŌROP  PARRŌSARM  PUIINM

`f87r.4`  soraiin.qockhos.cheodor.ckheokey.chcthody.s.odar
→ PORUII?  COSŌAOP  SARONOR  SŌAROŌRM  SASTAONM  P  ONUR

`f87r.5`  daiin.ctheey.ckheckhy.cthody.chor.s,al.dar.chor
→ NUII?  STARRM  SŌARSŌAM  STAONM  SAOR  PUL  NUR  SAOR

`f87r.6`  tos.she.keodaiin.pcheos.sheo.so.shkeody.soraiin
→ TOP  PAR  ŌRONUII?  MSAROP  PARO  PO  PAŌRONM  PORUII?

`f87r.7`  y,teeodal.cho.keeody.shy.ko[o:l],sols.chekol
→ MTRRONUL  SAO  ŌRRONM  PAM  ŌOOPOLP  SARŌOL

`f87r.8`  solsheor.ysaiin.chor.cheory.kchody
→ POLPAROR  MPUII?  SAOR  SARORM  ŌSAONM

`f87r.9`  sor.shocthey.oteody.dchol.saraiin
→ POR  PAOSTARM  OTRONM  NSAOL  PURUII?

`f87r.10`  sho.cthos.cheodal.ctheody.qoty
→ PAO  STAOP  SARONUL  STARONM  COTM

`f87r.11`  psheodshy.dal.shee.saldal.shol.aldy
→ MPARONPAM  NUL  PARR  PULNUL  PAOL  ULNM

`f87r.12`  ysheee[r:s].chetchy.teodar.otcheol.tockhy
→ MPARRRR  SARTSAM  TRONUR  OTSAROL  TOSŌAM

`f87r.13`  keor.ckheey.shody.qoeeeety.s,chody.daiin
→ ŌROR  SŌARRM  PAONM  CORRRRTM  PSAONM  NUII?

`f87r.14`  daiin.shol.cthey.okeol.cheor.okeeo,daiim
→ NUII?  PAOL  STARM  OŌROL  SAROR  OŌRRONUIIS

`f87r.15`  shos.cheol.cheos.ckhey.saiin.q'ockheo,ldaiin
→ PAOP  SAROL  SAROP  SŌARM  PUII?  COSŌAROLNUII?

`f87r.16`  yteeo[r:s].cheol.dcheeol
→ MTRROR  SAROL  NSARROL

### f87v  ·  herbal

`f87v.1`  @180;cheey.daiin.cpheodar.shody.dcheody.todor.oeeepchody<->oldar
→ SARRM  NUII?  SMARONUR  PAONM  NSARONM  TONOR  ORRRMSAONMOLNUR

`f87v.2`  schey.ctheey.qocthsy.s<->dcheoky.s,cth
→ PSARM  STARRM  COSTAPM  PNSAROŌM  PSTA

`f87v.3`  y,cheockhy.okey.cthy<->yteeor.{ct}os
→ MSAROSŌAM  OŌRM  STAMMTRROR  STOP

`f87v.4`  dcheecthey.cthosy<->ykeeor.oky
→ NSARRSTARM  STAOPMMŌRROR  OŌM

`f87v.5`  ycheey.keeo.salckhy<->eoiin.scheom
→ MSARRM  ŌRRO  PULSŌAMROII?  PSAROS

`f87v.6`  dcheos.shey.solchiyd<->oteos.cthey
→ NSAROP  PARM  POLSAIMNOTROP  STARM

`f87v.7`  qotechoep.cheos.cthey<->qokeod.qokeog
→ COTRSAORM  SAROP  STARMCOŌRON  COŌRO?

`f87v.8`  shoeey.cthey.qo.cthodol<->yteodaiin.sheol
→ PAORRM  STARM  CO  STAONOLMTRONUII?  PAROL

`f87v.9`  techol.qoscheody.otol
→ TRSAOL  COPSARONM  OTOL

`f87v.10`  opcheey.{cthh}y.cpheckhy<->cheo,r,chepcheol
→ OMSARRM  STAAM  SMARSŌAMSARORSARMSAROL

`f87v.11`  kchor.ol.cheeol.qok,odal<->lseeey.keodam
→ ŌSAOR  OL  SARROL  COŌONULLPRRRM  ŌRONUS

`f87v.12`  ytcheoq[o:y].chos.ckheos.cheoy<->s,cheol.sal.dain
→ MTSAROCO  SAOP  SŌAROP  SAROMPSAROL  PUL  NUI?

`f87v.13`  ksheol.qoar.cfhs.ykaiin<->saral.aiim.am
→ ŌPAROL  COUR  S?AP  MŌUII?PURUL  UIIS  US

`f87v.14`  san.ainy.keol,dair.old<->ain.atolg
→ PU?  UI?M  ŌROLNUIR  OLNUI?  UTOL?

`f87v.15`  yksho.qos<->arolor.or<->al.daraiing
→ MŌPAO  COPUROLOR  ORUL  NURUII??

`f87v.16`  saiin.olcthr
→ PUII?  OLSTAR

### f88r  ·  pharmaceutical

`f88r.1`  otorchety
→ OTORSARTM

`f88r.2`  osal
→ OPUL

`f88r.3`  orald
→ ORULN

`f88r.4`  oldar
→ OLNUR

`f88r.5`  otoky
→ OTOŌM

`f88r.6`  otaly
→ OTULM

`f88r.7`  dorsheoy.ctheol.qockhey.dory.sheor.sholfchor.dal.chcthol
→ NORPAROM  STAROL  COSŌARM  NORM  PAROR  PAOL?SAOR  NUL  SASTAOL

`f88r.8`  [r:s]al,sheom.keol,chear.shekor.qokor.daiin.sar.s,aiin.oky.sam
→ RULPAROS  ŌROLSARUR  PARŌOR  COŌOR  NUII?  PUR  PUII?  OŌM  PUS

`f88r.9`  oain.or.om.otam.okeom.cheeor.qokeody.dar.or.om.cheody
→ OUI?  OR  OS  OTUS  OŌROS  SARROR  COŌRONM  NUR  OR  OS  SARONM

`f88r.10`  qokeol.cheol.saiin.cheos.cheol.doleeey.or.cheom.cheo[j:m]am
→ COŌROL  SAROL  PUII?  SAROP  SAROL  NOLRRRM  OR  SAROS  SARO?US

`f88r.11`  yokeody.cheom.qoor.cheeb.ykeor.shy.sam
→ MOŌRONM  SAROS  COOR  SARR?  MŌROR  PAM  PUS

`f88r.12`  otaldy
→ OTULNM

`f88r.13`  oram
→ ORUS

`f88r.14`  dary
→ NURM

`f88r.15`  okol
→ OŌOL

`f88r.16`  sorory
→ PORORM

`f88r.17`  otyda
→ OTMNU

`f88r.18`  koa{iphh}y.cphol.orchor.pcheoly.otchol.oldy.salsaly
→ ŌOUIMAAM  SMAOL  ORSAOR  MSAROLM  OTSAOL  OLNM  PULPULM

`f88r.19`  dchey.chokol.daiin.qoekol.qoekol.qockhol.okol.cheol
→ NSARM  SAOŌOL  NUII?  CORŌOL  CORŌOL  COSŌAOL  OŌOL  SAROL

`f88r.20`  dsheol.qokeey.s.chy.s,aiin.chor.oteor.aiin.chosals
→ NPAROL  COŌRRM  P  SAM  PUII?  SAOR  OTROR  UII?  SAOPULP

`f88r.21`  teol.chor.olsheody.qokeol.sho{ikh}y.ol.sheeol.sheoldg
→ TROL  SAOR  OLPARONM  COŌROL  PAOIŌAM  OL  PARROL  PAROLN?

`f88r.22`  ychey.okaiin.chol.cheor.ol.chorcholsal
→ MSARM  OŌUII?  SAOL  SAROR  OL  SAORSAOLPUL

`f88r.23`  ofyskydal
→ O?MPŌMNUL

`f88r.24`  otor,am
→ OTORUS

`f88r.25`  ofaldo
→ O?ULNO

`f88r.26`  poeear.sheoky.olkeey.cthol.poldy.s<->okoldy
→ MORRUR  PAROŌM  OLŌRRM  STAOL  MOLNM  POŌOLNM

`f88r.27`  qokol.chol.qokol.qokol.chol.cheey.or.aiin.oldal
→ COŌOL  SAOL  COŌOL  COŌOL  SAOL  SARRM  OR  UII?  OLNUL

`f88r.28`  ykar.cheol.chol.chey.ckhey.s,or.shear.ar,alsy
→ MŌUR  SAROL  SAOL  SARM  SŌARM  POR  PARUR  URULPM

`f88r.29`  kor,chey.qokol.cheol.chody.qokol.kchor.chol,dal
→ ŌORSARM  COŌOL  SAROL  SAONM  COŌOL  ŌSAOR  SAOLNUL

`f88r.30`  ykeeey.cheor.cheotey.cheol.qokeor.chetchy.ofal
→ MŌRRRM  SAROR  SAROTRM  SAROL  COŌROR  SARTSAM  O?UL

`f88r.31`  dar.chear.chol.dol.qoekeor.cheom
→ NUR  SARUR  SAOL  NOL  CORŌROR  SAROS

### f88v  ·  pharmaceutical

`f88v.1`  okalyd
→ OŌULMN

`f88v.2`  cheocthy
→ SAROSTAM

`f88v.3`  cpheor
→ SMAROR

`f88v.4`  otar.arody
→ OTUR  URONM

`f88v.5`  otokol
→ OTOŌOL

`f88v.6`  teodal.lkeo,cheor.roshckhy.sorshy<->aiin.cheokal.saldaiin
→ TRONUL  LŌROSAROR  ROPASŌAM  PORPAMUII?  SAROŌUL  PULNUII?

`f88v.7`  dshor.shor.qokeody.qokeo,lchey.chkeor.qokeey.daiin.qokeom
→ NPAOR  PAOR  COŌRONM  COŌROLSARM  SAŌROR  COŌRRM  NUII?  COŌROS

`f88v.8`  qoaiin.cheoy.olcheody.qoekeol.cho.chckhy.qoeey.key.cheokam
→ COUII?  SAROM  OLSARONM  CORŌROL  SAO  SASŌAM  CORRM  ŌRM  SAROŌUS

`f88v.9`  choeey.keeod,y.s,aiin.chody.okearcheol.archeey.sairal
→ SAORRM  ŌRRONM  PUII?  SAONM  OŌRURSAROL  URSARRM  PUIRUL

`f88v.10`  dar.cheorol.chekol,daraly
→ NUR  SAROROL  SARŌOLNURULM

`f88v.11`  otoram
→ OTORUS

`f88v.12`  otor[a:y]
→ OTORU

`f88v.13`  cheosdy
→ SAROPNM

`f88v.14`  okaiin
→ OŌUII?

`f88v.15`  kosholdy.qotody.opykey.oldaiin.qoteody.yfolaiin.oraiin
→ ŌOPAOLNM  COTONM  OMMŌRM  OLNUII?  COTRONM  M?OLUII?  ORUII?

`f88v.16`  ysheod.sheo.sheody.qokeody.qoky.chees.cheody.qokeody.dal
→ MPARON  PARO  PARONM  COŌRONM  COŌM  SARRP  SARONM  COŌRONM  NUL

`f88v.17`  qokeey.qokeody.chor.oteody.qockhol.okol.cheedy.qokody
→ COŌRRM  COŌRONM  SAOR  OTRONM  COSŌAOL  OŌOL  SARRNM  COŌONM

`f88v.18`  ykeeor.chockhy.otol.cheeol.cheody.qotody.soteol.ch[o:e]tam
→ MŌRROR  SAOSŌAM  OTOL  SARROL  SARONM  COTONM  POTROL  SAOTUS

`f88v.19`  odaiin.sheo,ol.qokeey.olaiin.cheody.chocthey.oteody,dy
→ ONUII?  PAROOL  COŌRRM  OLUII?  SARONM  SAOSTARM  OTRONMNM

`f88v.20`  [s:]qokeodaiin.cheody.oteol.cheockhy.chody
→ PCOŌRONUII?  SARONM  OTROL  SAROSŌAM  SAONM

`f88v.21`  toair{ch'}y.oteeody.cpheody.ykchey.dam.cheor.chaly,korain
→ TOUIRSAM  OTRRONM  SMARONM  MŌSARM  NUS  SAROR  SAULMŌORUI?

`f88v.22`  dairodain.ykeodain.dain.shedy.qoteo.lchdy.qokeo,r,ain
→ NUIRONUI?  MŌRONUI?  NUI?  PARNM  COTRO  LSANM  COŌRORUI?

`f88v.23`  tol,keeodaiin.qoky.sheol.daiin.chees.aiin.chokar.daim[d:g]
→ TOLŌRRONUII?  COŌM  PAROL  NUII?  SARRP  UII?  SAOŌUR  NUISN

`f88v.24`  daiin.sheor.sheedy.daiin.sho{ikh}y.qokeody.do{ikh}y.dair
→ NUII?  PAROR  PARRNM  NUII?  PAOIŌAM  COŌRONM  NOIŌAM  NUIR

`f88v.25`  ykeey.sheor.tos.checkhy.dain.cheos.cheockhy.saldy
→ MŌRRM  PAROR  TOP  SARSŌAM  NUI?  SAROP  SAROSŌAM  PULNM

`f88v.26`  saiin.choky.cheor.shy
→ PUII?  SAOŌM  SAROR  PAM

`f88v.27`  daramdal
→ NURUSNUL

`f88v.28`  otydary
→ OTMNURM

`f88v.29`  otdordy
→ OTNORNM

`f88v.30`  dararda[?:]
→ NURURNU

### f89r1  ·  pharmaceutical

`f89r1.1`  okchshy
→ OŌSAPAM

`f89r1.2`  qkol
→ CŌOL

`f89r1.3`  oldam
→ OLNUS

`f89r1.4`  otoldy
→ OTOLNM

`f89r1.5`  ararchodaiin
→ URURSAONUII?

`f89r1.6`  qoar,shar.qopcholy.qokod.chepy,dar.sheey.okor,sheeos.oldain
→ COURPAUR  COMSAOLM  COŌON  SARMMNUR  PARRM  OŌORPARROP  OLNUI?

`f89r1.7`  dshody.qocthy.chockhy.dal.chedy.qokeody.daldaiin.chodaiin.dal
→ NPAONM  COSTAM  SAOSŌAM  NUL  SARNM  COŌRONM  NULNUII?  SAONUII?  NUL

`f89r1.8`  qokeol.chol.qodaiin.chol.cheody.qokechy.daiin.ctheody.dam
→ COŌROL  SAOL  CONUII?  SAOL  SARONM  COŌRSAM  NUII?  STARONM  NUS

`f89r1.9`  yshor.s<->oiiin.daiin.qokeey.daiin.ckhol.qokain.cheamy
→ MPAOR  POIII?  NUII?  COŌRRM  NUII?  SŌAOL  COŌUI?  SARUSM

`f89r1.10`  tdain.s<->chol.cheoky.cheody.qokar.dal.chor.{ckhh}y.daiin
→ TNUI?  PSAOL  SAROŌM  SARONM  COŌUR  NUL  SAOR  SŌAAM  NUII?

`f89r1.11`  ykyd
→ MŌMN

`f89r1.12`  chol,ches
→ SAOLSARP

`f89r1.13`  otorain
→ OTORUI?

`f89r1.14`  okaiin,dan
→ OŌUII?NU?

`f89r1.15`  tcheol.qoeair.sheol.qocphey.saiin.cheocphey.dal,darolg
→ TSAROL  CORUIR  PAROL  COSMARM  PUII?  SAROSMARM  NULNUROL?

`f89r1.16`  om,sheey.qokey,l.daiin.dalchom.ch{ckhhh}y.chol.cheos.aiin.dy
→ OSPARRM  COŌRML  NUII?  NULSAOS  SASŌAAAM  SAOL  SAROP  UII?  NM

`f89r1.17`  qeaiin.cheyl.seey.qotey.qokeeol.daiin.{ykh}edy.daiin.dam
→ CRUII?  SARML  PRRM  COTRM  COŌRROL  NUII?  MŌARNM  NUII?  NUS

`f89r1.18`  dals,al.dal.cheody.dainaldy.al,daldal
→ NULPUL  NUL  SARONM  NUI?ULNM  ULNULNUL

`f89r1.19`  pshol.sheo.qoa{ith}y.cheocphy.s,sheyr.qokair,ydam.daly
→ MPAOL  PARO  COUITAM  SAROSMAM  PPARMR  COŌUIRMNUS  NULM

`f89r1.20`  daim.cheom.qoa{ith}y.air.cheody.ldain.dal.chom.chtaii@197;
→ NUIS  SAROS  COUITAM  UIR  SARONM  LNUI?  NUL  SAOS  SATUII

`f89r1.21`  taiin.dam.shoety.dal.qokchy.ykchdy.otcham.ol.sshr,aiin
→ TUII?  NUS  PAORTM  NUL  COŌSAM  MŌSANM  OTSAUS  OL  PPARUII?

`f89r1.22`  ycheeo,r.sheol.qockhedy.yty.sheody.qotol.chead,chey.dal
→ MSARROR  PAROL  COSŌARNM  MTM  PARONM  COTOL  SARUNSARM  NUL

`f89r1.23`  dain.oteos.cheody.cheodain.daiin.chodaiin
→ NUI?  OTROP  SARONM  SARONUI?  NUII?  SAONUII?

`f89r1.24`  ykocfhy
→ MŌOS?AM

`f89r1.25`  saldam
→ PULNUS

`f89r1.26`  [s:r]ydarary
→ PMNURURM

`f89r1.27`  yd{cpo}dy
→ MNSMONM

### f89r2  ·  pharmaceutical

`f89r2.1`  odory
→ ONORM

`f89r2.2`  doly
→ NOLM

`f89r2.3`  opchosam
→ OMSAOPUS

`f89r2.4`  saloiinsheol
→ PULOII?PAROL

`f89r2.5`  opcheor
→ OMSAROR

`f89r2.6`  qokcheody.cheodal.dair.cholkeedy.qokedy.cheal.cheo.dal.qoaii[s:r].shey.cpheeedol.deey.qockhey.chaldy.daim
→ COŌSARONM  SARONUL  NUIR  SAOLŌRRNM  COŌRNM  SARUL  SARO  NUL  COUIIP  PARM  SMARRRNOL  NRRM  COSŌARM  SAULNM  NUIS

`f89r2.7`  chos,aiin.cheodal.daiin.chy.chedain.dolchsyckheol.daiin.chody.cheedy.tchodol.chor.choldy.chos.dol.okcheeg
→ SAOPUII?  SARONUL  NUII?  SAM  SARNUI?  NOLSAPMSŌAROL  NUII?  SAONM  SARRNM  TSAONOL  SAOR  SAOLNM  SAOP  NOL  OŌSARR?

`f89r2.8`  tol.daiin.daiin.daiinody.qokeey.cheoldy.qody.cheor.sain.daiin.oky.cheody.cheoky
→ TOL  NUII?  NUII?  NUII?ONM  COŌRRM  SAROLNM  CONM  SAROR  PUI?  NUII?  OŌM  SARONM  SAROŌM

`f89r2.9`  otold[:y]
→ OTOLN

`f89r2.10`  okol.shol.dy
→ OŌOL  PAOL  NM

`f89r2.11`  opchoroiin
→ OMSAOROII?

`f89r2.12`  porachol.[y:q]ody.qoteol.oldaiin.otol.sheor.shor.oldaiin.otchol.cheol.otolpchy.dar,cho.lkeopol.oeeor.or
→ MORUSAOL  MONM  COTROL  OLNUII?  OTOL  PAROR  PAOR  OLNUII?  OTSAOL  SAROL  OTOLMSAM  NURSAO  LŌROMOL  ORROR  OR

`f89r2.13`  daiin.olkey.okeol.okey.okeeol.qoor.ol.chor.cheky.chol.daiin.chol.cheol.koldam.olcheol.dol,cheol
→ NUII?  OLŌRM  OŌROL  OŌRM  OŌRROL  COOR  OL  SAOR  SARŌM  SAOL  NUII?  SAOL  SAROL  ŌOLNUS  OLSAROL  NOLSAROL

`f89r2.14`  tos.ol.chor.ydaiin.chey.s.oiiin.chckhy.qokeol.okey.okeey.keey.{ca}eky.qokol.okeey.dal.cheeody.oeckhy
→ TOP  OL  SAOR  MNUII?  SARM  P  OIII?  SASŌAM  COŌROL  OŌRM  OŌRRM  ŌRRM  SURŌM  COŌOL  OŌRRM  NUL  SARRONM  ORSŌAM

`f89r2.15`  ycheo,keeo,ckho.saiin.okeo.daiin.ockhy.s,ockhey.saiin.chchky
→ MSAROŌRROSŌAO  PUII?  OŌRO  NUII?  OSŌAM  POSŌARM  PUII?  SASAŌM

`f89r2.16`  korainy
→ ŌORUI?M

`f89r2.17`  sodar
→ PONUR

`f89r2.18`  cheys
→ SARMP

`f89r2.19`  cheody
→ SARONM

`f89r2.20`  oporain
→ OMORUI?

`f89r2.21`  okshdchos
→ OŌPANSAOP

`f89r2.22`  kolches.sheol.qokeoefy.sheey.opcheor.opcheol.shody.sholdy.qokal.chey.oldy.sheodal.ytoldy
→ ŌOLSARP  PAROL  COŌROR?M  PARRM  OMSAROR  OMSAROL  PAONM  PAOLNM  COŌUL  SARM  OLNM  PARONUL  MTOLNM

`f89r2.23`  daiin.cheok,o,keol,daiin.dal.dair.qokeey.okeol.daiin.ykeody.okeeey.as.cheey.okeol.cheo.cheky
→ NUII?  SAROŌOŌROLNUII?  NUL  NUIR  COŌRRM  OŌROL  NUII?  MŌRONM  OŌRRRM  UP  SARRM  OŌROL  SARO  SARŌM

`f89r2.24`  yokeeol.cheol.qokeey.qokeol.chey.cheokor.okeey,ky.daiin.qokeol,cheey.qokeey.saiin.oteos
→ MOŌRROL  SAROL  COŌRRM  COŌROL  SARM  SAROŌOR  OŌRRMŌM  NUII?  COŌROLSARRM  COŌRRM  PUII?  OTROP

`f89r2.25`  daiin.dal.sheol.s.aiin.qocheey.daiiin.qokeeyl.qokeody.chol,cheol.ykeo.qo.qol.cheo.loiiin.doigom
→ NUII?  NUL  PAROL  P  UII?  COSARRM  NUIII?  COŌRRML  COŌRONM  SAOLSAROL  MŌRO  CO  COL  SARO  LOIII?  NOI?OS

`f89r2.26`  scheor.sy.sorcheey.dol.cheor.cheey.keey.qokeey.daiin.ycheary.okeey.keeokechy.cthey.daiin.dy
→ PSAROR  PM  PORSARRM  NOL  SAROR  SARRM  ŌRRM  COŌRRM  NUII?  MSARURM  OŌRRM  ŌRROŌRSAM  STARM  NUII?  NM

`f89r2.27`  qokol.cheor.okoiin.okeoy.qoeey.cheor.cheey.qokeol.cheal.s.aiin.ocheol.soiiin.dair.chey.daiin
→ COŌOL  SAROR  OŌOII?  OŌROM  CORRM  SAROR  SARRM  COŌROL  SARUL  P  UII?  OSAROL  POIII?  NUIR  SARM  NUII?

`f89r2.28`  o,r,ain.ar.ain.ol,daiin.qoaiin.ol.chkaiin.daiin.okar.dair,y?dair
→ ORUI?  UR  UI?  OLNUII?  COUII?  OL  SAŌUII?  NUII?  OŌUR  NUIRMNUIR

`f89r2.29`  okain
→ OŌUI?

`f89r2.30`  yorain
→ MORUI?

`f89r2.31`  ofakal
→ O?UŌUL

`f89r2.32`  otalsy
→ OTULPM

`f89r2.33`  ytarem
→ MTURRS

`f89r2.34`  otolarol
→ OTOLUROL

### f89v2  ·  pharmaceutical

`f89v2.1`  choeesy
→ SAORRPM

`f89v2.2`  okam
→ OŌUS

`f89v2.3`  darcheor
→ NURSAROR

`f89v2.4`  chokaro
→ SAOŌURO

`f89v2.5`  sheol
→ PAROL

`f89v2.6`  chokam
→ SAOŌUS

`f89v2.7`  kosar.sheol.s,aiin.koiin.chtodaiin.pdiin.choty.qofoiin.dy.qopdal.doiir.ofaiin.ol,cfheol,dam
→ ŌOPUR  PAROL  PUII?  ŌOII?  SATONUII?  MNII?  SAOTM  CO?OII?  NM  COMNUL  NOIIR  O?UII?  OLS?AROLNUS

`f89v2.8`  dain.ykodaiir.okor.chear.otees.eeckhy.s.aiin.ckhey.otaiin.okar.dain.okol.ol.chor.dar
→ NUI?  MŌONUIIR  OŌOR  SARUR  OTRRP  RRSŌAM  P  UII?  SŌARM  OTUII?  OŌUR  NUI?  OŌOL  OL  SAOR  NUR

`f89v2.9`  ychey.okeey.qoeol.daiin.chor.chos.cheos.qol,e,eeey.dal.chody.cheor.chey.qoaiin.chody
→ MSARM  OŌRRM  COROL  NUII?  SAOR  SAOP  SAROP  COLRRRRM  NUL  SAONM  SAROR  SARM  COUII?  SAONM

`f89v2.10`  dair.or.cheol.chom.qol.cheo.lcho.l.or.cheo,daiin.chkam
→ NUIR  OR  SAROL  SAOS  COL  SARO  LSAO  L  OR  SARONUII?  SAŌUS

`f89v2.11`  otory
→ OTORM

`f89v2.12`  otair.chody
→ OTUIR  SAONM

`f89v2.13`  dykaran
→ NMŌURU?

`f89v2.14`  opcheedey
→ OMSARRNRM

`f89v2.15`  sor.oairar.sheety.chodor.kory.oeear.eais.sheotain.ytodaiin
→ POR  OUIRUR  PARRTM  SAONOR  ŌORM  ORRUR  RUIP  PAROTUI?  MTONUII?

`f89v2.16`  o,cthos.okaiir.okeos.dar.s.siin.ykeody.dar.okal.dal.dosal.dar.am
→ OSTAOP  OŌUIIR  OŌROP  NUR  P  PII?  MŌRONM  NUR  OŌUL  NUL  NOPUL  NUR  US

`f89v2.17`  y,{ch'}eo.qokeeol.chey.sair.dam.chy,for.opodaiin.dam.sa[s:r]y.qodam.yteos.aiin
→ MSARO  COŌRROL  SARM  PUIR  NUS  SAM?OR  OMONUII?  NUS  PUPM  CONUS  MTROP  UII?

`f89v2.18`  yokor.chor.cthy.daiin.chos.chey.dar.aiin,choeeer.okar.chcthy.darai[?:l]s
→ MOŌOR  SAOR  STAM  NUII?  SAOP  SARM  NUR  UII?SAORRRR  OŌUR  SASTAM  NURUIP

`f89v2.19`  toar.qokeeody.doef.shey.dair.olsheos.psheoepoain.daiin.qekor.okeor.otol,sheey.daldaiin
→ TOUR  COŌRRONM  NOR?  PARM  NUIR  OLPAROP  MPARORMOUI?  NUII?  CRŌOR  OŌROR  OTOLPARRM  NULNUII?

`f89v2.20`  dol.dair.chey.okaiin.shy.daiin.odor.sheos.aiin.daikeody.qokorar.sheody.qoko.ltcheody.otal
→ NOL  NUIR  SARM  OŌUII?  PAM  NUII?  ONOR  PAROP  UII?  NUIŌRONM  COŌORUR  PARONM  COŌO  LTSARONM  OTUL

`f89v2.21`  dar.qockhy.qokal.okeoy.chockh[:y].daiin.odaiin.ykeody.okols,sheey.keeody.daiin.qokos.okeom
→ NUR  COSŌAM  COŌUL  OŌROM  SAOSŌA  NUII?  ONUII?  MŌRONM  OŌOLPPARRM  ŌRRONM  NUII?  COŌOP  OŌROS

`f89v2.22`  ockhody.daiin.ykam.s.chty,chy.cthey.dair,air.chool.loy.dair.cheo,daiin
→ OSŌAONM  NUII?  MŌUS  P  SATMSAM  STARM  NUIRUIR  SAOOL  LOM  NUIR  SARONUII?

`f89v2.23`  opaloiiry
→ OMULOIIRM

`f89v2.24`  otaram
→ OTURUS

`f89v2.25`  chtchy
→ SATSAM

`f89v2.27`  sada?
→ PUNU

`f89v2.28`  daseky
→ NUPRŌM

### f89v1  ·  pharmaceutical

`f89v1.1`  okoraldy
→ OŌORULNM

`f89v1.2`  oto{ikh}y
→ OTOIŌAM

`f89v1.3`  otchar
→ OTSAUR

`f89v1.4`  darshody
→ NURPAONM

`f89v1.5`  koldal.sfal.cfhey.ofcheol.opolsy.daiin.qopol.oldaiin.octhody
→ ŌOLNUL  P?UL  S?ARM  O?SAROL  OMOLPM  NUII?  COMOL  OLNUII?  OSTAONM

`f89v1.6`  dor.sheey.qokol.cheol.cthody.qockhy.dain.yteey.otar.cthol
→ NOR  PARRM  COŌOL  SAROL  STAONM  COSŌAM  NUI?  MTRRM  OTUR  STAOL

`f89v1.7`  qokey.daiin.cheey.ctho,dy.qoor.shear.s,ol.chor.chearory
→ COŌRM  NUII?  SARRM  STAONM  COOR  PARUR  POL  SAOR  SARURORM

`f89v1.8`  shockhey.orarol.cheoky.qoy,chodair.choky.daiin.otarokar
→ PAOSŌARM  ORUROL  SAROŌM  COMSAONUIR  SAOŌM  NUII?  OTUROŌUR

`f89v1.9`  to{chh}o.cthor.okol.chekaiin.os.aiin.ol.cheokchey.qokoiiin.du
→ TOSAAO  STAOR  OŌOL  SARŌUII?  OP  UII?  OL  SAROŌSARM  COŌOIII?  N?

`f89v1.10`  tor.sheor.cheeor.cthey.qokol.daiin.chekal.dals.chear.qotam
→ TOR  PAROR  SARROR  STARM  COŌOL  NUII?  SARŌUL  NULP  SARUR  COTUS

`f89v1.11`  osheokaiin.s,ain.ol.shodain.qokar.ain.chekal.daiin.dar
→ OPAROŌUII?  PUI?  OL  PAONUI?  COŌUR  UI?  SARŌUL  NUII?  NUR

`f89v1.12`  qokar.odaiin
→ COŌUR  ONUII?

`f89v1.13`  tosheo.fcheody.shekey.or,shos.oiir.cphey.qokeody.cheody.daldy
→ TOPARO  ?SARONM  PARŌRM  ORPAOP  OIIR  SMARM  COŌRONM  SARONM  NULNM

`f89v1.14`  ykeey.ykeey.odal.shoky.okol.chody.okoaiin.dal,chdy.daldaldy
→ MŌRRM  MŌRRM  ONUL  PAOŌM  OŌOL  SAONM  OŌOUII?  NULSANM  NULNULNM

`f89v1.15`  dcheo{cy}.daiin.cthol.daiin.daldy.okeor.ytey.keor.cheyty.ochy
→ NSAROSM  NUII?  STAOL  NUII?  NULNM  OŌROR  MTRM  ŌROR  SARMTM  OSAM

`f89v1.16`  qokaiin.ykchol.qockhy.okaldy.okal.dal.chodar.okaiin.dalg
→ COŌUII?  MŌSAOL  COSŌAM  OŌULNM  OŌUL  NUL  SAONUR  OŌUII?  NUL?

`f89v1.17`  sal.shol.ykol.daram.sholckhy.dolchey.dalshdy.okeol.dalchy
→ PUL  PAOL  MŌOL  NURUS  PAOLSŌAM  NOLSARM  NULPANM  OŌROL  NULSAM

`f89v1.18`  qokol.sheol.qokol.dal.chol,dam.qoeey.saiin.ols.chokaiin
→ COŌOL  PAROL  COŌOL  NUL  SAOLNUS  CORRM  PUII?  OLP  SAOŌUII?

`f89v1.19`  sar.a.da[iin:?].ckhy.qotchy.okol.ycheo.cthody.okol.olkaycthy
→ PUR  U  NUII?  SŌAM  COTSAM  OŌOL  MSARO  STAONM  OŌOL  OLŌUMSTAM

`f89v1.20`  sol,chey.okchol.sair.daiin.okal,choldy
→ POLSARM  OŌSAOL  PUIR  NUII?  OŌULSAOLNM

`f89v1.21`  koeeorain
→ ŌORRORUI?

`f89v1.22`  otorshos
→ OTORPAOP

`f89v1.23`  opol,olaiin
→ OMOLOLUII?

`f89v1.24`  opaldaiin
→ OMULNUII?

### f90r1  ·  herbal

`f90r1.1`  poleeol.qokeol.qokchod.choly.ctho[g:m]
→ MOLRROL  COŌROL  COŌSAON  SAOLM  STAO?

`f90r1.2`  yshol.tor.sheor.qotchor.qoky.darala
→ MPAOL  TOR  PAROR  COTSAOR  COŌM  NURULU

`f90r1.3`  dair.shkeea.s.sary.okar.ykorshy.lkaldy
→ NUIR  PAŌRRU  P  PURM  OŌUR  MŌORPAM  LŌULNM

`f90r1.4`  talchor.chodaiin.chocfhor.qokchor.chockhy<->okchod.qofchol
→ TULSAOR  SAONUII?  SAOS?AOR  COŌSAOR  SAOSŌAMOŌSAON  CO?SAOL

`f90r1.5`  ytor.ckhy.lpychol.sho.ol.okachey.[r:s].sheom.kchol.dchy.dasady
→ MTOR  SŌAM  LMMSAOL  PAO  OL  OŌUSARM  R  PAROS  ŌSAOL  NSAM  NUPUNM

`f90r1.6`  tol.otchol.shorydar.qokeos.okeoschso.chol,ytod.qokeos.dolshy
→ TOL  OTSAOL  PAORMNUR  COŌROP  OŌROPSAPO  SAOLMTON  COŌROP  NOLPAM

`f90r1.7`  dar.chos.qocthy.qokcha.shko.qokol.oteey.chofy.ykeody.qokod
→ NUR  SAOP  COSTAM  COŌSAU  PAŌO  COŌOL  OTRRM  SAO?M  MŌRONM  COŌON

`f90r1.8`  kor.sheol.qodar.oko.ykeey.qokeey.qodar.qokeed.s.choky
→ ŌOR  PAROL  CONUR  OŌO  MŌRRM  COŌRRM  CONUR  COŌRRN  P  SAOŌM

`f90r1.9`  ykodar.qoekchy.shokol.okam
→ MŌONUR  CORŌSAM  PAOŌOL  OŌUS

### f90r2  ·  herbal

`f90r2.1`  toealchs.shakol.sheo.qoekeey<->soeeol.qoteody
→ TORULSAP  PAUŌOL  PARO  CORŌRRMPORROL  COTRONM

`f90r2.2`  saiin.ckheo.saiin.qockhey.s.ykeeody<->s,cheey.chos.ckhs
→ PUII?  SŌARO  PUII?  COSŌARM  P  MŌRRONMPSARRM  SAOP  SŌAP

`f90r2.3`  dsheeos.qokeod.qokeo.chol.ol.okal<->saiin.ctheo,s,ar
→ NPARROP  COŌRON  COŌRO  SAOL  OL  OŌULPUII?  STAROPUR

`f90r2.4`  al.s.oin.cheo.ro.sokeey.qokeeas<->al.aral.oy[r:s]
→ UL  P  OI?  SARO  RO  POŌRRM  COŌRRUPUL  URUL  OMR

`f90r2.5`  ychor.ckhor.qoeeor.okaiin.dom<->olcheo.rodaiin
→ MSAOR  SŌAOR  CORROR  OŌUII?  NOSOLSARO  RONUII?

`f90r2.6`  daiin.qokor.okoiin.daiin
→ NUII?  COŌOR  OŌOII?  NUII?

### f90v2  ·  herbal

`f90v2.1`  {c@181;h}da{i@133;h}y.qocfhey.opolraiin.ofchedal.s?<->shese.shodaiin.shea[s:r]
→ SANUIAM  COS?ARM  OMOLRUII?  O?SARNUL  PPARPR  PAONUII?  PARUP

`f90v2.2`  podchey.ctheod.{ikh}eeos.cheey.ykeey.s.o[is:?]<->qokchas.s,oin.sam
→ MONSARM  STARON  IŌARROP  SARRM  MŌRRM  P  OIPCOŌSAUP  POI?  PUS

`f90v2.3`  saiin.sheom.sheey.keeos.ol.cheeor.chy<->shy.tchody.okeeo[m:g]
→ PUII?  PAROS  PARRM  ŌRROP  OL  SARROR  SAMPAM  TSAONM  OŌRROS

`f90v2.4`  tchos.oteey.saiin.okeeey
→ TSAOP  OTRRM  PUII?  OŌRRRM

`f90v2.5`  tcheody.cpheal.qoar.cheol.chos,olols<->dshcheal.sheol.qodar
→ TSARONM  SMARUL  COUR  SAROL  SAOPOLOLPNPASARUL  PAROL  CONUR

`f90v2.6`  sal.sheol.shey.qokeey.qokeol.cheody.s<->ykeeol,dar,chody.y
→ PUL  PAROL  PARM  COŌRRM  COŌROL  SARONM  PMŌRROLNURSAONM  M

`f90v2.7`  shey.s.shee[y:a]l.sheol.sheody.tol.sheo{cty}<->oteey.chodar.chog
→ PARM  P  PARRML  PAROL  PARONM  TOL  PAROSTMOTRRM  SAONUR  SAO?

`f90v2.8`  teeas.qkeody.qokchy.oteeol.daiin
→ TRRUP  CŌRONM  COŌSAM  OTRROL  NUII?

### f90v1  ·  herbal

`f90v1.1`  pcheor.chodar.oleees.chepy.shol<->shckheo<->otol.shey<->cheo,r.cheokeey
→ MSAROR  SAONUR  OLRRRP  SARMM  PAOLPASŌAROOTOL  PARMSAROR  SAROŌRRM

`f90v1.2`  tshor.olsheod.qodaiin.qokeor.sy<->oraiin<->ykeeol<->octheody.{cthhh}y
→ TPAOR  OLPARON  CONUII?  COŌROR  PMORUII?MŌRROLOSTARONM  STAAAM

`f90v1.3`  daiin.shody.cfheos.qockhy.chol,ol<->sals<->sol<->yteey.or.cheey,tey
→ NUII?  PAONM  S?AROP  COSŌAM  SAOLOLPULPPOLMTRRM  OR  SARRMTRM

`f90v1.4`  kos.sheor.chockhor.qekeody.cheody<->sy<->s<->olcheey.{cthh}y.qoky
→ ŌOP  PAROR  SAOSŌAOR  CRŌRONM  SARONMPMPOLSARRM  STAAM  COŌM

`f90v1.5`  dcheey.keey.keeey.cthey.yty<->okeeody<->sy<->olcheey.sh.qokeys
→ NSARRM  ŌRRM  ŌRRRM  STARM  MTMOŌRRONMPMOLSARRM  PA  COŌRMP

`f90v1.6`  shctheo,ror,sheol,ol.kaiin
→ PASTARORORPAROLOL  ŌUII?

`f90v1.7`  ksheodal.sheody.qocheot[o:y]<->shokol.qokeshs<->yteody.poda{i@182;h}ey
→ ŌPARONUL  PARONM  COSAROTOPAOŌOL  COŌRPAPMTRONM  MONUIARM

`f90v1.8`  daiin.okeeey.cheo.qotecheor.cthodaim.s<->cheol.chor.okeam
→ NUII?  OŌRRRM  SARO  COTRSAROR  STAONUIS  PSAROL  SAOR  OŌRUS

`f90v1.9`  sheor.ol.qokeeoky.okeeol.okeeodaiin.ytol<->sor.a[s:r]iin.aiin
→ PAROR  OL  COŌRROŌM  OŌRROL  OŌRRONUII?  MTOLPOR  UPII?  UII?

`f90v1.10`  ykeeor.cheos.q{kh}ey.cheos.oteol.okechod<->oeey.keeos.aiiin
→ MŌRROR  SAROP  CŌARM  SAROP  OTROL  OŌRSAONORRM  ŌRROP  UIII?

`f90v1.11`  deeocthey.keeeol.sheol.{c't}sheol.daiin
→ NRROSTARM  ŌRRROL  PAROL  STPAROL  NUII?

### f93r  ·  herbal

`f93r.1`  kodshol.otolsheeos.octhodaly.opalepam.oepchksheey.qotodain.s.oar
→ ŌONPAOL  OTOLPARROP  OSTAONULM  OMULRMUS  ORMSAŌPARRM  COTONUI?  P  OUR

`f93r.2`  ycham.s.chol.chotom.cthodar.sheo.s.oteodal.s<->ofchoshy.cthoshol
→ MSAUS  P  SAOL  SAOTOS  STAONUR  PARO  P  OTRONUL  PO?SAOPAM  STAOPAOL

`f93r.3`  dsho.dal.dalody.ytchchy.dam.chody.dal,ol<->schodchy.qotchd
→ NPAO  NUL  NULONM  MTSASAM  NUS  SAONM  NULOLPSAONSAM  COTSAN

`f93r.4`  sol.shotol.qokchodal.shody.chotol,s<->otol.ytchdg
→ POL  PAOTOL  COŌSAONUL  PAONM  SAOTOLPOTOL  MTSAN?

`f93r.5`  ol.chody.cfhol.dol.qokol.otodar<->chodain
→ OL  SAONM  S?AOL  NOL  COŌOL  OTONURSAONUI?

`f93r.6`  tar,otor.s.cho.s.chol.sheoees
→ TUROTOR  P  SAO  P  SAOL  PARORRP

`f93r.7`  shor.shol.ody.cheodaiin.s
→ PAOR  PAOL  ONM  SARONUII?  P

`f93r.8`  lor,sheeody.chodaiin.s.odar
→ LORPARRONM  SAONUII?  P  ONUR

`f93r.9`  shodam.okcheody.cthoctho'l
→ PAONUS  OŌSARONM  STAOSTAOL

`f93r.10`  ychos.chey.keol.cheol.ckhody
→ MSAOP  SARM  ŌROL  SAROL  SŌAONM

`f93r.11`  okeol.oteol.s,odam.sheo,al.sal
→ OŌROL  OTROL  PONUS  PAROUL  PUL

`f93r.12`  qokor.shey.okcheor.sheodom
→ COŌOR  PARM  OŌSAROR  PARONOS

`f93r.13`  shodaiin.qotchy.kchol,r
→ PAONUII?  COTSAM  ŌSAOLR

`f93r.14`  ychey.ckhos.okcheod.chr
→ MSARM  SŌAOP  OŌSARON  SAR

`f93r.15`  ochol.shodal.dol.cheodam
→ OSAOL  PAONUL  NOL  SARONUS

`f93r.16`  choshy.qokor.chckhs
→ SAOPAM  COŌOR  SASŌAP

`f93r.17`  tcheo.l.cholchecthody
→ TSARO  L  SAOLSARSTAONM

`f93r.18`  olkees.shodaiin.shody
→ OLŌRRP  PAONUII?  PAONM

`f93r.19`  tchor.shol.r.sheoky
→ TSAOR  PAOL  R  PAROŌM

`f93r.20`  ychockhy.cthol.osos
→ MSAOSŌAM  STAOL  OPOP

`f93r.21`  dol.shol.daiin.shcthy
→ NOL  PAOL  NUII?  PASTAM

`f93r.22`  kchor.cthy.chakal.daiin
→ ŌSAOR  STAM  SAUŌUL  NUII?

`f93r.23`  oain.okor.shody.teols
→ OUI?  OŌOR  PAONM  TROLP

`f93r.24`  ychocthy.chotey.teey,s
→ MSAOSTAM  SAOTRM  TRRMP

`f93r.25`  ysaiin.chotar.shody
→ MPUII?  SAOTUR  PAONM

`f93r.26`  ocheodaiin.tchos.sor
→ OSARONUII?  TSAOP  POR

`f93r.27`  qokor.cheo.los.ckheody
→ COŌOR  SARO  LOP  SŌARONM

`f93r.28`  ychor.odol.chodaiin.s
→ MSAOR  ONOL  SAONUII?  P

`f93r.29`  dain.{ck}cho.ctho.ctho[s:e]g
→ NUI?  SŌSAO  STAO  STAOP?

`f93r.30`  shodaiin.qokcho.cthol
→ PAONUII?  COŌSAO  STAOL

`f93r.31`  ol.chol.cthol.olchod
→ OL  SAOL  STAOL  OLSAON

`f93r.32`  dol.chokal.schos
→ NOL  SAOŌUL  PSAOP

### f93v  ·  herbal

`f93v.1`  possheody.qoteeo.qoshocphy.opchody.opor<->opchy<->otchdal.or.shodaiin
→ MOPPARONM  COTRRO  COPAOSMAM  OMSAONM  OMOROMSAMOTSANUL  OR  PAONUII?

`f93v.2`  yteeody.qotody.qotchol.qocthody.ytey<->oky<->daiin<->dar.ctho[g:m]
→ MTRRONM  COTONM  COTSAOL  COSTAONM  MTRMOŌMNUII?NUR  STAO?

`f93v.3`  dchos.chody.qockhol.oky.cheodaiin.oty<->daiin<->otal<->dair.okol
→ NSAOP  SAONM  COSŌAOL  OŌM  SARONUII?  OTMNUII?OTULNUIR  OŌOL

`f93v.4`  sol.shol.shdchy.qokchol.qokchody.chol<->chol<->{cty}<->ykchy.dar
→ POL  PAOL  PANSAM  COŌSAOL  COŌSAONM  SAOLSAOLSTMMŌSAM  NUR

`f93v.5`  tshoky.cthody.qotchol.ckhol.dchog.s<->olo.oteo[?:s].chodaiindy
→ TPAOŌM  STAONM  COTSAOL  SŌAOL  NSAO?  POLO  OTRO  SAONUII?NM

`f93v.6`  ytch[?:o]l.ckhol.qochocthy.ctho.chkeey.cthody.s<->dar.she[y:q]okam
→ MTSAL  SŌAOL  COSAOSTAM  STAO  SAŌRRM  STAONM  PNUR  PARMOŌUS

`f93v.7`  oees.ckheody.qkcheey.koldy.tchodaiin.ctheos<->shodain.qokeeam
→ ORRP  SŌARONM  CŌSARRM  ŌOLNM  TSAONUII?  STAROPPAONUI?  COŌRRUS

`f93v.8`  dcho.chody.teol.sheol.cheeoldair.okchey.cthey<->dsheog.okeey.dama
→ NSAO  SAONM  TROL  PAROL  SARROLNUIR  OŌSARM  STARMNPARO?  OŌRRM  NUSU

`f93v.9`  odeeeodl.cheodar.oksho.chody.okchey.cthol.oly<->ytchol<->sar<->dar
→ ONRRRONL  SARONUR  OŌPAO  SAONM  OŌSARM  STAOL  OLMMTSAOLPURNUR

`f93v.10`  ychol.chs.ckhy.s,cheeol
→ MSAOL  SAP  SŌAM  PSARROL

### f94r  ·  herbal

`f94r.1`  tchedy.opaiir.chedaiin.dsheedy.qopchedal.keodaiin.otalaiin.oar
→ TSARNM  OMUIIR  SARNUII?  NPARRNM  COMSARNUL  ŌRONUII?  OTULUII?  OUR

`f94r.2`  dor.cheody.okaiin.odor.okal.okair.oky.daiir.qotar.okar.olaiin
→ NOR  SARONM  OŌUII?  ONOR  OŌUL  OŌUIR  OŌM  NUIIR  COTUR  OŌUR  OLUII?

`f94r.3`  todal.cholky.qokal.shdy.qoky.otody.qokolchey.qokair.opary
→ TONUL  SAOLŌM  COŌUL  PANM  COŌM  OTONM  COŌOLSARM  COŌUIR  OMURM

`f94r.4`  shor.olkeedy.ol,kchdy.cheedy.kalchdy.chedaiin.or.chol,kar,am
→ PAOR  OLŌRRNM  OLŌSANM  SARRNM  ŌULSANM  SARNUII?  OR  SAOLŌURUS

`f94r.5`  daiin.chekar.olkaiin.olkeody.ykaiin.otain.dar.okeed[y:o].ykaro
→ NUII?  SARŌUR  OLŌUII?  OLŌRONM  MŌUII?  OTUI?  NUR  OŌRRNM  MŌURO

`f94r.6`  saiin.choky.qotchdy.otaly.chedy.dal.dy.chckhaiin.chk.qof
→ PUII?  SAOŌM  COTSANM  OTULM  SARNM  NUL  NM  SASŌAUII?  SAŌ  CO?

`f94r.7`  pchedar.oraiin.cheor.kas.or.als<->o,xo{ckhh}y.olkain.am
→ MSARNUR  ORUII?  SAROR  ŌUP  OR  ULPO?OSŌAAM  OLŌUI?  US

`f94r.8`  yty.qokaiin.ykal.chdy.qoky<->osain.chykaidy.dam
→ MTM  COŌUII?  MŌUL  SANM  COŌMOPUI?  SAMŌUINM  NUS

`f94r.9`  otar,chdy.dytchdy
→ OTURSANM  NMTSANM

### f94v  ·  herbal

`f94v.1`  tshedy.chedar.char.qokchedy.okal.dar<->opchackhy.oteedan
→ TPARNM  SARNUR  SAUR  COŌSARNM  OŌUL  NUROMSAUSŌAM  OTRRNU?

`f94v.2`  ol,teedy.oteey.qekeey.oteey.teedal<->ykeedy.qotarain
→ OLTRRNM  OTRRM  CRŌRRM  OTRRM  TRRNULMŌRRNM  COTURUI?

`f94v.3`  yshedy.chdaiin.otedy.sdal,tamdy<->chdy.qokeey.tam
→ MPARNM  SANUII?  OTRNM  PNULTUSNMSANM  COŌRRM  TUS

`f94v.4`  dchdy.otar.otchy,kedy.qokchdy.ol<->okchy
→ NSANM  OTUR  OTSAMŌRNM  COŌSANM  OLOŌSAM

`f94v.5`  tedain.chedy.qokshd.okchdy.qokeal<->chorchor.tchor,am
→ TRNUI?  SARNM  COŌPAN  OŌSANM  COŌRULSAORSAOR  TSAORUS

`f94v.6`  ycheeo.lkeol.otor.opchdy.qotar.aral<->otor.otchy.tody.oty
→ MSARRO  LŌROL  OTOR  OMSANM  COTUR  URULOTOR  OTSAM  TONM  OTM

`f94v.7`  toky.shey.qokaiin
→ TOŌM  PARM  COŌUII?

`f94v.8`  pchedaiin.sheocthy.daiin.cphedy.fchd<->otchy.qotchy.par,ar
→ MSARNUII?  PAROSTAM  NUII?  SMARNM  ?SANOTSAM  COTSAM  MURUR

`f94v.9`  ytar.okedy.okeedy.qokshey.otaiin,y<->ypchdair.ol.s.aiin.oly
→ MTUR  OŌRNM  OŌRRNM  COŌPARM  OTUII?MMMSANUIR  OL  P  UII?  OLM

`f94v.10`  ol,air.cheey.okchaiin.shy.tararain<->otody.qodar.oteey.dar
→ OLUIR  SARRM  OŌSAUII?  PAM  TURURUI?OTONM  CONUR  OTRRM  NUR

`f94v.11`  todaiin.sh{cthh}y.qokar.chetaiin.chdy<->ykol.qoky.or,eedy.oky
→ TONUII?  PASTAAM  COŌUR  SARTUII?  SANMMŌOL  COŌM  ORRRNM  OŌM

`f94v.12`  daiin.chcthy.chdy.chckhy.okaiin
→ NUII?  SASTAM  SANM  SASŌAM  OŌUII?

### f95r1  ·  herbal

`f95r1.1`  kshdor.chepchdy.ofaiin.ol.oldaiin.opshol.qokaiin.oty.odain
→ ŌPANOR  SARMSANM  O?UII?  OL  OLNUII?  OMPAOL  COŌUII?  OTM  ONUI?

`f95r1.2`  ol.chdy.chdy.qokaiin.shdy.qokaiin.chdy,kol,chdy.qoty.oky,dan
→ OL  SANM  SANM  COŌUII?  PANM  COŌUII?  SANMŌOLSANM  COTM  OŌMNU?

`f95r1.3`  teodaiin.oekeey.qokees.ody.chekaiin.chekaiin.chky.chaiin
→ TRONUII?  ORŌRRM  COŌRRP  ONM  SARŌUII?  SARŌUII?  SAŌM  SAUII?

`f95r1.4`  ycheey,ky.olkain.chey,kain.cholky.chedy.qokaiin.chy.kaiin.ly
→ MSARRMŌM  OLŌUI?  SARMŌUI?  SAOLŌM  SARNM  COŌUII?  SAM  ŌUII?  LM

`f95r1.5`  atar.chedy.todaiin.qoky.shdaly
→ UTUR  SARNM  TONUII?  COŌM  PANULM

`f95r1.6`  tchdor.or.chekchdy.qokar.chcthy.qotchdy,lshedy.qoky.qofain.dy
→ TSANOR  OR  SARŌSANM  COŌUR  SASTAM  COTSANMLPARNM  COŌM  CO?UI?  NM

`f95r1.7`  ykchedy.sheky.chekar.chdain.chdaiin.okar.chetchdy.chdy.chkam
→ MŌSARNM  PARŌM  SARŌUR  SANUI?  SANUII?  OŌUR  SARTSANM  SANM  SAŌUS

`f95r1.8`  olkor.chdaiin.cholkaiin.qokeedy.qoky.chey.lchedy.chedy.alod
→ OLŌOR  SANUII?  SAOLŌUII?  COŌRRNM  COŌM  SARM  LSARNM  SARNM  ULON

`f95r1.9`  tchdy.tchor.chol.tar.chdy.okol.ykoldy.olkeedy.qotaiin.or
→ TSANM  TSAOR  SAOL  TUR  SANM  OŌOL  MŌOLNM  OLŌRRNM  COTUII?  OR

`f95r1.10`  daiin.chckhy.okaiin.chckhy.daiin.ykedy.ep[?:a]iin.okaraiin.ls
→ NUII?  SASŌAM  OŌUII?  SASŌAM  NUII?  MŌRNM  RMII?  OŌURUII?  LP

`f95r1.11`  ykaiin.or.chdy.chekain.ol,dar.ykar.olkeey.ldar.chekal
→ MŌUII?  OR  SANM  SARŌUI?  OLNUR  MŌUR  OLŌRRM  LNUR  SARŌUL

### f95r2  ·  herbal

`f95r2.1`  kshedy.or.chdy.dalfchy.qodaiin.chckhyfchy.daraiin.dalal
→ ŌPARNM  OR  SANM  NUL?SAM  CONUII?  SASŌAM?SAM  NURUII?  NULUL

`f95r2.2`  daiin.shody.chkain.chol.chckhy.otain.oty.oteedy.kar,okam
→ NUII?  PAONM  SAŌUI?  SAOL  SASŌAM  OTUI?  OTM  OTRRNM  ŌUROŌUS

`f95r2.3`  todaiin.chor.chckhy.qokol.chkar.ol.otaiin.ofar.okain.aram
→ TONUII?  SAOR  SASŌAM  COŌOL  SAŌUR  OL  OTUII?  O?UR  OŌUI?  URUS

`f95r2.4`  daiin.shody.tor.or.okain.chckhey
→ NUII?  PAONM  TOR  OR  OŌUI?  SASŌARM

`f95r2.5`  tshod.qokal.ody.chcfhol.okal.chedy.dalshdy.qopchdy.kary
→ TPAON  COŌUL  ONM  SAS?AOL  OŌUL  SARNM  NULPANM  COMSANM  ŌURM

`f95r2.6`  y,olkor.ol.shol.qotar.chdy.chdy.qokar.okar.qokar.odaly
→ MOLŌOR  OL  PAOL  COTUR  SANM  SANM  COŌUR  OŌUR  COŌUR  ONULM

`f95r2.7`  dshedy.otal.qokal.dol.or.eeedy.okeedy.okedyted.otam
→ NPARNM  OTUL  COŌUL  NOL  OR  RRRNM  OŌRRNM  OŌRNMTRN  OTUS

`f95r2.8`  tedykaiin.y,cheol.okal.chedy.shdy.qokchdy.otar.chctham
→ TRNMŌUII?  MSAROL  OŌUL  SARNM  PANM  COŌSANM  OTUR  SASTAUS

`f95r2.9`  poiin.okar.qokol.shsdy.okar.chdaiin.olky
→ MOII?  OŌUR  COŌOL  PAPNM  OŌUR  SANUII?  OLŌM

### f95v2  ·  herbal

`f95v2.1`  tchody,podar.shody.qofaiin.ofchdy.otedy.qotedaiin.shor.olsain
→ TSAONMMONUR  PAONM  CO?UII?  O?SANM  OTRNM  COTRNUII?  PAOR  OLPUI?

`f95v2.2`  sol.shedy.qotchey.alor.chdyty.olor.ok[a:o]dy.chody.qotaiin.y.kaipy
→ POL  PARNM  COTSARM  ULOR  SANMTM  OLOR  OŌUNM  SAONM  COTUII?  M  ŌUIMM

`f95v2.3`  archytaiin.shekoiin.okar.or.aiin.chckhy.okal.otain.okalody
→ URSAMTUII?  PARŌOII?  OŌUR  OR  UII?  SASŌAM  OŌUL  OTUI?  OŌULONM

`f95v2.4`  daiin.olkain.qokan.shar.shekydy.dain.alkain<->okalaiin.s
→ NUII?  OLŌUI?  COŌU?  PAUR  PARŌMNM  NUI?  ULŌUI?OŌULUII?  P

`f95v2.5`  tar.fcheey.shos.aiin.okar.olkaiin.otalain<->okaiin,ar
→ TUR  ?SARRM  PAOP  UII?  OŌUR  OLŌUII?  OTULUI?OŌUII?UR

`f95v2.6`  dain.ykaly.chals<->shedain.olaiin.y<->okain.ldy
→ NUI?  MŌULM  SAULPPARNUI?  OLUII?  MOŌUI?  LNM

`f95v2.7`  qokeey.dar.chdykain<->ytasal.otain
→ COŌRRM  NUR  SANMŌUI?MTUPUL  OTUI?

### f95v1  ·  herbal

`f95v1.1`  {c@132;h}olteedy,{c@133;h}oepaiin.oekshy.qofchdaiin.shoyfar.okshy.okain.ar.alfshed
→ SAOLTRRNMSAORMUII?  ORŌPAM  CO?SANUII?  PAOM?UR  OŌPAM  OŌUI?  UR  UL?PARN

`f95v1.2`  okshy.tshor.qoksh.qokain.otar.oty.qokedy.otal.ytchdy.qokar.am
→ OŌPAM  TPAOR  COŌPA  COŌUI?  OTUR  OTM  COŌRNM  OTUL  MTSANM  COŌUR  US

`f95v1.3`  tchody.qokaiin.y,char.okain.sheody.chedy.chcthykedy.ety.dain.al
→ TSAONM  COŌUII?  MSAUR  OŌUI?  PARONM  SARNM  SASTAMŌRNM  RTM  NUI?  UL

`f95v1.4`  tchedy.qokal.oty.shekshey.otaldy.okshey.ytshedy.okarar.yty.chdy
→ TSARNM  COŌUL  OTM  PARŌPARM  OTULNM  OŌPARM  MTPARNM  OŌURUR  MTM  SANM

`f95v1.5`  otal.shedy.odaiin.chey
→ OTUL  PARNM  ONUII?  SARM

`f95v1.6`  tshdal.qokshy.dchdy.shedy.dkshey.chefar.otchdy.ol.shedar.chdam
→ TPANUL  COŌPAM  NSANM  PARNM  NŌPARM  SAR?UR  OTSANM  OL  PARNUR  SANUS

`f95v1.7`  dshey,kain.qokar.olkar.chy.tar.otar.chdy.kchdy.dolkain.otardy
→ NPARMŌUI?  COŌUR  OLŌUR  SAM  TUR  OTUR  SANM  ŌSANM  NOLŌUI?  OTURNM

`f95v1.8`  dchody.sheos.qodaiin.fchodaiin.chtal.dar.okedy.okchedy
→ NSAONM  PAROP  CONUII?  ?SAONUII?  SATUL  NUR  OŌRNM  OŌSARNM

`f95v1.9`  tshey,taiin.ol,k,shol,kshed.qokeeod.raiin.qokeey.qoko.skchdy
→ TPARMTUII?  OLŌPAOLŌPARN  COŌRRON  RUII?  COŌRRM  COŌO  PŌSANM

`f95v1.10`  sain.sheyk.chody.k.chedain.chedaiin.otain.daiin
→ PUI?  PARMŌ  SAONM  Ō  SARNUI?  SARNUII?  OTUI?  NUII?

`f95v1.11`  pshedar.shedy.kshedy.qotches.or,aiin.shekaiin.otain.tshes.qokain
→ MPARNUR  PARNM  ŌPARNM  COTSARP  ORUII?  PARŌUII?  OTUI?  TPARP  COŌUI?

`f95v1.12`  shotshey.s,aiin.ody.olkchdy.qotaiin.shcthy.dolkchy.tchdaiin.dal
→ PAOTPARM  PUII?  ONM  OLŌSANM  COTUII?  PASTAM  NOLŌSAM  TSANUII?  NUL

`f95v1.13`  lshee.qodain.okaiin.otody.chcthy
→ LPARR  CONUI?  OŌUII?  OTONM  SASTAM

### f96r  ·  herbal

`f96r.1`  tor.cheeor.ckheos.olsheeosol.cpheol.cpheor.chodar
→ TOR  SARROR  SŌAROP  OLPARROPOL  SMAROL  SMAROR  SAONUR

`f96r.2`  ytol.oteeor.sheol.oteey.qokeody.qokeeody.cthey
→ MTOL  OTRROR  PAROL  OTRRM  COŌRONM  COŌRRONM  STARM

`f96r.3`  toaiin.{cthh}odal.chos.ckheody.keody.chodol.oty
→ TOUII?  STAAONUL  SAOP  SŌARONM  ŌRONM  SAONOL  OTM

`f96r.4`  or.chor.chkchol.chokchor.s.or.sheockhy.choly
→ OR  SAOR  SAŌSAOL  SAOŌSAOR  P  OR  PAROSŌAM  SAOLM

`f96r.5`  daiin.chodaiin.cthey.tol.sheor.qokeol.okol
→ NUII?  SAONUII?  STARM  TOL  PAROR  COŌROL  OŌOL

`f96r.6`  lor.ckheey.chol.cholody.cheol.ctheor.sor
→ LOR  SŌARRM  SAOL  SAOLONM  SAROL  STAROR  POR

`f96r.7`  oiir.or.ckhor.chkey.ckhocthy.or.chockhy
→ OIIR  OR  SŌAOR  SAŌRM  SŌAOSTAM  OR  SAOSŌAM

`f96r.8`  ykeor.[se:sh]cheeol.sheol.qokeeey.chol.daiin
→ MŌROR  PRSARROL  PAROL  COŌRRRM  SAOL  NUII?

`f96r.9`  todar.sheo.cthody.shokocfhy.chopcho.dory
→ TONUR  PARO  STAONM  PAOŌOS?AM  SAOMSAO  NORM

`f96r.10`  otchodol.shocthody.shockhy.otchodor.cho{cty}
→ OTSAONOL  PAOSTAONM  PAOSŌAM  OTSAONOR  SAOSTM

`f96r.11`  teol.cheody.shodol.qokchod<->s<->aiin.chokey
→ TROL  SARONM  PAONOL  COŌSAONPUII?  SAOŌRM

`f96r.12`  dcheor.cheol.cheodaiin.ol<->dy<->d<->chs<->archeody
→ NSAROR  SAROL  SARONUII?  OLNMNSAPURSARONM

`f96r.13`  oteodsho.qotchos
→ OTRONPAO  COTSAOP

### f96v  ·  herbal

`f96v.1`  psheessheeor.qoepsheody.odar.ocpheeo<->opar.ysar.osoj
→ MPARRPPARROR  CORMPARONM  ONUR  OSMARROOMUR  MPUR  OPO?

`f96v.2`  ytear.yteor.olcheey.dteodoiin<->saro<->qoches,y,cheom
→ MTRUR  MTROR  OLSARRM  NTRONOII?PUROCOSARPMSAROS

`f96v.3`  dcheoteos.cpheos.sor.chcthory<->cth<->ytchey.daiin
→ NSAROTROP  SMAROP  POR  SASTAORMSTAMTSARM  NUII?

`f96v.4`  dsheos.sheey.teocthey.{ct}eeodody
→ NPAROP  PARRM  TROSTARM  STRRONONM

`f96v.5`  tockhy.cthey.ckheeody.ar.eeeykey
→ TOSŌAM  STARM  SŌARRONM  UR  RRRMŌRM

`f96v.6`  yteeody.teodar.alchey.sy
→ MTRRONM  TRONUR  ULSARM  PM

`f96v.7`  sheodal.chorary{cto}l
→ PARONUL  SAORURMSTOL

`f96v.8`  ycheey.ckheal.daiins
→ MSARRM  SŌARUL  NUII?P

`f96v.9`  oeol.ckheor.cheoraiin
→ OROL  SŌAROR  SARORUII?

`f96v.10`  ctheor.oral.char.ckhey
→ STAROR  ORUL  SAUR  SŌARM

`f96v.11`  sar.os.checkhey.so{cthh}
→ PUR  OP  SARSŌARM  POSTAA

`f96v.12`  sosar.cheekeo.dain
→ POPUR  SARRŌRO  NUI?

`f96v.13`  soysar.cheor
→ POMPUR  SAROR

### f99r  ·  pharmaceutical

`f99r.1`  okaradag
→ OŌURUNU?

`f99r.2`  okar,y
→ OŌURM

`f99r.3`  darar
→ NURUR

`f99r.4`  oky
→ OŌM

`f99r.5`  salo
→ PULO

`f99r.6`  aro
→ URO

`f99r.7`  ain
→ UI?

`f99r.8`  okor
→ OŌOR

`f99r.9`  ralol
→ RULOL

`f99r.10`  skeeal
→ PŌRRUL

`f99r.11`  okary
→ OŌURM

`f99r.12`  okolo
→ OŌOLO

`f99r.13`  otalam
→ OTULUS

`f99r.14`  otoldy
→ OTOLNM

`f99r.15`  pcheody.oteody.daiin.cpheey.tshol.dal.cfheol.olaiin.sar
→ MSARONM  OTRONM  NUII?  SMARRM  TPAOL  NUL  S?AROL  OLUII?  PUR

`f99r.16`  saroshy.shor.s,shor.sheol.kolsheol.qoeol.sholkol.ckhol.ckhory
→ PUROPAM  PAOR  PPAOR  PAROL  ŌOLPAROL  COROL  PAOLŌOL  SŌAOL  SŌAORM

`f99r.17`  dcheor.chr.al.yckhy.okeol.ckhor.oraiin.chor.qokeeor.chory
→ NSAROR  SAR  UL  MSŌAM  OŌROL  SŌAOR  ORUII?  SAOR  COŌRROR  SAORM

`f99r.18`  qokeor.chol.ykol.cheey.chody.ckhol.daiin.okeoly.daiin.ckhy
→ COŌROR  SAOL  MŌOL  SARRM  SAONM  SŌAOL  NUII?  OŌROLM  NUII?  SŌAM

`f99r.19`  oparal
→ OMURUL

`f99r.20`  oaro
→ OURO

`f99r.21`  aloly
→ ULOLM

`f99r.22`  aora[?:r]
→ UORU

`f99r.23`  choky
→ SAOŌM

`f99r.24`  oky
→ OŌM

`f99r.25`  okeoly
→ OŌROLM

`f99r.26`  yteold
→ MTROLN

`f99r.27`  cheotchy
→ SAROTSAM

`f99r.28`  kodaiin.opchey.qoky.dar.otchor.opsho.okeol.sheol.oteoefol
→ ŌONUII?  OMSARM  COŌM  NUR  OTSAOR  OMPAO  OŌROL  PAROL  OTROR?OL

`f99r.29`  dsheol.ckhey.ckheol.okeol.ctheol.qokey.ckhol.okeol.okeey.dald
→ NPAROL  SŌARM  SŌAROL  OŌROL  STAROL  COŌRM  SŌAOL  OŌROL  OŌRRM  NULN

`f99r.30`  tol,cheody.qokol.okoly.okoldy.qokoly.qokal.okchol.qokold
→ TOLSARONM  COŌOL  OŌOLM  OŌOLNM  COŌOLM  COŌUL  OŌSAOL  COŌOLN

`f99r.31`  chees.okeey.qotol.sheol,daiin.qotol.okeol
→ SARRP  OŌRRM  COTOL  PAROLNUII?  COTOL  OŌROL

`f99r.32`  tsholdy
→ TPAOLNM

`f99r.33`  okos
→ OŌOP

`f99r.34`  oekey
→ ORŌRM

`f99r.35`  dar
→ NUR

`f99r.36`  chockhi[a:y]
→ SAOSŌAIU

`f99r.37`  r,cheyet
→ RSARMRT

`f99r.38`  saiiny
→ PUII?M

`f99r.39`  sory
→ PORM

`f99r.40`  dam
→ NUS

`f99r.41`  tsheeor.cpheol.{ck}ey.pchol.ckhey.ypchol,chor.choly.qotocthey.qkory
→ TPARROR  SMAROL  SŌRM  MSAOL  SŌARM  MMSAOLSAOR  SAOLM  COTOSTARM  CŌORM

`f99r.42`  sol.sheol.keshey.qokeeey.chs.chey.dalchey.ctheey.daiin.cheom
→ POL  PAROL  ŌRPARM  COŌRRRM  SAP  SARM  NULSARM  STARRM  NUII?  SAROS

`f99r.43`  daiin.cheeokeey.checkhey.dor.oldy.sheey.keody.okeeey.s.aiin.ols
→ NUII?  SARROŌRRM  SARSŌARM  NOR  OLNM  PARRM  ŌRONM  OŌRRRM  P  UII?  OLP

`f99r.44`  qokey.chkeey.chey.ckhey.ckhey.ykeey.oiin.air.chody.oeksa
→ COŌRM  SAŌRRM  SARM  SŌARM  SŌARM  MŌRRM  OII?  UIR  SAONM  ORŌPU

`f99r.45`  yteoldy
→ MTROLNM

`f99r.46`  tolsasy
→ TOLPUPM

`f99r.47`  tol,keey.ctheey
→ TOLŌRRM  STARRM

`f99r.48`  ykeol.okeol.ockhey.chol.cheodal.okeo,r,alcheeg.orar
→ MŌROL  OŌROL  OSŌARM  SAOL  SARONUL  OŌRORULSARR?  ORUR

`f99r.49`  okeeey.keey.keear.okeey.daiin.okeol,s.aiin.olaiir.oolsal
→ OŌRRRM  ŌRRM  ŌRRUR  OŌRRM  NUII?  OŌROLP  UII?  OLUIIR  OOLPUL

`f99r.50`  qokeeo.okeey.qokeey.okesy.qokeeo.sar.sheseky.or.al
→ COŌRRO  OŌRRM  COŌRRM  OŌRPM  COŌRRO  PUR  PARPRŌM  OR  UL

`f99r.51`  yshaiin.{ykh}ey.octhey.dy,daiin.okor.okeey.sh{cty}sh
→ MPAUII?  MŌARM  OSTARM  NMNUII?  OŌOR  OŌRRM  PASTMPA

`f99r.52`  ychor.ols.or,agairom
→ MSAOR  OLP  ORU?UIROS

### f99v  ·  pharmaceutical

`f99v.1`  okaramy
→ OŌURUSM

`f99v.2`  otoldy
→ OTOLNM

`f99v.3`  otor<->chy
→ OTORSAM

`f99v.4`  oldy
→ OLNM

`f99v.5`  dar<->ary
→ NURURM

`f99v.6`  otaly
→ OTULM

`f99v.7`  olsy
→ OLPM

`f99v.8`  arol
→ UROL

`f99v.9`  otoky
→ OTOŌM

`f99v.10`  sol.cheols.ockhey.qo{ckhh}y.qkoldy.s<->ok.oleees.oteey.dain
→ POL  SAROLP  OSŌARM  COSŌAAM  CŌOLNM  POŌ  OLRRRP  OTRRM  NUI?

`f99v.11`  okoiin.choty.qokchol.qokeol.okoldy<->q{kh}oldy.toly.daiin
→ OŌOII?  SAOTM  COŌSAOL  COŌROL  OŌOLNMCŌAOLNM  TOLM  NUII?

`f99v.12`  qokeo.qokeol.chockhy.otol.daiin.oty<->oto{ck}ey.da.chor,aiin
→ COŌRO  COŌROL  SAOSŌAM  OTOL  NUII?  OTMOTOSŌRM  NU  SAORUII?

`f99v.13`  okoraiin.okol.shocthy<->qokor.oloiram
→ OŌORUII?  OŌOL  PAOSTAMCOŌOR  OLOIRUS

`f99v.14`  okoldody
→ OŌOLNONM

`f99v.15`  oeeesary
→ ORRRPURM

`f99v.16`  daiiinc
→ NUIII?S

`f99v.17`  sary
→ PURM

`f99v.18`  saiino
→ PUII?O

`f99v.19`  otolsar
→ OTOLPUR

`f99v.20`  osary
→ OPURM

`f99v.21`  doror.okeeody.opar.okor.eosaiin.otoraiin.shey.ols,aiiin.qoetal
→ NOROR  OŌRRONM  OMUR  OŌOR  ROPUII?  OTORUII?  PARM  OLPUIII?  CORTUL

`f99v.22`  doiin.otey.o.keeol,s,aiin.okeol.qokeol.ctheol.qokeol.dy.qokaiin
→ NOII?  OTRM  O  ŌRROLPUII?  OŌROL  COŌROL  STAROL  COŌROL  NM  COŌUII?

`f99v.23`  qokeey.chol.okeoldy.qokol.qokeolo.lchol.okeol.sheodol.qokeechom
→ COŌRRM  SAOL  OŌROLNM  COŌOL  COŌROLO  LSAOL  OŌROL  PARONOL  COŌRRSAOS

`f99v.24`  shokeeey.cholshey.okol.qokey.okeodal,oldy
→ PAOŌRRRM  SAOLPARM  OŌOL  COŌRM  OŌRONULOLNM

`f99v.25`  darolaly
→ NUROLULM

`f99v.26`  okechy
→ OŌRSAM

`f99v.27`  otal
→ OTUL

`f99v.28`  chor.olekor
→ SAOR  OLRŌOR

`f99v.29`  okeodor
→ OŌRONOR

`f99v.30`  olky
→ OLŌM

`f99v.31`  doldam
→ NOLNUS

`f99v.32`  qokeeoy.chokol.qokeeo.dy.qokeeol.olpchey.daiir.okeedy<->okolol
→ COŌRROM  SAOŌOL  COŌRRO  NM  COŌRROL  OLMSARM  NUIIR  OŌRRNMOŌOLOL

`f99v.33`  dol.okeeol.okeor.okal.okaiin.ckheol.okolaiin.okolaiin.cheoldy
→ NOL  OŌRROL  OŌROR  OŌUL  OŌUII?  SŌAROL  OŌOLUII?  OŌOLUII?  SAROLNM

`f99v.34`  yoiin,ol.ol.olaiin.qockhey.qokol.olshy.qokeeor.or.aiin.doldam
→ MOII?OL  OL  OLUII?  COSŌARM  COŌOL  OLPAM  COŌRROR  OR  UII?  NOLNUS

`f99v.35`  ol,okeeey.oqoeeol.cheol.chody.okoiin
→ OLOŌRRRM  OCORROL  SAROL  SAONM  OŌOII?

`f99v.36`  oralas
→ ORULUP

`f99v.37`  {c@132;}eol,so{c@133;h}ey.qokol.olkeol.daiin<->okoly
→ SROLPOSARM  COŌOL  OLŌROL  NUII?OŌOLM

`f99v.38`  ol.cheey.qokeol.okeol.okeol.shokol<->ykey
→ OL  SARRM  COŌROL  OŌROL  OŌROL  PAOŌOLMŌRM

`f99v.39`  dar.shol.okchey.ckhey.qokololal<->okeol
→ NUR  PAOL  OŌSARM  SŌARM  COŌOLOLULOŌROL

`f99v.40`  or.aiin.okeody.okol.odaiin.qoky<->olaldy
→ OR  UII?  OŌRONM  OŌOL  ONUII?  COŌMOLULNM

`f99v.41`  qockhol.oiin.shody.qokol.aiidal<->aiidaiim
→ COSŌAOL  OII?  PAONM  COŌOL  UIINULUIINUIIS

`f99v.42`  ol,sheol.olkeol.okol.or.oraloly<->ykeol.okal.okaldaly
→ OLPAROL  OLŌROL  OŌOL  OR  ORULOLMMŌROL  OŌUL  OŌULNULM

`f99v.43`  ychol,olkeeoldy
→ MSAOLOLŌRROLNM

`f99v.44`  koleearol
→ ŌOLRRUROL

### f100r  ·  pharmaceutical

`f100r.1`  chosaroshol
→ SAOPUROPAOL

`f100r.2`  sochorcfhy
→ POSAORS?AM

`f100r.3`  otear
→ OTRUR

`f100r.4`  chofa[r:n]y
→ SAO?URM

`f100r.5`  sar,char<->daiindy
→ PURSAURNUII?NM

`f100r.6`  o[r:s]aro
→ ORURO

`f100r.7`  chalsain
→ SAULPUI?

`f100r.8`  soity
→ POITM

`f100r.9`  sosam
→ POPUS

`f100r.10`  dakocth
→ NUŌOSTA

`f100r.11`  sofam
→ PO?US

`f100r.12`  pcheol.sheod.qocpheeckhy.shodol.{c@132;h}da,@168;oto.cho[?:ch]os.sheey.ch{cthh'}o.s
→ MSAROL  PARON  COSMARRSŌAM  PAONOL  SANUOTO  SAOOP  PARRM  SASTAAO  P

`f100r.13`  dsheor.cthey.qokeey.oteey.ykeeodain.[r:s]orarydaiin.daiin.deeomchol
→ NPAROR  STARM  COŌRRM  OTRRM  MŌRRONUI?  RORURMNUII?  NUII?  NRROSSAOL

`f100r.14`  shor.chkeey.qoteey.qokeody.qoteold.qokeol.so.raiin.otal.yk[eee:ech]o
→ PAOR  SAŌRRM  COTRRM  COŌRONM  COTROLN  COŌROL  PO  RUII?  OTUL  MŌRRRO

`f100r.15`  dcheor.shol.qokeeol.chor.chol.qokeeody.dareu
→ NSAROR  PAOL  COŌRROL  SAOR  SAOL  COŌRRONM  NURR?

`f100r.16`  okeeos
→ OŌRROP

`f100r.17`  shockhey
→ PAOSŌARM

`f100r.18`  orol
→ OROL

`f100r.19`  olcheom
→ OLSAROS

`f100r.20`  oteol
→ OTROL

`f100r.21`  okols
→ OŌOLP

`f100r.22`  folshody.choldaiin.fchod,ycheol.cphol.qotees.shey.aseso,alcfhy
→ ?OLPAONM  SAOLNUII?  ?SAONMSAROL  SMAOL  COTRRP  PARM  UPRPOULS?AM

`f100r.23`  soiin.chol.cphol.shol.shol.qockhol.chor.chol.sho.keey.{chkhh}y.ykeeam
→ POII?  SAOL  SMAOL  PAOL  PAOL  COSŌAOL  SAOR  SAOL  PAO  ŌRRM  SAŌAAM  MŌRRUS

`f100r.24`  saiichor.sheor.qockhody.odeor.yk,sheey.cholsheody.sai.cheol.raiin
→ PUIISAOR  PAROR  COSŌAONM  ONROR  MŌPARRM  SAOLPARONM  PUI  SAROL  RUII?

`f100r.25`  sheor.qkeeody.chol.daiin.ctheol.olcheol.cheky.cheol.cheockhy.okeol
→ PAROR  CŌRRONM  SAOL  NUII?  STAROL  OLSAROL  SARŌM  SAROL  SAROSŌAM  OŌROL

`f100r.26`  yaiin.chekeey.chol.cholody.chos.olchor.qokeol.okeeol.cheols.al
→ MUII?  SARŌRRM  SAOL  SAOLONM  SAOP  OLSAOR  COŌROL  OŌRROL  SAROLP  UL

`f100r.27`  chol.cheol.cho.chckheody.otolchey
→ SAOL  SAROL  SAO  SASŌARONM  OTOLSARM

### f100v  ·  pharmaceutical

`f100v.1`  tolchd
→ TOLSAN

`f100v.2`  chols
→ SAOLP

`f100v.3`  opchor
→ OMSAOR

`f100v.4`  solsy
→ POLPM

`f100v.5`  soleesos
→ POLRRPOP

`f100v.6`  ykchochdy
→ MŌSAOSANM

`f100v.7`  ykchdy
→ MŌSANM

`f100v.8`  dchdy
→ NSANM

`f100v.9`  dalsy
→ NULPM

`f100v.10`  okcheor
→ OŌSAROR

`f100v.11`  ytchol
→ MTSAOL

`f100v.12`  dykchal
→ NMŌSAUL

`f100v.13`  chos.ctharal
→ SAOP  STAURUL

`f100v.14`  {c@132;h}dee{c@133;h}y.sheocphy.qoteody.ckhoor.ar.chor.oteey.daiin.qokomo
→ SANRRSAM  PAROSMAM  COTRONM  SŌAOOR  UR  SAOR  OTRRM  NUII?  COŌOSO

`f100v.15`  sor.cheey.dair.ol.cheol.qoolkeey.chol.cheey.qokeol.chotol,s
→ POR  SARRM  NUIR  OL  SAROL  COOLŌRRM  SAOL  SARRM  COŌROL  SAOTOLP

`f100v.16`  ykeeol.chol.chey.eeoseeo,s.sheeo.okeol.ches.okeor.okeol.dy
→ MŌRROL  SAOL  SARM  RROPRROP  PARRO  OŌROL  SARP  OŌROR  OŌROL  NM

`f100v.17`  chockhey.sholkcheol.qokeol.okol.chol.chotor.chso.solcthy
→ SAOSŌARM  PAOLŌSAROL  COŌROL  OŌOL  SAOL  SAOTOR  SAPO  POLSTAM

`f100v.18`  tachso.s.ol.cheo.cheeor.odaidy.ckhod.sh.chod.qokeol.sal
→ TUSAPO  P  OL  SARO  SARROR  ONUINM  SŌAON  PA  SAON  COŌROL  PUL

`f100v.19`  sain.cheokeos.chockhy.chocthey.keody.cho{ckhh}or.chckhey.du
→ PUI?  SAROŌROP  SAOSŌAM  SAOSTARM  ŌRONM  SAOSŌAAOR  SASŌARM  N?

`f100v.20`  ycheoky.shokeesy.qokeey.chokeol.saraloaly.cheor.ol.chockhar
→ MSAROŌM  PAOŌRRPM  COŌRRM  SAOŌROL  PURULOULM  SAROR  OL  SAOSŌAUR

`f100v.21`  soral.okor.ol.choy.ly.araroy.okar.cheeeal.cheokeol.orey
→ PORUL  OŌOR  OL  SAOM  LM  URUROM  OŌUR  SARRRUL  SAROŌROL  ORRM

`f100v.22`  daiin.cheky.chory
→ NUII?  SARŌM  SAORM

### f101r  ·  pharmaceutical

`f101r.1`  pcheol.sheol.ol,shey.qockhol.shor.yteol.sheockhey.qpol.chear.s,aiin.oleeey.qkeey.chopcheey.checkhey.cpheocthy.ykchy.cheey.chekeey.dal.chey
→ MSAROL  PAROL  OLPARM  COSŌAOL  PAOR  MTROL  PAROSŌARM  CMOL  SARUR  PUII?  OLRRRM  CŌRRM  SAOMSARRM  SARSŌARM  SMAROSTAM  MŌSAM  SARRM  SARŌRRM  NUL  SARM

`f101r.2`  dol.chokeey.chkey.cthey.okalchol.kol,o,keey.r.or.ol.okol,ol.olchey.qok,chal.okey.qokeol.kar.shey.teol.or.oiiin.chol,daiin
→ NOL  SAOŌRRM  SAŌRM  STARM  OŌULSAOL  ŌOLOŌRRM  R  OR  OL  OŌOLOL  OLSARM  COŌSAUL  OŌRM  COŌROL  ŌUR  PARM  TROL  OR  OIII?  SAOLNUII?

`f101r.3`  @183;ol{c@133;h}eol.okeor.r.sheol.qokol.shey.dol.shey.okeey.ctheey.yteeoldy.kchol.ol,sheody.or.ol.sheor.qotoiir.otol.sheey.s,sheo.tchey.ol,dar.am
→ OLSAROL  OŌROR  R  PAROL  COŌOL  PARM  NOL  PARM  OŌRRM  STARRM  MTRROLNM  ŌSAOL  OLPARONM  OR  OL  PAROR  COTOIIR  OTOL  PARRM  PPARO  TSARM  OLNUR  US

`f101r.4`  ycheeo.or.sheeol.daiin.sheeol.okeol.ctheol.{c'y}keeo.qockheol.daiin.shy.chol.okeeor.{cto}dy.chkchol.dateody.okeol.dairin.okeey.okeey.dairin
→ MSARRO  OR  PARROL  NUII?  PARROL  OŌROL  STAROL  SMŌRRO  COSŌAROL  NUII?  PAM  SAOL  OŌRROR  STONM  SAŌSAOL  NUTRONM  OŌROL  NUIRI?  OŌRRM  OŌRRM  NUIRI?

`f101r.5`  daiin.ctheol.cheol.okor.or.aiin.cheol.cho,keeodchey.okol.okeol.dor.chol.ch[y:a].r.aiin.oteol.or,aiin.ol,chey.oteeod.sheol.okeol.chosaiin.sheam
→ NUII?  STAROL  SAROL  OŌOR  OR  UII?  SAROL  SAOŌRRONSARM  OŌOL  OŌROL  NOR  SAOL  SAM  R  UII?  OTROL  ORUII?  OLSARM  OTRRON  PAROL  OŌROL  SAOPUII?  PARUS

`f101r.6`  okeeol.sho.shody.sho.shol.okeeeol.che[a:y]s.sheokeey.sheeor.chchy.chodaiin.cheeckhey.teeol.s.cheol.rar.oeeor
→ OŌRROL  PAO  PAONM  PAO  PAOL  OŌRRROL  SARUP  PAROŌRRM  PARROR  SASAM  SAONUII?  SARRSŌARM  TRROL  P  SAROL  RUR  ORROR

`f101r.7`  cphoar.oaiin.ypcholy.daiin.otaiin.otaiin.yfolaiin.@184;cheolain.ypchey.{yph}ody.shotey.odariin.sheo[o:a]r.sheor.ckheey.{ykh}ey.qokchey.cholp.cheol,dy
→ SMAOUR  OUII?  MMSAOLM  NUII?  OTUII?  OTUII?  M?OLUII?  SAROLUI?  MMSARM  MMAONM  PAOTRM  ONURII?  PAROOR  PAROR  SŌARRM  MŌARM  COŌSARM  SAOLM  SAROLNM

`f101r.8`  olaiin.oteol.chor.oteey.chokchey.kor,daiin.shok.chol.chol.qoky.daiin.ol.s.al.ydar.daiin,or.ory.okeey.daiin.shey.daiin.okol.cheor
→ OLUII?  OTROL  SAOR  OTRRM  SAOŌSARM  ŌORNUII?  PAOŌ  SAOL  SAOL  COŌM  NUII?  OL  P  UL  MNUR  NUII?OR  ORM  OŌRRM  NUII?  PARM  NUII?  OŌOL  SAROR

`f101r.9`  daiin.okeol.qokcheol.ykeor.dar.ol.otechy.ykeor.dor.aiin.chl,s.cheol.okeol.shey.qodar.soiin.choko.qokeol.daiin.[o:y],dar.okchol.cheo,rcheky
→ NUII?  OŌROL  COŌSAROL  MŌROR  NUR  OL  OTRSAM  MŌROR  NOR  UII?  SALP  SAROL  OŌROL  PARM  CONUR  POII?  SAOŌO  COŌROL  NUII?  ONUR  OŌSAOL  SARORSARŌM

`f101r.10`  ysho.qykeeol.chol.sho.odor.dor.chees.ykeol.chol.dol.kor.a{ith}y.ol.chso.sha.olcheeol.kolshey.okeoly.oiin.aiioly
→ MPAO  CMŌRROL  SAOL  PAO  ONOR  NOR  SARRP  MŌROL  SAOL  NOL  ŌOR  UITAM  OL  SAPO  PAU  OLSARROL  ŌOLPARM  OŌROLM  OII?  UIIOLM

### f101v  ·  pharmaceutical

`f101v.1`  [s:r]airaly
→ PUIRULM

`f101v.2`  otaldy
→ OTULNM

`f101v.3`  otol
→ OTOL

`f101v.4`  ytal
→ MTUL

`f101v.5`  dokor
→ NOŌOR

`f101v.6`  orar
→ ORUR

`f101v.7`  otarar
→ OTURUR

`f101v.8`  ot[o:a]ly
→ OTOLM

`f101v.9`  soraly
→ PORULM

`f101v.10`  okol
→ OŌOL

`f101v.11`  arom
→ UROS

`f101v.12`  oraram
→ ORURUS

`f101v.13`  oraeep
→ ORURRM

`f101v.14`  dytolg
→ NMTOL?

`f101v.15`  olkor
→ OLŌOR

`f101v.16`  dolary
→ NOLURM

`f101v.17`  odor
→ ONOR

`f101v.18`  olaran
→ OLURU?

`f101v.19`  tolchor.cheopor.or,ody.cphey,r.shee.fol,s,oiin.otsheey.otch???y,kcho,pcholy.chor.or.choror.sy<->dorar<->okoraiin.orolodain
→ TOLSAOR  SAROMOR  ORONM  SMARMR  PARR  ?OLPOII?  OTPARRM  OTSAMŌSAOMSAOLM  SAOR  OR  SAOROR  PMNORUROŌORUII?  OROLONUI?

`f101v.20`  or.aiin.or.o.or.odam.chor.s.aiin.okor.cheeor.sheeol.qokol.et???ol.qoor.cheey.qykeod.oeeo.r.choy.s<->okeeody<->chodaiin.cthy.okody.dar
→ OR  UII?  OR  O  OR  ONUS  SAOR  P  UII?  OŌOR  SARROR  PARROL  COŌOL  RTOL  COOR  SARRM  CMŌRON  ORRO  R  SAOM  POŌRRONMSAONUII?  STAM  OŌONM  NUR

`f101v.21`  ycheor.o[?:e]o.dain.cheokal.{ykh}ody.cheeods.oraiin.qoeey.cthey.???eocthy.dain.cheod?.dydy
→ MSAROR  OO  NUI?  SAROŌUL  MŌAONM  SARRONP  ORUII?  CORRM  STARM  ROSTAM  NUI?  SARON  NMNM

`f101v.22`  ksear.lol,keeol.otal.or.ol.aiin.okeod.{ykh}ey.dain.olcheol.???opcheol.cthey.qekeoldy.qocthor.sheody.qo{ckhh}ey.odaiin.shoytolaiin.?sodaiin,dy
→ ŌPRUR  LOLŌRROL  OTUL  OR  OL  UII?  OŌRON  MŌARM  NUI?  OLSAROL  OMSAROL  STARM  CRŌROLNM  COSTAOR  PARONM  COSŌAARM  ONUII?  PAOMTOLUII?  PONUII?NM

`f101v.23`  yaiin.ol,olor.daiin.okeey.qok.ykeol.daiin.qockhy.daiin.olch???dar.qokeol.dol.oraiin.oldaiin.keeol@138;,rch.qokeeeor.s,ydy.cheor.okeey.choldy.dar
→ MUII?  OLOLOR  NUII?  OŌRRM  COŌ  MŌROL  NUII?  COSŌAM  NUII?  OLSANUR  COŌROL  NOL  ORUII?  OLNUII?  ŌRROLRSA  COŌRRROR  PMNM  SAROR  OŌRRM  SAOLNM  NUR

`f101v.24`  teeeol.sheol.qokeor.{ykh}ol.olcho.r.chokey.chor.ctheey.daiin???daiin.cheeody.cheey,keo.cheol.daiiin.deeor.cheedy
→ TRRROL  PAROL  COŌROR  MŌAOL  OLSAO  R  SAOŌRM  SAOR  STARRM  NUII?NUII?  SARRONM  SARRMŌRO  SAROL  NUIII?  NRROR  SARRNM

`f101v.25`  daiin.dair.yteol.chor.qockhol.daiin.ckheey.chey.kchey.da???oiin.okeey.ckheo,l,cheody.kcheol.daiin.etee[o:y]s.ctheody.ctheo.ckhosh[?:e].olchor
→ NUII?  NUIR  MTROL  SAOR  COSŌAOL  NUII?  SŌARRM  SARM  ŌSARM  NUOII?  OŌRRM  SŌAROLSARONM  ŌSAROL  NUII?  RTRROP  STARONM  STARO  SŌAOPA  OLSAOR

`f101v.26`  olaiin.okeol.cheo.kol.ches.sheey.qoor.qokeody.cheor.okeo.???oiin.cheey.cthey.ory.ctheey.qokeey.shol.ody.cheol.oralar.shey.qokar,ary
→ OLUII?  OŌROL  SARO  ŌOL  SARP  PARRM  COOR  COŌRONM  SAROR  OŌRO  OII?  SARRM  STARM  ORM  STARRM  COŌRRM  PAOL  ONM  SAROL  ORULUR  PARM  COŌURURM

`f101v.27`  sal.chol.choly.okeey.dal.qol.shckheol.chol.cthear.keeol.???cheeo.ol,chs.oraiin.qokeeey.soiin.qodaiin.cheol.qokeey.daiin.cheodam
→ PUL  SAOL  SAOLM  OŌRRM  NUL  COL  PASŌAROL  SAOL  STARUR  ŌRROL  SARRO  OLSAP  ORUII?  COŌRRRM  POII?  CONUII?  SAROL  COŌRRM  NUII?  SARONUS

`f101v.28`  teol.cheol.etchey.???cheo,r.cheol.cthol.cholaiin.chol,qkar
→ TROL  SAROL  RTSARM  SAROR  SAROL  STAOL  SAOLUII?  SAOLCŌUR

### f102r1  ·  pharmaceutical

`f102r1.1`  daarod
→ NUURON

`f102r1.2`  otodeeodor
→ OTONRRONOR

`f102r1.3`  polaiin.shocthy.qoteol.loiiin.oteeor.cpheodar.sholdaiin
→ MOLUII?  PAOSTAM  COTROL  LOIII?  OTRROR  SMARONUR  PAOLNUII?

`f102r1.4`  dsheody.okeeoy.kod[?:a].chkeeody.daraiiin.ctheoly.qokcheololain
→ NPARONM  OŌRROM  ŌON  SAŌRRONM  NURUIII?  STAROLM  COŌSAROLOLUI?

`f102r1.5`  ytol.sheol.she.olaiin.orain.oraroekeol.chol.ekey.qokol.dain
→ MTOL  PAROL  PAR  OLUII?  ORUI?  ORURORŌROL  SAOL  RŌRM  COŌOL  NUI?

`f102r1.6`  daiin.ykeeol.oldy.okodaiin
→ NUII?  MŌRROL  OLNM  OŌONUII?

`f102r1.7`  okolaly
→ OŌOLULM

`f102r1.8`  pshodaiin.qoorar.chopy<->chofol.daiin.oteol.qoteol.doly
→ MPAONUII?  COORUR  SAOMMSAO?OL  NUII?  OTROL  COTROL  NOLM

`f102r1.9`  daiin.orsheoldy.qokeol<->oteeody.lshodykeodal.qokshdy,sy
→ NUII?  ORPAROLNM  COŌROLOTRRONM  LPAONMŌRONUL  COŌPANMPM

`f102r1.10`  ycheol.sholdy.chol.chol.ykeeol.dol.doleodaiin.dal.cthedy
→ MSAROL  PAOLNM  SAOL  SAOL  MŌRROL  NOL  NOLRONUII?  NUL  STARNM

`f102r1.11`  dcheo.qockhy.sol,sheey.okeody.qokeodol.shockhey.oleeol
→ NSARO  COSŌAM  POLPARRM  OŌRONM  COŌRONOL  PAOSŌARM  OLRROL

`f102r1.12`  ddardsh
→ NNURNPA

`f102r1.13`  teesody.qoeol.olcheor.qokey.okshey.qokeol.sheofol{ckhh}y
→ TRRPONM  COROL  OLSAROR  COŌRM  OŌPARM  COŌROL  PARO?OLSŌAAM

`f102r1.14`  doeey.keeol.qokeo.daor.shey.qoteol.okol.chos.s.or.oeeaiin
→ NORRM  ŌRROL  COŌRO  NUOR  PARM  COTROL  OŌOL  SAOP  P  OR  ORRUII?

`f102r1.15`  or.chol.daiin.dykeor.sheey.qokeody.dor.os.ykeeykam
→ OR  SAOL  NUII?  NMŌROR  PARRM  COŌRONM  NOR  OP  MŌRRMŌUS

`f102r1.16`  ddor.chordam<->soraiin.ykeey,dy.okeol.doeoear<->s.aral.dor
→ NNOR  SAORNUSPORUII?  MŌRRMNM  OŌROL  NORORURP  URUL  NOR

`f102r1.17`  ydar,arody<->oldaiin.sody.chockhy,oly
→ MNURURONMOLNUII?  PONM  SAOSŌAMOLM

### f102r2  ·  pharmaceutical

`f102r2.1`  kodaiig
→ ŌONUII?

`f102r2.2`  lsais.azg.cheey.cfhey.por,aiin.chefol,y
→ LPUIP  U??  SARRM  S?ARM  MORUII?  SAR?OLM

`f102r2.3`  ycheor.olaiin.olsho.qokol.olaiin.oldam
→ MSAROR  OLUII?  OLPAO  COŌOL  OLUII?  OLNUS

`f102r2.4`  daiin.ckheeol.oldor.okol.cheodor.sor.airam
→ NUII?  SŌARROL  OLNOR  OŌOL  SARONOR  POR  UIRUS

`f102r2.5`  tor.sheo.or.chey.qoor.yteor.chol.choky
→ TOR  PARO  OR  SARM  COOR  MTROR  SAOL  SAOŌM

`f102r2.6`  daiin.okody.qokeody.okeol.dor.chckhy.oteod.s,orsy
→ NUII?  OŌONM  COŌRONM  OŌROL  NOR  SASŌAM  OTRON  PORPM

`f102r2.7`  ok[?:o]rolda
→ OŌROLNU

`f102r2.8`  kolor.olaiin.opor.shey.opolkod.odain.sheo.qoeol.shey
→ ŌOLOR  OLUII?  OMOR  PARM  OMOLŌON  ONUI?  PARO  COROL  PARM

`f102r2.9`  dor.oiin.okeody.qokeol.sheoy.qo[o:d]chey.ckheol.sheey.skeekyd
→ NOR  OII?  OŌRONM  COŌROL  PAROM  COOSARM  SŌAROL  PARRM  PŌRRŌMN

`f102r2.10`  shockhy.qockhey.sol.eeey.dol.cheol.doaiin.qkeeey.cthey
→ PAOSŌAM  COSŌARM  POL  RRRM  NOL  SAROL  NOUII?  CŌRRRM  STARM

`f102r2.11`  kockhas.okor.ykeey.okeey.qokeey.dol.ol.sheody.okey.da,l,{cthhh}y
→ ŌOSŌAUP  OŌOR  MŌRRM  OŌRRM  COŌRRM  NOL  OL  PARONM  OŌRM  NULSTAAAM

`f102r2.12`  ytchy.o,l,ockhy.okeey.cheody.saiin.dol.ockhy.okeady
→ MTSAM  OLOSŌAM  OŌRRM  SARONM  PUII?  NOL  OSŌAM  OŌRUNM

`f102r2.13`  loeekadag
→ LORRŌUNU?

`f102r2.14`  oshea??l
→ OPARUL

`f102r2.15`  so???dch
→ PONSA

`f102r2.16`  {c@132;h}ol.d{c@133;h}ody.cthol,soeees.ykeody.qokeey.qotchy.soefchocphy
→ SAOL  NSAONM  STAOLPORRRP  MŌRONM  COŌRRM  COTSAM  POR?SAOSMAM

`f102r2.17`  ykeockhey.okey.qokeeo.ckhey.qokey.desey.qyoeey.dol.chkey.choky
→ MŌROSŌARM  OŌRM  COŌRRO  SŌARM  COŌRM  NRPRM  CMORRM  NOL  SAŌRM  SAOŌM

`f102r2.18`  otol.shey.qockhey.dol.shey.dol.sheey.qokol.daiin.oky.oky
→ OTOL  PARM  COSŌARM  NOL  PARM  NOL  PARRM  COŌOL  NUII?  OŌM  OŌM

`f102r2.19`  qokeod.okeal.okeo,l.y,cheo.ckhey.q{kh}ody.qokey.ody.keeody.chody
→ COŌRON  OŌRUL  OŌROL  MSARO  SŌARM  CŌAONM  COŌRM  ONM  ŌRRONM  SAONM

`f102r2.20`  ykeey.keeol.cheos.ydeeal.cheody.ykeea,d,o,lchey
→ MŌRRM  ŌRROL  SAROP  MNRRUL  SARONM  MŌRRUNOLSARM

`f102r2.21`  koldarod
→ ŌOLNURON

`f102r2.22`  odalydary
→ ONULMNURM

### f102v2  ·  pharmaceutical

`f102v2.1`  porshols
→ MORPAOLP

`f102v2.2`  soaimy
→ POUISM

`f102v2.3`  oror
→ OROR

`f102v2.4`  chor
→ SAOR

`f102v2.5`  sachy
→ PUSAM

`f102v2.6`  okeo[s:r]
→ OŌROP

`f102v2.7`  okol
→ OŌOL

`f102v2.8`  otory
→ OTORM

`f102v2.9`  ok?
→ OŌ

`f102v2.10`  okody
→ OŌONM

`f102v2.11`  cheor
→ SAROR

`f102v2.12`  okoroeey
→ OŌORORRM

`f102v2.13`  opchy
→ OMSAM

`f102v2.14`  sarol
→ PUROL

`f102v2.15`  olrodar
→ OLRONUR

`f102v2.16`  to[d:?]?
→ TON

`f102v2.17`  podeesho.oteeos.sheor.qo[t:k]eeo,ch,{ckhh}y.shkeey.chekeod
→ MONRRPAO  OTRROP  PAROR  COTRROSASŌAAM  PAŌRRM  SARŌRON

`f102v2.18`  ocheos.chyokeor.okeol.okeol.shy,y
→ OSAROP  SAMOŌROR  OŌROL  OŌROL  PAMM

`f102v2.19`  deeeo.qoeeor.o,eo{ikh}y.cheos.o.l.o,r.o,l.okeeos.ain
→ NRRRO  CORROR  OROIŌAM  SAROP  O  L  OR  OL  OŌRROP  UI?

`f102v2.20`  qokeor.cho.keeol.okeeey.qokeody.chockhey.qokeey.dol.ol.sheeoy.tody.cheoc?
→ COŌROR  SAO  ŌRROL  OŌRRRM  COŌRONM  SAOSŌARM  COŌRRM  NOL  OL  PARROM  TONM  SAROS

`f102v2.21`  ycheey.s.od,eey.okeeor.cheol.os,oiin.oeees.okear.chey.keey.saiin.oteo
→ MSARRM  P  ONRRM  OŌRROR  SAROL  OPOII?  ORRRP  OŌRUR  SARM  ŌRRM  PUII?  OTRO

`f102v2.22`  dain.or.aiin.cheol.s,oiir.chol.sheey.qockhy.ol.keo,r.okeody.okeor.cho?
→ NUI?  OR  UII?  SAROL  POIIR  SAOL  PARRM  COSŌAM  OL  ŌROR  OŌRONM  OŌROR  SAO

`f102v2.23`  okey.okey.shey.okey.oiees.or,eey
→ OŌRM  OŌRM  PARM  OŌRM  OIRRP  ORRRM

`f102v2.24`  okolky
→ OŌOLŌM

`f102v2.25`  osain
→ OPUI?

`f102v2.26`  aiky
→ UIŌM

`f102v2.27`  okeeoraiin
→ OŌRRORUII?

`f102v2.28`  okockhy
→ OŌOSŌAM

`f102v2.29`  os
→ OP

`f102v2.30`  pyd[ch:?]y.od[i:e]y.pcheady.qoekeey.oteey.qokeod,sheey.opaiin.deear
→ MMNSAM  ONIM  MSARUNM  CORŌRRM  OTRRM  COŌRONPARRM  OMUII?  NRRUR

`f102v2.31`  oldeey.ckhy.sheeody.eeos.sheshe.oeeor.ykeear.chekeey.ykory
→ OLNRRM  SŌAM  PARRONM  RROP  PARPAR  ORROR  MŌRRUR  SARŌRRM  MŌORM

`f102v2.32`  dar.cheor.shoar.okeol.shoy.s.ar.oky.cheeor.ol.daiin.sy
→ NUR  SAROR  PAOUR  OŌROL  PAOM  P  UR  OŌM  SARROR  OL  NUII?  PM

`f102v2.33`  qokeor.sho.?keeeos.cheor.o,s,al.chos,aiiin.o,ky.okaraiin
→ COŌROR  PAO  ŌRRROP  SAROR  OPUL  SAOPUIII?  OŌM  OŌURUII?

`f102v2.34`  sorshey.okeeor.sheockhey.qokeos.okchol.ctheor.okey.sal
→ PORPARM  OŌRROR  PAROSŌARM  COŌROP  OŌSAOL  STAROR  OŌRM  PUL

`f102v2.35`  ychor.sheol.por.sheeor.shekeey.qoky.cheo,teody.qokeol.daiin
→ MSAOR  PAROL  MOR  PARROR  PARŌRRM  COŌM  SAROTRONM  COŌROL  NUII?

`f102v2.36`  okeeor.cheey.okeey.sor.eeey.okey.okey.okeey.qokeor
→ OŌRROR  SARRM  OŌRRM  POR  RRRM  OŌRM  OŌRM  OŌRRM  COŌROR

`f102v2.37`  tchor,ar.chey.kor.or.cthey.qoeeey.qokeey.okeoroly.sar
→ TSAORUR  SARM  ŌOR  OR  STARM  CORRRM  COŌRRM  OŌROROLM  PUR

`f102v2.38`  dar.cheey.ckheey.qokeor.okey.chos.sho.ykeey.okeeo.ra[in:i?]
→ NUR  SARRM  SŌARRM  COŌROR  OŌRM  SAOP  PAO  MŌRRM  OŌRRO  RUI?

`f102v2.39`  yotaiin.cheor.cheekey.orain
→ MOTUII?  SAROR  SARRŌRM  ORUI?

### f102v1  ·  pharmaceutical

`f102v1.1`  keoraiiin
→ ŌRORUIII?

`f102v1.2`  okeody
→ OŌRONM

`f102v1.3`  okeody
→ OŌRONM

`f102v1.4`  daiisaly
→ NUIIPULM

`f102v1.5`  ypary
→ MMURM

`f102v1.6`  opchyt{cy}
→ OMSAMTSM

`f102v1.7`  poaiin.ockhey.pchol.doiin.shey.shockhsy.sheocthy.qokeody
→ MOUII?  OSŌARM  MSAOL  NOII?  PARM  PAOSŌAPM  PAROSTAM  COŌRONM

`f102v1.8`  dairn.ol.chey.[cth:ckh]eol.qokeor.os,aiin.cheor.qokey.choky
→ NUIR?  OL  SARM  STAROL  COŌROR  OPUII?  SAROR  COŌRM  SAOŌM

`f102v1.9`  teody.ckheey.qokeol.sheky.qockheor.or.cheo,rchol.qoteor.dar
→ TRONM  SŌARRM  COŌROL  PARŌM  COSŌAROR  OR  SARORSAOL  COTROR  NUR

`f102v1.10`  kochor.ol.ydaiin.choraiin.sheey.ykeey.kor,shey.qokey.dy
→ ŌOSAOR  OL  MNUII?  SAORUII?  PARRM  MŌRRM  ŌORPARM  COŌRM  NM

`f102v1.11`  sol,chol.qooiin.qokol.cheol.chey.kolcheey.daiin.cheody.dy
→ POLSAOL  COOII?  COŌOL  SAROL  SARM  ŌOLSARRM  NUII?  SARONM  NM

`f102v1.12`  y,cheol.cheol.doiir.shekcheor.s,ar.cheor.{@246;kh}ey.pchodaiin
→ MSAROL  SAROL  NOIIR  PARŌSAROR  PUR  SAROR  ŌARM  MSAONUII?

`f102v1.13`  toiin.ol.daiin.qkol.cheol.daiin.qokar.oaiin.cheey.[s:r]aiim
→ TOII?  OL  NUII?  CŌOL  SAROL  NUII?  COŌUR  OUII?  SARRM  PUIIS

`f102v1.14`  chor.cheor.ckhey.oteol.a{ikh}eky
→ SAOR  SAROR  SŌARM  OTROL  UIŌARŌM

`f102v1.15`  d?indy
→ NI?NM

`f102v1.16`  ypcholdy
→ MMSAOLNM

`f102v1.17`  loralody
→ LORULONM

`f102v1.18`  opchdard
→ OMSANURN

`f102v1.19`  fo[i:e]daiin.dair.or.sheol.okeeol.qoteol<->oro{ikh}ey.olkey
→ ?OINUII?  NUIR  OR  PAROL  OŌRROL  COTROLOROIŌARM  OLŌRM

`f102v1.20`  soiin.shey.qokeey.qoeeol.qokeody.sheody.qoeteey.okeey.dam
→ POII?  PARM  COŌRRM  CORROL  COŌRONM  PARONM  CORTRRM  OŌRRM  NUS

`f102v1.21`  qoeeody.ychey.okeody.deody.okody.cheodaiin.cheody.[r:s]am
→ CORRONM  MSARM  OŌRONM  NRONM  OŌONM  SARONUII?  SARONM  RUS

`f102v1.22`  yk[ee:ch]ody.chodaiin.qokeos.cheol.qool.chsey.oteody.okchy
→ MŌRRONM  SAONUII?  COŌROP  SAROL  COOL  SAPRM  OTRONM  OŌSAM

`f102v1.23`  ksheody.sho.qokey.sheody.qockhey.olcheor.odain.okchody
→ ŌPARONM  PAO  COŌRM  PARONM  COSŌARM  OLSAROR  ONUI?  OŌSAONM

`f102v1.24`  ysaiin.ckhey.qoor.cheol
→ MPUII?  SŌARM  COOR  SAROL

### f103r  ·  stars

`f103r.1`  pchedal.shdy.ytechypchy.otey.?lshey.qoteey.qotal.shedy.yshdal.dain.okal.daldy
→ MSARNUL  PANM  MTRSAMMSAM  OTRM  LPARM  COTRRM  COTUL  PARNM  MPANUL  NUI?  OŌUL  NULNM

`f103r.2`  dain.shek.ch{cphh}dy.daloky.opchedy.peshol.chep.ar.otchy.sal.lkeey.sar.ain.ok??.chedy
→ NUI?  PARŌ  SASMAANM  NULOŌM  OMSARNM  MRPAOL  SARM  UR  OTSAM  PUL  LŌRRM  PUR  UI?  OŌ  SARNM

`f103r.3`  yshdain.sheek.cheoty.eeokal.chedy.chckhy.or.orol.okaiin.eeal.ot.kar.otar.cha[l:?]
→ MPANUI?  PARRŌ  SAROTM  RROŌUL  SARNM  SASŌAM  OR  OROL  OŌUII?  RRUL  OT  ŌUR  OTUR  SAUL

`f103r.4`  ychedy.qokedy.okedy.qokeey.okey.chdar,ol.loty.chedaraly
→ MSARNM  COŌRNM  OŌRNM  COŌRRM  OŌRM  SANUROL  LOTM  SARNURULM

`f103r.5`  pocharal.okedar.shedy.oteey.qokey.lkar.sheeky.okalor.shedy.yt???.rkar.ota?.okdy
→ MOSAURUL  OŌRNUR  PARNM  OTRRM  COŌRM  LŌUR  PARRŌM  OŌULOR  PARNM  MT  RŌUR  OTU  OŌNM

`f103r.6`  ocheey.dain.shek.okeedy.okey.shedy.qokealdy.shcthy.qotedy.qoto???.ota.???.san,am
→ OSARRM  NUI?  PARŌ  OŌRRNM  OŌRM  PARNM  COŌRULNM  PASTAM  COTRNM  COTO  OTU  —  PU?US

`f103r.7`  saiin.chey.shs.olshedy.qokeey.okeeody.qoedy.ol,shedy
→ PUII?  SARM  PAP  OLPARNM  COŌRRM  OŌRRONM  CORNM  OLPARNM

`f103r.8`  daroal.okey.chedy.okey.rain.okechy.qoisal.qotar,adchey.of[ee:ch]o.lt??dy.??olkechdy,lo
→ NUROUL  OŌRM  SARNM  OŌRM  RUI?  OŌRSAM  COIPUL  COTURUNSARM  O?RRO  LTNM  OLŌRSANMLO

`f103r.9`  oteeos.ar.cheal.okeey.shey.lkaiin.shey.lkeor.otaiin.shedy.otey.l.?dy.okeedaram
→ OTRROP  UR  SARUL  OŌRRM  PARM  LŌUII?  PARM  LŌROR  OTUII?  PARNM  OTRM  L  NM  OŌRRNURUS

`f103r.10`  daiin.ol.oain.okeol.chol.okam.chety.shedy.otaiin.shedy.teolshy.oteedy.sor,ain
→ NUII?  OL  OUI?  OŌROL  SAOL  OŌUS  SARTM  PARNM  OTUII?  PARNM  TROLPAM  OTRRNM  PORUI?

`f103r.11`  dar.oteey.otain.lolshedy.okain.chey.qorain.shey.otoy.qokeol.key.da{ikh}yky
→ NUR  OTRRM  OTUI?  LOLPARNM  OŌUI?  SARM  CORUI?  PARM  OTOM  COŌROL  ŌRM  NUIŌAMŌM

`f103r.12`  oain.shey.shckhy.oteey.qokeol,keedy.shar,aiin.otedy
→ OUI?  PARM  PASŌAM  OTRRM  COŌROLŌRRNM  PAURUII?  OTRNM

`f103r.13`  podar,sheor.qotedy.okeey.qokar.checkhy.qokain.chedy.pchdy.tshdy.dal,kasol
→ MONURPAROR  COTRNM  OŌRRM  COŌUR  SARSŌAM  COŌUI?  SARNM  MSANM  TPANM  NULŌUPOL

`f103r.14`  okain.shekain.chedy.qokeechy.qok[y:?].shey.lol.s,aiin.chey.eekain.chcthy.qoky
→ OŌUI?  PARŌUI?  SARNM  COŌRRSAM  COŌM  PARM  LOL  PUII?  SARM  RRŌUI?  SASTAM  COŌM

`f103r.15`  qotedy.qokeey.sh[o:a]l.qotey.shkaiin
→ COTRNM  COŌRRM  PAOL  COTRM  PAŌUII?

`f103r.16`  dshol.sholkar.shdaiin.[chee:eeee]y.rar.okeey.shcfhedy.opcheol.oteedy.tchey.shky
→ NPAOL  PAOLŌUR  PANUII?  SARRM  RUR  OŌRRM  PAS?ARNM  OMSAROL  OTRRNM  TSARM  PAŌM

`f103r.17`  sar,shey.qokey,keedy.qokeey.chckhy.qokal.oty.or,aiin
→ PURPARM  COŌRMŌRRNM  COŌRRM  SASŌAM  COŌUL  OTM  ORUII?

`f103r.18`  polchedy.qokeol.okain.checthy.oteeylshedy.okain.qokain.qokalshedy.oteys
→ MOLSARNM  COŌROL  OŌUI?  SARSTAM  OTRRMLPARNM  OŌUI?  COŌUI?  COŌULPARNM  OTRMP

`f103r.19`  okaiin.chey.qoy.shey.qokaiin.chedy.qokain.oteol.lkar.okaral.lkldy.lr
→ OŌUII?  SARM  COM  PARM  COŌUII?  SARNM  COŌUI?  OTROL  LŌUR  OŌURUL  LŌLNM  LR

`f103r.20`  ychain.shckhy.qokaiin.shey.qokaiin.shedy.olor
→ MSAUI?  PASŌAM  COŌUII?  PARM  COŌUII?  PARNM  OLOR

`f103r.21`  pcheam.sokedy.dalkar.otal.qokal.chepy.okedy.qoky.pchedy.okaly.qokeedy.lor
→ MSARUS  POŌRNM  NULŌUR  OTUL  COŌUL  SARMM  OŌRNM  COŌM  MSARNM  OŌULM  COŌRRNM  LOR

`f103r.22`  dalshy.okain.shckhody.shdal.qokeedy.shedy.qotar.chcthy.chep.ar.otar.opchy
→ NULPAM  OŌUI?  PASŌAONM  PANUL  COŌRRNM  PARNM  COTUR  SASTAM  SARM  UR  OTUR  OMSAM

`f103r.23`  daiin.sheckhy.lchedy.chckhy.shol
→ NUII?  PARSŌAM  LSARNM  SASŌAM  PAOL

`f103r.24`  tchoky.okeal.shedy.qokal.oty.opchedy.qotain.shcthy.otey.dain.oteey.oky
→ TSAOŌM  OŌRUL  PARNM  COŌUL  OTM  OMSARNM  COTUI?  PASTAM  OTRM  NUI?  OTRRM  OŌM

`f103r.25`  dar,shey.qokain.chckhey.chey,kain.chedal.okeeey.qoodain.okain.[o:?]teey.ol
→ NURPARM  COŌUI?  SASŌARM  SARMŌUI?  SARNUL  OŌRRRM  COONUI?  OŌUI?  OTRRM  OL

`f103r.26`  oteedy.okeey.qot[ch:ee]y.shey.olcheedar.shey.lotor
→ OTRRNM  OŌRRM  COTSAM  PARM  OLSARRNUR  PARM  LOTOR

`f103r.27`  qokechy.okeey.qokeey.lkeeody.sheey.qokeey,lkeol.tchey,qokeey.okeey.qokaly
→ COŌRSAM  OŌRRM  COŌRRM  LŌRRONM  PARRM  COŌRRMLŌROL  TSARMCOŌRRM  OŌRRM  COŌULM

`f103r.28`  deshedy.qokeeey.dalkain.okaiin.chedy.qokeey.otain.ain.ol.cheey.lkeedy
→ NRPARNM  COŌRRRM  NULŌUI?  OŌUII?  SARNM  COŌRRM  OTUI?  UI?  OL  SARRM  LŌRRNM

`f103r.29`  qokeeechy.shokeey.qochey.qokeey.chal.chedy
→ COŌRRRSAM  PAOŌRRM  COSARM  COŌRRM  SAUL  SARNM

`f103r.30`  pcholkchdy.sheckhy.qokey.okaiin.shedy.chpchy.opchedy.oteeykshy.chdaly
→ MSAOLŌSANM  PARSŌAM  COŌRM  OŌUII?  PARNM  SAMSAM  OMSARNM  OTRRMŌPAM  SANULM

`f103r.31`  soiin.chol.kaiin.chal.okaiin.shckhy.qokal.shdar.shchdy.okaiin.chty
→ POII?  SAOL  ŌUII?  SAUL  OŌUII?  PASŌAM  COŌUL  PANUR  PASANM  OŌUII?  SATM

`f103r.32`  okeey.shedy.qokedy.qokal.shety.otedy.shcthy.oraiin
→ OŌRRM  PARNM  COŌRNM  COŌUL  PARTM  OTRNM  PASTAM  ORUII?

`f103r.33`  qokeey.chechy.qokey.shckhy.choldy.qokal.y.shedy.yteedy.qotail.shedy
→ COŌRRM  SARSAM  COŌRM  PASŌAM  SAOLNM  COŌUL  M  PARNM  MTRRNM  COTUIL  PARNM

`f103r.34`  sheod.oshey.cheedalaiin
→ PARON  OPARM  SARRNULUII?

`f103r.35`  qoke{ca}r.chain.olain.chey.kain.sheol.shedain.qokeedy.ykeedy,lcheg
→ COŌRSUR  SAUI?  OLUI?  SARM  ŌUI?  PAROL  PARNUI?  COŌRRNM  MŌRRNMLSAR?

`f103r.36`  okool.chedy.okeedy.qokeedy.qokeey.shdy.otey.qokeey
→ OŌOOL  SARNM  OŌRRNM  COŌRRNM  COŌRRM  PANM  OTRM  COŌRRM

`f103r.37`  pchedy.qokeey.qokeodair.qokshy.qokeedy.qokchdy.chsky.ee'ey.shalky
→ MSARNM  COŌRRM  COŌRONUIR  COŌPAM  COŌRRNM  COŌSANM  SAPŌM  RRRM  PAULŌM

`f103r.38`  otechedy.qokain.shcthy.chckhy.lokeedy.checkhy.lokain.shedy.okeey
→ OTRSARNM  COŌUI?  PASTAM  SASŌAM  LOŌRRNM  SARSŌAM  LOŌUI?  PARNM  OŌRRM

`f103r.39`  ykeedy.qokeey.lsheey.qotal.shedy.oteey
→ MŌRRNM  COŌRRM  LPARRM  COTUL  PARNM  OTRRM

`f103r.40`  qokeey.sheeol.shckhy.sheol.shodyol,aiin.otedy.qoteey.lotar.otam
→ COŌRRM  PARROL  PASŌAM  PAROL  PAONMOLUII?  OTRNM  COTRRM  LOTUR  OTUS

`f103r.41`  cheol.sheeey.qotey.oteeal.oteedy.shet,sho.keeo,s,shey.qokeedy.qokal.dal
→ SAROL  PARRRM  COTRM  OTRRUL  OTRRNM  PARTPAO  ŌRROPPARM  COŌRRNM  COŌUL  NUL

`f103r.42`  tshey.sheol.cheolshy.chalal
→ TPARM  PAROL  SAROLPAM  SAULUL

`f103r.43`  tar.cheal.ol.sheey.qotal.sheal.qokal.sheedy.okeshedy.shokey.qokaiin
→ TUR  SARUL  OL  PARRM  COTUL  PARUL  COŌUL  PARRNM  OŌRPARNM  PAOŌRM  COŌUII?

`f103r.44`  odeeey.qokeey.shey.sheal.otshedy
→ ONRRRM  COŌRRM  PARM  PARUL  OTPARNM

`f103r.45`  qokeedy.qokeedy.shol.shedar.chedy.qoteedy.oteedy.olkeol.ltar,y
→ COŌRRNM  COŌRRNM  PAOL  PARNUR  SARNM  COTRRNM  OTRRNM  OLŌROL  LTURM

`f103r.46`  chol,keey.qokeey.cheol.chorol,shedy.qokeey.qokeey.ol.loiin.chedan
→ SAOLŌRRM  COŌRRM  SAROL  SAOROLPARNM  COŌRRM  COŌRRM  OL  LOII?  SARNU?

`f103r.47`  ssheey.okeeo,l,lchey.qokaly.lcheedy.oloraiin
→ PPARRM  OŌRROLLSARM  COŌULM  LSARRNM  OLORUII?

`f103r.48`  polarar.lshedy.qotolaiin.qokeey.qokeey.shkchy.opchealol.kchy,sam
→ MOLURUR  LPARNM  COTOLUII?  COŌRRM  COŌRRM  PAŌSAM  OMSARULOL  ŌSAMPUS

`f103r.49`  okeey.lr.ain.l.ol,sheed.qokeey.sheol.qokeedy.shedy.qoky.leeesain,am
→ OŌRRM  LR  UI?  L  OLPARRN  COŌRRM  PAROL  COŌRRNM  PARNM  COŌM  LRRRPUI?US

`f103r.50`  ssheey.l,shey.qol.cheey.chey.qokeey.okeey.qokain.cheey.qotain
→ PPARRM  LPARM  COL  SARRM  SARM  COŌRRM  OŌRRM  COŌUI?  SARRM  COTUI?

`f103r.51`  saiin.cheteey.shey.cheosaiin
→ PUII?  SARTRRM  PARM  SAROPUII?

`f103r.52`  pchedal.oteey.qol,keedy.qokeey.qoty.chepchy.qopchey.lkaiin.otalsy
→ MSARNUL  OTRRM  COLŌRRNM  COŌRRM  COTM  SARMSAM  COMSARM  LŌUII?  OTULPM

`f103r.53`  sshey.qokedy.qokaiin.shdy.qokeey.chedy.qokeey.qokeey.lchedy.loty
→ PPARM  COŌRNM  COŌUII?  PANM  COŌRRM  SARNM  COŌRRM  COŌRRM  LSARNM  LOTM

`f103r.54`  dsheey.qoteeey.darchedy.qokey.qoty
→ NPARRM  COTRRRM  NURSARNM  COŌRM  COTM

### f103v  ·  stars

`f103v.1`  pol,dar.olfchey.qoky.dy.qokeey.qokeey.daiin.okeedaky.qote[iir:ar].shedy.dal
→ MOLNUR  OL?SARM  COŌM  NM  COŌRRM  COŌRRM  NUII?  OŌRRNUŌM  COTRIIR  PARNM  NUL

`f103v.2`  daiin.shey.qokal.shedy.qokeedy.qoteor.shey.qoty.chckhy.qotain.cha[l:?]r
→ NUII?  PARM  COŌUL  PARNM  COŌRRNM  COTROR  PARM  COTM  SASŌAM  COTUI?  SAULR

`f103v.3`  qo[k:t].or.chedy.qokey.dar.chcthy.char.qoty.shdy.okeedy.qokeey.qokain
→ COŌ  OR  SARNM  COŌRM  NUR  SASTAM  SAUR  COTM  PANM  OŌRRNM  COŌRRM  COŌUI?

`f103v.4`  y,cheey.qokeey.okeey.lkees,ol.qoteedy.ykeedy
→ MSARRM  COŌRRM  OŌRRM  LŌRRPOL  COTRRNM  MŌRRNM

`f103v.5`  pcheor.olkeey.cheky.qokshdy.qokaiin.okechdy.qopchdy.qotedy.qokaiin.oly
→ MSAROR  OLŌRRM  SARŌM  COŌPANM  COŌUII?  OŌRSANM  COMSANM  COTRNM  COŌUII?  OLM

`f103v.6`  dain.shey.qokeedy.cheol.qoeeor.lshor.qoky.shedy.qokaiin.chedy.qokam
→ NUI?  PARM  COŌRRNM  SAROL  CORROR  LPAOR  COŌM  PARNM  COŌUII?  SARNM  COŌUS

`f103v.7`  daiin.shey.chol.chey.oteey.lkeeor.okaiin.shedy.shedy.qokaiin.ol.chedydy
→ NUII?  PARM  SAOL  SARM  OTRRM  LŌRROR  OŌUII?  PARNM  PARNM  COŌUII?  OL  SARNMNM

`f103v.8`  sain.shey.olsheey.dair.chekoal.okeey
→ PUI?  PARM  OLPARRM  NUIR  SARŌOUL  OŌRRM

`f103v.9`  pchal,shal.shorchdy.okeor.okaiin.shedy.pchedy.qotchedy.qotar.ol.lkar
→ MSAULPAUL  PAORSANM  OŌROR  OŌUII?  PARNM  MSARNM  COTSARNM  COTUR  OL  LŌUR

`f103v.10`  or.cheey.qokeeshy.o[k:t]eey.loiin.o{ith}y.otedy.lor.aiin.sheor.qotain.olldy
→ OR  SARRM  COŌRRPAM  OŌRRM  LOII?  OITAM  OTRNM  LOR  UII?  PAROR  COTUI?  OLLNM

`f103v.11`  qokeedy.olkeeshy.qoky.qokal,shed
→ COŌRRNM  OLŌRRPAM  COŌM  COŌULPARN

`f103v.12`  sal.sheal.shedy.okeedy.qokeey.l,ol,shedy.pchor,pchedy.pol.sheedy.opalam
→ PUL  PARUL  PARNM  OŌRRNM  COŌRRM  LOLPARNM  MSAORMSARNM  MOL  PARRNM  OMULUS

`f103v.13`  dain.{ch'}eey.olshy.otey.olshedy.qotshdy.okeey.lr,ain.okan.olshey
→ NUI?  SARRM  OLPAM  OTRM  OLPARNM  COTPANM  OŌRRM  LRUI?  OŌU?  OLPARM

`f103v.14`  teeol.sheol.sho.qokeedy.shedy.qokey.oshedy.oteedy.qokain.otar,aiin.otam
→ TRROL  PAROL  PAO  COŌRRNM  PARNM  COŌRM  OPARNM  OTRRNM  COŌUI?  OTURUII?  OTUS

`f103v.15`  tchedal.shey.lcheey.lchdy.ch,ar.olchey.lcheody.tedy.otain.otain.ota[?:l]y
→ TSARNUL  PARM  LSARRM  LSANM  SAUR  OLSARM  LSARONM  TRNM  OTUI?  OTUI?  OTUM

`f103v.16`  daiin.sheekchy.okeeshy.qol.shedy.otain.ol,kedy
→ NUII?  PARRŌSAM  OŌRRPAM  COL  PARNM  OTUI?  OLŌRNM

`f103v.17`  qokeedy.chedy.qoteey.oteedy.lkedy.shedy.qokal.ol,char.otal.opchedy
→ COŌRRNM  SARNM  COTRRM  OTRRNM  LŌRNM  PARNM  COŌUL  OLSAUR  OTUL  OMSARNM

`f103v.18`  yshear.ol.oqaiin.chckhey.lchedy.chedy.olaiin.oteedy.qokeedal.larorol
→ MPARUR  OL  OCUII?  SASŌARM  LSARNM  SARNM  OLUII?  OTRRNM  COŌRRNUL  LUROROL

`f103v.19`  daiin.chey.lkeey.chalkar.cheeey,l,chealainor
→ NUII?  SARM  LŌRRM  SAULŌUR  SARRRMLSARULUI?OR

`f103v.20`  pol.char.otar.okaiin.sha{ikh}y.oteal.okain.qotal.shedy.qokeey.lolain
→ MOL  SAUR  OTUR  OŌUII?  PAUIŌAM  OTRUL  OŌUI?  COTUL  PARNM  COŌRRM  LOLUI?

`f103v.21`  tokain.shal.qokeed.oteedy.sheoky.sha{ikhh}y.tar.teor.otam,oll
→ TOŌUI?  PAUL  COŌRRN  OTRRNM  PAROŌM  PAUIŌAAM  TUR  TROR  OTUSOLL

`f103v.22`  olshey.qokshy.qotalsheey.[o:a]loiin.oleeedy.qokain.shedy.qokey
→ OLPARM  COŌPAM  COTULPARRM  OLOII?  OLRRRNM  COŌUI?  PARNM  COŌRM

`f103v.23`  ycheody.l.ar.cheey.or,aiiin.oteey.otal.otear.[o:a]r.ar.keey.qoty
→ MSARONM  L  UR  SARRM  ORUIII?  OTRRM  OTUL  OTRUR  OR  UR  ŌRRM  COTM

`f103v.24`  ykeey.lchey.qokeey.ror.aiin.olan.otan.otain.otain.ar,y,kain
→ MŌRRM  LSARM  COŌRRM  ROR  UII?  OLU?  OTU?  OTUI?  OTUI?  URMŌUI?

`f103v.25`  sain.olkeeey.qokan.oteedy.qotain.otal.oty.opar.aram.oteeam
→ PUI?  OLŌRRRM  COŌU?  OTRRNM  COTUI?  OTUL  OTM  OMUR  URUS  OTRRUS

`f103v.26`  yteey.qokeey.sheety.oteey.lshedy.oteaiin
→ MTRRM  COŌRRM  PARRTM  OTRRM  LPARNM  OTRUII?

`f103v.27`  fcheody.arar.okeey.okeey.lchedy.oteal.lpar.otedy.qotar.otaryly
→ ?SARONM  URUR  OŌRRM  OŌRRM  LSARNM  OTRUL  LMUR  OTRNM  COTUR  OTURMLM

`f103v.28`  daiin.checkhy.ykeey.shckhy.otealshey.okain.chey.oteedy.por,aiin,y
→ NUII?  SARSŌAM  MŌRRM  PASŌAM  OTRULPARM  OŌUI?  SARM  OTRRNM  MORUII?M

`f103v.29`  olcheeey.chey.lkchdy.sho.chcthy.sal,araiin.qokeey
→ OLSARRRM  SARM  LŌSANM  PAO  SASTAM  PULURUII?  COŌRRM

`f103v.30`  pchear.okain.opchedy.pchol.fchedy.otedy.poly.lchedy.fchedey.rar
→ MSARUR  OŌUI?  OMSARNM  MSAOL  ?SARNM  OTRNM  MOLM  LSARNM  ?SARNRM  RUR

`f103v.31`  okeey.l.chey.qokeey.o,qokeey.chedy.qekchy.daiin.chckhy.sar.olainy
→ OŌRRM  L  SARM  COŌRRM  OCOŌRRM  SARNM  CRŌSAM  NUII?  SASŌAM  PUR  OLUI?M

`f103v.32`  qokeeey.chey.qotey.chokaiin.shal.chedy.olkam
→ COŌRRRM  SARM  COTRM  SAOŌUII?  PAUL  SARNM  OLŌUS

`f103v.33`  yshey.lkeey.qokain.okey.okaiin.cheody.otey.shdpchy.opchey.oly
→ MPARM  LŌRRM  COŌUI?  OŌRM  OŌUII?  SARONM  OTRM  PANMSAM  OMSARM  OLM

`f103v.34`  daiin.sheey.ol.chey.qok,shey.qokaiin.checkhy.otedy.lshey.lchdy
→ NUII?  PARRM  OL  SARM  COŌPARM  COŌUII?  SARSŌAM  OTRNM  LPARM  LSANM

`f103v.35`  qol,shey.ykeey.okeey.lshey.sheckhy.chtain.oty.okedy.otaly
→ COLPARM  MŌRRM  OŌRRM  LPARM  PARSŌAM  SATUI?  OTM  OŌRNM  OTULM

`f103v.36`  saiin.shey.qokeey.oshey.olshedy
→ PUII?  PARM  COŌRRM  OPARM  OLPARNM

`f103v.37`  olshey.qokain.ol.sh[e:?]y.qokeshe.lsheok.shdy.qcphey.chetydar
→ OLPARM  COŌUI?  OL  PARM  COŌRPAR  LPAROŌ  PANM  CSMARM  SARTMNUR

`f103v.38`  oteey.l.chees.ol.chey.chey.chol,keechy
→ OTRRM  L  SARRP  OL  SARM  SARM  SAOLŌRRSAM

`f103v.39`  polshor.keeolshey.okey.lcharar.shol.okeedar.shes,aiin.oty.lchdy
→ MOLPAOR  ŌRROLPARM  OŌRM  LSAURUR  PAOL  OŌRRNUR  PARPUII?  OTM  LSANM

`f103v.40`  yteey.sheal.shey.qoain.ol.keey.qokaiin.shckhy.lchedy.rain
→ MTRRM  PARUL  PARM  COUI?  OL  ŌRRM  COŌUII?  PASŌAM  LSARNM  RUI?

`f103v.41`  daiin.shey.l,shey.lshey.qoar.sha[s:r].al.otar.shedy.{ith}y.lchdy.rar
→ NUII?  PARM  LPARM  LPARM  COUR  PAUP  UL  OTUR  PARNM  ITAM  LSANM  RUR

`f103v.42`  yshey.sheykain.chey.rar.arol.chsaly
→ MPARM  PARMŌUI?  SARM  RUR  UROL  SAPULM

`f103v.43`  orain.chckhey.qokaiin.shckhy.shtal,opchy.lkeedy.chdy,lchedy
→ ORUI?  SASŌARM  COŌUII?  PASŌAM  PATULOMSAM  LŌRRNM  SANMLSARNM

`f103v.44`  qkain.shey.ar.ar.oky.rain.chckhy.shedy.qokeory.lteedy.ro
→ CŌUI?  PARM  UR  UR  OŌM  RUI?  SASŌAM  PARNM  COŌRORM  LTRRNM  RO

`f103v.45`  okey.ol,cheey.lcheey.lkain.shckhy.sheckhy,or,ain.otar.oly
→ OŌRM  OLSARRM  LSARRM  LŌUI?  PASŌAM  PARSŌAMORUI?  OTUR  OLM

`f103v.46`  tain.shol.qokain.chckhy.rorol.chdy.raly.osaiin.chary
→ TUI?  PAOL  COŌUI?  SASŌAM  ROROL  SANM  RULM  OPUII?  SAURM

### f104r  ·  stars

`f104r.1`  pchdar.chedy.char.qopchedy.ocphedy.qopchedy.shedaiin.oteeochey.qopchedy.sain
→ MSANUR  SARNM  SAUR  COMSARNM  OSMARNM  COMSARNM  PARNUII?  OTRROSARM  COMSARNM  PUI?

`f104r.2`  o,ar.aiin.yteeody.cheedaiin.cheodar.s,aiin.chey.tair.os,aiin.chcthedy.teedaram
→ OUR  UII?  MTRRONM  SARRNUII?  SARONUR  PUII?  SARM  TUIR  OPUII?  SASTARNM  TRRNURUS

`f104r.3`  daiir.o.cthedy.otech.ykar.otedy.otody.qoteeor.yteeody.oteedy.aky.okal.daram
→ NUIIR  O  STARNM  OTRSA  MŌUR  OTRNM  OTONM  COTRROR  MTRRONM  OTRRNM  UŌM  OŌUL  NURUS

`f104r.4`  o,l,sheedy.qokeedy.chedal.qodaiin.qodaiin.chry
→ OLPARRNM  COŌRRNM  SARNUL  CONUII?  CONUII?  SARM

`f104r.5`  kchdal.qotaiin.qoshedy.ol.chl.ol.cheda{iph}y.al.lod.pchdair.opchdy.qod
→ ŌSANUL  COTUII?  COPARNM  OL  SAL  OL  SARNUIMAM  UL  LON  MSANUIR  OMSANM  CON

`f104r.6`  y,cheeody.aiin.lkar.cheeo.dain.ockhedy.qokeedy.qotain.otchdy.otain.chedam
→ MSARRONM  UII?  LŌUR  SARRO  NUI?  OSŌARNM  COŌRRNM  COTUI?  OTSANM  OTUI?  SARNUS

`f104r.7`  dchodees.sheos.odaiin.otchedy.qodain.shedy.chedy.qodain.okar.ar.okaim
→ NSAONRRP  PAROP  ONUII?  OTSARNM  CONUI?  PARNM  SARNM  CONUI?  OŌUR  UR  OŌUIS

`f104r.8`  o,lsheedy.lkeedy.lkeody.qokaiin.chedal.qokar.odar.qokal.okar.otar.odr
→ OLPARRNM  LŌRRNM  LŌRONM  COŌUII?  SARNUL  COŌUR  ONUR  COŌUL  OŌUR  OTUR  ONR

`f104r.9`  ycheeoy.qokecho.qokol.cheeo,dam
→ MSARROM  COŌRSAO  COŌOL  SARRONUS

`f104r.10`  tol.chedal.cheo{cka}y.otyd.os.l.air.shdy.qokchd.octheody.cholfor.otalr
→ TOL  SARNUL  SAROSŌUM  OTMN  OP  L  UIR  PANM  COŌSAN  OSTARONM  SAOL?OR  OTULR

`f104r.11`  otodchy.lkeody.qokair.otoly.shodar.cheey.okar,olkeedy
→ OTONSAM  LŌRONM  COŌUIR  OTOLM  PAONUR  SARRM  OŌUROLŌRRNM

`f104r.12`  tshdol,qotchedy.qokoeey.qoteode.lo.sar.al.octhy.qotor.opchey.qotam
→ TPANOLCOTSARNM  COŌORRM  COTRONR  LO  PUR  UL  OSTAM  COTOR  OMSARM  COTUS

`f104r.13`  olcheol.qodain.chokar.okcho,lkain.okar.cheody.okeeody.qodam.chdy
→ OLSAROL  CONUI?  SAOŌUR  OŌSAOLŌUI?  OŌUR  SARONM  OŌRRONM  CONUS  SANM

`f104r.14`  daiin.choaiin.qokechy.qotal.cheolor.saiin.olkeechey.otal.ol,oeeal
→ NUII?  SAOUII?  COŌRSAM  COTUL  SAROLOR  PUII?  OLŌRRSARM  OTUL  OLORRUL

`f104r.15`  sor.chodaiin.chody.okar.otolkeechdy.okal.kaiin.cheodaiin
→ POR  SAONUII?  SAONM  OŌUR  OTOLŌRRSANM  OŌUL  ŌUII?  SARONUII?

`f104r.16`  ocheo{ith}ey.qoctheody.ykeeodey.qoepchy.opchey,qoty.sh,tey.yteedy.shody
→ OSAROITARM  COSTARONM  MŌRRONRM  CORMSAM  OMSARMCOTM  PATRM  MTRRNM  PAONM

`f104r.17`  ykeeshedy.olkeeody.qotey.qokar.chedy.qokedy.oteechy.chyteody.okar,ody
→ MŌRRPARNM  OLŌRRONM  COTRM  COŌUR  SARNM  COŌRNM  OTRRSAM  SAMTRONM  OŌURONM

`f104r.18`  dcheeokeody.qokain.qolar.or.chockhar.otalkshedy
→ NSARROŌRONM  COŌUI?  COLUR  OR  SAOSŌAUR  OTULŌPARNM

`f104r.19`  toaiin.chdar.otar,shd.qotar.olkchedy.cheokeey.kary.opair.otor.airod.lshd
→ TOUII?  SANUR  OTURPAN  COTUR  OLŌSARNM  SAROŌRRM  ŌURM  OMUIR  OTOR  UIRON  LPAN

`f104r.20`  dsheoy.qocthey.qokchdy.qokaiin.chol.rar.cheody.cheeekan.ar.ain.ar.alam
→ NPAROM  COSTARM  COŌSANM  COŌUII?  SAOL  RUR  SARONM  SARRRŌU?  UR  UI?  UR  ULUS

`f104r.21`  dsheedy.qokaiin.chear.olkchedy.charaiin
→ NPARRNM  COŌUII?  SARUR  OLŌSARNM  SAURUII?

`f104r.22`  tshedar.chllo.rl.shed.kchedy.chokor.cheedy.opchar.cheor.chckhey.taiin.dam
→ TPARNUR  SALLO  RL  PARN  ŌSARNM  SAOŌOR  SARRNM  OMSAUR  SAROR  SASŌARM  TUII?  NUS

`f104r.23`  ol.sheockhey.chol,kechdy.okeedal.lkain.chol,keeody.otchor.aiir.chol.kar.alol
→ OL  PAROSŌARM  SAOLŌRSANM  OŌRRNUL  LŌUI?  SAOLŌRRONM  OTSAOR  UIIR  SAOL  ŌUR  ULOL

`f104r.24`  daiin.char.qotal.okechol.olkeeor.olkeeodal.lkaiin.chal,keeedy.qokam
→ NUII?  SAUR  COTUL  OŌRSAOL  OLŌRROR  OLŌRRONUL  LŌUII?  SAULŌRRRNM  COŌUS

`f104r.25`  sar.okair.chckhey.qodaiin.chckhy.checkhd.l,raiin.otain.ar,airam
→ PUR  OŌUIR  SASŌARM  CONUII?  SASŌAM  SARSŌAN  LRUII?  OTUI?  URUIRUS

`f104r.26`  shar.sheey.kar.sheody
→ PAUR  PARRM  ŌUR  PARONM

`f104r.27`  pchedar.qokaiin.qotaiin.dl.ral.cheodl.cphaiin.daiin.ar.qekeeey.qoparaiin
→ MSARNUR  COŌUII?  COTUII?  NL  RUL  SARONL  SMAUII?  NUII?  UR  CRŌRRRM  COMURUII?

`f104r.28`  olcheear.chedar.or.aror,sheey.olkeechy.or.char.cheeo,l.s.or.or,aiin.atam
→ OLSARRUR  SARNUR  OR  URORPARRM  OLŌRRSAM  OR  SAUR  SARROL  P  OR  ORUII?  UTUS

`f104r.29`  ysheodaiin.shody.yteedy.cheedar.or,air.cheoltar.arodly
→ MPARONUII?  PAONM  MTRRNM  SARRNUR  ORUIR  SAROLTUR  URONLM

`f104r.30`  okeeo,l,keeo.dain.lkeodaiin.qokeeo.lkeeeey.okeody.otechdy.opcheof.qopaiin
→ OŌRROLŌRRO  NUI?  LŌRONUII?  COŌRRO  LŌRRRRM  OŌRONM  OTRSANM  OMSARO?  COMUII?

`f104r.31`  qokeeo.aiin.ok{ch'}eey.okolchey.lcheeey.oteey.lkechedy.qokaiin.chedar.cholcham
→ COŌRRO  UII?  OŌSARRM  OŌOLSARM  LSARRRM  OTRRM  LŌRSARNM  COŌUII?  SARNUR  SAOLSAUS

`f104r.32`  ysheeody.qo[cth:et?].okshey.otechshy.cheol.kaiin.shoda.lkaiin.cheodain.qokar.alchd
→ MPARRONM  COSTA  OŌPARM  OTRSAPAM  SAROL  ŌUII?  PAONU  LŌUII?  SARONUI?  COŌUR  ULSAN

`f104r.33`  okchechy.qokcheedy.okchdal.qokal.char.olkeeey.olcheo.lkaiin.chey.raly
→ OŌSARSAM  COŌSARRNM  OŌSANUL  COŌUL  SAUR  OLŌRRRM  OLSARO  LŌUII?  SARM  RULM

`f104r.34`  pchol,ksheody.qokeshedy.qokal.chedy.qokaiin.otaiin.cheody.qokal.taiin.cholxy
→ MSAOLŌPARONM  COŌRPARNM  COŌUL  SARNM  COŌUII?  OTUII?  SARONM  COŌUL  TUII?  SAOL?M

`f104r.35`  yshoiin.qocheol.chedaiin.qodal.chey.chol,cheol.olaly
→ MPAOII?  COSAROL  SARNUII?  CONUL  SARM  SAOLSAROL  OLULM

`f104r.36`  psheody.qotar.chopar.qotaly.qotsheod.qotechy.kaiin.okar.qopchar.opam
→ MPARONM  COTUR  SAOMUR  COTULM  COTPARON  COTRSAM  ŌUII?  OŌUR  COMSAUR  OMUS

`f104r.37`  okaiin.cheodal.qoaiin.okar.oraiin.okar.oteody.qokaiin.okal.qotir
→ OŌUII?  SARONUL  COUII?  OŌUR  ORUII?  OŌUR  OTRONM  COŌUII?  OŌUL  COTIR

`f104r.38`  okaiin.[o:a]rcheol.qokchol.kcheody.qotchdy
→ OŌUII?  ORSAROL  COŌSAOL  ŌSARONM  COTSANM

`f104r.39`  pcholor.ar.aiin.alkchdy.qotal.chol.qoar.aiin.qopcheedy.qotair.ofaiino
→ MSAOLOR  UR  UII?  ULŌSANM  COTUL  SAOL  COUR  UII?  COMSARRNM  COTUIR  O?UII?O

`f104r.40`  olkeeos.olkaiin.oair.qcthy.oiinol,al.ly.oeear.chcthy.olched.qotaiiin
→ OLŌRROP  OLŌUII?  OUIR  CSTAM  OII?OLUL  LM  ORRUR  SASTAM  OLSARN  COTUIII?

`f104r.41`  qoteey.qokeor.soiir.qoty.qokl.lkaiin.yteedy.qokain.oqockhy.dar
→ COTRRM  COŌROR  POIIR  COTM  COŌL  LŌUII?  MTRRNM  COŌUI?  OCOSŌAM  NUR

`f104r.42`  y.lshedy.cholkar
→ M  LPARNM  SAOLŌUR

`f104r.43`  tsheodl.qokaiin.qokchedy.ykchdy.pchedy.qokeedy.oteey.qokain.oteo,l,dal
→ TPARONL  COŌUII?  COŌSARNM  MŌSANM  MSARNM  COŌRRNM  OTRRM  COŌUI?  OTROLNUL

`f104r.44`  okcheochy.cheey.qoeedaiin.qokeey.ar.cheol.olkair.qokaiin.otaiin.okam
→ OŌSAROSAM  SARRM  CORRNUII?  COŌRRM  UR  SAROL  OLŌUIR  COŌUII?  OTUII?  OŌUS

`f104r.45`  daiin.olcheeo.l.s.aiin.otain.ar.chedy.qokaiin.otaiin.otaiin
→ NUII?  OLSARRO  L  P  UII?  OTUI?  UR  SARNM  COŌUII?  OTUII?  OTUII?

### f104v  ·  stars

`f104v.1`  pchdoiin.opcheedy.orar.oltcheey.opchedy.ol.ear.aiir,aly.cheodaiin.cheekain.dam
→ MSANOII?  OMSARRNM  ORUR  OLTSARRM  OMSARNM  OL  RUR  UIIRULM  SARONUII?  SARRŌUI?  NUS

`f104v.2`  ychedaiin.qoteed.chockhy.otaiin.ydaiin.qokamdy.otarar.alched.otair,oram
→ MSARNUII?  COTRRN  SAOSŌAM  OTUII?  MNUII?  COŌUSNM  OTURUR  ULSARN  OTUIRORUS

`f104v.3`  shod.chedy.qotaiin.odaiin.okeol.ockhey.chol.qokeedy.qotair.oeedaiin.ol.d[l:o]
→ PAON  SARNM  COTUII?  ONUII?  OŌROL  OSŌARM  SAOL  COŌRRNM  COTUIR  ORRNUII?  OL  NL

`f104v.4`  qoteedy.chedaiin.chokar.qotol.qotched.chol.chey.qol.chedy.qoeeey.qokeedy
→ COTRRNM  SARNUII?  SAOŌUR  COTOL  COTSARN  SAOL  SARM  COL  SARNM  CORRRM  COŌRRNM

`f104v.5`  dcheol.chdeey.oeeodain.s,airol.chedal
→ NSAROL  SANRRM  ORRONUI?  PUIROL  SARNUL

`f104v.6`  solchd.shol.sheol.qokchy.qoka.l.chedy.shedy.qokain.cheedy.cpheo.apchedy.qotady
→ POLSAN  PAOL  PAROL  COŌSAM  COŌU  L  SARNM  PARNM  COŌUI?  SARRNM  SMARO  UMSARNM  COTUNM

`f104v.7`  o.scheo.lchody.cheey.qo{ck}y.cheo,ain.o,chedy.cheedy.chedy.sol.cheodalol
→ O  PSARO  LSAONM  SARRM  COSŌM  SAROUI?  OSARNM  SARRNM  SARNM  POL  SARONULOL

`f104v.8`  tchodls.cheeody.cheeool.ls.air.ykeedy.chotedy.qotchedy.chedy.qoeky.qoteeo.lo
→ TSAONLP  SARRONM  SARROOL  LP  UIR  MŌRRNM  SAOTRNM  COTSARNM  SARNM  CORŌM  COTRRO  LO

`f104v.9`  ycheo.lcheod.otaiin.qokeedy.qokaiin.cheor.ol.chedaiin.qotar.chedy.qoty.dal
→ MSARO  LSARON  OTUII?  COŌRRNM  COŌUII?  SAROR  OL  SARNUII?  COTUR  SARNM  COTM  NUL

`f104v.10`  shol.cheedy.qokaiin.qoteedy.otaiin.oteedy.qotedor.okain.cheos.cheeo.lchey
→ PAOL  SARRNM  COŌUII?  COTRRNM  OTUII?  OTRRNM  COTRNOR  OŌUI?  SAROP  SARRO  LSARM

`f104v.11`  ycheedy.qo{cthh}y.ykchedor.cheeky.qokchd.qotol.qokol.qokol.daiin
→ MSARRNM  COSTAAM  MŌSARNOR  SARRŌM  COŌSAN  COTOL  COŌOL  COŌOL  NUII?

`f104v.12`  polchechy.oteoy.chotchs.cheeta.ot[eee:ech]y.oteedy.qoty.ched.l.cheol.par.oltedy.chedam
→ MOLSARSAM  OTROM  SAOTSAP  SARRTU  OTRRRM  OTRRNM  COTM  SARN  L  SAROL  MUR  OLTRNM  SARNUS

`f104v.13`  ycheol.cheody.qoeechdy.qokeol.qotaiin.chedar.cheo,lkaiin.cheetar.aiin.ch[ei:a]taiin
→ MSAROL  SARONM  CORRSANM  COŌROL  COTUII?  SARNUR  SAROLŌUII?  SARRTUR  UII?  SARITUII?

`f104v.14`  yt{oh}edy.qokeeo.lcheolshedy.s.aiin.cheky.daindl
→ MTOARNM  COŌRRO  LSAROLPARNM  P  UII?  SARŌM  NUI?NL

`f104v.15`  tolkshey.chocthy.qokeochy.qokchy.qotcheo.qotcheo.dlchd.chedy.tchdy.qotchdy.ram
→ TOLŌPARM  SAOSTAM  COŌROSAM  COŌSAM  COTSARO  COTSARO  NLSAN  SARNM  TSANM  COTSANM  RUS

`f104v.16`  dcheedy.qockheey.chdor.as.aiin.ch{cthh}y.dchdar.chdy.qokchedy.olkchy.qokain.dadam
→ NSARRNM  COSŌARRM  SANOR  UP  UII?  SASTAAM  NSANUR  SANM  COŌSARNM  OLŌSAM  COŌUI?  NUNUS

`f104v.17`  ycheechy.cheey.cheos.{ai}s.otkchedy.cholkchy.qotchdy.qotol.sheedy.or,ain.cheol
→ MSARRSAM  SARRM  SAROP  UIP  OTŌSARNM  SAOLŌSAM  COTSANM  COTOL  PARRNM  ORUI?  SAROL

`f104v.18`  dcheeoy.qokaiiin.qokaiin.lkar.ytaiin.otcheochy.sarain
→ NSARROM  COŌUIII?  COŌUII?  LŌUR  MTUII?  OTSAROSAM  PURUI?

`f104v.19`  pcheor.chol.chpcheor.cholkshedy.qotol.sheedy.qokchy.qotched.sho.fchor.ols.aiin.chekal
→ MSAROR  SAOL  SAMSAROR  SAOLŌPARNM  COTOL  PARRNM  COŌSAM  COTSARN  PAO  ?SAOR  OLP  UII?  SARŌUL

`f104v.20`  or.sheeo.lcheedy.qokeey.qochey.qotcheedy.qotchedy.qokol.chor.chorol.chdar.otam
→ OR  PARRO  LSARRNM  COŌRRM  COSARM  COTSARRNM  COTSARNM  COŌOL  SAOR  SAOROL  SANUR  OTUS

`f104v.21`  yshor.sheedy.qokaiin.shokchey.qokeey.chodain
→ MPAOR  PARRNM  COŌUII?  PAOŌSARM  COŌRRM  SAONUI?

`f104v.22`  ytchedy.qokchedy.qotchy.qokchedy.qokchd.ls,aiin.qchor.sheor.ytaiin.chey.tal
→ MTSARNM  COŌSARNM  COTSAM  COŌSARNM  COŌSAN  LPUII?  CSAOR  PAROR  MTUII?  SARM  TUL

`f104v.23`  tchey.qokchey.qochey.qodeey.qodaiin.chodaiin.chckhdy.dairar.otar.qotai@208;.?l
→ TSARM  COŌSARM  COSARM  CONRRM  CONUII?  SAONUII?  SASŌANM  NUIRUR  OTUR  COTUI  L

`f104v.24`  ykaiin.cheor.cheeey.daiiin.cheo,dalaiin.chockhedy.chedaiin.otor.qokar,ary
→ MŌUII?  SAROR  SARRRM  NUIII?  SARONULUII?  SAOSŌARNM  SARNUII?  OTOR  COŌURURM

`f104v.25`  dsheey.qoykeey.lchedy.qokedaiin.ar,chcthy.daiin,cheey.sair.ol.aiin.chedy
→ NPARRM  COMŌRRM  LSARNM  COŌRNUII?  URSASTAM  NUII?SARRM  PUIR  OL  UII?  SARNM

`f104v.26`  ysheor.sheey.qodaiin.chodar.chochs
→ MPAROR  PARRM  CONUII?  SAONUR  SAOSAP

`f104v.27`  pchoror.shor.sheol.sheol.sheol.qokchedy.chdor.sho,r.aiin.chpchs.aiin.al
→ MSAOROR  PAOR  PAROL  PAROL  PAROL  COŌSARNM  SANOR  PAOR  UII?  SAMSAP  UII?  UL

`f104v.28`  olsho.l[s:?]air.olcheey.qokeechy.qokchy.daiin.chody.qodaiin.cheody
→ OLPAO  LPUIR  OLSARRM  COŌRRSAM  COŌSAM  NUII?  SAONM  CONUII?  SARONM

`f104v.29`  kche.shodaiin.qokeey.cheokcheo.lol.kaiin.qotchdy.lcheo.l,chedy.l,cheed.chaim
→ ŌSAR  PAONUII?  COŌRRM  SAROŌSARO  LOL  ŌUII?  COTSANM  LSARO  LSARNM  LSARRN  SAUIS

`f104v.30`  ycheol.kaiin.cheody.shaiin.qoeeol.otair,or.cheeody.okcheey.lkair.ar.ar.adam
→ MSAROL  ŌUII?  SARONM  PAUII?  CORROL  OTUIROR  SARRONM  OŌSARRM  LŌUIR  UR  UR  UNUS

`f104v.31`  y,cheoraiin.cthey.chol.sheody.qokair.qoeey.cheey.lkeedy
→ MSARORUII?  STARM  SAOL  PARONM  COŌUIR  CORRM  SARRM  LŌRRNM

`f104v.32`  pchedy,kchedy.cheocphey.or,ain.cheeos.aiiiro.lcheedy.lcheedy.qosaiin.cfheo.ar,als.am
→ MSARNMŌSARNM  SAROSMARM  ORUI?  SARROP  UIIIRO  LSARRNM  LSARRNM  COPUII?  S?ARO  URULP  US

`f104v.33`  yteeey.cheeod.ykeey.kaiin.qokaiin.cheey.or.ol.ar.odar.chedain.etar.ar,air.ary
→ MTRRRM  SARRON  MŌRRM  ŌUII?  COŌUII?  SARRM  OR  OL  UR  ONUR  SARNUI?  RTUR  URUIR  URM

`f104v.34`  ycheo.lkeed.qotain.okaiin.chokain.okain.cheol.olcho
→ MSARO  LŌRRN  COTUI?  OŌUII?  SAOŌUI?  OŌUI?  SAROL  OLSAO

`f104v.35`  psheodar.sheedy.qotchedar.oteedy.qotaiin.oka{ifhh}y.sheody.qokedy.topaiin.am
→ MPARONUR  PARRNM  COTSARNUR  OTRRNM  COTUII?  OŌUI?AAM  PARONM  COŌRNM  TOMUII?  US

`f104v.36`  sar,aiir.sheos.qoiiin.okeedy.qokcheodaiin
→ PURUIIR  PAROP  COIII?  OŌRRNM  COŌSARONUII?

`f104v.37`  posairy.ytedar,chedy.shoefcheey,kechy.sar,odl.air.shey.qopcheey,sol.ain.arodam
→ MOPUIRM  MTRNURSARNM  PAOR?SARRMŌRSAM  PURONL  UIR  PARM  COMSARRMPOL  UI?  URONUS

`f104v.38`  okechey.chedy,chchy.qotain.qokain.chey.or,aiin.cheo.or,aiin.chedain.okam
→ OŌRSARM  SARNMSASAM  COTUI?  COŌUI?  SARM  ORUII?  SARO  ORUII?  SARNUI?  OŌUS

`f104v.39`  yshey.@206;ar.a,kain.char.lkeey.roiir.shey.cheey.kar.ar.lkchs.ar,y,@206;,ais.alod
→ MPARM  UR  UŌUI?  SAUR  LŌRRM  ROIIR  PARM  SARRM  ŌUR  UR  LŌSAP  URMUIP  ULON

`f104v.40`  qokeeey.okchedy.qokeey.aiin,odain.orchedy.qoky
→ COŌRRRM  OŌSARNM  COŌRRM  UII?ONUI?  ORSARNM  COŌM

`f104v.41`  tchedy.qotechy.otcheeo,l,keedy.qoty.raiin.cheedy.qotaiin.otchdy.qotain
→ TSARNM  COTRSAM  OTSARROLŌRRNM  COTM  RUII?  SARRNM  COTUII?  OTSANM  COTUI?

`f104v.42`  oteedchey.qoeeda.lchal.cheedy.qoteey.sheey.teeeo.dar.cheed.qotain.chedy
→ OTRRNSARM  CORRNU  LSAUL  SARRNM  COTRRM  PARRM  TRRRO  NUR  SARRN  COTUI?  SARNM

`f104v.43`  chey.keeey.qockheey.lkeey.o,keeedy.qokeey.okchey.qot[?:e]odaiin.okain.orom
→ SARM  ŌRRRM  COSŌARRM  LŌRRM  OŌRRRNM  COŌRRM  OŌSARM  COTONUII?  OŌUI?  OROS

`f104v.44`  daiin.y,cheeo,chey.okeeey.qokeeey.okeey.okeey
→ NUII?  MSARROSARM  OŌRRRM  COŌRRRM  OŌRRM  OŌRRM

### f105r  ·  stars

`f105r.1`  @199;aiin,dar.chcphy.qokeey.qopaiin.ypcheeey.saraisl.aiin.cheedy.[?:k]aiin.arody
→ UII?NUR  SASMAM  COŌRRM  COMUII?  MMSARRRM  PURUIPL  UII?  SARRNM  UII?  URONM

`f105r.2`  dshees.yey.cheey.raiin.otchdy.qodor.ches.or.cheey.okees.odar.cheody,qody
→ NPARRP  MRM  SARRM  RUII?  OTSANM  CONOR  SARP  OR  SARRM  OŌRRP  ONUR  SARONMCONM

`f105r.3`  olshey.qod[en:a'].odeey.kcheody.cheeo.ar.yteey.ytchy.otedy.qokeedy.qokeey.rol
→ OLPARM  CONR?  ONRRM  ŌSARONM  SARRO  UR  MTRRM  MTSAM  OTRNM  COŌRRNM  COŌRRM  ROL

`f105r.4`  ykaiin.olkeedy.odaiin.okar.eeeodaiin.yteey.ochedy.[q:?]okeeey.oy.teedy.qotam
→ MŌUII?  OLŌRRNM  ONUII?  OŌUR  RRRONUII?  MTRRM  OSARNM  COŌRRRM  OM  TRRNM  COTUS

`f105r.5`  daiin.yteedy.yteeeody.yl.cheod.or.aiiroekey.otchdy.otey
→ NUII?  MTRRNM  MTRRRONM  ML  SARON  OR  UIIRORŌRM  OTSANM  OTRM

`f105r.6`  par.arody.shedeeey.qopchedy.qody.qoteody.aiin.yteody.qokor.olpshedy
→ MUR  URONM  PARNRRRM  COMSARNM  CONM  COTRONM  UII?  MTRONM  COŌOR  OLMPARNM

`f105r.7`  ysheeody.ykeeos.or.aiiin.shey.qodaiiin.qokeed.qokeey.saiin.aiirody
→ MPARRONM  MŌRROP  OR  UIII?  PARM  CONUIII?  COŌRRN  COŌRRM  PUII?  UIIRONM

`f105r.8`  sheey.oleeey.or,air.qokaiin.chey.qokeedy.qokedy.oteedy.lchedy.oesal
→ PARRM  OLRRRM  ORUIR  COŌUII?  SARM  COŌRRNM  COŌRNM  OTRRNM  LSARNM  ORPUL

`f105r.9`  oeeolchy.okee[y:o]dy.okeey.okchey
→ ORROLSAM  OŌRRMNM  OŌRRM  OŌSARM

`f105r.10`  sairy.ore.daiindy.ytam
→ PUIRM  ORR  NUII?NM  MTUS

`f105r.11`  pdar,o,shedy.otcheos.oiiin,al.tchedarchy.fchos,aiin.polaiin.polkeeey.dyaiin
→ MNUROPARNM  OTSAROP  OIII?UL  TSARNURSAM  ?SAOPUII?  MOLUII?  MOLŌRRRM  NMUII?

`f105r.12`  ya[iir:iin].yteeo,dy.qoeeody.qoeedy.kchedy.qotchdy.otcheey.chey.teeor.ykedy.ry
→ MUIIR  MTRRONM  CORRONM  CORRNM  ŌSARNM  COTSANM  OTSARRM  SARM  TRROR  MŌRNM  RM

`f105r.13`  dyteey.qokdy.chedy.chedy.dal.qoked.shedy.qoteody.cheedy.ot
→ NMTRRM  COŌNM  SARNM  SARNM  NUL  COŌRN  PARNM  COTRONM  SARRNM  OT

`f105r.14`  kesoar.qoeeedy.keeody.dlls,air.shckhy.oekeody.cheody.oeey.qokeeody.sheo,lkeey
→ ŌRPOUR  CORRRNM  ŌRRONM  NLLPUIR  PASŌAM  ORŌRONM  SARONM  ORRM  COŌRRONM  PAROLŌRRM

`f105r.15`  lksheey.ol.r.aiin.okeedy.olkeeody.lkaiin.okeeol.oteeol.shod.daiin.aral
→ LŌPARRM  OL  R  UII?  OŌRRNM  OLŌRRONM  LŌUII?  OŌRROL  OTRROL  PAON  NUII?  URUL

`f105r.16`  yteody.oteeeos.aiin.odal.oiir.okeedy.oral
→ MTRONM  OTRRROP  UII?  ONUL  OIIR  OŌRRNM  ORUL

`f105r.17`  lteedy.okeeddl.sheokedy.qokedy.shol.kol.aiirol.qokchedy.daiin.okedy.q@145;ky
→ LTRRNM  OŌRRNNL  PAROŌRNM  COŌRNM  PAOL  ŌOL  UIIROL  COŌSARNM  NUII?  OŌRNM  CŌM

`f105r.18`  sheoy.oleedy.daiin.al,chedy.okeeey.chdaiin.otedy.cheoty.oteedy.oteey.chdy
→ PAROM  OLRRNM  NUII?  ULSARNM  OŌRRRM  SANUII?  OTRNM  SAROTM  OTRRNM  OTRRM  SANM

`f105r.19`  dsechey.oteol.daiindy.saiin.chedy.laiin.okeeody.okeeyteedy.odaiin.aiir,al
→ NPRSARM  OTROL  NUII?NM  PUII?  SARNM  LUII?  OŌRRONM  OŌRRMTRRNM  ONUII?  UIIRUL

`f105r.20`  s,aiin.chey,teol.ykair.paiir.olkaiin.olfaiin.odar.al.airody.al.teedar.dam
→ PUII?  SARMTROL  MŌUIR  MUIIR  OLŌUII?  OL?UII?  ONUR  UL  UIRONM  UL  TRRNUR  NUS

`f105r.21`  ycheo.lkedy.qoeey.qokedy.qokedal.saiin.otol.shody.chedy.okaiin.chekaim
→ MSARO  LŌRNM  CORRM  COŌRNM  COŌRNUL  PUII?  OTOL  PAONM  SARNM  OŌUII?  SARŌUIS

`f105r.22`  olkchokeedy.ypair.opaiin.opail.oteodl.eeol.keey.r,aiin.ylkaiin.am.ols
→ OLŌSAOŌRRNM  MMUIR  OMUII?  OMUIL  OTRONL  RROL  ŌRRM  RUII?  MLŌUII?  US  OLP

`f105r.23`  dchees.opchey.aeeod[ch:ee]y.chefchedy
→ NSARRP  OMSARM  URRONSAM  SAR?SARNM

`f105r.24`  pcheor.ain.ckheey.okeeey.paiin.ar,aiiin.chpaiikey.sheo.pcheey.dal.daiin.dam
→ MSAROR  UI?  SŌARRM  OŌRRRM  MUII?  URUIII?  SAMUIIŌRM  PARO  MSARRM  NUL  NUII?  NUS

`f105r.25`  deeedy.cheodkedy.chedy.decthdy.daiiils.airols
→ NRRRNM  SARONŌRNM  SARNM  NRSTANM  NUIIILP  UIROLP

`f105r.26`  pdal.sheey.yqopchy.airal.sheey.fchdy.qopchdy.raiir.oky.chdedy.qodeedy.qokedy
→ MNUL  PARRM  MCOMSAM  UIRUL  PARRM  ?SANM  COMSANM  RUIIR  OŌM  SANRNM  CONRRNM  COŌRNM

`f105r.27`  dair.cho,al.r.lal.cheesy.cphedy
→ NUIR  SAOUL  R  LUL  SARRPM  SMARNM

`f105r.28`  pchsed.sheefy.opchey.qoteedy.qoeey.qokeedy.laiiin.odaiin.aiir.opair.kechedy
→ MSAPRN  PARR?M  OMSARM  COTRRNM  CORRM  COŌRRNM  LUIII?  ONUII?  UIIR  OMUIR  ŌRSARNM

`f105r.29`  oees.olkeedy.qockhy.r,aiin.chol.okair.oteedy.qopchedy.odaiin.ypchedy.ytam
→ ORRP  OLŌRRNM  COSŌAM  RUII?  SAOL  OŌUIR  OTRRNM  COMSARNM  ONUII?  MMSARNM  MTUS

`f105r.30`  oleedar.aiildy.dar.oiin.y,teey.tair.cheody.qokolky.cheolkary
→ OLRRNUR  UIILNM  NUR  OII?  MTRRM  TUIR  SARONM  COŌOLŌM  SAROLŌURM

`f105r.31`  kodeey.lchl.shx.ar.aii[j:d]y.cpheesy.okal.lkedy.lkar.chedy,qokaiin.or.fchoky
→ ŌONRRM  LSAL  PA?  UR  UII?M  SMARRPM  OŌUL  LŌRNM  LŌUR  SARNMCOŌUII?  OR  ?SAOŌM

`f105r.32`  ycheochy.lkeol.daiin.qkair.olkchey.dar.qopchdy.dair.otar.ar.ajam
→ MSAROSAM  LŌROL  NUII?  CŌUIR  OLŌSARM  NUR  COMSANM  NUIR  OTUR  UR  U?US

`f105r.33`  okeeodair.oteey.lkeey.teeolteedy.ot,okal.or,aiiin.qokaiin.ar.airod
→ OŌRRONUIR  OTRRM  LŌRRM  TRROLTRRNM  OTOŌUL  ORUIII?  COŌUII?  UR  UIRON

`f105r.34`  dor.ail.cheky.kar.odaiin.ykl.al.oees.al.ar.alkam
→ NOR  UIL  SARŌM  ŌUR  ONUII?  MŌL  UL  ORRP  UL  UR  ULŌUS

`f105r.35`  ypchedy.okaiir.opcheedy.qokair.dar.kal.otar.ol.qokal.kor.orolpchey.ofory
→ MMSARNM  OŌUIIR  OMSARRNM  COŌUIR  NUR  ŌUL  OTUR  OL  COŌUL  ŌOR  OROLMSARM  O?ORM

`f105r.36`  dyteey.otedaiin.otar.ol.chedy.ted.qotar.oteodar.otam.ytedy.otaiin
→ NMTRRM  OTRNUII?  OTUR  OL  SARNM  TRN  COTUR  OTRONUR  OTUS  MTRNM  OTUII?

`f105r.37`  otoiir.chedaiin.otair.otaly
→ OTOIIR  SARNUII?  OTUIR  OTULM

### f105v  ·  stars

`f105v.1`  polairy.oair.olpcheey.ykaiin.olpchedy.opchedaiin.dairody.ypcheddy.sairy
→ MOLUIRM  OUIR  OLMSARRM  MŌUII?  OLMSARNM  OMSARNUII?  NUIRONM  MMSARNNM  PUIRM

`f105v.2`  ysheod.ykeeedy.keshed.qodaiin.oteodair.or.chkar.otaiin.chpor,or.otchy.otor
→ MPARON  MŌRRRNM  ŌRPARN  CONUII?  OTRONUIR  OR  SAŌUR  OTUII?  SAMOROR  OTSAM  OTOR

`f105v.3`  dshedy.qoedaiin.ytoiin.okair.qotol.dol.okoldy.qokedy.opched.oteedy.qotaiin
→ NPARNM  CORNUII?  MTOII?  OŌUIR  COTOL  NOL  OŌOLNM  COŌRNM  OMSARN  OTRRNM  COTUII?

`f105v.4`  olkeeol.orchsey.qokeedy.chdor.olar.ol.keeol.chedaiin
→ OLŌRROL  ORSAPRM  COŌRRNM  SANOR  OLUR  OL  ŌRROL  SARNUII?

`f105v.5`  pchedal.qopchdy.daiin.chedy.daiin.okaildy.opchedaiin.[o:y]pcheo.olkeedy.sairom
→ MSARNUL  COMSANM  NUII?  SARNM  NUII?  OŌUILNM  OMSARNUII?  OMSARO  OLŌRRNM  PUIROS

`f105v.6`  dcheo.fcheeody.ckheey.dar.aiin.al.dar.ar.daiiidy.otedy.oteody.ykaiin.[g:m]
→ NSARO  ?SARRONM  SŌARRM  NUR  UII?  UL  NUR  UR  NUIIINM  OTRNM  OTRONM  MŌUII?  ?

`f105v.7`  ycheeo.lkaiin.otair.ol.olkaiin.okairody.lchedr
→ MSARRO  LŌUII?  OTUIR  OL  OLŌUII?  OŌUIRONM  LSARNR

`f105v.8`  fodal.kedar.olpchesd.araiin.ksheeol.opchedy.pchedy.opcheddl.pchdar.air.odar
→ ?ONUL  ŌRNUR  OLMSARPN  URUII?  ŌPARROL  OMSARNM  MSARNM  OMSARNNL  MSANUR  UIR  ONUR

`f105v.9`  lcheey.qoeees.y.daiin.okairy.otchedy.ockhedy.otchey.daiin.or.r.ail.[l:?],okam
→ LSARRM  CORRRP  M  NUII?  OŌUIRM  OTSARNM  OSŌARNM  OTSARM  NUII?  OR  R  UIL  LOŌUS

`f105v.10`  ykeey.ky.che.oiiin.dal,kaiin.okairo.l,kair.chedy.s,odar.air.al.oral.odam
→ MŌRRM  ŌM  SAR  OIII?  NULŌUII?  OŌUIRO  LŌUIR  SARNM  PONUR  UIR  UL  ORUL  ONUS

`f105v.11`  roees.aiiin.ol.okaiin.os.aiin.chckhodu.qoteedy.ckhddl.aiir.ypar.kaii{i'h}dy
→ RORRP  UIII?  OL  OŌUII?  OP  UII?  SASŌAON?  COTRRNM  SŌANNL  UIIR  MMUR  ŌUIIIANM

`f105v.12`  ysheedy.aiin.okeol.ykedor.ar.ar.alkair.otar.otaiin.otal.tair.am
→ MPARRNM  UII?  OŌROL  MŌRNOR  UR  UR  ULŌUIR  OTUR  OTUII?  OTUL  TUIR  US

`f105v.13`  saiin.opchedy.qokchdy.otar.al.kair.okees.lkchdal
→ PUII?  OMSARNM  COŌSANM  OTUR  UL  ŌUIR  OŌRRP  LŌSANUL

`f105v.14`  pchedaiin.chckhdy.qokaiir.olpchedy.olord.aiiin.[t:k]ail.odar.kard.chtchy
→ MSARNUII?  SASŌANM  COŌUIIR  OLMSARNM  OLORN  UIII?  TUIL  ONUR  ŌURN  SATSAM

`f105v.15`  ycheey.kar.ykeey.otaiin.ot,al,dar.chdor.kalchedy.opchdy.daiin.oraiin.r
→ MSARRM  ŌUR  MŌRRM  OTUII?  OTULNUR  SANOR  ŌULSARNM  OMSANM  NUII?  ORUII?  R

`f105v.16`  daiin.cheey.dal.chl.okair.aiin.cpheor.aiin.okal.chodaiin.otaiin.opaiim
→ NUII?  SARRM  NUL  SAL  OŌUIR  UII?  SMAROR  UII?  OŌUL  SAONUII?  OTUII?  OMUIIS

`f105v.17`  olr.aiin.chey.l,raiin.lkl.dl.lklor.diiin,olkaiin
→ OLR  UII?  SARM  LRUII?  LŌL  NL  LŌLOR  NIII?OLŌUII?

`f105v.18`  pchor.chedaiin.okaiin.cholkal.qolkaiin.oltchdy.qopchsd.opair,orair.karaim
→ MSAOR  SARNUII?  OŌUII?  SAOLŌUL  COLŌUII?  OLTSANM  COMSAPN  OMUIRORUIR  ŌURUIS

`f105v.19`  ycheey.aiin.otleey.lkaiir.cheeo.taiin.okeed.ail.kchey.rokaix.am
→ MSARRM  UII?  OTLRRM  LŌUIIR  SARRO  TUII?  OŌRRN  UIL  ŌSARM  ROŌUI?  US

`f105v.20`  porair.chopchdy.chedain.otair.otchod.aiin.alol.cheo.ypchedy.kairodl,lpaim
→ MORUIR  SAOMSANM  SARNUI?  OTUIR  OTSAON  UII?  ULOL  SARO  MMSARNM  ŌUIRONLLMUIS

`f105v.21`  ykeeo.daiim.sheey.qokaiin.cheot,daiin.qoek,eeykeody.qopaiin.or.aiikam
→ MŌRRO  NUIIS  PARRM  COŌUII?  SAROTNUII?  CORŌRRMŌRONM  COMUII?  OR  UIIŌUS

`f105v.22`  daiin.cheodaiin.chedal.air.okaiin.cheey
→ NUII?  SARONUII?  SARNUL  UIR  OŌUII?  SARRM

`f105v.23`  tcholkaiin.odal,kl.chees.aiiin.shees.qopdaiin.chod[s:r].alkeey.paradam
→ TSAOLŌUII?  ONULŌL  SARRP  UIII?  PARRP  COMNUII?  SAONP  ULŌRRM  MURUNUS

`f105v.24`  alcheey.okaiin.otar.oto,daiin.ckheol.lkol.fchedypaiin
→ ULSARRM  OŌUII?  OTUR  OTONUII?  SŌAROL  LŌOL  ?SARNMMUII?

`f105v.25`  kchdaldy.alfo,lfcheedy.ofoiir.opchey.fchedy.qotor.oeeeodr.qopar.{aifhh}y.dl
→ ŌSANULNM  UL?OL?SARRNM  O?OIIR  OMSARM  ?SARNM  COTOR  ORRRONR  COMUR  UI?AAM  NL

`f105v.26`  lkl.sheeodees.otaiin.otar.otal.or.aiin.chedor.alkaiin.chs.alkaiin.ry
→ LŌL  PARRONRRP  OTUII?  OTUR  OTUL  OR  UII?  SARNOR  ULŌUII?  SAP  ULŌUII?  RM

`f105v.27`  sheoe.arxor.eesy.qopcheo,ain.orkchdy.daiin.oteedy.ko,lkair.otaiilody
→ PAROR  UR?OR  RRPM  COMSAROUI?  ORŌSANM  NUII?  OTRRNM  ŌOLŌUIR  OTUIILONM

`f105v.28`  oeoar.ar.al.odor.aiil.otaiin
→ OROUR  UR  UL  ONOR  UIIL  OTUII?

`f105v.29`  tdol.tor,oaldar.aiir.okokeedy.karody,qoeedy.sho.qopchedy.daiin.opairam
→ TNOL  TOROULNUR  UIIR  OŌOŌRRNM  ŌURONMCORRNM  PAO  COMSARNM  NUII?  OMUIRUS

`f105v.30`  dchedy.cheey.qokor.otaiin.otair.otair.okeedy.kaiin.aiin.s.aiin,sy
→ NSARNM  SARRM  COŌOR  OTUII?  OTUIR  OTUIR  OŌRRNM  ŌUII?  UII?  P  UII?PM

`f105v.31`  ychtaiir.aiichy.dol.aiin.otaiin.aiidy.okchd.otar.daiin
→ MSATUIIR  UIISAM  NOL  UII?  OTUII?  UIINM  OŌSAN  OTUR  NUII?

`f105v.32`  poar.keeodaiin.qoair.ar.a{iphh}ey.qoeedeody.qokaiin.qotedair.apo,rairapy
→ MOUR  ŌRRONUII?  COUIR  UR  UIMAARM  CORRNRONM  COŌUII?  COTRNUIR  UMORUIRUMM

`f105v.33`  lsheody.tair.oteey.oteeo.o.l.otaiin.okeey.qokaiin.or.aiir.al.dar
→ LPARONM  TUIR  OTRRM  OTRRO  O  L  OTUII?  OŌRRM  COŌUII?  OR  UIIR  UL  NUR

`f105v.34`  sheeo.daiin.chsd.qokeeey.dair.okaiin.otaiin.chedaiin.olkal.lkldain
→ PARRO  NUII?  SAPN  COŌRRRM  NUIR  OŌUII?  OTUII?  SARNUII?  OLŌUL  LŌLNUI?

`f105v.35`  doee.okcheeo.l,taiin.otcheedy.chor.aiin.odaiin.chedy.otaiin.al.kaishd
→ NORR  OŌSARRO  LTUII?  OTSARRNM  SAOR  UII?  ONUII?  SARNM  OTUII?  UL  ŌUIPAN

`f105v.36`  laiin.sheod.okeeody.qoaiin.ytaiin.otair.chdal,dy,daim.chdaiin.o{ckhh}y
→ LUII?  PARON  OŌRRONM  COUII?  MTUII?  OTUIR  SANULNMNUIS  SANUII?  OSŌAAM

`f105v.37`  yshey.ckhy.sheo.qoeeo.lkaiin.chs,okol.tchdy.sheeey.okaiin.ar.aildy
→ MPARM  SŌAM  PARO  CORRO  LŌUII?  SAPOŌOL  TSANM  PARRRM  OŌUII?  UR  UILNM

`f105v.38`  cheody.oaiir.ain.okshey
→ SARONM  OUIIR  UI?  OŌPARM

### f106r  ·  stars

`f106r.1`  pshdar.shoefy.yteedy.sh[a:o]l.korchy.sheky.otchedy.okshed.qotedy.qoted.yteeody
→ MPANUR  PAOR?M  MTRRNM  PAUL  ŌORSAM  PARŌM  OTSARNM  OŌPARN  COTRNM  COTRN  MTRRONM

`f106r.2`  shedchy.ytchedy.chees.otshes.okcho.chdy.qokeedy.ched.chedy.chedy.qotar.rod
→ PARNSAM  MTSARNM  SARRP  OTPARP  OŌSAO  SANM  COŌRRNM  SARN  SARNM  SARNM  COTUR  RON

`f106r.3`  dshes.lchedy.lkchedy.ytchdy.or,cheos
→ NPARP  LSARNM  LŌSARNM  MTSANM  ORSAROP

`f106r.4`  pcheodair.okchedy.olkeeedy.or.arojy.qopchdy.sholfchdy.cheeky.lchedy.qokam
→ MSARONUIR  OŌSARNM  OLŌRRRNM  OR  URO?M  COMSANM  PAOL?SANM  SARRŌM  LSARNM  COŌUS

`f106r.5`  ysheor.aiin.char.okaiin.qokeechy.checkhy.qokeod.ar.qokeo.lkeo.lchor[o:a]m
→ MPAROR  UII?  SAUR  OŌUII?  COŌRRSAM  SARSŌAM  COŌRON  UR  COŌRO  LŌRO  LSAOROS

`f106r.6`  shor.sheor.orkchsd.otair,or.qokeeo.raiin.qokeeolchedy.olchedy.qokeol.qoky
→ PAOR  PAROR  ORŌSAPN  OTUIROR  COŌRRO  RUII?  COŌRROLSARNM  OLSARNM  COŌROL  COŌM

`f106r.7`  olched.qoiin.ychedy.qokam.sheol.qokor.cheees
→ OLSARN  COII?  MSARNM  COŌUS  PAROL  COŌOR  SARRRP

`f106r.8`  porarchy.orar.ol,kaiin.shedy.oteedy.qotor.qoteedo.qoteedy.dair.ok[ch:ee]daim
→ MORURSAM  ORUR  OLŌUII?  PARNM  OTRRNM  COTOR  COTRRNO  COTRRNM  NUIR  OŌSANUIS

`f106r.9`  ychor.chol.qokain.chocphol.lchedy.qocheo.qokar
→ MSAOR  SAOL  COŌUI?  SAOSMAOL  LSARNM  COSARO  COŌUR

`f106r.10`  pshoair.lkeeshedy.qokain.cheoly.qokedy.lchedy.qokedy.otedy.qotoky
→ MPAOUIR  LŌRRPARNM  COŌUI?  SAROLM  COŌRNM  LSARNM  COŌRNM  OTRNM  COTOŌM

`f106r.11`  sar.aiin.cheol.aiin.cheokey.raiin.chokar.cholky.okeees.aiin.okeey.lchg
→ PUR  UII?  SAROL  UII?  SAROŌRM  RUII?  SAOŌUR  SAOLŌM  OŌRRRP  UII?  OŌRRM  LSA?

`f106r.12`  okeey.lcheedy.olkeey.qokeeo.dchedy
→ OŌRRM  LSARRNM  OLŌRRM  COŌRRO  NSARNM

`f106r.13`  pcheol.sheokaiin.otey.qokeeor.sheo,aiin.otchey.pcheo,ror,aiin.daiinopal
→ MSAROL  PAROŌUII?  OTRM  COŌRROR  PAROUII?  OTSARM  MSARORORUII?  NUII?OMUL

`f106r.14`  ychol.okaiin.olcheey.dolchedy.otair.otal.chedy.okeor
→ MSAOL  OŌUII?  OLSARRM  NOLSARNM  OTUIR  OTUL  SARNM  OŌROR

`f106r.15`  podaroar.oteeo,lchor.shol.tchedy.chotar.opchedy.opches,aiin.okchdam
→ MONUROUR  OTRROLSAOR  PAOL  TSARNM  SAOTUR  OMSARNM  OMSARPUII?  OŌSANUS

`f106r.16`  soin.oin.okain.aiin.arol.ocheedy.lkeeeody.daiin.chedar.okol.otar.chdam
→ POI?  OI?  OŌUI?  UII?  UROL  OSARRNM  LŌRRRONM  NUII?  SARNUR  OŌOL  OTUR  SANUS

`f106r.17`  yochor.lshedy.qockhey.qokedain.or.aiinchodar
→ MOSAOR  LPARNM  COSŌARM  COŌRNUI?  OR  UII?SAONUR

`f106r.18`  kshed.dsheol.qokeedy.otol.okeedy.lkeedar.sheopchy.qopchy.qotolchy.qoty.chdy
→ ŌPARN  NPAROL  COŌRRNM  OTOL  OŌRRNM  LŌRRNUR  PAROMSAM  COMSAM  COTOLSAM  COTM  SANM

`f106r.19`  otchedy.qokeey.shosaiin.qokaiin.okain.cholkeeey.ltal.olcheey.qotchoraiin,y
→ OTSARNM  COŌRRM  PAOPUII?  COŌUII?  OŌUI?  SAOLŌRRRM  LTUL  OLSARRM  COTSAORUII?M

`f106r.20`  ytaiin.cheey.qokaiin.shaiin.qokeedy.sail,chedy.cheodal.qochedy.qokaiin
→ MTUII?  SARRM  COŌUII?  PAUII?  COŌRRNM  PUILSARNM  SARONUL  COSARNM  COŌUII?

`f106r.21`  olkeedy.qokchedy.cheo.lkeedy.chearaiin.okain
→ OLŌRRNM  COŌSARNM  SARO  LŌRRNM  SARURUII?  OŌUI?

`f106r.22`  tshodair.olkeees.odain.qokeedy.opchor.aror,pcheeody.daiir,opchedy.opchody
→ TPAONUIR  OLŌRRRP  ONUI?  COŌRRNM  OMSAOR  URORMSARRONM  NUIIROMSARNM  OMSAONM

`f106r.23`  ychedy.qckhedy.dair,al.qokedy.shecphy.qokchy.otedy.dar.aror
→ MSARNM  CSŌARNM  NUIRUL  COŌRNM  PARSMAM  COŌSAM  OTRNM  NUR  UROR

`f106r.24`  podshedy.qokchedy.lkechor.otchodar.cho.lky.chedar.otaiin.chkchedaram
→ MONPARNM  COŌSARNM  LŌRSAOR  OTSAONUR  SAO  LŌM  SARNUR  OTUII?  SAŌSARNURUS

`f106r.25`  soraiin.cheeo.lo.lchey.qokaiin.shedy.okain.shear.qokain.chees.ykarain
→ PORUII?  SARRO  LO  LSARM  COŌUII?  PARNM  OŌUI?  PARUR  COŌUI?  SARRP  MŌURUI?

`f106r.26`  ycheeo.lkeey
→ MSARRO  LŌRRM

`f106r.27`  tcheoky.lkshedy.qokaiin.lky.raiin.chy.rody.chlar.cheeorfor.cheoly
→ TSAROŌM  LŌPARNM  COŌUII?  LŌM  RUII?  SAM  RONM  SALUR  SARROR?OR  SAROLM

`f106r.28`  okaiin.ol.lcho.rcheo.raiin.qokaiin.chey.chokaiin.chear.ar.ol.raralchl
→ OŌUII?  OL  LSAO  RSARO  RUII?  COŌUII?  SARM  SAOŌUII?  SARUR  UR  OL  RURULSAL

`f106r.29`  saiin.chal.chlal.okal.ykalaiin.okain.qokain.ar.okaiin.char.aiiny
→ PUII?  SAUL  SALUL  OŌUL  MŌULUII?  OŌUI?  COŌUI?  UR  OŌUII?  SAUR  UII?M

`f106r.30`  ycheeo.lkaiin.cho.ror.sheo,l,kain.shor.sar.aiiry.sheo,al.kairam
→ MSARRO  LŌUII?  SAO  ROR  PAROLŌUI?  PAOR  PUR  UIIRM  PAROUL  ŌUIRUS

`f106r.31`  ysha[r:ir].chkar.aiiiky.ral.cheol.oraiin
→ MPAUR  SAŌUR  UIIIŌM  RUL  SAROL  ORUII?

`f106r.32`  poral.sho,keeody.qokain.chckhy.olteeedy.qopche[r:s].al.karchy.qotedary
→ MORUL  PAOŌRRONM  COŌUI?  SASŌAM  OLTRRRNM  COMSARR  UL  ŌURSAM  COTRNURM

`f106r.33`  ycheol.chokaiin.sheody.chody.qokaiin.ar.akair,aiir.okaly
→ MSAROL  SAOŌUII?  PARONM  SAONM  COŌUII?  UR  UŌUIRUIIR  OŌULM

`f106r.34`  tcheorsho.lkshey.lpcheo,ro,lpchey.oporaiin.chpchy.qopcheody.qotarain
→ TSARORPAO  LŌPARM  LMSAROROLMSARM  OMORUII?  SAMSAM  COMSARONM  COTURUI?

`f106r.35`  okaiin.choky.lkar.chdy.lchedy
→ OŌUII?  SAOŌM  LŌUR  SANM  LSARNM

`f106r.36`  psheodalo.dar.sheodal.qotedy.qotes,aiin.okalal.shdy.otaiin.shedy
→ MPARONULO  NUR  PARONUL  COTRNM  COTRPUII?  OŌULUL  PANM  OTUII?  PARNM

`f106r.37`  tchodaiin.tcheo,dlchy
→ TSAONUII?  TSARONLSAM

`f106r.38`  pshodaiin.opchy.sh,o,teeody.shotchey.yteey.sholfaiin.opchdy.lchdy.dol
→ MPAONUII?  OMSAM  PAOTRRONM  PAOTSARM  MTRRM  PAOL?UII?  OMSANM  LSANM  NOL

`f106r.39`  ycheool.cheeey.ol,aiin.cheody.laiiin.chekol,cheey.okchar.aiin,aloal
→ MSAROOL  SARRRM  OLUII?  SARONM  LUIII?  SARŌOLSARRM  OŌSAUR  UII?ULOUL

`f106r.40`  shaiin.ar.aiin.sheey.lkaiin.sheedy.shedy.qokal.chey.okaiin.chdaldy
→ PAUII?  UR  UII?  PARRM  LŌUII?  PARRNM  PARNM  COŌUL  SARM  OŌUII?  SANULNM

`f106r.41`  dair,alsheod.shedy.cholchedy.cheol.shory
→ NUIRULPARON  PARNM  SAOLSARNM  SAROL  PAORM

`f106r.42`  pcheodar.shol,ka[in:ir].ok{e'e}chedy.qoteey.shotchy.qoty,lpaiin.shedy.lar
→ MSARONUR  PAOLŌUI?  OŌRRSARNM  COTRRM  PAOTSAM  COTMLMUII?  PARNM  LUR

`f106r.43`  daiiral.sheol.daiin.otedy.qokain.okar.cheor.al.taiin.chekal.otaras
→ NUIIRUL  PAROL  NUII?  OTRNM  COŌUI?  OŌUR  SAROR  UL  TUII?  SARŌUL  OTURUP

`f106r.44`  dshedy.qoteey.otaiin.chy.chealol.chlchd,aiin.oty.otair.otaiikam
→ NPARNM  COTRRM  OTUII?  SAM  SARULOL  SALSANUII?  OTM  OTUIR  OTUIIŌUS

`f106r.45`  y,sheedal.okain.okain.otar.kaiin.chdalkair.olkai[?:r].al,keedy.okal
→ MPARRNUL  OŌUI?  OŌUI?  OTUR  ŌUII?  SANULŌUIR  OLŌUI  ULŌRRNM  OŌUL

`f106r.46`  sotchdaiin.shodaiin.otedy.qokeedy.qokaiin.ykar.qokain.cheedy.lol
→ POTSANUII?  PAONUII?  OTRNM  COŌRRNM  COŌUII?  MŌUR  COŌUI?  SARRNM  LOL

`f106r.47`  ycheoar.okain.qokain.char,oky.cheokam
→ MSAROUR  OŌUI?  COŌUI?  SAUROŌM  SAROŌUS

### f106v  ·  stars

`f106v.1`  fsheda.looin.opaiiral.oteodaiin.chopchy.otair.kar.alalor.aiin.aly.kar
→ ?PARNU  LOOI?  OMUIIRUL  OTRONUII?  SAOMSAM  OTUIR  ŌUR  ULULOR  UII?  ULM  ŌUR

`f106v.2`  daiin.al.sheeodar.y,chtain.char,otar.qokar.o[t:k]ar.shed.sheo,keorain,amchy
→ NUII?  UL  PARRONUR  MSATUI?  SAUROTUR  COŌUR  OTUR  PARN  PAROŌRORUI?USSAM

`f106v.3`  yshedaiin.shckhy.cheokchy.sar.al.cho,lchedy.ytain.otar.al.chdy.daly,lody
→ MPARNUII?  PASŌAM  SAROŌSAM  PUR  UL  SAOLSARNM  MTUI?  OTUR  UL  SANM  NULMLONM

`f106v.4`  ycheoto.lsheo,aiin.chcthy.okain.chdal.chdam.charam
→ MSAROTO  LPAROUII?  SASTAM  OŌUI?  SANUL  SANUS  SAURUS

`f106v.5`  tshoar.oeey.qokain.shypchedy.opched.qopchedy.otaiin.chepar,aiin,octhy.dair.ry
→ TPAOUR  ORRM  COŌUI?  PAMMSARNM  OMSARN  COMSARNM  OTUII?  SARMURUII?OSTAM  NUIR  RM

`f106v.6`  daiin.shody.kchedy.sheody.olkaiin.shkar.chody.talshdy.qokain.kararo
→ NUII?  PAONM  ŌSARNM  PARONM  OLŌUII?  PAŌUR  SAONM  TULPANM  COŌUI?  ŌURURO

`f106v.7`  soy,she[a:o]lsho.dy.chain.shol.kain.shokaiin.qotaiin.chodar.ail,dal,dar.loror
→ POMPARULPAO  NM  SAUI?  PAOL  ŌUI?  PAOŌUII?  COTUII?  SAONUR  UILNULNUR  LOROR

`f106v.8`  oraiin.cheo,rol.aiin.otaiin
→ ORUII?  SAROROL  UII?  OTUII?

`f106v.9`  tshodaiin.sholkair.orainkar,aiin.shtchy.qopchdy.qopchy.lolkair.shear,am
→ TPAONUII?  PAOLŌUIR  ORUI?ŌURUII?  PATSAM  COMSANM  COMSAM  LOLŌUIR  PARURUS

`f106v.10`  ysheody.cheol.oteey.qodaiin.ytain.ychdy.oltydy
→ MPARONM  SAROL  OTRRM  CONUII?  MTUI?  MSANM  OLTMNM

`f106v.11`  tchdys,arshedy.oteeody,kshedy.qotchdy.qotar.shedy.qotedy.opchy.kaiin,sham
→ TSANMPURPARNM  OTRRONMŌPARNM  COTSANM  COTUR  PARNM  COTRNM  OMSAM  ŌUII?PAUS

`f106v.12`  ycheey.qoeeda.chodain.otalchdy.qokaiin.chokaiin.chody.qokal.otal.otam
→ MSARRM  CORRNU  SAONUI?  OTULSANM  COŌUII?  SAOŌUII?  SAONM  COŌUL  OTUL  OTUS

`f106v.13`  olkeealkchedy.qoeeey.ral.ches.al.ytar.shsy.lchey.ykaiin.shy.lkam
→ OLŌRRULŌSARNM  CORRRM  RUL  SARP  UL  MTUR  PAPM  LSARM  MŌUII?  PAM  LŌUS

`f106v.14`  schedy.raiin.char.arshey.chedy.aiiin.alkam
→ PSARNM  RUII?  SAUR  URPARM  SARNM  UIII?  ULŌUS

`f106v.15`  kcheo[a:y]kar.shedy.qofchdy.otshedy.qokchdy.qotshdy.qokchdy.kair.alody
→ ŌSAROUŌUR  PARNM  CO?SANM  OTPARNM  COŌSANM  COTPANM  COŌSANM  ŌUIR  ULONM

`f106v.16`  sarar.okear.aiin.chotal.shody.qotchdy.qotar.shedy.chodal.chedy.qotam
→ PURUR  OŌRUR  UII?  SAOTUL  PAONM  COTSANM  COTUR  PARNM  SAONUL  SARNM  COTUS

`f106v.17`  salar.she[o:a]dar.okain.qodaiin.chodal
→ PULUR  PARONUR  OŌUI?  CONUII?  SAONUL

`f106v.18`  pshodalos.qokshdy.qokshy.opchdy.qokshd.ar.shdar.oeedy.qotaly.dairy
→ MPAONULOP  COŌPANM  COŌPAM  OMSANM  COŌPAN  UR  PANUR  ORRNM  COTULM  NUIRM

`f106v.19`  darshy.otaiin.otal.chedy.r,ain.olaiin.otaiin.sain
→ NURPAM  OTUII?  OTUL  SARNM  RUI?  OLUII?  OTUII?  PUI?

`f106v.20`  polchs.lkaiir.shokar.choefy.shor.qokor.sheeo.kol{ch'}es.okcharain
→ MOLSAP  LŌUIIR  PAOŌUR  SAOR?M  PAOR  COŌOR  PARRO  ŌOLSARP  OŌSAURUI?

`f106v.21`  ycheo,lkaiin.cheo,lchdaiin.osaiin.okal.sheedy.qokchedy
→ MSAROLŌUII?  SAROLSANUII?  OPUII?  OŌUL  PARRNM  COŌSARNM

`f106v.22`  tshod.qokchy.qokaiin.okshy.qokar.shedy.shey.qopshedy.shdykairylam
→ TPAON  COŌSAM  COŌUII?  OŌPAM  COŌUR  PARNM  PARM  COMPARNM  PANMŌUIRMLUS

`f106v.23`  ol,kalol.shar.chor.okal.chdy.chol.chedy.qotaiin.or,aiin.okeedy.qokain
→ OLŌULOL  PAUR  SAOR  OŌUL  SANM  SAOL  SARNM  COTUII?  ORUII?  OŌRRNM  COŌUI?

`f106v.24`  soraiin.solshedy.qokchdy.qokol.chdaiin.chdal.air.odl.charain.oka{ifh}y
→ PORUII?  POLPARNM  COŌSANM  COŌOL  SANUII?  SANUL  UIR  ONL  SAURUI?  OŌUI?AM

`f106v.25`  sar.sheol.chol.shar.chol.okarol
→ PUR  PAROL  SAOL  PAUR  SAOL  OŌUROL

`f106v.26`  tar.air.kshdain.okal.chdy.lchedy.kshar.chopchy.otches.aral.opchdy
→ TUR  UIR  ŌPANUI?  OŌUL  SANM  LSARNM  ŌPAUR  SAOMSAM  OTSARP  URUL  OMSANM

`f106v.27`  olcheo.odaiin.sheotal.shoor.qokeey.oarar
→ OLSARO  ONUII?  PAROTUL  PAOOR  COŌRRM  OURUR

`f106v.28`  psheody.olkeedy.qokor.sheos.choty.qotaiin.oteody.otaiin.qokar.otydy
→ MPARONM  OLŌRRNM  COŌOR  PAROP  SAOTM  COTUII?  OTRONM  OTUII?  COŌUR  OTMNM

`f106v.29`  ycheey.olchey.chedy.qotaiin.cheos.otaiin.otain.chotar.olos.aiin.cheog
→ MSARRM  OLSARM  SARNM  COTUII?  SAROP  OTUII?  OTUI?  SAOTUR  OLOP  UII?  SARO?

`f106v.30`  otaiin.okochey.qody.oeesysarx,[o:y]keey.oteedy.ksheody.qokeedy.qotokody
→ OTUII?  OŌOSARM  CONM  ORRPMPUR?OŌRRM  OTRRNM  ŌPARONM  COŌRRNM  COTOŌONM

`f106v.31`  sheeyko.shody.chosaiin.olcham
→ PARRMŌO  PAONM  SAOPUII?  OLSAUS

`f106v.32`  polos.shdair.sheky.keedy.qoeedy.qofchedy.sair.al.pchedy.ypodaiin.saram
→ MOLOP  PANUIR  PARŌM  ŌRRNM  CORRNM  CO?SARNM  PUIR  UL  MSARNM  MMONUII?  PURUS

`f106v.33`  choaiin.ody.qotar.chey.ol,aiin.chey,dychy
→ SAOUII?  ONM  COTUR  SARM  OLUII?  SARMNMSAM

`f106v.34`  pchodaiin.kcheeor,al.ky.shcthy.otos.ar.odal.pcheody.qotaiin.otor.alodam
→ MSAONUII?  ŌSARRORUL  ŌM  PASTAM  OTOP  UR  ONUL  MSARONM  COTUII?  OTOR  ULONUS

`f106v.35`  shody.shockhy.qokeey.qokcho,l,kchedy.shdy.kchedy.chedy.qockhey.okaiin,al
→ PAONM  PAOSŌAM  COŌRRM  COŌSAOLŌSARNM  PANM  ŌSARNM  SARNM  COSŌARM  OŌUII?UL

`f106v.36`  sol.sheedy.qokaiin.cholkaiin
→ POL  PARRNM  COŌUII?  SAOLŌUII?

`f106v.37`  pyoaly.cheo,aiir.al.kcheodar.qodaiin.shcphoor.shedy.otedar.opol.fchedy.odr
→ MMOULM  SAROUIIR  UL  ŌSARONUR  CONUII?  PASMAOOR  PARNM  OTRNUR  OMOL  ?SARNM  ONR

`f106v.38`  okcheody.qokeey.otchey.qokeey.qokeedal.qotchkeey.qol.rody.raiin.oty
→ OŌSARONM  COŌRRM  OTSARM  COŌRRM  COŌRRNUL  COTSAŌRRM  COL  RONM  RUII?  OTM

`f106v.39`  qokaiin.chey,kar.oteol
→ COŌUII?  SARMŌUR  OTROL

`f106v.40`  ko.sheody.qody.ches.aiin.dair.air.opchedy.pchdy.kolchedy.tcheodar.podkor
→ ŌO  PARONM  CONM  SARP  UII?  NUIR  UIR  OMSARNM  MSANM  ŌOLSARNM  TSARONUR  MONŌOR

`f106v.41`  otedy.qoar.cheey.kaiin.qokeeody.okaiin.oteey.qoteedy.choty
→ OTRNM  COUR  SARRM  ŌUII?  COŌRRONM  OŌUII?  OTRRM  COTRRNM  SAOTM

`f106v.42`  py,chal.shedy.qoteedy.cheyky.okedaiin.otedy.odaiin.chdy.chy.keedy.lkey
→ MMSAUL  PARNM  COTRRNM  SARMŌM  OŌRNUII?  OTRNM  ONUII?  SANM  SAM  ŌRRNM  LŌRM

`f106v.43`  chedy.okeey.qokeedy.okeey.sheey.qokaiin.al,al,kalos.chedy.dkaiin.chcthy
→ SARNM  OŌRRM  COŌRRNM  OŌRRM  PARRM  COŌUII?  ULULŌULOP  SARNM  NŌUII?  SASTAM

`f106v.44`  cthey.chey.okal.chey.keeyrain.okeeo.otaiin.chedar.oteedy.otol.oty
→ STARM  SARM  OŌUL  SARM  ŌRRMRUI?  OŌRRO  OTUII?  SARNUR  OTRRNM  OTOL  OTM

`f106v.45`  ysair.okeey.cheodain.chey.tchar.oqotaiin.oty.rasal.oteey.sar.aildy
→ MPUIR  OŌRRM  SARONUI?  SARM  TSAUR  OCOTUII?  OTM  RUPUL  OTRRM  PUR  UILNM

`f106v.46`  ytar,okain.cheokaiin.chedy.okeeey.chkaiin.ol.oky.raiin.cheoar.chos
→ MTUROŌUI?  SAROŌUII?  SARNM  OŌRRRM  SAŌUII?  OL  OŌM  RUII?  SAROUR  SAOP

`f106v.47`  dcheoaiin.shky
→ NSAROUII?  PAŌM

### f107r  ·  stars

`f107r.1`  pchdlar.sheolor.ykeeol.qokchy.otor.okeesodar.tarair.oteey.otaiin.ytar
→ MSANLUR  PAROLOR  MŌRROL  COŌSAM  OTOR  OŌRRPONUR  TURUIR  OTRRM  OTUII?  MTUR

`f107r.2`  dchey.qoteos.aiin.shedy.oteed.qor.aiin.cheockhy.olkeey.qotain.chey.qeeey.lor
→ NSARM  COTROP  UII?  PARNM  OTRRN  COR  UII?  SAROSŌAM  OLŌRRM  COTUI?  SARM  CRRRM  LOR

`f107r.3`  olcheey.cheos.qokeeey.ycheedy.qotain.ykain.okeey.raiin
→ OLSARRM  SAROP  COŌRRRM  MSARRNM  COTUI?  MŌUI?  OŌRRM  RUII?

`f107r.4`  teeody.chedain.qoteey.qokar.deeoltedy.otar,ain.chady.otokcho.qoked.okchedy
→ TRRONM  SARNUI?  COTRRM  COŌUR  NRROLTRNM  OTURUI?  SAUNM  OTOŌSAO  COŌRN  OŌSARNM

`f107r.5`  olkchedy.tedy.oteeey.okchedy.qokeed.qokear.chedy.chokchedy.qokain.ar
→ OLŌSARNM  TRNM  OTRRRM  OŌSARNM  COŌRRN  COŌRUR  SARNM  SAOŌSARNM  COŌUI?  UR

`f107r.6`  okcheey.qokeedy.chotchedy.daiinar.oteey.lteey.chedaiin.ok[che:eee]y.otaiin.am
→ OŌSARRM  COŌRRNM  SAOTSARNM  NUII?UR  OTRRM  LTRRM  SARNUII?  OŌSARM  OTUII?  US

`f107r.7`  ytaiin.cheotchey.okaiin.chckhy.okeedy.otcheey
→ MTUII?  SAROTSARM  OŌUII?  SASŌAM  OŌRRNM  OTSARRM

`f107r.8`  torshor.sheeey.oteeol.qokeey.qokedy.lkaiin.qokaiin.qokar,al.okiroley
→ TORPAOR  PARRRM  OTRROL  COŌRRM  COŌRNM  LŌUII?  COŌUII?  COŌURUL  OŌIROLRM

`f107r.9`  okaiin.sheey.tcheol,kain.okeey.chedy.okeedy.chdykchedy.chey,kain,an
→ OŌUII?  PARRM  TSAROLŌUI?  OŌRRM  SARNM  OŌRRNM  SANMŌSARNM  SARMŌUI?U?

`f107r.10`  yteedy.qokeedy.okeol.lchedy.qokal.lor.sheal.cheedaiin.chey.sair.alo,m
→ MTRRNM  COŌRRNM  OŌROL  LSARNM  COŌUL  LOR  PARUL  SARRNUII?  SARM  PUIR  ULOS

`f107r.11`  cheeo.cheeol.qokaiin.ytain.y.keeol,l.oraiin.okaiin.okar.okaiin.otaram
→ SARRO  SARROL  COŌUII?  MTUI?  M  ŌRROLL  ORUII?  OŌUII?  OŌUR  OŌUII?  OTURUS

`f107r.12`  y,chol.chol.loraiir.aiinal
→ MSAOL  SAOL  LORUIIR  UII?UL

`f107r.13`  polchls,aiin.sheky.qokaiin.opchal.shedy.pshedaiin.otodal.shedy.otaral
→ MOLSALPUII?  PARŌM  COŌUII?  OMSAUL  PARNM  MPARNUII?  OTONUL  PARNM  OTURUL

`f107r.14`  cthedy.lshedy.cheolchear.or,alam.chtaiin.otarain.chey.qokaiin.otain
→ STARNM  LPARNM  SAROLSARUR  ORULUS  SATUII?  OTURUI?  SARM  COŌUII?  OTUI?

`f107r.15`  ychol.oiin.chey.qockhal.{ch'}al.otaraiin.sheky.okeeey.raiin.airal
→ MSAOL  OII?  SARM  COSŌAUL  SAUL  OTURUII?  PARŌM  OŌRRRM  RUII?  UIRUL

`f107r.16`  tolshoror.olkeedy.qotaiin.otalar.opcheol.qeeoy.shey.kair.otaiinam
→ TOLPAOROR  OLŌRRNM  COTUII?  OTULUR  OMSAROL  CRROM  PARM  ŌUIR  OTUII?US

`f107r.17`  sair.chey.losaiin.chey
→ PUIR  SARM  LOPUII?  SARM

`f107r.18`  poalosy.shey.tar,a{iph}y.f,arsheey.fol.rolchy.sheey.opolkaiin.ypaiinal
→ MOULOPM  PARM  TURUIMAM  ?URPARRM  ?OL  ROLSAM  PARRM  OMOLŌUII?  MMUII?UL

`f107r.19`  oaiin.ol.rar.sheey.ylar,aiin.cholal.dy.cheeody.okeeey.cheodaiin.aldy
→ OUII?  OL  RUR  PARRM  MLURUII?  SAOLUL  NM  SARRONM  OŌRRRM  SARONUII?  ULNM

`f107r.20`  tcheol.kcheedy
→ TSAROL  ŌSARRNM

`f107r.21`  taror.olal.okain.okaiin.qotal,shaiin.qokeol.lkaiin.okeeo.lkaiin,aiin
→ TUROR  OLUL  OŌUI?  OŌUII?  COTULPAUII?  COŌROL  LŌUII?  OŌRRO  LŌUII?UII?

`f107r.22`  yksheol.okaiiin.sho{ikh}y.daiin.qotalal.lshedy.qokal.r.aiiin.okair.lldy
→ MŌPAROL  OŌUIII?  PAOIŌAM  NUII?  COTULUL  LPARNM  COŌUL  R  UIII?  OŌUIR  LLNM

`f107r.23`  chodaiin.shar.chodaiin
→ SAONUII?  PAUR  SAONUII?

`f107r.24`  pal,alchky.okil,cheol,kair.lkain.qokeeo,kair.dar,aiinpchod,lkaiiin.olfy
→ MULULSAŌM  OŌILSAROLŌUIR  LŌUI?  COŌRROŌUIR  NURUII?MSAONLŌUIII?  OL?M

`f107r.25`  ycheain.chal.kal.chedy.qokaiin.chody.qokchdy.qokal.char.chdalal.om
→ MSARUI?  SAUL  ŌUL  SARNM  COŌUII?  SAONM  COŌSANM  COŌUL  SAUR  SANULUL  OS

`f107r.26`  ol,cheor.shey.cheey.olcheol.kaiin.otair.okal.cheody
→ OLSAROR  PARM  SARRM  OLSAROL  ŌUII?  OTUIR  OŌUL  SARONM

`f107r.27`  pydar.aiiro[d:?].qokiir.otiir.ofchedy.qofchedy.qofchol.chkaiin.chpaiin.orol
→ MMNUR  UIIRON  COŌIIR  OTIIR  O?SARNM  CO?SARNM  CO?SAOL  SAŌUII?  SAMUII?  OROL

`f107r.28`  kar.aiin.chl.cholor.sheees.aiin.cheey.otchy.lkaiin.ykaiin.ykalkal
→ ŌUR  UII?  SAL  SAOLOR  PARRRP  UII?  SARRM  OTSAM  LŌUII?  MŌUII?  MŌULŌUL

`f107r.29`  olkeeolkeeo.ar.shol
→ OLŌRROLŌRRO  UR  PAOL

`f107r.30`  pair.aii{ikh}eedy.shalkaiin.kairy.okaral.qokaiin.opaichy.opal.rary.ky
→ MUIR  UIIIŌARRNM  PAULŌUII?  ŌUIRM  OŌURUL  COŌUII?  OMUISAM  OMUL  RURM  ŌM

`f107r.31`  daiin.sheol.chdy.okaiin.sheykal.shy.kl.al.kal.chdy.r,aiin.chain.yols
→ NUII?  PAROL  SANM  OŌUII?  PARMŌUL  PAM  ŌL  UL  ŌUL  SANM  RUII?  SAUI?  MOLP

`f107r.32`  salxar,shy.qokaiin.okal.qockhedy.okr.aiin.otar.qocthy.rolky
→ PUL?URPAM  COŌUII?  OŌUL  COSŌARNM  OŌR  UII?  OTUR  COSTAM  ROLŌM

`f107r.33`  yaiin.chekain.cheo.kaiin.chey.qol.kaiiin.chky.lcheel.lkar.okal
→ MUII?  SARŌUI?  SARO  ŌUII?  SARM  COL  ŌUIII?  SAŌM  LSARRL  LŌUR  OŌUL

`f107r.34`  pairar.al.oro,lkeey.qotal.cheotain.dar.okaiin.otaiin.otar.opaim
→ MUIRUR  UL  OROLŌRRM  COTUL  SAROTUI?  NUR  OŌUII?  OTUII?  OTUR  OMUIS

`f107r.35`  daiin.shl.lkeeol.lchedy.qokor.lkaiin.chedy.qotaiin.al.ol.kaldaim
→ NUII?  PAL  LŌRROL  LSARNM  COŌOR  LŌUII?  SARNM  COTUII?  UL  OL  ŌULNUIS

`f107r.36`  dar.alchor.kcheo.rkeey.chaiin.al.dal.qokchey.qokl.chey.lkaiin.lkar
→ NUR  ULSAOR  ŌSARO  RŌRRM  SAUII?  UL  NUL  COŌSARM  COŌL  SARM  LŌUII?  LŌUR

`f107r.37`  ychklkaiin.chckhy.cho,l,olkain
→ MSAŌLŌUII?  SASŌAM  SAOLOLŌUI?

`f107r.38`  poaral,orar.ofchey.qoteedy.qotaiin.opchedy.qokchey.otlchdain.aly
→ MOURULORUR  O?SARM  COTRRNM  COTUII?  OMSARNM  COŌSARM  OTLSANUI?  ULM

`f107r.39`  tair.cheol.cheol.kchekain.cheear.[o:a]l.oiin.cho.lkain.al.oeedy.chey
→ TUIR  SAROL  SAROL  ŌSARŌUI?  SARRUR  OL  OII?  SAO  LŌUI?  UL  ORRNM  SARM

`f107r.40`  lolkaiin.chey.qokaiin.chal.aiin.okaiin.olkar.otair.okal.okal
→ LOLŌUII?  SARM  COŌUII?  SAUL  UII?  OŌUII?  OLŌUR  OTUIR  OŌUL  OŌUL

`f107r.41`  qokaiin.ar.ockhey.qokal.otal.otam
→ COŌUII?  UR  OSŌARM  COŌUL  OTUL  OTUS

`f107r.42`  pcholky.sokeey.aiin.oteey.ykchey.paichy.okeey.tain.ar.arodl.kairam
→ MSAOLŌM  POŌRRM  UII?  OTRRM  MŌSARM  MUISAM  OŌRRM  TUI?  UR  URONL  ŌUIRUS

`f107r.43`  okeear.a{ith}y.daiin.sheody.ykchedy.chykaiin.otal.taiin.chotaiir.aram
→ OŌRRUR  UITAM  NUII?  PARONM  MŌSARNM  SAMŌUII?  OTUL  TUII?  SAOTUIIR  URUS

`f107r.44`  ycheodain.okeey.qokeeody.qokaiin
→ MSARONUI?  OŌRRM  COŌRRONM  COŌUII?

`f107r.45`  podky.chedy.qockhy.qokeedy.qokokil.y.chees.opal,kaiin.otaiin.otaram
→ MONŌM  SARNM  COSŌAM  COŌRRNM  COŌOŌIL  M  SARRP  OMULŌUII?  OTUII?  OTURUS

`f107r.46`  sar.cheey.qodaiin.qokaiin.ol.cheor,aiin.otal,taiin.qokaiin.otal.alkal
→ PUR  SARRM  CONUII?  COŌUII?  OL  SARORUII?  OTULTUII?  COŌUII?  OTUL  ULŌUL

`f107r.47`  okain.cheey.lol.loeey.[o:a]iinal
→ OŌUI?  SARRM  LOL  LORRM  OII?UL

`f107r.48`  fairal.chkal.lky.otain.ar.kalkal.qotain.oty.lky.otaiin.ytaiin.om
→ ?UIRUL  SAŌUL  LŌM  OTUI?  UR  ŌULŌUL  COTUI?  OTM  LŌM  OTUII?  MTUII?  OS

`f107r.49`  o.alain.a{ikh}y.chkain.okair.chtl.lkaiin.okair.chtl.ra{ith}ty
→ O  ULUI?  UIŌAM  SAŌUI?  OŌUIR  SATL  LŌUII?  OŌUIR  SATL  RUITATM

`f107r.50`  chain.al.lkeey.chol.taidy.qotaiin.y,taiin.lkl.lfchal.pchdy,pal.tar
→ SAUI?  UL  LŌRRM  SAOL  TUINM  COTUII?  MTUII?  LŌL  L?SAUL  MSANMMUL  TUR

`f107r.51`  sar.ain.chol.ol,cheey.otal.otal,ol.otchy.qoky.otaily
→ PUR  UI?  SAOL  OLSARRM  OTUL  OTULOL  OTSAM  COŌM  OTUILM

### f107v  ·  stars

`f107v.1`  kaisar.olkeeey.otalkchy.lkaiin.ot[o:e]dy.qokair.lkal.chey.chody.otal,cheey
→ ŌUIPUR  OLŌRRRM  OTULŌSAM  LŌUII?  OTONM  COŌUIR  LŌUL  SARM  SAONM  OTULSARRM

`f107v.2`  daiin.dckhy.ol,daiin.chkal.qokedy.otal.chedy.oteos.aiin.otar.alkain.ol
→ NUII?  NSŌAM  OLNUII?  SAŌUL  COŌRNM  OTUL  SARNM  OTROP  UII?  OTUR  ULŌUI?  OL

`f107v.3`  sain.ain.aiiin.qokaiin.shol.kal.qokar,al.ochedy.lkaiin.otal.olkiir.alody
→ PUI?  UI?  UIII?  COŌUII?  PAOL  ŌUL  COŌURUL  OSARNM  LŌUII?  OTUL  OLŌIIR  ULONM

`f107v.4`  dain.cheky.okechy.qokain.shocthy.otaiin.alkaiin
→ NUI?  SARŌM  OŌRSAM  COŌUI?  PAOSTAM  OTUII?  ULŌUII?

`f107v.5`  tol,sheockhedy.qotol.chdor.otechdy.teol.tedaiin.opchedy.qopchdy.ytar.aiiil
→ TOLPAROSŌARNM  COTOL  SANOR  OTRSANM  TROL  TRNUII?  OMSARNM  COMSANM  MTUR  UIIIL

`f107v.6`  paiin.okaiin.qokaiy.olkeedy.qokeey.qotaiin.oky.lkal.otaiin.aiin.qokaldy
→ MUII?  OŌUII?  COŌUIM  OLŌRRNM  COŌRRM  COTUII?  OŌM  LŌUL  OTUII?  UII?  COŌULNM

`f107v.7`  taiin.cheockhy.chain.qokain
→ TUII?  SAROSŌAM  SAUI?  COŌUI?

`f107v.8`  polcheolkain.qokair.okeol.qokol.qokaiin.opcheol.qotedy.ltedy.otedam
→ MOLSAROLŌUI?  COŌUIR  OŌROL  COŌOL  COŌUII?  OMSAROL  COTRNM  LTRNM  OTRNUS

`f107v.9`  saiin.shey,kedy.qokain.qokedy.qokaiin.y,lkaiin.qoky.lkal,tar,aty
→ PUII?  PARMŌRNM  COŌUI?  COŌRNM  COŌUII?  MLŌUII?  COŌM  LŌULTURUTM

`f107v.10`  shodaiin.shey.qokair.qokaiin.chokedy.tain.shedy
→ PAONUII?  PARM  COŌUIR  COŌUII?  SAOŌRNM  TUI?  PARNM

`f107v.11`  tshedy.okal.shedy.qokchey.chky.qokeey.qotaiin.otol.qoteedy.qopchcfhy
→ TPARNM  OŌUL  PARNM  COŌSARM  SAŌM  COŌRRM  COTUII?  OTOL  COTRRNM  COMSAS?AM

`f107v.12`  qokeey.lcheol.chol,kaiin.olkal.shedy.qokaly.odar.choty.qokaiin.otam
→ COŌRRM  LSAROL  SAOLŌUII?  OLŌUL  PARNM  COŌULM  ONUR  SAOTM  COŌUII?  OTUS

`f107v.13`  ycheey.qokain.ockheody.qokair.otal.qokaiin.otal.sho{ck}y.qokaiin.dalam
→ MSARRM  COŌUI?  OSŌARONM  COŌUIR  OTUL  COŌUII?  OTUL  PAOSŌM  COŌUII?  NULUS

`f107v.14`  daiin.shaiin.okaiin.qokar.qokal.qokal.cheody.qokain.okchdy.dlkal
→ NUII?  PAUII?  OŌUII?  COŌUR  COŌUL  COŌUL  SARONM  COŌUI?  OŌSANM  NLŌUL

`f107v.15`  solain.qokal.okeey.lkaiin.okain.chkal.otain.chcthy.tarairy
→ POLUI?  COŌUL  OŌRRM  LŌUII?  OŌUI?  SAŌUL  OTUI?  SASTAM  TURUIRM

`f107v.16`  parair.okal.opchol.okal.opaiin.otedy.qokeody.tolkol.lkar.aiiraly
→ MURUIR  OŌUL  OMSAOL  OŌUL  OMUII?  OTRNM  COŌRONM  TOLŌOL  LŌUR  UIIRULM

`f107v.17`  saiin.or.ykeear.chckhy.okaiin.okal.qoklaiin.cheol.qokar.chey.lkam
→ PUII?  OR  MŌRRUR  SASŌAM  OŌUII?  OŌUL  COŌLUII?  SAROL  COŌUR  SARM  LŌUS

`f107v.18`  qokain.qokchey.qekchdy.okaiin.lkl.chol.raiin.otaiin.alkaiin.dal
→ COŌUI?  COŌSARM  CRŌSANM  OŌUII?  LŌL  SAOL  RUII?  OTUII?  ULŌUII?  NUL

`f107v.19`  soral.olaiin.chor.okaiin.chkain.okaiin
→ PORUL  OLUII?  SAOR  OŌUII?  SAŌUI?  OŌUII?

`f107v.20`  palar.or.air.kalkal.okaiin.chpal.cheody.qopchedy.pcholkal.opalkam
→ MULUR  OR  UIR  ŌULŌUL  OŌUII?  SAMUL  SARONM  COMSARNM  MSAOLŌUL  OMULŌUS

`f107v.21`  taiin.ol,kaiin.chol.kchedy.qokol.ain.air.kaiin.okal.otar.otalal
→ TUII?  OLŌUII?  SAOL  ŌSARNM  COŌOL  UI?  UIR  ŌUII?  OŌUL  OTUR  OTULUL

`f107v.22`  dar.alol.olaiin.olkal.chol.chdar
→ NUR  ULOL  OLUII?  OLŌUL  SAOL  SANUR

`f107v.23`  palchar.ar,akaiiky.char.raikchy.opchain.opalkar.otal.otar.alky
→ MULSAUR  URUŌUIIŌM  SAUR  RUIŌSAM  OMSAUI?  OMULŌUR  OTUL  OTUR  ULŌM

`f107v.24`  dain.olaiin.chol.olkain.lkaiin
→ NUI?  OLUII?  SAOL  OLŌUI?  LŌUII?

`f107v.25`  kaolkar.kolkar.okeol.qokeor,al.tody.opchey.oty.al.ky.pchey.ra[g:m]
→ ŌUOLŌUR  ŌOLŌUR  OŌROL  COŌRORUL  TONM  OMSARM  OTM  UL  ŌM  MSARM  RU?

`f107v.26`  oraiin.sheor.qokain.cheody.qokain.otal.okaiin.olkeeo,r,ar,al.oldy
→ ORUII?  PAROR  COŌUI?  SARONM  COŌUI?  OTUL  OŌUII?  OLŌRRORURUL  OLNM

`f107v.27`  dal.okain.okchey.qokshy.okol.lkshedy.taraiin.sho.qokor.cheey.qokam
→ NUL  OŌUI?  OŌSARM  COŌPAM  OŌOL  LŌPARNM  TURUII?  PAO  COŌOR  SARRM  COŌUS

`f107v.28`  y,cheor.cheol.lcheedy.raraiin
→ MSAROR  SAROL  LSARRNM  RURUII?

`f107v.29`  tolkeeedy.okeol.cheody.qokeey.qokchedy.qotyshey.q{cthh}y.lty.ltam
→ TOLŌRRRNM  OŌROL  SARONM  COŌRRM  COŌSARNM  COTMPARM  CSTAAM  LTM  LTUS

`f107v.30`  okain.ol.okaiin.lkeody.otaiin.chol.lkaiin.lkeeey.qokaiin.chey.qoky
→ OŌUI?  OL  OŌUII?  LŌRONM  OTUII?  SAOL  LŌUII?  LŌRRRM  COŌUII?  SARM  COŌM

`f107v.31`  sokod.chey.lkaiin.chedy.qe.okeody.qokeedy.rary
→ POŌON  SARM  LŌUII?  SARNM  CR  OŌRONM  COŌRRNM  RURM

`f107v.32`  tay.oaiin.okeeody.okaiin.otaiin.otchey.qokaiin.otedy.qokam
→ TUM  OUII?  OŌRRONM  OŌUII?  OTUII?  OTSARM  COŌUII?  OTRNM  COŌUS

`f107v.33`  orain.chol.qodaiin.odain.aiin.okain.chkaly.raiin.y.kaiin,aldy
→ ORUI?  SAOL  CONUII?  ONUI?  UII?  OŌUI?  SAŌULM  RUII?  M  ŌUII?ULNM

`f107v.34`  dyair.chey.lkchy.lchedy.raiin.sheey
→ NMUIR  SARM  LŌSAM  LSARNM  RUII?  PARRM

`f107v.35`  polchedy.olkeey.lkey.chcthy.lkar.shedy.qokaiin.chedy.qokeedy.lol
→ MOLSARNM  OLŌRRM  LŌRM  SASTAM  LŌUR  PARNM  COŌUII?  SARNM  COŌRRNM  LOL

`f107v.36`  tol,chey.lcheor.sheol.qokaiin.olkeedy.okar.ar.olkain.odain
→ TOLSARM  LSAROR  PAROL  COŌUII?  OLŌRRNM  OŌUR  UR  OLŌUI?  ONUI?

`f107v.37`  poraiin.o,kal,chedy.qolkeey.lpcheedy.qokol.rol,keedy.okaiin.otary
→ MORUII?  OŌULSARNM  COLŌRRM  LMSARRNM  COŌOL  ROLŌRRNM  OŌUII?  OTURM

`f107v.38`  dain.okchey.qokchey.qokaiin.olkeey.qokol.oteey.oteey.lkain
→ NUI?  OŌSARM  COŌSARM  COŌUII?  OLŌRRM  COŌOL  OTRRM  OTRRM  LŌUI?

`f107v.39`  okain.cheor.olkaiin.oain.cheary.raiin.okoiin.odaiin.okaiin,y
→ OŌUI?  SAROR  OLŌUII?  OUI?  SARURM  RUII?  OŌOII?  ONUII?  OŌUII?M

`f107v.40`  chokeey.qokey.qokaiii.lor.aiin.aiily
→ SAOŌRRM  COŌRM  COŌUIII  LOR  UII?  UIILM

`f107v.41`  pokar.ar.keey.okeeo.l,cheey.qokchey.oteey.lkeeo,l.lkeedy.qokeey.lkain
→ MOŌUR  UR  ŌRRM  OŌRRO  LSARRM  COŌSARM  OTRRM  LŌRROL  LŌRRNM  COŌRRM  LŌUI?

`f107v.42`  or,ain.oloeeey.qokain
→ ORUI?  OLORRRM  COŌUI?

`f107v.43`  pol,keeeo.kaii[s:r]r.qokeey.chckhy.lkchaly.lkeey.opchey.rar.aiin.cheokaly
→ MOLŌRRRO  ŌUIIPR  COŌRRM  SASŌAM  LŌSAULM  LŌRRM  OMSARM  RUR  UII?  SAROŌULM

`f107v.44`  kaich.o,l,air.arody.qokeey.qokeey
→ ŌUISA  OLUIR  URONM  COŌRRM  COŌRRM

`f107v.45`  porain.okain.okechdy.dal.keeedal.shedy.okeeolkcheey.lkar.aiin.al
→ MORUI?  OŌUI?  OŌRSANM  NUL  ŌRRRNUL  PARNM  OŌRROLŌSARRM  LŌUR  UII?  UL

`f107v.46`  soain.aiin.chey.qolaiin.al.chedy.kedy.qoteey.oteey.qokeeylkain
→ POUI?  UII?  SARM  COLUII?  UL  SARNM  ŌRNM  COTRRM  OTRRM  COŌRRMLŌUI?

`f107v.47`  y,cheey.qokeey.okeoteey.qokey.qokey.qokeey.daiin.y.okeey.odain
→ MSARRM  COŌRRM  OŌROTRRM  COŌRM  COŌRM  COŌRRM  NUII?  M  OŌRRM  ONUI?

`f107v.48`  oteedy.qokey.qokeedy.chody.chey,qoky.oteey.otain.chey.aiinal
→ OTRRNM  COŌRM  COŌRRNM  SAONM  SARMCOŌM  OTRRM  OTUI?  SARM  UII?UL

`f107v.49`  ycheosaiin.oekey.chey.qokeey.y,cheey.dy.qoy
→ MSAROPUII?  ORŌRM  SARM  COŌRRM  MSARRM  NM  COM

### f108r  ·  stars

`f108r.1`  teodeeor.qopchety.okeeoly.okchdpchy.toda{i'h}x.opar,yo,lpair,ody.otedy.kedydy
→ TRONRROR  COMSARTM  OŌRROLM  OŌSANMSAM  TONUIA?  OMURMOLMUIRONM  OTRNM  ŌRNMNM

`f108r.2`  qokeedy.chokedy.chockhed.qokeor.shedy.otal.otaiin.otedy.qokechy.ofchdy.qody
→ COŌRRNM  SAOŌRNM  SAOSŌARN  COŌROR  PARNM  OTUL  OTUII?  OTRNM  COŌRSAM  O?SANM  CONM

`f108r.3`  cheodchy.qote[{ci}:a]r.okedy.oteal.lkedal.okedy.otedy.okedal.chckhedy.chokedal
→ SARONSAM  COTRSIR  OŌRNM  OTRUL  LŌRNUL  OŌRNM  OTRNM  OŌRNUL  SASŌARNM  SAOŌRNUL

`f108r.4`  ychedaiin.shky.chdy.oteeody.chedor.sheeky
→ MSARNUII?  PAŌM  SANM  OTRRONM  SARNOR  PARRŌM

`f108r.5`  tchokedy.chey.oteey.okeey.lked{ch'}edy.okche{cf},y.pchofar.cheo.pchedy.qotedy.otol
→ TSAOŌRNM  SARM  OTRRM  OŌRRM  LŌRNSARNM  OŌSARS?M  MSAO?UR  SARO  MSARNM  COTRNM  OTOL

`f108r.6`  ol.cheol.qo.qokeey.qokeey.qokeedy.sheoky.otedy.qotey.qokchey.chdar.aiin,y
→ OL  SAROL  CO  COŌRRM  COŌRRM  COŌRRNM  PAROŌM  OTRNM  COTRM  COŌSARM  SANUR  UII?M

`f108r.7`  ok[che:eee]y.okedy.qokchedy.chedy.qokedy.okar.chdy.okar.char.chkaiin.chsy
→ OŌSARM  OŌRNM  COŌSARNM  SARNM  COŌRNM  OŌUR  SANM  OŌUR  SAUR  SAŌUII?  SAPM

`f108r.8`  pochedy.shy.shokeedar.al.kedal.chokchy.qokar.ch.okeey.qaiin.okeedy.qetam
→ MOSARNM  PAM  PAOŌRRNUR  UL  ŌRNUL  SAOŌSAM  COŌUR  SA  OŌRRM  CUII?  OŌRRNM  CRTUS

`f108r.9`  cthey.chedain.chedy.okedy.lkedy.raraiin.qokar.otal,kedy.ar.air.ockhedy
→ STARM  SARNUI?  SARNM  OŌRNM  LŌRNM  RURUII?  COŌUR  OTULŌRNM  UR  UIR  OSŌARNM

`f108r.10`  taiin.shkeedy.qoteey.oteey.ykeol.ykeedy.chekar.qokeeodaiin.okeyty.ody
→ TUII?  PAŌRRNM  COTRRM  OTRRM  MŌROL  MŌRRNM  SARŌUR  COŌRRONUII?  OŌRMTM  ONM

`f108r.11`  te[o:a]deey.ar.aiin.okeey.qetchdy.oteeody.okaiin.ykeeo.dain.otalaiin.oly
→ TRONRRM  UR  UII?  OŌRRM  CRTSANM  OTRRONM  OŌUII?  MŌRRO  NUI?  OTULUII?  OLM

`f108r.12`  tshey.okchey.dain.aloiin.ocheey.qokaiin.chlam.okaiin.okal.kain.alam
→ TPARM  OŌSARM  NUI?  ULOII?  OSARRM  COŌUII?  SALUS  OŌUII?  OŌUL  ŌUI?  ULUS

`f108r.13`  ykeey.raiin.ar,ail,odaiin
→ MŌRRM  RUII?  URUILONUII?

`f108r.14`  polchal.shol.qokar.shedy.pcholy.qokal.opchdy.ofal.shor.qokaiin.otalod
→ MOLSAUL  PAOL  COŌUR  PARNM  MSAOLM  COŌUL  OMSANM  O?UL  PAOR  COŌUII?  OTULON

`f108r.15`  orain.cheey.chey.qokeey.chedy.okchedy.qoeedy.qockhey.d,iirain.okain
→ ORUI?  SARRM  SARM  COŌRRM  SARNM  OŌSARNM  CORRNM  COSŌARM  NIIRUI?  OŌUI?

`f108r.16`  sa{ith}y.olkaiin.chckhy.daiin.dal,daiin
→ PUITAM  OLŌUII?  SASŌAM  NUII?  NULNUII?

`f108r.17`  fcheokair.okedaiin.chedy.qokeed.okain.chdy.laiin.ofar.chedy.tedam
→ ?SAROŌUIR  OŌRNUII?  SARNM  COŌRRN  OŌUI?  SANM  LUII?  O?UR  SARNM  TRNUS

`f108r.18`  okeedy.lkal.daiin.ykchedy.qokol.chedy.qokedy.lkedy.okalo,l.chedl,y
→ OŌRRNM  LŌUL  NUII?  MŌSARNM  COŌOL  SARNM  COŌRNM  LŌRNM  OŌULOL  SARNLM

`f108r.19`  dchedy.okeedar.shchy.okol.kedy.okeedy.chal,raiin.otedy.chtal.om
→ NSARNM  OŌRRNUR  PASAM  OŌOL  ŌRNM  OŌRRNM  SAULRUII?  OTRNM  SATUL  OS

`f108r.20`  dain.chey.qokeedy.cholcheey.dalkar.okedy
→ NUI?  SARM  COŌRRNM  SAOLSARRM  NULŌUR  OŌRNM

`f108r.21`  qolshy.qoeedy.lkealshedy.shokal.keedy.qotedy.qopchedy.otal.dkedam
→ COLPAM  CORRNM  LŌRULPARNM  PAOŌUL  ŌRRNM  COTRNM  COMSARNM  OTUL  NŌRNUS

`f108r.22`  dcheol.shol.dal.qokaiin.otal.ol.shedy.qokey.chey,lor.aiin.okeeam
→ NSAROL  PAOL  NUL  COŌUII?  OTUL  OL  PARNM  COŌRM  SARMLOR  UII?  OŌRRUS

`f108r.23`  ykeol.chey.okain.charain
→ MŌROL  SARM  OŌUI?  SAURUI?

`f108r.24`  folaiin.{c'hkh}y.qokal.lkedy.qotedy.qoked.qotedy.okal,chdar,al,char,aiin
→ ?OLUII?  SAŌAM  COŌUL  LŌRNM  COTRNM  COŌRN  COTRNM  OŌULSANURULSAURUII?

`f108r.25`  y,cheeor.aiin.okeey.cheol.chedy.opchsd.opchedy.alkedy.al,lkeam.ol.rain,al
→ MSARROR  UII?  OŌRRM  SAROL  SARNM  OMSAPN  OMSARNM  ULŌRNM  ULLŌRUS  OL  RUI?UL

`f108r.26`  dair.okal.chedy.qokeedy.oteor,al.qokedy.qokedy.otaiin.otedar.chalkeedy
→ NUIR  OŌUL  SARNM  COŌRRNM  OTRORUL  COŌRNM  COŌRNM  OTUII?  OTRNUR  SAULŌRRNM

`f108r.27`  ychedain.orcheory.qoaiin.okeey.qokeey.chdal.okedy.qokedy.okedam.chdy
→ MSARNUI?  ORSARORM  COUII?  OŌRRM  COŌRRM  SANUL  OŌRNM  COŌRNM  OŌRNUS  SANM

`f108r.28`  sain.arolkeey.qoal.olkedy.okaiin
→ PUI?  UROLŌRRM  COUL  OLŌRNM  OŌUII?

`f108r.29`  polchedy.okedy.qopchedy.okeolkey.teedy.qotaiin.otedy.okeedy.otedam
→ MOLSARNM  OŌRNM  COMSARNM  OŌROLŌRM  TRRNM  COTUII?  OTRNM  OŌRRNM  OTRNUS

`f108r.30`  ykeol.chedal.chokedy.o.qokedy.okchedy.saiin.alkan
→ MŌROL  SARNUL  SAOŌRNM  O  COŌRNM  OŌSARNM  PUII?  ULŌU?

`f108r.31`  keol.sheody.qokedy.qokeedy.qokoy.qoiiedy.otedy.qokedy.qokedy.qokal
→ ŌROL  PARONM  COŌRNM  COŌRRNM  COŌOM  COIIRNM  OTRNM  COŌRNM  COŌRNM  COŌUL

`f108r.32`  ykedar.chedy.qokey.lkeedy.otedy.[o:y]kedy.otedy.otal.shol.alodar.or.alold
→ MŌRNUR  SARNM  COŌRM  LŌRRNM  OTRNM  OŌRNM  OTRNM  OTUL  PAOL  ULONUR  OR  ULOLN

`f108r.33`  solkedy.okchd.qokedy.okedy.okeol.chdy.okar.okedy.okedy.chlar
→ POLŌRNM  OŌSAN  COŌRNM  OŌRNM  OŌROL  SANM  OŌUR  OŌRNM  OŌRNM  SALUR

`f108r.34`  ycheol.chckhy.qokedy.okain
→ MSAROL  SASŌAM  COŌRNM  OŌUI?

`f108r.35`  pychory.opchey.lkeol.chdar.shedy.qofchdy.opalal.cheedy.qokalchdy.opchdy
→ MMSAORM  OMSARM  LŌROL  SANUR  PARNM  CO?SANM  OMULUL  SARRNM  COŌULSANM  OMSANM

`f108r.36`  okechy.okeol.okeedy.cheedar.okedy.qotal.chdy.chedal.chedy
→ OŌRSAM  OŌROL  OŌRRNM  SARRNUR  OŌRNM  COTUL  SANM  SARNUL  SARNM

`f108r.37`  tchedy.qokey.okeey.lkeey.chedy.cheokeey.qokeey.chedl,al.lkair.alkeedy.ram
→ TSARNM  COŌRM  OŌRRM  LŌRRM  SARNM  SAROŌRRM  COŌRRM  SARNLUL  LŌUIR  ULŌRRNM  RUS

`f108r.38`  dcheeody.cheedy.qokeedy.otedy.qeeey.chey
→ NSARRONM  SARRNM  COŌRRNM  OTRNM  CRRRM  SARM

`f108r.39`  poro.l.tedo.lchdain.qokar.otedy.otarar.yty.sho,qotedy.oteedy.okedy
→ MORO  L  TRNO  LSANUI?  COŌUR  OTRNM  OTURUR  MTM  PAOCOTRNM  OTRRNM  OŌRNM

`f108r.40`  okor,aiin.okeedy.qokeedy.okeeom.cheykeeed.chol.qekeey.or,aiin.chckhom
→ OŌORUII?  OŌRRNM  COŌRRNM  OŌRROS  SARMŌRRRN  SAOL  CRŌRRM  ORUII?  SASŌAOS

`f108r.41`  sheedain.qokeedy.chokeedy.qoteody.keesho.daiin.chedy.keedal.as.keodky
→ PARRNUI?  COŌRRNM  SAOŌRRNM  COTRONM  ŌRRPAO  NUII?  SARNM  ŌRRNUL  UP  ŌRONŌM

`f108r.42`  okeey.qokeey.qokeedy.qokeey.chedal.chedy.qokeey.okeedain.otain.oolals
→ OŌRRM  COŌRRM  COŌRRNM  COŌRRM  SARNUL  SARNM  COŌRRM  OŌRRNUI?  OTUI?  OOLULP

`f108r.43`  olke?y.okey.lokeey.qokedy.ol,kechy.chedar.olal.oedy.qckhy.cheam
→ OLŌRM  OŌRM  LOŌRRM  COŌRNM  OLŌRSAM  SARNUR  OLUL  ORNM  CSŌAM  SARUS

`f108r.44`  ychey.chey.okar.charam.otam.cheody
→ MSARM  SARM  OŌUR  SAURUS  OTUS  SARONM

`f108r.45`  dain.sheckhy.okeey.keey.lchedy.okeey.qokedy.chedy.dalkedy.qokedy.dal
→ NUI?  PARSŌAM  OŌRRM  ŌRRM  LSARNM  OŌRRM  COŌRNM  SARNM  NULŌRNM  COŌRNM  NUL

`f108r.46`  yteedy.qokeed,y.qokey.otedy.okedy.qokaiin.cheodar.cheey.qokedy.al
→ MTRRNM  COŌRRNM  COŌRM  OTRNM  OŌRNM  COŌUII?  SARONUR  SARRM  COŌRNM  UL

`f108r.47`  yched.chockhey.dain.sheol.okedy.lkeedy.oteedy.qokeedy.ched,al.keam
→ MSARN  SAOSŌARM  NUI?  PAROL  OŌRNM  LŌRRNM  OTRRNM  COŌRRNM  SARNUL  ŌRUS

`f108r.48`  pcheedy.qokeo.l.okeol.keol.dain.ar.otedy.qokedy.qokeedy.qokeedy.lchdy
→ MSARRNM  COŌRO  L  OŌROL  ŌROL  NUI?  UR  OTRNM  COŌRNM  COŌRRNM  COŌRRNM  LSANM

`f108r.49`  oteedy.lchedy.qokeedy.qokeedy.qokeo.lchedy.qokey.qokeey.lkedy.lkedy
→ OTRRNM  LSARNM  COŌRRNM  COŌRRNM  COŌRO  LSARNM  COŌRM  COŌRRM  LŌRNM  LŌRNM

`f108r.50`  qokeedy,lchedy.lkaiin.chdy.qokey.okedy.okaram.chdar,ar.okam
→ COŌRRNMLSARNM  LŌUII?  SANM  COŌRM  OŌRNM  OŌURUS  SANURUR  OŌUS

### f108v  ·  stars

`f108v.1`  pchedal.qokeedar.otedy.qokeedy.lky.ltal.aiin.oteo.fcheey.otedar.am,ol
→ MSARNUL  COŌRRNUR  OTRNM  COŌRRNM  LŌM  LTUL  UII?  OTRO  ?SARRM  OTRNUR  USOL

`f108v.2`  daiin.shal.qokedy.qoee[ch:?]y.okain.oteey.checkhy.lkeedy.qokeedar.araiin.okam
→ NUII?  PAUL  COŌRNM  CORRSAM  OŌUI?  OTRRM  SARSŌAM  LŌRRNM  COŌRRNUR  URUII?  OŌUS

`f108v.3`  ssheedal.ol.lkedy.lkeedy.chedalkedy.lkeedy.qokechedy.otedain.oteey.lol
→ PPARRNUL  OL  LŌRNM  LŌRRNM  SARNULŌRNM  LŌRRNM  COŌRSARNM  OTRNUI?  OTRRM  LOL

`f108v.4`  dchedy.shedy.qokeed.qoteedy.qoteedy.arain.al.keedy
→ NSARNM  PARNM  COŌRRN  COTRRNM  COTRRNM  URUI?  UL  ŌRRNM

`f108v.5`  polaiin.okedain.okal.otchedy.qokeedy.raraiin.o.keedy.qokar.qokal,dam
→ MOLUII?  OŌRNUI?  OŌUL  OTSARNM  COŌRRNM  RURUII?  O  ŌRRNM  COŌUR  COŌULNUS

`f108v.6`  oeeedain.chey.lokeey.lchedy.loety.qokeedy.qokeey.qokar.okeedy.kedarxy
→ ORRRNUI?  SARM  LOŌRRM  LSARNM  LORTM  COŌRRNM  COŌRRM  COŌUR  OŌRRNM  ŌRNUR?M

`f108v.7`  pchedaiin.okedy.otedal.lkedeed.okedar.okeey.qoteol.lkedy.otey.[r:s]aiin.am
→ MSARNUII?  OŌRNM  OTRNUL  LŌRNRRN  OŌRNUR  OŌRRM  COTROL  LŌRNM  OTRM  RUII?  US

`f108v.8`  ysheedy.okeedy.oteedy.qokeedy.okeedy.okeedy.chedal.okar.qoteedar.oty
→ MPARRNM  OŌRRNM  OTRRNM  COŌRRNM  OŌRRNM  OŌRRNM  SARNUL  OŌUR  COTRRNUR  OTM

`f108v.9`  qokeeo,dar.chedam.chlal.okaldain.sheed.lchedy.l,keedy.ched,kel.cthdy
→ COŌRRONUR  SARNUS  SALUL  OŌULNUI?  PARRN  LSARNM  LŌRRNM  SARNŌRL  STANM

`f108v.10`  ol.cheey.leedaiin.shckhaiin.okeal.okar.aralor,om.shee.ka{ith}y.chectham
→ OL  SARRM  LRRNUII?  PASŌAUII?  OŌRUL  OŌUR  URULOROS  PARR  ŌUITAM  SARSTAUS

`f108v.11`  sain.al,keed,ain.olkeeed.qokedy.lkeedy.cho,lkain.oteshy.shedy.d[ee:a]dy
→ PUI?  ULŌRRNUI?  OLŌRRRN  COŌRNM  LŌRRNM  SAOLŌUI?  OTRPAM  PARNM  NRRNM

`f108v.12`  tshedky.sheckhy.akey.sheey.teeody.qokedy.qokeedy.shok,ar.aiin.okeey.tedam
→ TPARNŌM  PARSŌAM  UŌRM  PARRM  TRRONM  COŌRNM  COŌRRNM  PAOŌUR  UII?  OŌRRM  TRNUS

`f108v.13`  daiin.cheol.qokeey.qokeedy.qokeey.raiin.chckhy.okeey.qokeedy.okedain.ald[or:?]
→ NUII?  SAROL  COŌRRM  COŌRRNM  COŌRRM  RUII?  SASŌAM  OŌRRM  COŌRRNM  OŌRNUI?  ULNOR

`f108v.14`  qokeey.lo.r.aiin.chey.keear.a,ral.olaiin.chedy
→ COŌRRM  LO  R  UII?  SARM  ŌRRUR  URUL  OLUII?  SARNM

`f108v.15`  pcheor.okear.sheey.qokeey.ykeealkey.[r:?]ar,aiin.opsholal.shedy.ofaramoty
→ MSAROR  OŌRUR  PARRM  COŌRRM  MŌRRULŌRM  RURUII?  OMPAOLUL  PARNM  O?URUSOTM

`f108v.16`  okeey.lshey.qokeeal.lkeey.okeol.okedy.qotal.sholkeedy.chedy.qokain.teedu
→ OŌRRM  LPARM  COŌRRUL  LŌRRM  OŌROL  OŌRNM  COTUL  PAOLŌRRNM  SARNM  COŌUI?  TRRN?

`f108v.17`  qokeey.lkeed.chedy.qokeeos.sheol.tedy.qopchdy.qokeshdy.kedar.otal.raram
→ COŌRRM  LŌRRN  SARNM  COŌRROP  PAROL  TRNM  COMSANM  COŌRPANM  ŌRNUR  OTUL  RURUS

`f108v.18`  okeey.l,keedy.okeal.okey.cheykedy.qoeedy.lo.rair.cheey.ol.l,s,aiin.am
→ OŌRRM  LŌRRNM  OŌRUL  OŌRM  SARMŌRNM  CORRNM  LO  RUIR  SARRM  OL  LPUII?  US

`f108v.19`  qokeeol.olcheeey.lcheam
→ COŌRROL  OLSARRRM  LSARUS

`f108v.20`  polkeedal.sheo,kchey.lotedaiin.otedy.opchedaiin.otshedy.qotey.r,aiin,ol
→ MOLŌRRNUL  PAROŌSARM  LOTRNUII?  OTRNM  OMSARNUII?  OTPARNM  COTRM  RUII?OL

`f108v.21`  daiin.shol.olkeeey.lky.chedar.chey,kechey.qotedy.otedy.oteedain.cheody.llod
→ NUII?  PAOL  OLŌRRRM  LŌM  SARNUR  SARMŌRSARM  COTRNM  OTRNM  OTRRNUI?  SARONM  LLON

`f108v.22`  daiin.shey.sheey.dain,alsar.sheeo,lkain.shey.cheee[g:d]aiin.oloeeedy.otaiin.al
→ NUII?  PARM  PARRM  NUI?ULPUR  PARROLŌUI?  PARM  SARRR?UII?  OLORRRNM  OTUII?  UL

`f108v.23`  qokeeor.okeey.qoeey.chodaal.daiin.checthal.cheeky.otar,aiin.chckhy.lteedy
→ COŌRROR  OŌRRM  CORRM  SAONUUL  NUII?  SARSTAUL  SARRŌM  OTURUII?  SASŌAM  LTRRNM

`f108v.24`  daiin.chekeek.checkhy.ol.r.ain.odar.sheey.daiin.tchar.okeedaiin.oram
→ NUII?  SARŌRRŌ  SARSŌAM  OL  R  UI?  ONUR  PARRM  NUII?  TSAUR  OŌRRNUII?  ORUS

`f108v.25`  sheeol.okeey.kaiin.okaiin.ol.lchey.ctheo.r,aiin.cheey.qokeey.qokeeaiin.al
→ PARROL  OŌRRM  ŌUII?  OŌUII?  OL  LSARM  STARO  RUII?  SARRM  COŌRRM  COŌRRUII?  UL

`f108v.26`  sair.okeaiin.cheol.shedy.qokeeey.dlaiin.ar.or.lkar.char.aiin.okal.ldyr.ls
→ PUIR  OŌRUII?  SAROL  PARNM  COŌRRRM  NLUII?  UR  OR  LŌUR  SAUR  UII?  OŌUL  LNMR  LP

`f108v.27`  sal.lcheal.lkeeey.okar.ar.ain.olcheees.[o:a]l.cheal.okaiin.ykar.al.okalam
→ PUL  LSARUL  LŌRRRM  OŌUR  UR  UI?  OLSARRRP  OL  SARUL  OŌUII?  MŌUR  UL  OŌULUS

`f108v.28`  paror,aiin.shedy.qokey.qol.eees.aiin.lal.lkeeedy.otain.sheey.chol.tan,al
→ MURORUII?  PARNM  COŌRM  COL  RRRP  UII?  LUL  LŌRRRNM  OTUI?  PARRM  SAOL  TU?UL

`f108v.29`  dar.chey.o.cheol.chedeey.qokeedy.chea[?:m]
→ NUR  SARM  O  SAROL  SARNRRM  COŌRRNM  SARU

`f108v.30`  polshedaiin.qokeoy.keol.chokeol.qotedy.qoteedy.dar.raiin.shedy.qotain.oteedy
→ MOLPARNUII?  COŌROM  ŌROL  SAOŌROL  COTRNM  COTRRNM  NUR  RUII?  PARNM  COTUI?  OTRRNM

`f108v.31`  ol.cheol.shed.qokedy.qokedain.checkhed.qoteedy.otedy,qokedy.okeea,r.l,kam
→ OL  SAROL  PARN  COŌRNM  COŌRNUI?  SARSŌARN  COTRRNM  OTRNMCOŌRNM  OŌRRUR  LŌUS

`f108v.32`  dain.shedain.qokedar.olkeedy.qokeedy.shedy.chedar.chedy.oteedy.qokam
→ NUI?  PARNUI?  COŌRNUR  OLŌRRNM  COŌRRNM  PARNM  SARNUR  SARNM  OTRRNM  COŌUS

`f108v.33`  sain.ain.chey.lchs.shed.qokeedy.oteey.qokedy.qokeedy.cheedy.qokeedar,oldy
→ PUI?  UI?  SARM  LSAP  PARN  COŌRRNM  OTRRM  COŌRNM  COŌRRNM  SARRNM  COŌRRNUROLNM

`f108v.34`  tolshey.ochey.qokeey.qotedy.chot[ee:ch]y.qokey.cholkeedy.lkedy.lchedy.qokeey
→ TOLPARM  OSARM  COŌRRM  COTRNM  SAOTRRM  COŌRM  SAOLŌRRNM  LŌRNM  LSARNM  COŌRRM

`f108v.35`  daiin.chedy.lchedy.sholkeedy.qokeedy.chey.qokeey.qokeedy.oteedy.lchedam
→ NUII?  SARNM  LSARNM  PAOLŌRRNM  COŌRRNM  SARM  COŌRRM  COŌRRNM  OTRRNM  LSARNUS

`f108v.36`  daiin.shechy.qokedy.qokain.chor.chal.chal.chedy.dain,alal.keedy.otalys
→ NUII?  PARSAM  COŌRNM  COŌUI?  SAOR  SAUL  SAUL  SARNM  NUI?ULUL  ŌRRNM  OTULMP

`f108v.37`  sain.sheor.sheey.sheckhey.qokey.okey.shey.lkain.shedy.qokain.dalam
→ PUI?  PAROR  PARRM  PARSŌARM  COŌRM  OŌRM  PARM  LŌUI?  PARNM  COŌUI?  NULUS

`f108v.38`  dsheol.qokeedy.qokeedy.chey.qokeedy.qokedy.sheckhy.lkedy.qoteedy.otam
→ NPAROL  COŌRRNM  COŌRRNM  SARM  COŌRRNM  COŌRNM  PARSŌAM  LŌRNM  COTRRNM  OTUS

`f108v.39`  sain.chey.lkedain.chey.rar.ain.al.chear.olor.chedaiin.oteey.chedy,rl
→ PUI?  SARM  LŌRNUI?  SARM  RUR  UI?  UL  SARUR  OLOR  SARNUII?  OTRRM  SARNMRL

`f108v.40`  daiin.sheeal.qokeedy.qokeedy.qokeedy.qotey.qokeey.qokeey.otedy,qotaiin
→ NUII?  PARRUL  COŌRRNM  COŌRRNM  COŌRRNM  COTRM  COŌRRM  COŌRRM  OTRNMCOTUII?

`f108v.41`  dshedy,tedy.checkhey.sheeky.lsheedain.shear.olkedy.chy.kar.tar.otaiin
→ NPARNMTRNM  SARSŌARM  PARRŌM  LPARRNUI?  PARUR  OLŌRNM  SAM  ŌUR  TUR  OTUII?

`f108v.42`  ycheain.chey.lcheal.ykeey.qolcheedy.qokeedy.okeedy,qokey.qokeedy.qoteedy
→ MSARUI?  SARM  LSARUL  MŌRRM  COLSARRNM  COŌRRNM  OŌRRNMCOŌRM  COŌRRNM  COTRRNM

`f108v.43`  shodain.cheal.shedy.rcheetey.qokeey.cheolkeedy.cheol.chedytey.okeearam
→ PAONUI?  SARUL  PARNM  RSARRTRM  COŌRRM  SAROLŌRRNM  SAROL  SARNMTRM  OŌRRURUS

`f108v.44`  y,shey.qol.lchey.shey.qoke[a:?]r.shey.qokeey.lsheey.oteey.sheey,qol.cheekeey.lchg
→ MPARM  COL  LSARM  PARM  COŌRUR  PARM  COŌRRM  LPARRM  OTRRM  PARRMCOL  SARRŌRRM  LSA?

`f108v.45`  sheol.shedy.qokeey.chedar.sheal.qokeedy.qokeedy.qokey.sheey.qokeal.aral
→ PAROL  PARNM  COŌRRM  SARNUR  PARUL  COŌRRNM  COŌRRNM  COŌRM  PARRM  COŌRUL  URUL

`f108v.46`  saiin.sheeain.qkain.okeey.qokalor.cheol.keol.chedy.qokeey.qokeey.ral
→ PUII?  PARRUI?  CŌUI?  OŌRRM  COŌULOR  SAROL  ŌROL  SARNM  COŌRRM  COŌRRM  RUL

`f108v.47`  ycheey.qokeeey.shedain.qokeedy.qokeey.okeedal.okeol.lkeey.lchedy.lchedy
→ MSARRM  COŌRRRM  PARNUI?  COŌRRNM  COŌRRM  OŌRRNUL  OŌROL  LŌRRM  LSARNM  LSARNM

`f108v.48`  da[ir:is],al.checthy.qol.eeedy.chckhey.olchey.sheey.qokeeey.qokeedar.al,keedy
→ NUIRUL  SARSTAM  COL  RRRNM  SASŌARM  OLSARM  PARRM  COŌRRRM  COŌRRNUR  ULŌRRNM

`f108v.49`  saiin.okain.cheey.lkaiin.cheal.cheol.keear.qokeedy.qokeey.checkhedy.qokal.oam
→ PUII?  OŌUI?  SARRM  LŌUII?  SARUL  SAROL  ŌRRUR  COŌRRNM  COŌRRM  SARSŌARNM  COŌUL  OUS

`f108v.50`  dsheey.oteey.cheol.teedar.okeedy.qokeedy.checkhy.oteey.aiin.okeey.chey,qokey
→ NPARRM  OTRRM  SAROL  TRRNUR  OŌRRNM  COŌRRNM  SARSŌAM  OTRRM  UII?  OŌRRM  SARMCOŌRM

`f108v.51`  ssheodain.qokeeo.okeey.qoksheedy.char,air.okeey.qokeeolchey.olkeey.okeey,lar
→ PPARONUI?  COŌRRO  OŌRRM  COŌPARRNM  SAURUIR  OŌRRM  COŌRROLSARM  OLŌRRM  OŌRRMLUR

`f108v.52`  saiin.cheol.qokeedy.qokeedy.chedy.qokeey.cheal.llchey.daiin.okeey.qokeey
→ PUII?  SAROL  COŌRRNM  COŌRRNM  SARNM  COŌRRM  SARUL  LLSARM  NUII?  OŌRRM  COŌRRM

`f108v.53`  olchar.ol,chedy.lshy.otedy
→ OLSAUR  OLSARNM  LPAM  OTRNM

### f111r  ·  stars

`f111r.1`  kcholchdar.shar.aiip.chepchedy.chetalshy.sheek.shear.shey.ror.am.shey
→ ŌSAOLSANUR  PAUR  UIIM  SARMSARNM  SARTULPAM  PARRŌ  PARUR  PARM  ROR  US  PARM

`f111r.2`  daiin,sheeky.okeey.okeey.qaal.shedy.okeey.oteey.shedy.chcthy.lcheol.oteeam
→ NUII?PARRŌM  OŌRRM  OŌRRM  CUUL  PARNM  OŌRRM  OTRRM  PARNM  SASTAM  LSAROL  OTRRUS

`f111r.3`  dsheedy.lkeedy.chckhy.lchedy.qokeey.qokear.chal.qokeear.cheokedy.sal.lokam
→ NPARRNM  LŌRRNM  SASŌAM  LSARNM  COŌRRM  COŌRUR  SAUL  COŌRRUR  SAROŌRNM  PUL  LOŌUS

`f111r.4`  saiin.oteedy.qokeey.daiin.okedal.chedy.qokedy.l,shedy.ch{ct}chy.okeey.lor.ar.am
→ PUII?  OTRRNM  COŌRRM  NUII?  OŌRNUL  SARNM  COŌRNM  LPARNM  SASTSAM  OŌRRM  LOR  UR  US

`f111r.5`  saiin.sheekshy.ol,shedy.chokchey.lkey.otain
→ PUII?  PARRŌPAM  OLPARNM  SAOŌSARM  LŌRM  OTUI?

`f111r.6`  dain.shedy.qoky.chedy.qok.shed.olchedy.qokeedy.teedy.chdy.keedy.qotchedy.dary
→ NUI?  PARNM  COŌM  SARNM  COŌ  PARN  OLSARNM  COŌRRNM  TRRNM  SANM  ŌRRNM  COTSARNM  NURM

`f111r.7`  sshedy.qokeey.checthey.oteedy.lchedy.chol.sheeol.qokeody.raiin,otedy.otar,aiin,om
→ PPARNM  COŌRRM  SARSTARM  OTRRNM  LSARNM  SAOL  PARROL  COŌRONM  RUII?OTRNM  OTURUII?OS

`f111r.8`  daiin.o.chedain.daiin.cheedy.qokeey.qokedy.ch{ckhh}y.otshedy.lkeeol.lkeey.qotchdy
→ NUII?  O  SARNUI?  NUII?  SARRNM  COŌRRM  COŌRNM  SASŌAAM  OTPARNM  LŌRROL  LŌRRM  COTSANM

`f111r.9`  ycheeodain.okeeo.olchedy.lchedy.qokeey.okeeedy.okain.chedy.chedyteey.dal.lam
→ MSARRONUI?  OŌRRO  OLSARNM  LSARNM  COŌRRM  OŌRRRNM  OŌUI?  SARNM  SARNMTRRM  NUL  LUS

`f111r.10`  ykeedaiin.shekain.shedy.qokear.ochey.reeey.qokeey.olaiiin.chedy.lkeeody.oraiin.oty
→ MŌRRNUII?  PARŌUI?  PARNM  COŌRUR  OSARM  RRRRM  COŌRRM  OLUIII?  SARNM  LŌRRONM  ORUII?  OTM

`f111r.11`  dshey.lkeedy.lkeedy.cheedy.oteedaiin.sheedy.ar.a{ikh}y.shkaiin.chey.daiin.daram
→ NPARM  LŌRRNM  LŌRRNM  SARRNM  OTRRNUII?  PARRNM  UR  UIŌAM  PAŌUII?  SARM  NUII?  NURUS

`f111r.12`  dsheeo.qokeedy.otchedey.lshey.lkeedy.oteey.qokeedy.oteolair.ar.shedam.cheam
→ NPARRO  COŌRRNM  OTSARNRM  LPARM  LŌRRNM  OTRRM  COŌRRNM  OTROLUIR  UR  PARNUS  SARUS

`f111r.13`  qosheo.lchdy.lshedy.olkeeedy.lr.al.chr.or,dain.shey.arain.chey.teey.cheodaiin
→ COPARO  LSANM  LPARNM  OLŌRRRNM  LR  UL  SAR  ORNUI?  PARM  URUI?  SARM  TRRM  SARONUII?

`f111r.14`  dchedar.oteey.lchey.ykeeeos.aiin.shear.oteedy.tedam.oteey.pchedey.chedy.lchedy
→ NSARNUR  OTRRM  LSARM  MŌRRROP  UII?  PARUR  OTRRNM  TRNUS  OTRRM  MSARNRM  SARNM  LSARNM

`f111r.15`  sheeodar.aiin.sheey.shey.oteody.oteedy.chey.daiin.oteol.otedar.tar.pchdam
→ PARRONUR  UII?  PARRM  PARM  OTRONM  OTRRNM  SARM  NUII?  OTROL  OTRNUR  TUR  MSANUS

`f111r.16`  dchedshey.qokeedy.okeodain.shet.sheota[?:im].oteal,tey.lkeey.sheedy.shtar.keedy
→ NSARNPARM  COŌRRNM  OŌRONUI?  PART  PAROTU  OTRULTRM  LŌRRM  PARRNM  PATUR  ŌRRNM

`f111r.17`  otes.lchey.lshedy.qoteedy.olcheody.qokeey.chey.kal.chekeedy.oteed.keedy.otam
→ OTRP  LSARM  LPARNM  COTRRNM  OLSARONM  COŌRRM  SARM  ŌUL  SARŌRRNM  OTRRN  ŌRRNM  OTUS

`f111r.18`  daiin.shecthey.oteody.qochey.qokeey.chey.teey.qokeedy.qokeedy.cheol.lokeedy.lched
→ NUII?  PARSTARM  OTRONM  COSARM  COŌRRM  SARM  TRRM  COŌRRNM  COŌRRNM  SAROL  LOŌRRNM  LSARN

`f111r.19`  saiin.okeeol.qokeedy.lchey.lcheoekam.oaiin.cheky.qokeeodar.checthdy.qoted,l.loty
→ PUII?  OŌRROL  COŌRRNM  LSARM  LSARORŌUS  OUII?  SARŌM  COŌRRONUR  SARSTANM  COTRNL  LOTM

`f111r.20`  qokeey.qokeey.l[ch:a]edy.checthy.chedey.cheol.teedy.okeedy.qokeedy.okeey.cho,ol.l,kai@175;
→ COŌRRM  COŌRRM  LSARNM  SARSTAM  SARNRM  SAROL  TRRNM  OŌRRNM  COŌRRNM  OŌRRM  SAOOL  LŌUI

`f111r.21`  daiin.okar.ain.teey.oteey.ox,o,r,shey.chey,ky,deedy.cheo.dain.sheet.ar.al,l.cheotydy
→ NUII?  OŌUR  UI?  TRRM  OTRRM  O?ORPARM  SARMŌMNRRNM  SARO  NUI?  PARRT  UR  ULL  SAROTMNM

`f111r.22`  ssheo,l,keedy.dal.tched.checkhey.okey.qo,ain.qo,chedy.qokeor.okeey.keo,cthedy.qokey
→ PPAROLŌRRNM  NUL  TSARN  SARSŌARM  OŌRM  COUI?  COSARNM  COŌROR  OŌRRM  ŌROSTARNM  COŌRM

`f111r.23`  dshey.sheeckhy.qokeshey.keeshody.qokeey.qokedy.okain.shekal.okechedy.qokechedy
→ NPARM  PARRSŌAM  COŌRPARM  ŌRRPAONM  COŌRRM  COŌRNM  OŌUI?  PARŌUL  OŌRSARNM  COŌRSARNM

`f111r.24`  sain.chckhey.cheos.lchal.lkechey.okeey.lkechedy.oteodain.char.lky.lchr.ainai@175;
→ PUI?  SASŌARM  SAROP  LSAUL  LŌRSARM  OŌRRM  LŌRSARNM  OTRONUI?  SAUR  LŌM  LSAR  UI?UI

`f111r.25`  so,sheor.okeedy.oteeey.qokeey.qokeeo,s.chedar.alal.o{ikh}y.oxar.aiin.odaiin.chody
→ POPAROR  OŌRRNM  OTRRRM  COŌRRM  COŌRROP  SARNUR  ULUL  OIŌAM  O?UR  UII?  ONUII?  SAONM

`f111r.26`  soaiin.shecthy.oteodaiin.chedy.otedar.air,ykeey.shedain.l.chedy.qokeedy.qoteedaiin
→ POUII?  PARSTAM  OTRONUII?  SARNM  OTRNUR  UIRMŌRRM  PARNUI?  L  SARNM  COŌRRNM  COTRRNUII?

`f111r.27`  dar.sheod.qokeey.qokeody.otey.lkeedy.chl.lkeey.daiin.chedar.chedyteedain.olkal
→ NUR  PARON  COŌRRM  COŌRONM  OTRM  LŌRRNM  SAL  LŌRRM  NUII?  SARNUR  SARNMTRRNUI?  OLŌUL

`f111r.28`  qokeeol.shedy.qokeod.cheokeey.sheokar.shekeey.qotees.al,dain.chedy.qotain.alam
→ COŌRROL  PARNM  COŌRON  SAROŌRRM  PAROŌUR  PARŌRRM  COTRRP  ULNUI?  SARNM  COTUI?  ULUS

`f111r.29`  salkeedy.lkeedy.chckhy.rky.chey.okeeo.chr.al.ar.qokeedy.qokedy.qoteedy.qod
→ PULŌRRNM  LŌRRNM  SASŌAM  RŌM  SARM  OŌRRO  SAR  UL  UR  COŌRRNM  COŌRNM  COTRRNM  CON

`f111r.30`  qockhedy.qokeechy.qotchey.chtar.ar.chkeey.lkar.aiin.chedy.qokeey.q[o:?]irain
→ COSŌARNM  COŌRRSAM  COTSARM  SATUR  UR  SAŌRRM  LŌUR  UII?  SARNM  COŌRRM  COIRUI?

`f111r.31`  sheotchedy.shedain.shkeyqokeaiin.shkeody.qokeey.qokeedy.chkal.checthy
→ PAROTSARNM  PARNUI?  PAŌRMCOŌRUII?  PAŌRONM  COŌRRM  COŌRRNM  SAŌUL  SARSTAM

`f111r.32`  dsheeoteey.qokeeo.l,keey.tear.qoteey.qotain.cho,lkeeedy.lchechdy.qokechy
→ NPARROTRRM  COŌRRO  LŌRRM  TRUR  COTRRM  COTUI?  SAOLŌRRRNM  LSARSANM  COŌRSAM

`f111r.33`  qoeeeo.[s:d].ain.ar.ol,keey.lkair.cheda.chkal.keeodal.eees.chody.qokeedy,dl
→ CORRRO  P  UI?  UR  OLŌRRM  LŌUIR  SARNU  SAŌUL  ŌRRONUL  RRRP  SAONM  COŌRRNMNL

`f111r.34`  teo.olkeeo.al.lkeeey.olain.ar.akeom.qokain.al.qokeeod.lkedlkey.teedar
→ TRO  OLŌRRO  UL  LŌRRRM  OLUI?  UR  UŌROS  COŌUI?  UL  COŌRRON  LŌRNLŌRM  TRRNUR

`f111r.35`  y,chedl.ar,aiin.aiy.dam
→ MSARNL  URUII?  UIM  NUS

`f111r.36`  polal.shedal.pchedy.qofchedy.pykeor.cheefy.qopchey.opchedal.lfchedy,pchal
→ MOLUL  PARNUL  MSARNM  CO?SARNM  MMŌROR  SARR?M  COMSARM  OMSARNUL  L?SARNMMSAUL

`f111r.37`  dain.chol.l,cheeol,keeol.lkeeedy.qokeey.l.keedy.l,kedy.okeal.kain.chckhy.ltedy
→ NUI?  SAOL  LSARROLŌRROL  LŌRRRNM  COŌRRM  L  ŌRRNM  LŌRNM  OŌRUL  ŌUI?  SASŌAM  LTRNM

`f111r.38`  dched.daiin.al.okeey.kechedy.chcthedy.chedain.otedy.qokeedy,key.l.ltain
→ NSARN  NUII?  UL  OŌRRM  ŌRSARNM  SASTARNM  SARNUI?  OTRNM  COŌRRNMŌRM  L  LTUI?

`f111r.39`  saiin.chckhedy.okain.oteain.shok.qokechdy.okechedy.chedy.qokeey.cheamar
→ PUII?  SASŌARNM  OŌUI?  OTRUI?  PAOŌ  COŌRSANM  OŌRSARNM  SARNM  COŌRRM  SARUSUR

`f111r.40`  saiin.al,keey.okedain.otedy.qokeokedy.qokeedy.oteeolkeey.okeeo,l,lainal
→ PUII?  ULŌRRM  OŌRNUI?  OTRNM  COŌROŌRNM  COŌRRNM  OTRROLŌRRM  OŌRROLLUI?UL

`f111r.41`  ycheey.raiin.cheody.qokechy.qokeey.okedy.lchedy.qokeeal.daiin.otaral
→ MSARRM  RUII?  SARONM  COŌRSAM  COŌRRM  OŌRNM  LSARNM  COŌRRUL  NUII?  OTURUL

`f111r.42`  qokeol.qok[a:ee]l.qokeeol.cho,lkedy.l.chedy.chedy.chedyteokain.chedy.l,kag,am
→ COŌROL  COŌUL  COŌRROL  SAOLŌRNM  L  SARNM  SARNM  SARNMTROŌUI?  SARNM  LŌU?US

`f111r.43`  okeedy.lkeedy.lkedar.okeedy.chedy
→ OŌRRNM  LŌRRNM  LŌRNUR  OŌRRNM  SARNM

`f111r.44`  pchedar.oteeol.lkeedain.okeam.sheo.teolkedain.shal.keey.lteeal.cheal.oty
→ MSARNUR  OTRROL  LŌRRNUI?  OŌRUS  PARO  TROLŌRNUI?  PAUL  ŌRRM  LTRRUL  SARUL  OTM

`f111r.45`  oain.ain.keeey.teed.checkhed.iir.okeey.lkeeey.okeeo,lkeey.lkeey.lkeedy.qoky
→ OUI?  UI?  ŌRRRM  TRRN  SARSŌARN  IIR  OŌRRM  LŌRRRM  OŌRROLŌRRM  LŌRRM  LŌRRNM  COŌM

`f111r.46`  y.cheeo.lkeey.oteed.lkeedy.okeeshey.chey.lkar.al.olchal.or.aiin.che[o:?]m
→ M  SARRO  LŌRRM  OTRRN  LŌRRNM  OŌRRPARM  SARM  LŌUR  UL  OLSAUL  OR  UII?  SAROS

`f111r.47`  sheedy.qokeey.sheey.qoteedy.qeear.al.chedy.okeey.chedy
→ PARRNM  COŌRRM  PARRM  COTRRNM  CRRUR  UL  SARNM  OŌRRM  SARNM

`f111r.48`  poeokeey.lkeedy.tedain.shecthy.qokeedy.chckhy.lfchy.cheal.chepcham.daim
→ MOROŌRRM  LŌRRNM  TRNUI?  PARSTAM  COŌRRNM  SASŌAM  L?SAM  SARUL  SARMSAUS  NUIS

`f111r.49`  dcheey.keeey.qockhey.qokeey.lchedy,keeor.okeey.lkeedy.lkeey.qokaiin.ol
→ NSARRM  ŌRRRM  COSŌARM  COŌRRM  LSARNMŌRROR  OŌRRM  LŌRRNM  LŌRRM  COŌUII?  OL

`f111r.50`  okeey.l.chedy.cheekain.qokeeokain.chckhy.cheal,k[ee:ei]l.qokain.chckhal.lkal
→ OŌRRM  L  SARNM  SARRŌUI?  COŌRROŌUI?  SASŌAM  SARULŌRRL  COŌUI?  SASŌAUL  LŌUL

`f111r.51`  polkeeo,shey.cheokeain.chl,kar.r.aiin.char.?ain.al.lkeedy.qokal.okchy
→ MOLŌRROPARM  SAROŌRUI?  SALŌUR  R  UII?  SAUR  UI?  UL  LŌRRNM  COŌUL  OŌSAM

`f111r.52`  dair,al.qokeey.qokaiin.sheal.qokeain.shckhy.sain.chckhy.char.aiin.alom
→ NUIRUL  COŌRRM  COŌUII?  PARUL  COŌRUI?  PASŌAM  PUI?  SASŌAM  SAUR  UII?  ULOS

`f111r.53`  yshe.aiin.okshdy.shkeey,kain.chaiin.alolshey.qokaiin.chcthydain
→ MPAR  UII?  OŌPANM  PAŌRRMŌUI?  SAUII?  ULOLPARM  COŌUII?  SASTAMNUI?

`f111r.54`  tair.chckhaiin.dair.qokal.otain.okal
→ TUIR  SASŌAUII?  NUIR  COŌUL  OTUI?  OŌUL

### f111v  ·  stars

`f111v.1`  koshey.qokal.chckheal.opcheodair.alkain.sheokain.cheok.okeal,shedy.ralchy
→ ŌOPARM  COŌUL  SASŌARUL  OMSARONUIR  ULŌUI?  PAROŌUI?  SAROŌ  OŌRULPARNM  RULSAM

`f111v.2`  sheekeey.cheol.keedy.qokair.shecthy.qokeol.okechedy.qokedy.qopchedy.qokedam,chy
→ PARRŌRRM  SAROL  ŌRRNM  COŌUIR  PARSTAM  COŌROL  OŌRSARNM  COŌRNM  COMSARNM  COŌRNUSSAM

`f111v.3`  dain.chedy.shedal.otedy.otee[y:o].chedy.qokeey.dain.chcthar.otar.qotain.otaim
→ NUI?  SARNM  PARNUL  OTRNM  OTRRM  SARNM  COŌRRM  NUI?  SASTAUR  OTUR  COTUI?  OTUIS

`f111v.4`  daiin.chey.chokedair.air.alo,lshedy.qotedy.qokedar.oteedy.okedy.chedy.lkam
→ NUII?  SARM  SAOŌRNUIR  UIR  ULOLPARNM  COTRNM  COŌRNUR  OTRRNM  OŌRNM  SARNM  LŌUS

`f111v.5`  qokeed.o.aiin.otedy.qokedy.chedy.qokeey.qokeedy.qokeol.shedy.qotedal.lol
→ COŌRRN  O  UII?  OTRNM  COŌRNM  SARNM  COŌRRM  COŌRRNM  COŌROL  PARNM  COTRNUL  LOL

`f111v.6`  okeeo.okch[o:a]r.oteedy.cheal.qokeey.lkeey.chol.l.kaiin.oteedaiin.as,alkeedym
→ OŌRRO  OŌSAOR  OTRRNM  SARUL  COŌRRM  LŌRRM  SAOL  L  ŌUII?  OTRRNUII?  UPULŌRRNMS

`f111v.7`  qokeechey.qokaiin.oteaiin.fcheeo,l,kain.okeey.l,lcheedy.otal.kain.chedain,al
→ COŌRRSARM  COŌUII?  OTRUII?  ?SARROLŌUI?  OŌRRM  LLSARRNM  OTUL  ŌUI?  SARNUI?UL

`f111v.8`  sho.otchey.cheol,kechy.chcthey.okain.ol.l,keey.qokain.checkhy.chedar,am
→ PAO  OTSARM  SAROLŌRSAM  SASTARM  OŌUI?  OL  LŌRRM  COŌUI?  SARSŌAM  SARNURUS

`f111v.9`  lshey.shedal.okear.l,kedy.cheolkeey.lkey.okeey.qokeey.qokey.qokain.am
→ LPARM  PARNUL  OŌRUR  LŌRNM  SAROLŌRRM  LŌRM  OŌRRM  COŌRRM  COŌRM  COŌUI?  US

`f111v.10`  soiin.shed.qoksheo.lor.cheo.lol,aiin.shey.qokain.chear.qoteol.shcthy.ldy
→ POII?  PARN  COŌPARO  LOR  SARO  LOLUII?  PARM  COŌUI?  SARUR  COTROL  PASTAM  LNM

`f111v.11`  y,lcheey.shear.aiin.shee[a:o]r.otain.otedy.qokain.chedkain.shedaitain.shalg
→ MLSARRM  PARUR  UII?  PARRUR  OTUI?  OTRNM  COŌUI?  SARNŌUI?  PARNUITUI?  PAUL?

`f111v.12`  qear,ain.shey.okeeey.qokaiin.checkhy.sho.lchal.sh[ee:ea]y.shckhey.kshartar
→ CRURUI?  PARM  OŌRRRM  COŌUII?  SARSŌAM  PAO  LSAUL  PARRM  PASŌARM  ŌPAURTUR

`f111v.13`  sheaiin.okaiin.shckhy.cheol,kedy.chetar.okaiin.shal.lchdal,tedy.tar,amd
→ PARUII?  OŌUII?  PASŌAM  SAROLŌRNM  SARTUR  OŌUII?  PAUL  LSANULTRNM  TURUSN

`f111v.14`  qocheol.qokain.chear.ol.oin.shedy.qotaiin.qokeechy.olkeey.lkain.lal,[g:d]m
→ COSAROL  COŌUI?  SARUR  OL  OI?  PARNM  COTUII?  COŌRRSAM  OLŌRRM  LŌUI?  LUL?S

`f111v.15`  sar.she[y:o].l.otain.qokaiin.al.kain.chedy.otal.lchedy.qokain.chtal.otain.[?:l].l,s
→ PUR  PARM  L  OTUI?  COŌUII?  UL  ŌUI?  SARNM  OTUL  LSARNM  COŌUI?  SATUL  OTUI?  —  LP

`f111v.16`  qokain.sheol.qokain.shckhey.lchedy.okar,al.qotal.shedy.otain.far.aiin.am
→ COŌUI?  PAROL  COŌUI?  PASŌARM  LSARNM  OŌURUL  COTUL  PARNM  OTUI?  ?UR  UII?  US

`f111v.17`  solkain.shey.okaiin.sheey.qokain.chkal.chckhy.saiin.ar.lchal.she.otain
→ POLŌUI?  PARM  OŌUII?  PARRM  COŌUI?  SAŌUL  SASŌAM  PUII?  UR  LSAUL  PAR  OTUI?

`f111v.18`  tai[s:r].shedy.qoeedaiin.okain.{c'hh}ey,kaiin.shey.otain.alkain.o.l.r.ol.dain
→ TUIP  PARNM  CORRNUII?  OŌUI?  SAARMŌUII?  PARM  OTUI?  ULŌUI?  O  L  R  OL  NUI?

`f111v.19`  qokaiin.cheal.tain.qokain.shey.qokain.char.shcthey.qoky.chy.qokaiin
→ COŌUII?  SARUL  TUI?  COŌUI?  PARM  COŌUI?  SAUR  PASTARM  COŌM  SAM  COŌUII?

`f111v.20`  shain.qokal.shar.qoteal.qotain.chedy.qotain.shcthy.qokshedy.qotain.ar
→ PAUI?  COŌUL  PAUR  COTRUL  COTUI?  SARNM  COTUI?  PASTAM  COŌPARNM  COTUI?  UR

`f111v.21`  sair.air.ain.qol.rar.ain.cheey.lkeey.lkain.cheokain.sheo.qo.qokain.chear.alam
→ PUIR  UIR  UI?  COL  RUR  UI?  SARRM  LŌRRM  LŌUI?  SAROŌUI?  PARO  CO  COŌUI?  SARUR  ULUS

`f111v.22`  saiin.ychear.olsheey.chetain.chedy.qokain.okain.al.chan.okalchey.lkeeey
→ PUII?  MSARUR  OLPARRM  SARTUI?  SARNM  COŌUI?  OŌUI?  UL  SAU?  OŌULSARM  LŌRRRM

`f111v.23`  qokaiin.sheckhy.qokar.chalkain.chckhedy.lcheol.okaiin.qokain.cheol.daiin.lam
→ COŌUII?  PARSŌAM  COŌUR  SAULŌUI?  SASŌARNM  LSAROL  OŌUII?  COŌUI?  SAROL  NUII?  LUS

`f111v.24`  cheodain.qokar.otain.chedy.lkain.chey.shckhy.qokl.chedy.qokar.chctham
→ SARONUI?  COŌUR  OTUI?  SARNM  LŌUI?  SARM  PASŌAM  COŌL  SARNM  COŌUR  SASTAUS

`f111v.25`  tair.alchedar.shykaiin.chd[?:e][?:y]
→ TUIR  ULSARNUR  PAMŌUII?  SAN

`f111v.26`  polar,ar.okshey.qokain.chey,kal,keedy.qopchedy.qopchey.ltchs.alpchdar
→ MOLURUR  OŌPARM  COŌUI?  SARMŌULŌRRNM  COMSARNM  COMSARM  LTSAP  ULMSANUR

`f111v.27`  ol.sheey.tsheey.alkar.sheey.otain.ches.shy.qokl.chey.qoklcheor.ldar,llo
→ OL  PARRM  TPARRM  ULŌUR  PARRM  OTUI?  SARP  PAM  COŌL  SARM  COŌLSAROR  LNURLLO

`f111v.28`  qorchain.okain.chear.lkain
→ CORSAUI?  OŌUI?  SARUR  LŌUI?

`f111v.29`  polkiin.cheopaiin.otain.shedy.pchedy.opcheedy.qokain.chcfhey.otchey,lldy
→ MOLŌII?  SAROMUII?  OTUI?  PARNM  MSARNM  OMSARRNM  COŌUI?  SAS?ARM  OTSARMLLNM

`f111v.30`  shokar.okeokain.sheekain.qokain.chechey.qokeey.qetain.otain.ar.lkain.lky
→ PAOŌUR  OŌROŌUI?  PARRŌUI?  COŌUI?  SARSARM  COŌRRM  CRTUI?  OTUI?  UR  LŌUI?  LŌM

`f111v.31`  pochey.oteain.chekain.cheal.lain.chey.qokain.chey.lkain.chal.ldy.llm
→ MOSARM  OTRUI?  SARŌUI?  SARUL  LUI?  SARM  COŌUI?  SARM  LŌUI?  SAUL  LNM  LLS

`f111v.32`  tar.chey,tain.chkar.alkar.chey.qol.chedy.okain.chey.l,cheey.charan
→ TUR  SARMTUI?  SAŌUR  ULŌUR  SARM  COL  SARNM  OŌUI?  SARM  LSARRM  SAURU?

`f111v.33`  y,sh[eei:ea]l.[?:q]oair.ain.okan.sheain,y.qokan.chan.aman.cheal,char
→ MPARRIL  OUIR  UI?  OŌU?  PARUI?M  COŌU?  SAU?  USU?  SARULSAUR

`f111v.34`  polar.okar.teody.qokain.talol.tarol.opchedy.qotar.otar.chtal,sam
→ MOLUR  OŌUR  TRONM  COŌUI?  TULOL  TUROL  OMSARNM  COTUR  OTUR  SATULPUS

`f111v.35`  oain.okaiin.chcthy.lkain.lchey.lshekain.qotal.shedy.chkeey.lkeeed.lkain.y
→ OUI?  OŌUII?  SASTAM  LŌUI?  LSARM  LPARŌUI?  COTUL  PARNM  SAŌRRM  LŌRRRN  LŌUI?  M

`f111v.36`  shain.okaiin.chey.qokar.ar.ar.ain.olr.ar.olor
→ PAUI?  OŌUII?  SARM  COŌUR  UR  UR  UI?  OLR  UR  OLOR

`f111v.37`  polchey,lkarshar.ykain.qokain.shalky.dy.tor,chey.keedy.lteedy.r,aldl
→ MOLSARMLŌURPAUR  MŌUI?  COŌUI?  PAULŌM  NM  TORSARM  ŌRRNM  LTRRNM  RULNL

`f111v.38`  ycheey.o,aiin.checkhey.otain.qotl.chear.chedy.qokeey.okeedy.lkeey
→ MSARRM  OUII?  SARSŌARM  OTUI?  COTL  SARUR  SARNM  COŌRRM  OŌRRNM  LŌRRM

`f111v.39`  dsheey.qokal.chedy.chcthy.qokain.chedy.lkeey.shey.qokain.chedy.lchdy
→ NPARRM  COŌUL  SARNM  SASTAM  COŌUI?  SARNM  LŌRRM  PARM  COŌUI?  SARNM  LSANM

`f111v.40`  ykeeey.lkain.chckhy.chokain.chckhal.sheckhedy.qokeey.qokeedy.lchsl
→ MŌRRRM  LŌUI?  SASŌAM  SAOŌUI?  SASŌAUL  PARSŌARNM  COŌRRM  COŌRRNM  LSAPL

`f111v.41`  oteey,l,chedy.teeedy,lkeey.oteedy.okedy.chedy.qokeey.checthy.qotal
→ OTRRMLSARNM  TRRRNMLŌRRM  OTRRNM  OŌRNM  SARNM  COŌRRM  SARSTAM  COTUL

`f111v.42`  cheeo.l,keey.chear.qokeain.okeeor.cheedy.okain.chedy.chedy.teedy.lcheam
→ SARRO  LŌRRM  SARUR  COŌRUI?  OŌRROR  SARRNM  OŌUI?  SARNM  SARNM  TRRNM  LSARUS

`f111v.43`  ycheo,daiin.sheeky.chokeal.sheekar.okaiin.otain.chear.alo,laiin.chota[g:m]
→ MSARONUII?  PARRŌM  SAOŌRUL  PARRŌUR  OŌUII?  OTUI?  SARUR  ULOLUII?  SAOTU?

`f111v.44`  dain.teeodain.cheeal.olaiin.or
→ NUI?  TRRONUI?  SARRUL  OLUII?  OR

`f111v.45`  pollaiin.okain.sheal.pchedain.opchey.polshy.okshey.opchedy.qopchair.alky
→ MOLLUII?  OŌUI?  PARUL  MSARNUI?  OMSARM  MOLPAM  OŌPARM  OMSARNM  COMSAUIR  ULŌM

`f111v.46`  sol.chey.lkeey.rolkeey.chckhy.okeeey.lchedy.lkeain.checthy.qotainaly
→ POL  SARM  LŌRRM  ROLŌRRM  SASŌAM  OŌRRRM  LSARNM  LŌRUI?  SARSTAM  COTUI?ULM

`f111v.47`  sain.cheey.qokeey.cheytain.olain.ykeeedy.chekain.chckhey.lchar
→ PUI?  SARRM  COŌRRM  SARMTUI?  OLUI?  MŌRRRNM  SARŌUI?  SASŌARM  LSAUR

`f111v.48`  psalar.cheey.qekal.cheykaiin.tain.chal.al.skaiin.okchedy.opchdal.opchy
→ MPULUR  SARRM  CRŌUL  SARMŌUII?  TUI?  SAUL  UL  PŌUII?  OŌSARNM  OMSANUL  OMSAM

`f111v.49`  s[o:a]iry.cheey.chkain.chal.lor,sheey.qokain.okain.chey.qokain.o,keey
→ POIRM  SARRM  SAŌUI?  SAUL  LORPARRM  COŌUI?  OŌUI?  SARM  COŌUI?  OŌRRM

`f111v.50`  shaiin.qoiiin.okain.chey.qokeeey.okain.chees.ar.ol.loeees.otain.or
→ PAUII?  COIII?  OŌUI?  SARM  COŌRRRM  OŌUI?  SARRP  UR  OL  LORRRP  OTUI?  OR

`f111v.51`  sain.cheal.chckhy.okain.okal,aiin.choty.chckhy
→ PUI?  SARUL  SASŌAM  OŌUI?  OŌULUII?  SAOTM  SASŌAM

### f112r  ·  stars

`f112r.1`  folchey.qokeey.ykair.@185;arally.oteedal.or,aiin.chcphy
→ ?OLSARM  COŌRRM  MŌUIR  URULLM  OTRRNUL  ORUII?  SASMAM

`f112r.2`  saiin.oar.qolkaiin.otail.ol.olaiin.chol.otar
→ PUII?  OUR  COLŌUII?  OTUIL  OL  OLUII?  SAOL  OTUR

`f112r.3`  or,chedar.cheey.oteedy.oteedy.otaiin.oty.odys
→ ORSARNUR  SARRM  OTRRNM  OTRRNM  OTUII?  OTM  ONMP

`f112r.4`  qokeedy.chokain.otain.otar.chedy.taim.oram
→ COŌRRNM  SAOŌUI?  OTUI?  OTUR  SARNM  TUIS  ORUS

`f112r.5`  otair,o,kody.otody.otal.okeeey.otar.am.oain,oy
→ OTUIROŌONM  OTONM  OTUL  OŌRRRM  OTUR  US  OUI?OM

`f112r.6`  chedal.oteedy.okeey,qokeedy.olkeedy.oteeyoram
→ SARNUL  OTRRNM  OŌRRMCOŌRRNM  OLŌRRNM  OTRRMORUS

`f112r.7`  taiin.olkeedy.qoteo.l,oeey.keey.qokeey.oteedyram
→ TUII?  OLŌRRNM  COTRO  LORRM  ŌRRM  COŌRRM  OTRRNMRUS

`f112r.8`  sairo,r.e{th}edy.chol.qotchedy.dody.qokeeey.dairam
→ PUIROR  RTARNM  SAOL  COTSARNM  NONM  COŌRRRM  NUIRUS

`f112r.9`  saiin.ol.okeey.qokeey.[y:o],chedy.teedy.qokchy.qokar,y
→ PUII?  OL  OŌRRM  COŌRRM  MSARNM  TRRNM  COŌSAM  COŌURM

`f112r.10`  dair.al.chedy.qodain.dam
→ NUIR  UL  SARNM  CONUI?  NUS

`f112r.11`  tchedy.qoteey.qeol.qokeey.otey.qokeey.qokedy.chotyr
→ TSARNM  COTRRM  CROL  COŌRRM  OTRM  COŌRRM  COŌRNM  SAOTMR

`f112r.12`  dchedy.qo,otchedy.chdy.qokeey.qotain.oteedy.oteey.ror
→ NSARNM  COOTSARNM  SANM  COŌRRM  COTUI?  OTRRNM  OTRRM  ROR

`f112r.13`  sor,aiin.chdy.ches.qokeey.okeey.otaiin.chcthy.oteey,dy
→ PORUII?  SANM  SARP  COŌRRM  OŌRRM  OTUII?  SASTAM  OTRRMNM

`f112r.14`  soarar.al.chey.otaiin.okeedy.qokeey
→ POURUR  UL  SARM  OTUII?  OŌRRNM  COŌRRM

`f112r.15`  poar,alchar.octhy.otedy.qokeedy.okedy.pchedy.opamdy
→ MOURULSAUR  OSTAM  OTRNM  COŌRRNM  OŌRNM  MSARNM  OMUSNM

`f112r.16`  solol.she?dy.shol.qokeey.qokeeey.qokedain.otain.ar,amchg
→ POLOL  PARNM  PAOL  COŌRRM  COŌRRRM  COŌRNUI?  OTUI?  URUSSA?

`f112r.17`  qoeeea[r:n].she.olkeear.cheey.qor.cheo.ral.cheey.qokey.t[ee:a]y.am
→ CORRRUR  PAR  OLŌRRUR  SARRM  COR  SARO  RUL  SARRM  COŌRM  TRRM  US

`f112r.18`  saiin.al,key.chey.dalchd,aiin.okal.chody.chedy.cham
→ PUII?  ULŌRM  SARM  NULSANUII?  OŌUL  SAONM  SARNM  SAUS

`f112r.19`  polchdy.o,l.otal,y,raiin.sheky.qeey.qokey.qokeey.qoky,am
→ MOLSANM  OL  OTULMRUII?  PARŌM  CRRM  COŌRM  COŌRRM  COŌMUS

`f112r.20`  qoaiin.or.aiin.cheol.keody.qol.keol.okeeey.dal,aiin.ody
→ COUII?  OR  UII?  SAROL  ŌRONM  COL  ŌROL  OŌRRRM  NULUII?  ONM

`f112r.21`  sol,keedy.raiin.chcthey.okeedy.qoteedy.qeey.rair.al,sy
→ POLŌRRNM  RUII?  SASTARM  OŌRRNM  COTRRNM  CRRM  RUIR  ULPM

`f112r.22`  daichy.lchedy.qoinal
→ NUISAM  LSARNM  COI?UL

`f112r.23`  qoain.qoiin.olcheedy.dairiy.teedy.qopol.chdy.oteor.octhdy.otychey
→ COUI?  COII?  OLSARRNM  NUIRIM  TRRNM  COMOL  SANM  OTROR  OSTANM  OTMSARM

`f112r.24`  cheeteey.qokeeey.lkeey.okeedykey.lkedy.qokedy.otedy.otedy.lo
→ SARRTRRM  COŌRRRM  LŌRRM  OŌRRNMŌRM  LŌRNM  COŌRNM  OTRNM  OTRNM  LO

`f112r.25`  tedain.shedy.ochor.okchd.ykedy.kedy.chor.aiin.cheety.chcthy.okey
→ TRNUI?  PARNM  OSAOR  OŌSAN  MŌRNM  ŌRNM  SAOR  UII?  SARRTM  SASTAM  OŌRM

`f112r.26`  tockhy.chedy.chedam
→ TOSŌAM  SARNM  SARNUS

`f112r.27`  pcholkeedy.okchoiiin.aky.opchedy.kolfchdy.opchedy.lky.shty
→ MSAOLŌRRNM  OŌSAOIII?  UŌM  OMSARNM  ŌOL?SANM  OMSARNM  LŌM  PATM

`f112r.28`  ysheedy.sheokeedy.qokeedy.qokain.oteedy.chckhy.ytchedy.shara[m:r]
→ MPARRNM  PAROŌRRNM  COŌRRNM  COŌUI?  OTRRNM  SASŌAM  MTSARNM  PAURUS

`f112r.29`  sar.aiin.olshedy.chokeey.sal.okaiin.oteey.qokeey.olor,al.chealy
→ PUR  UII?  OLPARNM  SAOŌRRM  PUL  OŌUII?  OTRRM  COŌRRM  OLORUL  SARULM

`f112r.30`  tar.ar.cheokey.okeody.chol.ol.chedy.qokedy.cheom
→ TUR  UR  SAROŌRM  OŌRONM  SAOL  OL  SARNM  COŌRNM  SAROS

`f112r.31`  pair,al.keolor.okaiin.otain.oteey.lchedy.okeeor.oteor.karainy
→ MUIRUL  ŌROLOR  OŌUII?  OTUI?  OTRRM  LSARNM  OŌRROR  OTROR  ŌURUI?M

`f112r.32`  sor.ar,al.ar.s.alkeeor.ol,shedy.okeechy.qoiiin.oteey.ched,alam
→ POR  URUL  UR  P  ULŌRROR  OLPARNM  OŌRRSAM  COIII?  OTRRM  SARNULUS

`f112r.33`  sarol.okcheey.cphedy.shckhey.okeeor.chedy.shdal
→ PUROL  OŌSARRM  SMARNM  PASŌARM  OŌRROR  SARNM  PANUL

`f112r.34`  pair,ar.l,shdar.okechedy.qokar,aram.qotedy.araiin.qokchdy.opary
→ MUIRUR  LPANUR  OŌRSARNM  COŌURURUS  COTRNM  URUII?  COŌSANM  OMURM

`f112r.35`  sain.olaiin.qopchdy.qoky.okeal.chedy.okeey.otedy.ar.ar.okeedy
→ PUI?  OLUII?  COMSANM  COŌM  OŌRUL  SARNM  OŌRRM  OTRNM  UR  UR  OŌRRNM

`f112r.36`  sain.ol.checkhy.olchain.okeey.olam
→ PUI?  OL  SARSŌAM  OLSAUI?  OŌRRM  OLUS

`f112r.37`  pam.okaiin.olkedy.okedy.okeey.okeedy.keedar.otear.shkear.qoky
→ MUS  OŌUII?  OLŌRNM  OŌRNM  OŌRRM  OŌRRNM  ŌRRNUR  OTRUR  PAŌRUR  COŌM

`f112r.38`  sar.ain.olkeear.okeody.qok[?:a]iin.oteedy.qokey.okal,okedy
→ PUR  UI?  OLŌRRUR  OŌRONM  COŌII?  OTRRNM  COŌRM  OŌULOŌRNM

`f112r.39`  polkeedy.qopal.otedy.opal.aiin.okaiiin.sheody.yteokar.ogom
→ MOLŌRRNM  COMUL  OTRNM  OMUL  UII?  OŌUIII?  PARONM  MTROŌUR  O?OS

`f112r.40`  sain.okal.lkeedy.okar.okchedy.qokal.keedy.chkey.oty.oral
→ PUI?  OŌUL  LŌRRNM  OŌUR  OŌSARNM  COŌUL  ŌRRNM  SAŌRM  OTM  ORUL

`f112r.41`  yshesy.alain.cheey.okchey.qokchy.okchaiin.ykeeor.okeey.ory
→ MPARPM  ULUI?  SARRM  OŌSARM  COŌSAM  OŌSAUII?  MŌRROR  OŌRRM  ORM

`f112r.42`  pol,ar.shedy.qokaiin.[y:o].okeedy.qotal.chody.oteody.araryteop
→ MOLUR  PARNM  COŌUII?  M  OŌRRNM  COTUL  SAONM  OTRONM  URURMTROM

`f112r.43`  yteeo.r,aiin.okar.opor.aiin.ycheedy.q[ee:o]dar.yteeey.sheor.oteeg
→ MTRRO  RUII?  OŌUR  OMOR  UII?  MSARRNM  CRRNUR  MTRRRM  PAROR  OTRR?

`f112r.44`  sar.ain.qok[o:a]ekeeey.yk.[?:a]koeechey.okeeedy.alair.[a:o]kcheey.ar.arody
→ PUR  UI?  COŌORŌRRRM  MŌ  ŌORRSARM  OŌRRRNM  ULUIR  UŌSARRM  UR  URONM

`f112r.45`  yor.aiin.o,keeey,teey.shkar.oteeedyqokeey.okeey.okary.oin.yky
→ MOR  UII?  OŌRRRMTRRM  PAŌUR  OTRRRNMCOŌRRM  OŌRRM  OŌURM  OI?  MŌM

### f112v  ·  stars

`f112v.1`  keeoal,chool.opal.otalair,y.fcheol.oteey.qor.eees.am
→ ŌRROULSAOOL  OMUL  OTULUIRM  ?SAROL  OTRRM  COR  RRRP  US

`f112v.2`  oar.o[r:s]al.okeeshy.qokeey.okain.qokal.okeol.oty.oraiin
→ OUR  ORUL  OŌRRPAM  COŌRRM  OŌUI?  COŌUL  OŌROL  OTM  ORUII?

`f112v.3`  qokeeor.ar.sheey.or.ar.aiiin.okeey.l,keeody.sheedy.qotam
→ COŌRROR  UR  PARRM  OR  UR  UIII?  OŌRRM  LŌRRONM  PARRNM  COTUS

`f112v.4`  shody.qo.oeeeody.oteey.qokeedy.okeey.qokeedy.qoky.am
→ PAONM  CO  ORRRONM  OTRRM  COŌRRNM  OŌRRM  COŌRRNM  COŌM  US

`f112v.5`  sain.aiiin.okey.daiin.otal.chear.okedy.okaiin.cheeoldy
→ PUI?  UIII?  OŌRM  NUII?  OTUL  SARUR  OŌRNM  OŌUII?  SARROLNM

`f112v.6`  saiin.[o:a]l.oaiin.okeeedy.chea{ikh}y
→ PUII?  OL  OUII?  OŌRRRNM  SARUIŌAM

`f112v.7`  pcheokeey.oeeeky.qoteedy.oees,aiin.oteor.opchdar.opary
→ MSAROŌRRM  ORRRŌM  COTRRNM  ORRPUII?  OTROR  OMSANUR  OMURM

`f112v.8`  ocheor.okar.aiiin.otaiin.okal.okar.otal,kedy.chekaiiin
→ OSAROR  OŌUR  UIII?  OTUII?  OŌUL  OŌUR  OTULŌRNM  SARŌUIII?

`f112v.9`  soaiin.ar,aiin.okaiin.otaiin.cheekain.okchedy.qokchdy
→ POUII?  URUII?  OŌUII?  OTUII?  SARRŌUI?  OŌSARNM  COŌSANM

`f112v.10`  dain.sheey.okchedy,oror
→ NUI?  PARRM  OŌSARNMOROR

`f112v.11`  tchor.aiin.odeedy.oteeey.qokey.lody.chcfhy.ochos.aiin.olky
→ TSAOR  UII?  ONRRNM  OTRRRM  COŌRM  LONM  SAS?AM  OSAOP  UII?  OLŌM

`f112v.12`  daiin.al.olkeedain.oteey.sheeol.qokeedy.qochaiin.oteey,qoty
→ NUII?  UL  OLŌRRNUI?  OTRRM  PARROL  COŌRRNM  COSAUII?  OTRRMCOTM

`f112v.13`  dcheoty.oy.otchedy.chedy.daiin.chedal.chedy.qokaiin.otam
→ NSAROTM  OM  OTSARNM  SARNM  NUII?  SARNUL  SARNM  COŌUII?  OTUS

`f112v.14`  sain.air.a@175;.ykeedain.qokeedy.chedaiin.al[o:a]in
→ PUI?  UIR  U  MŌRRNUI?  COŌRRNM  SARNUII?  ULOI?

`f112v.15`  pchodain.okeedy.qokeedy.olkeedy.qokain.sheey.qokedar.aiin.am
→ MSAONUI?  OŌRRNM  COŌRRNM  OLŌRRNM  COŌUI?  PARRM  COŌRNUR  UII?  US

`f112v.16`  sa[iin:ir].okeey.sheey.qoteedy.qokey.chedy.qokeey.qokeey.chdaly
→ PUII?  OŌRRM  PARRM  COTRRNM  COŌRM  SARNM  COŌRRM  COŌRRM  SANULM

`f112v.17`  daiin.ch[ear:eeir].chedy.chy,keedy.chdaiin.cheedy.qokain.otaldal
→ NUII?  SARUR  SARNM  SAMŌRRNM  SANUII?  SARRNM  COŌUI?  OTULNUL

`f112v.18`  saiin.or,aiin.chey.qokeedy.qokeeey.qokeeody.qotam.olaiin,am
→ PUII?  ORUII?  SARM  COŌRRNM  COŌRRRM  COŌRRONM  COTUS  OLUII?US

`f112v.19`  s,arain.ain.al.qoeeey.qoteo.ar.aiiinol.chalor
→ PURUI?  UI?  UL  CORRRM  COTRO  UR  UIII?OL  SAULOR

`f112v.20`  pchoraiin.ar.alchedy.olkeedy.qokedy.qotaiin.chocthedy.saisal
→ MSAORUII?  UR  ULSARNM  OLŌRRNM  COŌRNM  COTUII?  SAOSTARNM  PUIPUL

`f112v.21`  saiin.chekain.cheol.qoeedy.chol.keedy.qokaiin.shedy.qokeol.kain
→ PUII?  SARŌUI?  SAROL  CORRNM  SAOL  ŌRRNM  COŌUII?  PARNM  COŌROL  ŌUI?

`f112v.22`  [s:e]oiin.ol.cheol.chedy.qokeey.chetain
→ POII?  OL  SAROL  SARNM  COŌRRM  SARTUI?

`f112v.23`  ycheol,keeor.olkeeey.chedain.ol.cheedaiin.sheedy.qokeedy.qotain
→ MSAROLŌRROR  OLŌRRRM  SARNUI?  OL  SARRNUII?  PARRNM  COŌRRNM  COTUI?

`f112v.24`  soiin.or.okain.otchedy.qokeedy.eeed[ee:a][g:d].ckhedy.cheedaiin.cheedy
→ POII?  OR  OŌUI?  OTSARNM  COŌRRNM  RRRNRR?  SŌARNM  SARRNUII?  SARRNM

`f112v.25`  pchdaiin.shedy.otaiin.cheedy.qokeeey.l,keeedy.cheey.lor.eeedy.qokeey
→ MSANUII?  PARNM  OTUII?  SARRNM  COŌRRRM  LŌRRRNM  SARRM  LOR  RRRNM  COŌRRM

`f112v.26`  ychedal.checkhey.checkhy.cheeol.qokeedy.qoteosam.chos
→ MSARNUL  SARSŌARM  SARSŌAM  SARROL  COŌRRNM  COTROPUS  SAOP

`f112v.27`  pchodain.aiin.teeedy.qoeey.okeedy.qokeear.al.okedal.olkeedy.qotedy
→ MSAONUI?  UII?  TRRRNM  CORRM  OŌRRNM  COŌRRUR  UL  OŌRNUL  OLŌRRNM  COTRNM

`f112v.28`  shey.keedal.aiin.cheol.keeeody.qoiin.ykeey.qokeeey.ykeey.qoeey.qokaim
→ PARM  ŌRRNUL  UII?  SAROL  ŌRRRONM  COII?  MŌRRM  COŌRRRM  MŌRRM  CORRM  COŌUIS

`f112v.29`  sheey.qoeekain.ol,kain.alor.chedal.sheody
→ PARRM  CORRŌUI?  OLŌUI?  ULOR  SARNUL  PARONM

`f112v.30`  polor.sheedy.okeedey.sal,aiin.sheedar.okedy.qopchedy.dalkedy.opchdy
→ MOLOR  PARRNM  OŌRRNRM  PULUII?  PARRNUR  OŌRNM  COMSARNM  NULŌRNM  OMSANM

`f112v.31`  tar,aiin.okeear.oteody.arar
→ TURUII?  OŌRRUR  OTRONM  URUR

`f112v.32`  tchedor.shee,keedy.otedar.checphey.qopchedy.qopcheey.kar.opcheeo,r,a{ify}
→ TSARNOR  PARRŌRRNM  OTRNUR  SARSMARM  COMSARNM  COMSARRM  ŌUR  OMSARRORUI?M

`f112v.33`  or.cheeor.okeedy.qokedy.qokeedy.chedaiin.okeeedy.otaiin.cheekey.chol
→ OR  SARROR  OŌRRNM  COŌRNM  COŌRRNM  SARNUII?  OŌRRRNM  OTUII?  SARRŌRM  SAOL

`f112v.34`  saiin.chedaiin.checkhy.lkeedy.qokeedy.chkaiin.checkhol.chdam
→ PUII?  SARNUII?  SARSŌAM  LŌRRNM  COŌRRNM  SAŌUII?  SARSŌAOL  SANUS

`f112v.35`  pched.shedain.qokaiin.okees.chedy.checkhy
→ MSARN  PARNUI?  COŌUII?  OŌRRP  SARNM  SARSŌAM

`f112v.36`  tchede.okeey.lky.shedaiiin.chdy.qokeedy.cheky.lkedy.qotedy.raram
→ TSARNR  OŌRRM  LŌM  PARNUIII?  SANM  COŌRRNM  SARŌM  LŌRNM  COTRNM  RURUS

`f112v.37`  teedal.sain.ar.otaiin.shedy.qokedaiin.ar.qokaiin.chol,kedy.qokam
→ TRRNUL  PUI?  UR  OTUII?  PARNM  COŌRNUII?  UR  COŌUII?  SAOLŌRNM  COŌUS

`f112v.38`  sa.ar,oiin.okchey.al.chedy.chol.otaiin.chedar.lkain.cheo,dain
→ PU  UROII?  OŌSARM  UL  SARNM  SAOL  OTUII?  SARNUR  LŌUI?  SARONUI?

`f112v.39`  teodarody.opcheed.okaiin.chaiin.otam.oteedy.qoteey.qotain.chcthd
→ TRONURONM  OMSARRN  OŌUII?  SAUII?  OTUS  OTRRNM  COTRRM  COTUI?  SASTAN

`f112v.40`  y,cheol.lchedy.chckhy.cheolchal.shchy.daiin.cheolor.okain.chedy.daiin
→ MSAROL  LSARNM  SASŌAM  SAROLSAUL  PASAM  NUII?  SAROLOR  OŌUI?  SARNM  NUII?

`f112v.41`  ykeedan.checkhey.oain.chol
→ MŌRRNU?  SARSŌARM  OUI?  SAOL

`f112v.42`  p[o:a]ly.keedain.she,kchdy.chotshe.otechy.qokchdy.otara[y:g].shain.qokedy
→ MOLM  ŌRRNUI?  PARŌSANM  SAOTPAR  OTRSAM  COŌSANM  OTURUM  PAUI?  COŌRNM

`f112v.43`  ooeeor.oeeal.olkeol.al.chol.chl,olchedy.ykeedy.chtal.kar.opchy.famam
→ OORROR  ORRUL  OLŌROL  UL  SAOL  SALOLSARNM  MŌRRNM  SATUL  ŌUR  OMSAM  ?USUS

`f112v.44`  qokchal.qokey.qaiin.otol.teol.okal.otedar.epalchdy.alpchdy
→ COŌSAUL  COŌRM  CUII?  OTOL  TROL  OŌUL  OTRNUR  RMULSANM  ULMSANM

`f112v.45`  ycheey.chokeey.okasal.tchdy.oteol.chcthy.alaiin.char.al.kamdam
→ MSARRM  SAOŌRRM  OŌUPUL  TSANM  OTROL  SASTAM  ULUII?  SAUR  UL  ŌUSNUS

`f112v.46`  ykeey.lor.chaiin.cheky.chokain.char,am.chey.kain.chdal.okaiin.daldy
→ MŌRRM  LOR  SAUII?  SARŌM  SAOŌUI?  SAURUS  SARM  ŌUI?  SANUL  OŌUII?  NULNM

`f112v.47`  [?:e].otar.aig.oaral.alor.aiiin.olkaiin.oty.ary
→ —  OTUR  UI?  OURUL  ULOR  UIII?  OLŌUII?  OTM  URM

### f113r  ·  stars

`f113r.1`  pches@186;chy.ypcheedy.fchdy.chetar.qopchedaiin.oteey.oty.lkchy.chodain.alar.chedy
→ MSARPSAM  MMSARRNM  ?SANM  SARTUR  COMSARNUII?  OTRRM  OTM  LŌSAM  SAONUI?  ULUR  SARNM

`f113r.2`  dar.okeedy.oteeody.qokedy.otchechy.okeorl.al,keeos.ched.al.ar.ch{ckhh}y.ykolairol
→ NUR  OŌRRNM  OTRRONM  COŌRNM  OTSARSAM  OŌRORL  ULŌRROP  SARN  UL  UR  SASŌAAM  MŌOLUIROL

`f113r.3`  shchs.oal.chs,aiin.oteeosy
→ PASAP  OUL  SAPUII?  OTRROPM

`f113r.4`  kcheeos.olkeedy.shoaiin.cheeody.qokchedy.chckhody.qokedy.qotaly.lkar.ar,al,om
→ ŌSARROP  OLŌRRNM  PAOUII?  SARRONM  COŌSARNM  SASŌAONM  COŌRNM  COTULM  LŌUR  URULOS

`f113r.5`  ycheeckhy.osaiin.cheoar.qokaiin.chekal.otar.shos,aiin.chckhy.chd[o:y].okol,chedy.chedy
→ MSARRSŌAM  OPUII?  SAROUR  COŌUII?  SARŌUL  OTUR  PAOPUII?  SASŌAM  SANO  OŌOLSARNM  SARNM

`f113r.6`  sor.cheo.cheey.oteeos.aiin.otain.otal.ches.aiin.alchl,sheey.kchol.okeeo.l.kaiin.ol
→ POR  SARO  SARRM  OTRROP  UII?  OTUI?  OTUL  SARP  UII?  ULSALPARRM  ŌSAOL  OŌRRO  L  ŌUII?  OL

`f113r.7`  chos.sheey.qokchey.sokal.okeey.char.laiin.olkain
→ SAOP  PARRM  COŌSARM  POŌUL  OŌRRM  SAUR  LUII?  OLŌUI?

`f113r.8`  pchosos.cheoarkeeol.qokeey.lkchey.qokar.chos.shey.qopchy.rchsy.chykeor.otal
→ MSAOPOP  SAROURŌRROL  COŌRRM  LŌSARM  COŌUR  SAOP  PARM  COMSAM  RSAPM  SAMŌROR  OTUL

`f113r.9`  dchos,aiin.oteey.qokaiin.cho.okaiin.cheodaiin.[a:?]ky.le.chody.chotaiin
→ NSAOPUII?  OTRRM  COŌUII?  SAO  OŌUII?  SARONUII?  UŌM  LR  SAONM  SAOTUII?

`f113r.10`  pcheody.qokeody.cheoar.chy.kcheeor.ety.sheody.sheodaiin.qoteoar.otam.otchedy.qoty
→ MSARONM  COŌRONM  SAROUR  SAM  ŌSARROR  RTM  PARONM  PARONUII?  COTROUR  OTUS  OTSARNM  COTM

`f113r.11`  daiin.cholchey.okecheey.chokeo,l,sheo.qoaiin.shoo.keeeol.keody.chor.chor.kal.laram
→ NUII?  SAOLSARM  OŌRSARRM  SAOŌROLPARO  COUII?  PAOO  ŌRRROL  ŌRONM  SAOR  SAOR  ŌUL  LURUS

`f113r.12`  y,shoain.qoeey.qoaiin.shol.lkeeoar.chodaiin.otam.chos,aiin
→ MPAOUI?  CORRM  COUII?  PAOL  LŌRROUR  SAONUII?  OTUS  SAOPUII?

`f113r.13`  polchor.cheody.qotedy.lkeches.l,keeol.lkcheol.lkchedy.kotchy.lpchedy.qopchedy.ro
→ MOLSAOR  SARONM  COTRNM  LŌRSARP  LŌRROL  LŌSAROL  LŌSARNM  ŌOTSAM  LMSARNM  COMSARNM  RO

`f113r.14`  ycheo.lkchey.l,chol.oiiin.qoksheoy.qokcheody.lcheo.l,kchedy.chokchy.okchdar.al
→ MSARO  LŌSARM  LSAOL  OIII?  COŌPAROM  COŌSARONM  LSARO  LŌSARNM  SAOŌSAM  OŌSANUR  UL

`f113r.15`  chol.chs.s,aiin.chaiiin
→ SAOL  SAP  PUII?  SAUIII?

`f113r.16`  pcheoor.olkeedy.qokeedy.shdy.qofchedy.chcfhor.chedy.qokeeol.por.aiin.chepchar
→ MSAROOR  OLŌRRNM  COŌRRNM  PANM  CO?SARNM  SAS?AOR  SARNM  COŌRROL  MOR  UII?  SARMSAUR

`f113r.17`  dor.shar.shol.qokeey.qok,chol.chedaiin.qoky.chokain.chotar.chokar.char.alom
→ NOR  PAUR  PAOL  COŌRRM  COŌSAOL  SARNUII?  COŌM  SAOŌUI?  SAOTUR  SAOŌUR  SAUR  ULOS

`f113r.18`  ycheod.cheoaiin.chal.olkaiin.chkaiin.cheeey.lkeeo.aiiin.okeedy.qokcheey.rchedy
→ MSARON  SAROUII?  SAUL  OLŌUII?  SAŌUII?  SARRRM  LŌRRO  UIII?  OŌRRNM  COŌSARRM  RSARNM

`f113r.19`  yhal.cheeo.rlaiin.chckhey.cheol
→ MAUL  SARRO  RLUII?  SASŌARM  SAROL

`f113r.20`  kshoraiin.qokeeoar.shoteol.lklcheol.qokar.chdain.cpho{ith}y.chor.aiin.ckhydy
→ ŌPAORUII?  COŌRROUR  PAOTROL  LŌLSAROL  COŌUR  SANUI?  SMAOITAM  SAOR  UII?  SŌAMNM

`f113r.21`  oiir.shol.shedair.otchdy.shokchy.shaiiin.shckhey.lshor.air.okeody
→ OIIR  PAOL  PARNUIR  OTSANM  PAOŌSAM  PAUIII?  PASŌARM  LPAOR  UIR  OŌRONM

`f113r.22`  tchoar.sheeodaiin.chkaiin.otchod.okchedy.qokaiin.cho[k:t]ain.sheor.qokchy.qopam
→ TSAOUR  PARRONUII?  SAŌUII?  OTSAON  OŌSARNM  COŌUII?  SAOŌUI?  PAROR  COŌSAM  COMUS

`f113r.23`  ykeoeshy.qokaiin.chal.kiin.chckhey.lkchey.qokal.chocthy.lkchor.lkchedy.lkaiin
→ MŌRORPAM  COŌUII?  SAUL  ŌII?  SASŌARM  LŌSARM  COŌUL  SAOSTAM  LŌSAOR  LŌSARNM  LŌUII?

`f113r.24`  dair.chor.chopchey.araiin.or.ral.arody
→ NUIR  SAOR  SAOMSARM  URUII?  OR  RUL  URONM

`f113r.25`  pchedair.shotedy.qopchody.chfchol.kchdaiin.chpchshdy.rair.shedy.qokchey.sairy
→ MSARNUIR  PAOTRNM  COMSAONM  SA?SAOL  ŌSANUII?  SAMSAPANM  RUIR  PARNM  COŌSARM  PUIRM

`f113r.26`  tol.cheshy.lkchedy.lchod.chal.char,lkeeody.oteeo.loaiin.okeedy
→ TOL  SARPAM  LŌSARNM  LSAON  SAUL  SAURLŌRRONM  OTRRO  LOUII?  OŌRRNM

`f113r.27`  tchol.chol.lsheol.shor.kcheey.y,raiin.sheol.tcheody.tchey.sheoky.lpchedy.qokam
→ TSAOL  SAOL  LPAROL  PAOR  ŌSARRM  MRUII?  PAROL  TSARONM  TSARM  PAROŌM  LMSARNM  COŌUS

`f113r.28`  sar.al.chal.os.akchy.daiin.cheeeo,rain.otain.chol.lcholkaiin.cheokedy.loda[s:r]
→ PUR  UL  SAUL  OP  UŌSAM  NUII?  SARRRORUI?  OTUI?  SAOL  LSAOLŌUII?  SAROŌRNM  LONUP

`f113r.29`  y,sheeoaiin.olkeeol.chtchol.kcheody.lkchedy.okaiin.chal.taiin.oteedy
→ MPARROUII?  OLŌRROL  SATSAOL  ŌSARONM  LŌSARNM  OŌUII?  SAUL  TUII?  OTRRNM

`f113r.30`  folchear.oteol.lshedy.lkshedy.sheeeky.otar.qchar.tar.shkchedy.qokchd.opy
→ ?OLSARUR  OTROL  LPARNM  LŌPARNM  PARRRŌM  OTUR  CSAUR  TUR  PAŌSARNM  COŌSAN  OMM

`f113r.31`  ytaiin.okaiin.chear.ckhar.shal.shckhy.okain.o,{kh}ar.chor.cky.chokain.qoky
→ MTUII?  OŌUII?  SARUR  SŌAUR  PAUL  PASŌAM  OŌUI?  OŌAUR  SAOR  SŌM  SAOŌUI?  COŌM

`f113r.32`  shodaiin.shkaiin.chcthal.okshedy.otal.okaiin.cphoal.otain.okaiin.chedy.qotal
→ PAONUII?  PAŌUII?  SASTAUL  OŌPARNM  OTUL  OŌUII?  SMAOUL  OTUI?  OŌUII?  SARNM  COTUL

`f113r.33`  ykeeor.chear.okain.chear.chockhy
→ MŌRROR  SARUR  OŌUI?  SARUR  SAOSŌAM

`f113r.34`  palshsar.lshdaiin.otshsaiin.shocfhy.qopchear.shkair.qopchdy.qoteedy.rchedy.ldy
→ MULPAPUR  LPANUII?  OTPAPUII?  PAOS?AM  COMSARUR  PAŌUIR  COMSANM  COTRRNM  RSARNM  LNM

`f113r.35`  y,sh,s,sheeo,lkeeos.aiin.qokeees.okchedy.qotaiin.otar.okar.ockhy.rchdy.qosain
→ MPAPPARROLŌRROP  UII?  COŌRRRP  OŌSARNM  COTUII?  OTUR  OŌUR  OSŌAM  RSANM  COPUI?

`f113r.36`  dcheey.sheody.shedain
→ NSARRM  PARONM  PARNUI?

`f113r.37`  tshedy.qokaiin.shedar.sheocphy.okchdy.pcheody.opchear.opchedy.lfchedy.otal
→ TPARNM  COŌUII?  PARNUR  PAROSMAM  OŌSANM  MSARONM  OMSARUR  OMSARNM  L?SARNM  OTUL

`f113r.38`  daiin.sheor.qoteey.daiin.okchedy.sheo[s:r].aiin
→ NUII?  PAROR  COTRRM  NUII?  OŌSARNM  PAROP  UII?

`f113r.39`  pcheockhy.l,kchey.qofsheeey.lkeody.kcheodaiin.por,shed,qopoeey.pokeey.rair,aly
→ MSAROSŌAM  LŌSARM  CO?PARRRM  LŌRONM  ŌSARONUII?  MORPARNCOMORRM  MOŌRRM  RUIRULM

`f113r.40`  tarar.cheey.cheokeol.chcheey.cthes.aiin.ctheey.ctharad.shee.qo,tchey.taram
→ TURUR  SARRM  SAROŌROL  SASARRM  STARP  UII?  STARRM  STAURUN  PARR  COTSARM  TURUS

`f113r.41`  dsheo.oin.okaiin.cheey.taiin.lkeechey.okain.sheey.qoees.[o:e]keeody
→ NPARO  OI?  OŌUII?  SARRM  TUII?  LŌRRSARM  OŌUI?  PARRM  CORRP  OŌRRONM

`f113r.42`  pcheodaiin.sholkeechy.ar.alkar.otchedy.cheol.tcheor.qokchedy.pchor.aral
→ MSARONUII?  PAOLŌRRSAM  UR  ULŌUR  OTSARNM  SAROL  TSAROR  COŌSARNM  MSAOR  URUL

`f113r.43`  ykcheor.sheeod.lkar.ar.al.s.aiin.cheeey.ol.chedy.lchey.lkar,am.chedam
→ MŌSAROR  PARRON  LŌUR  UR  UL  P  UII?  SARRRM  OL  SARNM  LSARM  LŌURUS  SARNUS

`f113r.44`  cheeky.lkedy.chedy.lkaiin
→ SARRŌM  LŌRNM  SARNM  LŌUII?

`f113r.45`  tchodairos.or.chey.qotaiin.opchey.chtaiir.shedy.qotor.sheol.qotody.tedy
→ TSAONUIROP  OR  SARM  COTUII?  OMSARM  SATUIIR  PARNM  COTOR  PAROL  COTONM  TRNM

`f113r.46`  oaiin.cheokeeas.lkaiin.chkal,kar.cheeody.qokeeody.qokeey.chos,araiinol
→ OUII?  SAROŌRRUP  LŌUII?  SAŌULŌUR  SARRONM  COŌRRONM  COŌRRM  SAOPURUII?OL

`f113r.47`  y,sheol.keechey.cholkeedy.qokaiin.chedal.l.kches.ar.okain.qokaiin.oram
→ MPAROL  ŌRRSARM  SAOLŌRRNM  COŌUII?  SARNUL  L  ŌSARP  UR  OŌUI?  COŌUII?  ORUS

`f113r.48`  tcho,arorshy.qokaiin.shey.ch{ckhh}y.sheolkchy.qokeol.kaiin.checkhy.ralchs
→ TSAOURORPAM  COŌUII?  PARM  SASŌAAM  PAROLŌSAM  COŌROL  ŌUII?  SARSŌAM  RULSAP

`f113r.49`  sain.cheeey.cheo.kcheey.qokeey.lkeeey.okeeey.lkchey.lcho,r,aiin.otain.al
→ PUI?  SARRRM  SARO  ŌSARRM  COŌRRM  LŌRRRM  OŌRRRM  LŌSARM  LSAORUII?  OTUI?  UL

`f113r.50`  tchedy.okeey.cheeos.lkaiin.chey.otain.cheeody.qokeeody.okaiin.oteedy
→ TSARNM  OŌRRM  SARROP  LŌUII?  SARM  OTUI?  SARRONM  COŌRRONM  OŌUII?  OTRRNM

`f113r.51`  ykeeol.qokaiin.olkal.airody.okaiin.okalal.loary
→ MŌRROL  COŌUII?  OLŌUL  UIRONM  OŌUII?  OŌULUL  LOURM

### f113v  ·  stars

`f113v.1`  folorarom.otchey.qotar.air.otair.opchedy.qokeedody.chey,keeoy.rol.lkar.ch[s:r]om,oky
→ ?OLORUROS  OTSARM  COTUR  UIR  OTUIR  OMSARNM  COŌRRNONM  SARMŌRROM  ROL  LŌUR  SAPOSOŌM

`f113v.2`  teoar.ain.qotar.ycheey.otaiir.otaiin.okchy.lkchdy.oteol.ar.al.ar,aiin.okal.cheyor
→ TROUR  UI?  COTUR  MSARRM  OTUIIR  OTUII?  OŌSAM  LŌSANM  OTROL  UR  UL  URUII?  OŌUL  SARMOR

`f113v.3`  sar,aiin.chotar.okeeodar.qokain.olol,olam
→ PURUII?  SAOTUR  OŌRRONUR  COŌUI?  OLOLOLUS

`f113v.4`  fchoctheody.keeodar.oteedy.rchedy.qokechy.otcher.oparaiin.oteody.otaiin.otl.aroshy
→ ?SAOSTARONM  ŌRRONUR  OTRRNM  RSARNM  COŌRSAM  OTSARR  OMURUII?  OTRONM  OTUII?  OTL  UROPAM

`f113v.5`  dcheos.otaiin.otedy.otodaiin.qokeey.rcheey.qoeear.oteedy.qokeedy.otedar.ar.ot.otees.al
→ NSAROP  OTUII?  OTRNM  OTONUII?  COŌRRM  RSARRM  CORRUR  OTRRNM  COŌRRNM  OTRNUR  UR  OT  OTRRP  UL

`f113v.6`  tcheolchy.lcheol.chockhy.cheoda?daiin
→ TSAROLSAM  LSAROL  SAOSŌAM  SARONUNUII?

`f113v.7`  fcheshd,teody.lkeeody.oteedy.lchealaim.shockhol.opchedy.qotaiin.otar,ar,al.oteal
→ ?SARPANTRONM  LŌRRONM  OTRRNM  LSARULUIS  PAOSŌAOL  OMSARNM  COTUII?  OTURURUL  OTRUL

`f113v.8`  ycheody.qokeeor.choltar.olkam.chokam.odal.sheckhy.qokchedy.otor.otar.toky
→ MSARONM  COŌRROR  SAOLTUR  OLŌUS  SAOŌUS  ONUL  PARSŌAM  COŌSARNM  OTOR  OTUR  TOŌM

`f113v.9`  dair.ar.okaiin.chokaiin.checkhol.cholkaiin.olchy
→ NUIR  UR  OŌUII?  SAOŌUII?  SARSŌAOL  SAOLŌUII?  OLSAM

`f113v.10`  polaiin.oteol.otedyar.aral.kedy.qokeedy.olar,aiin.kchey.dal.otor.ar.opchey.ro
→ MOLUII?  OTROL  OTRNMUR  URUL  ŌRNM  COŌRRNM  OLURUII?  ŌSARM  NUL  OTOR  UR  OMSARM  RO

`f113v.11`  orsheor.oteeo,cheey.olkeey.otal.chotair.otar.qotar.okar.oko.lkedal.ram
→ ORPAROR  OTRROSARRM  OLŌRRM  OTUL  SAOTUIR  OTUR  COTUR  OŌUR  OŌO  LŌRNUL  RUS

`f113v.12`  solchedy.otsheody.arl.olchey.oror
→ POLSARNM  OTPARONM  URL  OLSARM  OROR

`f113v.13`  poraiin.otar.ar.okol.shedy.qokchedy.otchdy.qotor.qoteedar.roral.fchee,llor
→ MORUII?  OTUR  UR  OŌOL  PARNM  COŌSARNM  OTSANM  COTOR  COTRRNUR  RORUL  ?SARRLLOR

`f113v.14`  dar.al.sheey.qotaiin.chor.cthol.okeshos.olchedy.qokaiin.okal.o,kaiin.olo
→ NUR  UL  PARRM  COTUII?  SAOR  STAOL  OŌRPAOP  OLSARNM  COŌUII?  OŌUL  OŌUII?  OLO

`f113v.15`  @187;ar,ar.okeey.oeky.otcheedaiin.ol.tchdy.pche[o:a]l.kcheor.@206;aiin.cheey.qokaram
→ URUR  OŌRRM  ORŌM  OTSARRNUII?  OL  TSANM  MSAROL  ŌSAROR  UII?  SARRM  COŌURUS

`f113v.16`  daiin.chl.l,keey.lkaiin.chdain.qokain.{ch'}eor.okalchedy.qokar.olkam.ar
→ NUII?  SAL  LŌRRM  LŌUII?  SANUI?  COŌUI?  SAROR  OŌULSARNM  COŌUR  OLŌUS  UR

`f113v.17`  saraiin.shedy.lcheey.olkar.okaiin.cthororaiin.yteeeor
→ PURUII?  PARNM  LSARRM  OLŌUR  OŌUII?  STAORORUII?  MTRRROR

`f113v.18`  pychdar.chckhedy.otshedy.tcheepchey.lky.lkches.qokody.lkeshdy.fchocthor.opam
→ MMSANUR  SASŌARNM  OTPARNM  TSARRMSARM  LŌM  LŌSARP  COŌONM  LŌRPANM  ?SAOSTAOR  OMUS

`f113v.19`  daiin.qokeeody.qokar.okaiin.qokaiin.okar.checthy.okal,ched.lchal.qckham
→ NUII?  COŌRRONM  COŌUR  OŌUII?  COŌUII?  OŌUR  SARSTAM  OŌULSARN  LSAUL  CSŌAUS

`f113v.20`  lkaiin.ch{ckhh}y.chody.otchar.ar.otary.ol,aiin
→ LŌUII?  SASŌAAM  SAONM  OTSAUR  UR  OTURM  OLUII?

`f113v.21`  polaiin.otar.qotain.chtol.tarol.cheol.kaiin.chp,kcheos.okar.a{ith}ar,lo
→ MOLUII?  OTUR  COTUI?  SATOL  TUROL  SAROL  ŌUII?  SAMŌSAROP  OŌUR  UITAURLO

`f113v.22`  okaiin.okaiin.ch[ee:a]ky.raiin.olal.okaiin.cheody.okaiin.okaiin.otar.aly
→ OŌUII?  OŌUII?  SARRŌM  RUII?  OLUL  OŌUII?  SARONM  OŌUII?  OŌUII?  OTUR  ULM

`f113v.23`  ykaiin.al,kar.okain.qokaiin.chakair.okar.al.cheody.qokor.otal.lkl.lol
→ MŌUII?  ULŌUR  OŌUI?  COŌUII?  SAUŌUIR  OŌUR  UL  SARONM  COŌOR  OTUL  LŌL  LOL

`f113v.24`  olkeey.lcheey.loar.cheos
→ OLŌRRM  LSARRM  LOUR  SAROP

`f113v.25`  tokary.lkchey,lkeedy.otey.pcheol.qopchey.cthol.opaiin.ol.keeor.opshedy.qotam
→ TOŌURM  LŌSARMLŌRRNM  OTRM  MSAROL  COMSARM  STAOL  OMUII?  OL  ŌRROR  OMPARNM  COTUS

`f113v.26`  okiin.al,keechy.qoteeol.otar.ar.otchey.otaiin.al.otaiin.otol.qotody.loty
→ OŌII?  ULŌRRSAM  COTRROL  OTUR  UR  OTSARM  OTUII?  UL  OTUII?  OTOL  COTONM  LOTM

`f113v.27`  y,cheeo,l,cheeo.alkeedy
→ MSARROLSARRO  ULŌRRNM

`f113v.28`  paiir.oteey.l,kaiin.o{i'h}ox.arash.{oph}eey.cphedy.opcheody.okalchdy.qotol.oky
→ MUIIR  OTRRM  LŌUII?  OIAO?  URUPA  OMARRM  SMARNM  OMSARONM  OŌULSANM  COTOL  OŌM

`f113v.29`  ykeeol.chedy.qokeey.olkeeey.okaiin.a,r.cthey.okaiin.al.lor.air.aralg
→ MŌRROL  SARNM  COŌRRM  OLŌRRRM  OŌUII?  UR  STARM  OŌUII?  UL  LOR  UIR  URUL?

`f113v.30`  ysheey.qoeey.or.aiiin.okeeo,l.otain.ar.ol.okaiiin.aiin.shody.otcham
→ MPARRM  CORRM  OR  UIII?  OŌRROL  OTUI?  UR  OL  OŌUIII?  UII?  PAONM  OTSAUS

`f113v.31`  daiiin.cheol.teeoar.shek.lchedy.okaiin.chckhaiin.otaiin.otaiin.araral
→ NUIII?  SAROL  TRROUR  PARŌ  LSARNM  OŌUII?  SASŌAUII?  OTUII?  OTUII?  URURUL

`f113v.32`  sheo,l.keey.qokain.char.ar.olar.aiiin.okar
→ PAROL  ŌRRM  COŌUI?  SAUR  UR  OLUR  UIII?  OŌUR

`f113v.33`  pol[s:r]airy.oteo.qokeedy.qokaiin.okal.qofcheol.qokaiin.opalor.lkch.ofch[r:s]
→ MOLPUIRM  OTRO  COŌRRNM  COŌUII?  OŌUL  CO?SAROL  COŌUII?  OMULOR  LŌSA  O?SAR

`f113v.34`  daiin.cheaiin.okchey.cheky.qokain.otecheedy.qokaiin.chckhey.chearam
→ NUII?  SARUII?  OŌSARM  SARŌM  COŌUI?  OTRSARRNM  COŌUII?  SASŌARM  SARURUS

`f113v.35`  qokaiin.air.lo,r.chedy.otain
→ COŌUII?  UIR  LOR  SARNM  OTUI?

`f113v.36`  ofaral.olkaiin.okar.okeeedy.tshedy.qokeedy.otchey,p,chedy.tsho.lteam
→ O?URUL  OLŌUII?  OŌUR  OŌRRRNM  TPARNM  COŌRRNM  OTSARMMSARNM  TPAO  LTRUS

`f113v.37`  qol.aiin.olaiin.oteeey.lchedy.qokair.y,daiin
→ COL  UII?  OLUII?  OTRRRM  LSARNM  COŌUIR  MNUII?

`f113v.38`  pcholky.otar.airol.okeedy.chokor.sheedy.oteey.teear.otorsheey.qoteal
→ MSAOLŌM  OTUR  UIROL  OŌRRNM  SAOŌOR  PARRNM  OTRRM  TRRUR  OTORPARRM  COTRUL

`f113v.39`  osheol.cheol.ar.aloiiin.oteeey.otain.chekey.qokain.chcthy.qotam,lr
→ OPAROL  SAROL  UR  ULOIII?  OTRRRM  OTUI?  SARŌRM  COŌUI?  SASTAM  COTUSLR

`f113v.40`  oraiin.cheor.alkain.oteey.ar,aiin.otaiin.okeey.lkeeedy.qo,oeeey,aiin
→ ORUII?  SAROR  ULŌUI?  OTRRM  URUII?  OTUII?  OŌRRM  LŌRRRNM  COORRRMUII?

`f113v.41`  dair.aiin.okain.a,r,aiin.cheody
→ NUIR  UII?  OŌUI?  URUII?  SARONM

`f113v.42`  pol.keeo,dy.qoeees.aiin.or,aiin.oteol.fchedy.otchey.dar.otakeol.ol
→ MOL  ŌRRONM  CORRRP  UII?  ORUII?  OTROL  ?SARNM  OTSARM  NUR  OTUŌROL  OL

`f113v.43`  ycheo,l.keey.lkeees.or,aiin.otaiin.chkain.olar.olchedy.qok,aiinos
→ MSAROL  ŌRRM  LŌRRRP  ORUII?  OTUII?  SAŌUI?  OLUR  OLSARNM  COŌUII?OP

`f113v.44`  daiin.cheal.otain.okar.otaiin.oloiin
→ NUII?  SARUL  OTUI?  OŌUR  OTUII?  OLOII?

`f113v.45`  polaiin.arol.shear.okeeeody.ls,ar.lkeey.opchedy.qokchdy.ota.aram
→ MOLUII?  UROL  PARUR  OŌRRRONM  LPUR  LŌRRM  OMSARNM  COŌSANM  OTU  URUS

`f113v.46`  o,lkaiin.cheey.lain.al.cheey
→ OLŌUII?  SARRM  LUI?  UL  SARRM

`f113v.47`  polaiin.ksheeol.lkaiin.tair.shey.qotain.ar,akal.shey.qopchedy,ldy
→ MOLUII?  ŌPARROL  LŌUII?  TUIR  PARM  COTUI?  URUŌUL  PARM  COMSARNMLNM

`f113v.48`  y.cheol.cheey.qol.lsheedy.qokaiin.chedy,kain.qokeeedy.lkaiin.okal,dy
→ M  SAROL  SARRM  COL  LPARRNM  COŌUII?  SARNMŌUI?  COŌRRRNM  LŌUII?  OŌULNM

`f113v.49`  yshey.teeo.oteedy.qokeey.otaiin.olaiin.cheokain.lkeey.ltal.keedy
→ MPARM  TRRO  OTRRNM  COŌRRM  OTUII?  OLUII?  SAROŌUI?  LŌRRM  LTUL  ŌRRNM

### f114r  ·  stars

`f114r.1`  tchedol.dairor.pcheos.ytaiin.otody.yteeed.oteeodl.o@188;aiin.okarol
→ TSARNOL  NUIROR  MSAROP  MTUII?  OTONM  MTRRRN  OTRRONL  OUII?  OŌUROL

`f114r.2`  deedar.qoteeddy.dair.o,kedy.okoeey.r,aiin.oor.cheed.ol.keeed.lkeeedam
→ NRRNUR  COTRRNNM  NUIR  OŌRNM  OŌORRM  RUII?  OOR  SARRN  OL  ŌRRRN  LŌRRRNUS

`f114r.3`  ycheod
→ MSARON

`f114r.4`  fdeechdy.opchedaiin.ypchedy.odaly.chedy.qop.cheokaiin.shedy.podair.ochedal
→ ?NRRSANM  OMSARNUII?  MMSARNM  ONULM  SARNM  COM  SAROŌUII?  PARNM  MONUIR  OSARNUL

`f114r.5`  loiin.chedy.qokaiin.chdy.daiin.dchd?s.eedol.chdol,kchedy.cho.kaiin.chdy
→ LOII?  SARNM  COŌUII?  SANM  NUII?  NSANP  RRNOL  SANOLŌSARNM  SAO  ŌUII?  SANM

`f114r.6`  qoeedy.okchedy.doiiin.chedy.daiin.ykeedy.okeeedy.chedol.chdaiin.ykar.dary
→ CORRNM  OŌSARNM  NOIII?  SARNM  NUII?  MŌRRNM  OŌRRRNM  SARNOL  SANUII?  MŌUR  NURM

`f114r.7`  cheol.dchedy.dkchs.aiin,chdedy.qodaiin.okchedaiin.chain
→ SAROL  NSARNM  NŌSAP  UII?SANRNM  CONUII?  OŌSARNUII?  SAUI?

`f114r.8`  fchey,dam.okchedam.qokeedaiin.otairar.okchedy.otaiin.opcheol.ofcheda[iir:iis].ocphy
→ ?SARMNUS  OŌSARNUS  COŌRRNUII?  OTUIRUR  OŌSARNM  OTUII?  OMSAROL  O?SARNUIIR  OSMAM

`f114r.9`  dcheod.qodaiin.daiin.chey.kal,dody.chdairod.okchdy.chody.daiin.dar.oarorold
→ NSARON  CONUII?  NUII?  SARM  ŌULNONM  SANUIRON  OŌSANM  SAONM  NUII?  NUR  OUROROLN

`f114r.10`  qokeedy.chdodaiin.qoedeey.chdaiin.chedalos
→ COŌRRNM  SANONUII?  CORNRRM  SANUII?  SARNULOP

`f114r.11`  da[l:?]chy.kolky.qoedaiin.dolor.shedy.qokchdy.ofchedy.tolpchy.doiiin.chocfhdy.opailo
→ NULSAM  ŌOLŌM  CORNUII?  NOLOR  PARNM  COŌSANM  O?SARNM  TOLMSAM  NOIII?  SAOS?ANM  OMUILO

`f114r.12`  ykcheshd.ol,air.okaiin.otedy.ykeeey.teos.lair.sheod.chody.otchedair.okam
→ MŌSARPAN  OLUIR  OŌUII?  OTRNM  MŌRRRM  TROP  LUIR  PARON  SAONM  OTSARNUIR  OŌUS

`f114r.13`  qokchedy.daiin.octhdy
→ COŌSARNM  NUII?  OSTANM

`f114r.14`  solpchd.oiin.chcthdy.qodair.ol.daldy.qopdain.opdaiin.opdairody.opdaildo.ary
→ POLMSAN  OII?  SASTANM  CONUIR  OL  NULNM  COMNUI?  OMNUII?  OMNUIRONM  OMNUILNO  URM

`f114r.15`  qoedy.otair.otar,okod.chodar,y.dal.oeedy.qokolkchdy.dalol,y,qokaiin.ched.al
→ CORNM  OTUIR  OTUROŌON  SAONURM  NUL  ORRNM  COŌOLŌSANM  NULOLMCOŌUII?  SARN  UL

`f114r.16`  cheoal.sheedo.l,kol.dair.dair.chdair.cheoty.otal,cheo.dair.chekar.otol.chedy
→ SAROUL  PARRNO  LŌOL  NUIR  NUIR  SANUIR  SAROTM  OTULSARO  NUIR  SARŌUR  OTOL  SARNM

`f114r.17`  qokeedain.cheedy.qokey.qokeeodaiin.daiin.oeted.akaiin.otchedy.qokchedy.chckhd
→ COŌRRNUI?  SARRNM  COŌRM  COŌRRONUII?  NUII?  ORTRN  UŌUII?  OTSARNM  COŌSARNM  SASŌAN

`f114r.18`  lcheos.okar.y.cheodeeey.qoeeody.qodaiin.daildain
→ LSAROP  OŌUR  M  SARONRRRM  CORRONM  CONUII?  NUILNUI?

`f114r.19`  pairody.shedar.qopchdy.dchedy.dol.qopchedy.daiin.ofchedaiin.chodaiin.opair,dar.oty
→ MUIRONM  PARNUR  COMSANM  NSARNM  NOL  COMSARNM  NUII?  O?SARNUII?  SAONUII?  OMUIRNUR  OTM

`f114r.20`  sair,chedaiin.dalchdy.daiidy.olchedy.chedaiin.oteedy.qoted,aiin.otar.otedy.do.rol
→ PUIRSARNUII?  NULSANM  NUIINM  OLSARNM  SARNUII?  OTRRNM  COTRNUII?  OTUR  OTRNM  NO  ROL

`f114r.21`  lcheey.lchedo.lcheo.dkair
→ LSARRM  LSARNO  LSARO  NŌUIR

`f114r.22`  tchedair.shodaiin.dair.kchedy.qopchdy.chdy,pdaiin.qokair,olchdy.rodeedy.q{cphh}edy
→ TSARNUIR  PAONUII?  NUIR  ŌSARNM  COMSANM  SANMMNUII?  COŌUIROLSANM  RONRRNM  CSMAARNM

`f114r.23`  or,cheo.al.taiin.qokedaiin.oeain.al.s.ain,ches
→ ORSARO  UL  TUII?  COŌRNUII?  ORUI?  UL  P  UI?SARP

`f114r.24`  tchedaiin.oldal.chor.chpcheey.chcphey.cphochy.chos.aiir.chty.chopo,sair.cphy.dair
→ TSARNUII?  OLNUL  SAOR  SAMSARRM  SASMARM  SMAOSAM  SAOP  UIIR  SATM  SAOMOPUIR  SMAM  NUIR

`f114r.25`  oaiil,chey.qokeedy.chedy.qoeey.qokodaiin.cheey,kais.aiy.okol.aiir.otair.or,airy
→ OUIILSARM  COŌRRNM  SARNM  CORRM  COŌONUII?  SARRMŌUIP  UIM  OŌOL  UIIR  OTUIR  ORUIRM

`f114r.26`  ycheeodaiin.olkaiir.qokaiin.chodaiin.okar.olkaiin.okaiin.cheody.airoy.olam
→ MSARRONUII?  OLŌUIIR  COŌUII?  SAONUII?  OŌUR  OLŌUII?  OŌUII?  SARONM  UIROM  OLUS

`f114r.27`  cheeo,daiin.sheedy.qodaiin.ksam.chodal.olchedy
→ SARRONUII?  PARRNM  CONUII?  ŌPUS  SAONUL  OLSARNM

`f114r.28`  pchedairs.oeail.chotar,qokeedair.olkaiin.opdaiin.otoldair.chdy,tedair.aiir,aim
→ MSARNUIRP  ORUIL  SAOTURCOŌRRNUIR  OLŌUII?  OMNUII?  OTOLNUIR  SANMTRNUIR  UIIRUIS

`f114r.29`  ch[o:?]l.oeedy.keedy.chee{ck}y.cheodeey.keedeedy.daiiin.ald,air.ar.shol.chedy.otchedy.qoty
→ SAOL  ORRNM  ŌRRNM  SARRSŌM  SARONRRM  ŌRRNRRNM  NUIII?  ULNUIR  UR  PAOL  SARNM  OTSARNM  COTM

`f114r.30`  y,chedar.okeedy.lkeedy.aiin.oeedaiin.qoaiin.ykedy.okair.olkeedy.qoain.ain.okeey.ram
→ MSARNUR  OŌRRNM  LŌRRNM  UII?  ORRNUII?  COUII?  MŌRNM  OŌUIR  OLŌRRNM  COUI?  UI?  OŌRRM  RUS

`f114r.31`  sair.aiin.cheedain.okaiin.otedy.qokeedain.orain
→ PUIR  UII?  SARRNUI?  OŌUII?  OTRNM  COŌRRNUI?  ORUI?

`f114r.32`  tcheodaiin.chaiin.qokaiin.otaiin.otalkain.otchedain.qotcho.chdy.dair.qotar
→ TSARONUII?  SAUII?  COŌUII?  OTUII?  OTULŌUI?  OTSARNUI?  COTSAO  SANM  NUIR  COTUR

`f114r.33`  daiin.oteed,aiin.saiin.yteey.aiin.al,odaiin.chedal.odaii[s:r].aiin.cheo,dal.chedy
→ NUII?  OTRRNUII?  PUII?  MTRRM  UII?  ULONUII?  SARNUL  ONUIIP  UII?  SARONUL  SARNM

`f114r.34`  ytain.o,l,kaiin.y,kar.chdar.alkam
→ MTUI?  OLŌUII?  MŌUR  SANUR  ULŌUS

`f114r.35`  pcheos.air,oy.sheo.qok[{oh}:ch]ey.sheeka[s:r].oar.ytched.lked.o,kchdar.otal.kar
→ MSAROP  UIROM  PARO  COŌOARM  PARRŌUP  OUR  MTSARN  LŌRN  OŌSANUR  OTUL  ŌUR

`f114r.36`  ychedar.a{ikh}dy.otar,ain.ykeodaiin.qoeedaiin.qokal.sain.otchedy.qokar
→ MSARNUR  UIŌANM  OTURUI?  MŌRONUII?  CORRNUII?  COŌUL  PUI?  OTSARNM  COŌUR

`f114r.37`  odar.or,aiin.otshedy.okaiin.yky.ols.ol.kaiin.chees.air.qotaiin.chedaiiin
→ ONUR  ORUII?  OTPARNM  OŌUII?  MŌM  OLP  OL  ŌUII?  SARRP  UIR  COTUII?  SARNUIII?

`f114r.38`  qoeedy.qokchedy.cheey.raiin.ar,ain.aiin.al,chol?
→ CORRNM  COŌSARNM  SARRM  RUII?  URUI?  UII?  ULSAOL

`f114r.39`  todaiin.cheoltchedaiin.daiin.okar.qoeedain.[q:y]cho.oeda[?:ir].opchedy.qetchar
→ TONUII?  SAROLTSARNUII?  NUII?  OŌUR  CORRNUI?  CSAO  ORNU  OMSARNM  CRTSAUR

`f114r.40`  yteedy.qotey.qoedaiin.qokchedy.teedy.qoteeedy.qotar.otees.chos.otchdy
→ MTRRNM  COTRM  CORNUII?  COŌSARNM  TRRNM  COTRRRNM  COTUR  OTRRP  SAOP  OTSANM

`f114r.41`  oshey.daiin.sheody.qoty.cheey.taiin.qokaiin.qokeeedy.oqotaiiin.o,qoeeo[s:r]ain
→ OPARM  NUII?  PARONM  COTM  SARRM  TUII?  COŌUII?  COŌRRRNM  OCOTUIII?  OCORROPUI?

`f114r.42`  poedair.qotol.qodaiin.otaiin.qotar.qotchey.qotaiin.cheopy.qopaiin.cheody
→ MORNUIR  COTOL  CONUII?  OTUII?  COTUR  COTSARM  COTUII?  SAROMM  COMUII?  SARONM

`f114r.43`  ycheedy.qoodaiin.daiiral.chedal.chos.oral,tedy.qotchdy.qotar.cheo.dain
→ MSARRNM  COONUII?  NUIIRUL  SARNUL  SAOP  ORULTRNM  COTSANM  COTUR  SARO  NUI?

`f114r.44`  ydaiin.chedy.qoal.cheey.qokair.okeedy.chotal.chol.okain.ar.da[?:r].opaiin
→ MNUII?  SARNM  COUL  SARRM  COŌUIR  OŌRRNM  SAOTUL  SAOL  OŌUI?  UR  NU  OMUII?

`f114r.45`  dain.ched.chodaiin.otain.chdar.chedy.chocthy
→ NUI?  SARN  SAONUII?  OTUI?  SANUR  SARNM  SAOSTAM

### f114v  ·  stars

`f114v.1`  pchdol.dar.chedain.chodalr.fcheey.dchedy.qocphdy.otdady.qotedar.daiin
→ MSANOL  NUR  SARNUI?  SAONULR  ?SARRM  NSARNM  COSMANM  OTNUNM  COTRNUR  NUII?

`f114v.2`  dshedal.qoteody.choddy.otol.chedal.otain.chedol.chedain.shedy.qotched.dl
→ NPARNUL  COTRONM  SAONNM  OTOL  SARNUL  OTUI?  SARNOL  SARNUI?  PARNM  COTSARN  NL

`f114v.3`  oeos.qotcheo.odain.qotain.otar.qotchd.dol.qotchedy.choty.ol.lchdaiin.dal
→ OROP  COTSARO  ONUI?  COTUI?  OTUR  COTSAN  NOL  COTSARNM  SAOTM  OL  LSANUII?  NUL

`f114v.4`  qokedy.cheocthedy.qoted.qotedol.chedar.qotedy.okeedy.daiin.chedaiin.oky
→ COŌRNM  SAROSTARNM  COTRN  COTRNOL  SARNUR  COTRNM  OŌRRNM  NUII?  SARNUII?  OŌM

`f114v.5`  chedy.qokeedy.okaly.cheedain.shedy
→ SARNM  COŌRRNM  OŌULM  SARRNUI?  PARNM

`f114v.6`  tedcheo.cheo.cthedy.qotchedy.qotaiin.opchedy.shedy.qepoepy.chedar.dairy
→ TRNSARO  SARO  STARNM  COTSARNM  COTUII?  OMSARNM  PARNM  CRMORMM  SARNUR  NUIRM

`f114v.7`  ytedshedy.otaiin.cheedar.ch[ee:eo]y.s.aiin.chedky.chedaiin.shod.chokchedy
→ MTRNPARNM  OTUII?  SARRNUR  SARRM  P  UII?  SARNŌM  SARNUII?  PAON  SAOŌSARNM

`f114v.8`  pchedchdy.qoteedy.qokedain.chdaiin.qokedy.chedain.qoeedy.qotey.qotaiin
→ MSARNSANM  COTRRNM  COŌRNUI?  SANUII?  COŌRNM  SARNUI?  CORRNM  COTRM  COTUII?

`f114v.9`  soes.oeeos.aiin.olkeey.keol.qotcheedy.qockhed.skaiin.sheedy.qotal.chedy
→ PORP  ORROP  UII?  OLŌRRM  ŌROL  COTSARRNM  COSŌARN  PŌUII?  PARRNM  COTUL  SARNM

`f114v.10`  olkees.chedaiin.qotaiin.olchedaiin.chedain.dain.chcthdy
→ OLŌRRP  SARNUII?  COTUII?  OLSARNUII?  SARNUI?  NUI?  SASTANM

`f114v.11`  tchedy.qotaiin.chdy.qotedy.tedaiin.chepched.otol.shedain.pol.otam
→ TSARNM  COTUII?  SANM  COTRNM  TRNUII?  SARMSARN  OTOL  PARNUI?  MOL  OTUS

`f114v.12`  ochedy.choaiin.ch{cty}.chedal.daiin.ytar.otchedy.qotaiin.dain.dar,[y:q]og
→ OSARNM  SAOUII?  SASTM  SARNUL  NUII?  MTUR  OTSARNM  COTUII?  NUI?  NURMO?

`f114v.13`  sheedy.qoteeo,s,oiiin.chcthain
→ PARRNM  COTRROPOIII?  SASTAUI?

`f114v.14`  tsheodar.cheo.ckhor.qopchedy.qopchedy.qokchedy.shody.qotaiin.ofcheds
→ TPARONUR  SARO  SŌAOR  COMSARNM  COMSARNM  COŌSARNM  PAONM  COTUII?  O?SARNP

`f114v.15`  ochedain.chedy.okal.chaiin.qokod.qokol.cheedy.qotody.cheol.kchedy.ldy
→ OSARNUI?  SARNM  OŌUL  SAUII?  COŌON  COŌOL  SARRNM  COTONM  SAROL  ŌSARNM  LNM

`f114v.16`  ytchedy.qool.chey.ol,aiin.chedar.chdaiin.chdal.qokaiin.choky.chol.dam
→ MTSARNM  COOL  SARM  OLUII?  SARNUR  SANUII?  SANUL  COŌUII?  SAOŌM  SAOL  NUS

`f114v.17`  sheoal.chos.oaiir,alchedy.chcphedy.okary
→ PAROUL  SAOP  OUIIRULSARNM  SASMARNM  OŌURM

`f114v.18`  dorkcheky.cheo,aiin.qotaiin.otody.qokalsheody.choypshedy.qoto.@189;shxam
→ NORŌSARŌM  SAROUII?  COTUII?  OTONM  COŌULPARONM  SAOMMPARNM  COTO  PA?US

`f114v.19`  o,sh[s:?]odaiin.chotain.qotar
→ OPAPONUII?  SAOTUI?  COTUR

`f114v.20`  tshedain.qotchody.qokol.shedy.qokchedy.daiin.qofchdar.chdor.chdy.dary
→ TPARNUI?  COTSAONM  COŌOL  PARNM  COŌSARNM  NUII?  CO?SANUR  SANOR  SANM  NURM

`f114v.21`  dair.cheeo.chy.chdaiin.qokedy.otcheodaiin.qokchdy.otedal.dain.aral
→ NUIR  SARRO  SAM  SANUII?  COŌRNM  OTSARONUII?  COŌSANM  OTRNUL  NUI?  URUL

`f114v.22`  ychedar.shod.qokaiin.qotchey.chockhy.olkedy.otechy.ykedckhy
→ MSARNUR  PAON  COŌUII?  COTSARM  SAOSŌAM  OLŌRNM  OTRSAM  MŌRNSŌAM

`f114v.23`  pshedy.qopcheos.okaiin.qotchedy.qotchdar.cheeos.olteody.otoydy
→ MPARNM  COMSAROP  OŌUII?  COTSARNM  COTSANUR  SARROP  OLTRONM  OTOMNM

`f114v.24`  olkaiin.cheotaiin.qoteody.qokod.sheoeed.qodeedy.yteedy.aiin.am
→ OLŌUII?  SAROTUII?  COTRONM  COŌON  PARORRN  CONRRNM  MTRRNM  UII?  US

`f114v.25`  sor.aiin.otchedy.otaiin.alkain.okeedy
→ POR  UII?  OTSARNM  OTUII?  ULŌUI?  OŌRRNM

`f114v.26`  pcheodal.chopcheod.qoto,s.araiin.qota,l,cheo.pchdal.qoeedy.chcthey
→ MSARONUL  SAOMSARON  COTOP  URUII?  COTULSARO  MSANUL  CORRNM  SASTARM

`f114v.27`  o,sheeo.l,kchee.okeey.qoteor.chokaiin.chdy.qokaiin.chokeey.tainary
→ OPARRO  LŌSARR  OŌRRM  COTROR  SAOŌUII?  SANM  COŌUII?  SAOŌRRM  TUI?URM

`f114v.28`  tchedy.shdo.qotched.chees.ar.aiin.chetam
→ TSARNM  PANO  COTSARN  SARRP  UR  UII?  SARTUS

`f114v.29`  pchdair.sho.qopchey.otcheed.chedy.qopcheo.r.ocpheody.opchdy,qopairam
→ MSANUIR  PAO  COMSARM  OTSARRN  SARNM  COMSARO  R  OSMARONM  OMSANMCOMUIRUS

`f114v.30`  y,cheey.qooeey.qolcheey.qoteey.qotaiin.otal.otaiin.oteeo.teey.rain
→ MSARRM  COORRM  COLSARRM  COTRRM  COTUII?  OTUL  OTUII?  OTRRO  TRRM  RUI?

`f114v.31`  olaiin.cheo.otcheody.lkchedy.okol.okaiin.otaiin.otal.qotar
→ OLUII?  SARO  OTSARONM  LŌSARNM  OŌOL  OŌUII?  OTUII?  OTUL  COTUR

`f114v.32`  y,cheol.oleey.cheoaiin.chetaiin.sheeodain
→ MSAROL  OLRRM  SAROUII?  SARTUII?  PARRONUI?

`f114v.33`  kaiin.sheey.oaiin.sheol.qoteey.qokeeedy.cheo,ctheey.qokeeo.lkealy
→ ŌUII?  PARRM  OUII?  PAROL  COTRRM  COŌRRRNM  SAROSTARRM  COŌRRO  LŌRULM

`f114v.34`  olkeechy.ol.oaiin.aiin.chocthey.qotedal.octhy.sotey.cheos.air
→ OLŌRRSAM  OL  OUII?  UII?  SAOSTARM  COTRNUL  OSTAM  POTRM  SAROP  UIR

`f114v.35`  yshey.kair.yteeey.qokaiin.chckhy.chodaiin.olkaim
→ MPARM  ŌUIR  MTRRRM  COŌUII?  SASŌAM  SAONUII?  OLŌUIS

`f114v.36`  tshey.oidal.op.shoko.otchey.qopchol.qopaiin.qotar.al,kal.ram
→ TPARM  OINUL  OM  PAOŌO  OTSARM  COMSAOL  COMUII?  COTUR  ULŌUL  RUS

`f114v.37`  dcheey.ol.cheodaiiin.qokar.otaiin.otal.o,kaiin.chey.tar.arody
→ NSARRM  OL  SARONUIII?  COŌUR  OTUII?  OTUL  OŌUII?  SARM  TUR  URONM

`f114v.38`  oteey.okedaiin.otaiin.qotchey.qoteeody.otaiin.okal.dals
→ OTRRM  OŌRNUII?  OTUII?  COTSARM  COTRRONM  OTUII?  OŌUL  NULP

`f114v.39`  qo,[?:o]eecheedy.o.kecheokeo.oteo,daiin.okaiin.choty.odaiin.otam
→ CORRSARRNM  O  ŌRSAROŌRO  OTRONUII?  OŌUII?  SAOTM  ONUII?  OTUS

`f114v.40`  eeo.cheo,y.ot[ee:a]y.qotaiin.cheo,l.oteeey.daiin.oteey.teeedy.dm
→ RRO  SAROM  OTRRM  COTUII?  SAROL  OTRRRM  NUII?  OTRRM  TRRRNM  NS

`f114v.41`  yaiin.o?oy.[o:a]keey.cheody.qokaiin.otain.al.kain.choty
→ MUII?  OOM  OŌRRM  SARONM  COŌUII?  OTUI?  UL  ŌUI?  SAOTM

### f115r  ·  stars

`f115r.1`  <@H=2>f{c'hh}dar.qopchol.qochedain.otedy.cheop,ol.teeedy.oroiir.oechedy.oteedy.qotchedy
→ A?SAANUR  COMSAOL  COSARNUI?  OTRNM  SAROMOL  TRRRNM  OROIIR  ORSARNM  OTRRNM  COTSARNM

`f115r.2`  dcheeos.shedy.qokeeo.qoky.qokeeor.cheody.qokeeo.qokeo.rorol.kcheody,qokchy
→ NSARROP  PARNM  COŌRRO  COŌM  COŌRROR  SARONM  COŌRRO  COŌRO  ROROL  ŌSARONMCOŌSAM

`f115r.3`  qol,cheol.chor.od.qol,chedy.qockheos.cholor.daar.oraro
→ COLSAROL  SAOR  ON  COLSARNM  COSŌAROP  SAOLOR  NUUR  ORURO

`f115r.4`  dchedain.qokeedy.olkeechdy.chor.chey.kchor.orchedar.otar.sheod.qoteedy.dardyr
→ NSARNUI?  COŌRRNM  OLŌRRSANM  SAOR  SARM  ŌSAOR  ORSARNUR  OTUR  PARON  COTRRNM  NURNMR

`f115r.5`  ycheedy.chedar.olkees.sheed.qodain.qoteedy.qokedy.qokeed.lchedar.qotchedy.ro
→ MSARRNM  SARNUR  OLŌRRP  PARRN  CONUI?  COTRRNM  COŌRNM  COŌRRN  LSARNUR  COTSARNM  RO

`f115r.6`  cheo,ckhdy.qotchdy.qokedy.qokar.okeeeosaiin.chl.chedar.chody.qotar.chedam.chd
→ SAROSŌANM  COTSANM  COŌRNM  COŌUR  OŌRRROPUII?  SAL  SARNUR  SAONM  COTUR  SARNUS  SAN

`f115r.7`  dar,chedy.qotchy.chedy.chedar.shey.otain.chorar
→ NURSARNM  COTSAM  SARNM  SARNUR  PARM  OTUI?  SAORUR

`f115r.8`  kcheor.cheol.orair.ot,chedar.lor.aiin.qokain.qoteeol.dar.ar.al.opchedy.darom
→ ŌSAROR  SAROL  ORUIR  OTSARNUR  LOR  UII?  COŌUI?  COTRROL  NUR  UR  UL  OMSARNM  NUROS

`f115r.9`  dchedaiin.qoteeedy.qokeedy.qoteo.lor.cheo,r,ar.cheor.cheody
→ NSARNUII?  COTRRRNM  COŌRRNM  COTRO  LOR  SARORUR  SAROR  SARONM

`f115r.10`  tchedy.kechedy.qokchey.keedy,qokor.chedaiin.dair.qotchedy.qotcheedy.qekor
→ TSARNM  ŌRSARNM  COŌSARM  ŌRRNMCOŌOR  SARNUII?  NUIR  COTSARNM  COTSARRNM  CRŌOR

`f115r.11`  daiin.chedy.chol.chedy.qok[o:a]iin.qokcheedy.qototeeey.rain.cheo.chkain.cho.lory
→ NUII?  SARNM  SAOL  SARNM  COŌOII?  COŌSARRNM  COTOTRRRM  RUI?  SARO  SAŌUI?  SAO  LORM

`f115r.12`  dsheo.qokeedaiin.qokechdy.qodaiin.or.chol,o,ro.chey
→ NPARO  COŌRRNUII?  COŌRSANM  CONUII?  OR  SAOLORO  SARM

`f115r.13`  <@H=3>tchedy.qoolkeedy.qokchedy.qotchd.lpchedy.qotcho.lar.airorlchy.cpholrory
→ ATSARNM  COOLŌRRNM  COŌSARNM  COTSAN  LMSARNM  COTSAO  LUR  UIRORLSAM  SMAOLRORM

`f115r.14`  ycheeo,rcheeo.qo.lkain.cheey.saiin.cheedy.tcheo.lodar.chtar.as,kaiin.dam
→ MSARRORSARRO  CO  LŌUI?  SARRM  PUII?  SARRNM  TSARO  LONUR  SATUR  UPŌUII?  NUS

`f115r.15`  y,cheo.lkeodain.chcthed.qokar.chedy.qotain.chody.qotain.cheol.lkar.air,om
→ MSARO  LŌRONUI?  SASTARN  COŌUR  SARNM  COTUI?  SAONM  COTUI?  SAROL  LŌUR  UIROS

`f115r.16`  dshedy.qotshedy.dar.oltedy.qotar.chodar.cheocthy.chdy.qotor.otchdy.qotolchd
→ NPARNM  COTPARNM  NUR  OLTRNM  COTUR  SAONUR  SAROSTAM  SANM  COTOR  OTSANM  COTOLSAN

`f115r.17`  qol.cheey.qotchy.daiin.daiin.cheocthy.dolkeedy.qotaiin.chol.oteeedchey.okeedain
→ COL  SARRM  COTSAM  NUII?  NUII?  SAROSTAM  NOLŌRRNM  COTUII?  SAOL  OTRRRNSARM  OŌRRNUI?

`f115r.18`  cheol.lcheey.okcho.keedor.ykechey.chchdy
→ SAROL  LSARRM  OŌSAO  ŌRRNOR  MŌRSARM  SASANM

`f115r.19`  pcheodain.qokchey.qotchedy.darailchedy.polchedy.chol.pchody.qotchedy.qofchedy.ram
→ MSARONUI?  COŌSARM  COTSARNM  NURUILSARNM  MOLSARNM  SAOL  MSAONM  COTSARNM  CO?SARNM  RUS

`f115r.20`  lcheod.lkchedy.chockhy.chedy.qokchedy.qoky.chor.al.alor.cheey.qol.keo,r,shey
→ LSARON  LŌSARNM  SAOSŌAM  SARNM  COŌSARNM  COŌM  SAOR  UL  ULOR  SARRM  COL  ŌRORPARM

`f115r.21`  yches.oaiin.or,al.chy.cheody.rodaiin.cheockhy.oeeody
→ MSARP  OUII?  ORUL  SAM  SARONM  RONUII?  SAROSŌAM  ORRONM

`f115r.22`  psheody.chsho.tchdy.dar.chedy.okchdar.chdor.cheedy.{y@162;h}y.cheedy.qepchey.lkam
→ MPARONM  SAPAO  TSANM  NUR  SARNM  OŌSANUR  SANOR  SARRNM  MAM  SARRNM  CRMSARM  LŌUS

`f115r.23`  dchey,keey.qokeod.chody.qokcho.[s:r].checthy.qokeeey.keeey.lol.chedy.qokchedy.ldy
→ NSARMŌRRM  COŌRON  SAONM  COŌSAO  P  SARSTAM  COŌRRRM  ŌRRRM  LOL  SARNM  COŌSARNM  LNM

`f115r.24`  dcheol.qokeol.or.ar.aiin.cheey.okeeeo.or.chl.lor.ol.otlaiin.cheeor.ary
→ NSAROL  COŌROL  OR  UR  UII?  SARRM  OŌRRRO  OR  SAL  LOR  OL  OTLUII?  SARROR  URM

`f115r.25`  y,cheodain.cheey.qotchedy.qokeeody.choar.cheey
→ MSARONUI?  SARRM  COTSARNM  COŌRRONM  SAOUR  SARRM

`f115r.26`  ksheoary.otchey.qoteeo.s.ar.aiiin.chotchdy.qodair.sheol.pchedy.dal.dalom
→ ŌPAROURM  OTSARM  COTRRO  P  UR  UIII?  SAOTSANM  CONUIR  PAROL  MSARNM  NUL  NULOS

`f115r.27`  ysheeo.los.ar.chey.qoky.chol,kchedshedy.qokaiin.shey.qoetar.chol.qokaram
→ MPARRO  LOP  UR  SARM  COŌM  SAOLŌSARNPARNM  COŌUII?  PARM  CORTUR  SAOL  COŌURUS

`f115r.28`  cheo.chos.al.saiin.cheody.llsan.arorochees
→ SARO  SAOP  UL  PUII?  SARONM  LLPU?  UROROSARRP

`f115r.29`  fshedy.shdalky.cheedar.qopchedy.qopchedyd.lksho.ror.pchodar.ol,chedyo
→ ?PARNM  PANULŌM  SARRNUR  COMSARNM  COMSARNMN  LŌPAO  ROR  MSAONUR  OLSARNMO

`f115r.30`  dsheodar.sheo.qokecheos.cheos.r.char.qokchar.qolcheey.lkedy.qotal
→ NPARONUR  PARO  COŌRSAROP  SAROP  R  SAUR  COŌSAUR  COLSARRM  LŌRNM  COTUL

`f115r.31`  shod.ykaiin.chdy.qotchedy.dchol.daiin.qopol.qokair[o:a]r.lchea.raiin.dlchd
→ PAON  MŌUII?  SANM  COTSARNM  NSAOL  NUII?  COMOL  COŌUIROR  LSARU  RUII?  NLSAN

`f115r.32`  sor.chey.okaiin.qokeey.qokeedy.qoaiin.chedy.qotaiin.chety.laiin.chedy
→ POR  SARM  OŌUII?  COŌRRM  COŌRRNM  COUII?  SARNM  COTUII?  SARTM  LUII?  SARNM

`f115r.33`  y,cheey.qotaiin.chokeeey.chckhey.qoky.aiin.cheey.lkeedy.ok{oh}y.chokchaiin
→ MSARRM  COTUII?  SAOŌRRRM  SASŌARM  COŌM  UII?  SARRM  LŌRRNM  OŌOAM  SAOŌSAUII?

`f115r.34`  cheeo.l,keeey.okeey.raiin.cheky
→ SARRO  LŌRRRM  OŌRRM  RUII?  SARŌM

`f115r.35`  posheos.aral.chaiin.shkchedy.otais.chsi.chpchar.ar.al,odaiin.chcphy.dy
→ MOPAROP  URUL  SAUII?  PAŌSARNM  OTUIP  SAPI  SAMSAUR  UR  ULONUII?  SASMAM  NM

`f115r.36`  daiin.cheey.qoek.chody.qodain.sheey.dar.oranol
→ NUII?  SARRM  CORŌ  SAONM  CONUI?  PARRM  NUR  ORU?OL

`f115r.37`  sorols.cheos.lkshey.qokcho.[r:s]aiin.chkshy.qos.aiin.okchey.pchar
→ POROLP  SAROP  LŌPARM  COŌSAO  RUII?  SAŌPAM  COP  UII?  OŌSARM  MSAUR

`f115r.38`  dor.cheol.chot.qotchy.qokchy.sol.raiin.shey.kchedy.daiin.shedy.qoty
→ NOR  SAROL  SAOT  COTSAM  COŌSAM  POL  RUII?  PARM  ŌSARNM  NUII?  PARNM  COTM

`f115r.39`  y,chey.keey.qodain.cheody.qok[o:a]r
→ MSARM  ŌRRM  CONUI?  SARONM  COŌOR

`f115r.40`  paiinody.lkcheo.lchy.qokchedy.qokl.sheedy.qokar,aiir.ar.opchdain
→ MUII?ONM  LŌSARO  LSAM  COŌSARNM  COŌL  PARRNM  COŌURUIIR  UR  OMSANUI?

`f115r.41`  dar.olchy.olchey.qolcheor.okchor
→ NUR  OLSAM  OLSARM  COLSAROR  OŌSAOR

`f115r.42`  tcheodl.raiin.chkar.qokol.lchdy.qorshy.qokain.qokain.chep.chotchdy
→ TSARONL  RUII?  SAŌUR  COŌOL  LSANM  CORPAM  COŌUI?  COŌUI?  SARM  SAOTSANM

`f115r.43`  dcheo,dain.sheol.qotchedy.qokchedy.qokchedy.chotar.orar.oiin.olchdy
→ NSARONUI?  PAROL  COTSARNM  COŌSARNM  COŌSARNM  SAOTUR  ORUR  OII?  OLSANM

`f115r.44`  dcheos.shedar.qoor.cheor.shody.qokain.otar.ar.otar.ytar.ar.aloky
→ NSAROP  PARNUR  COOR  SAROR  PAONM  COŌUI?  OTUR  UR  OTUR  MTUR  UR  ULOŌM

`f115r.45`  y.dchedy.kody.qokeedy.chols
→ M  NSARNM  ŌONM  COŌRRNM  SAOLP

### f115v  ·  stars

`f115v.1`  tchedor.otchedy.qotees.ytain.qoty.qotar.opolaiin.qotdain.ol.raiin,om
→ TSARNOR  OTSARNM  COTRRP  MTUI?  COTM  COTUR  OMOLUII?  COTNUI?  OL  RUII?OS

`f115v.2`  ykeeochody.qokeedy.yteedy.qokar.qor.chodaiin.qokchdy.chdar.okchdy.qokam
→ MŌRROSAONM  COŌRRNM  MTRRNM  COŌUR  COR  SAONUII?  COŌSANM  SANUR  OŌSANM  COŌUS

`f115v.3`  dsheol.qokchedy.qokshedy.qotchey.otaiin.qotedy.lkedain.dalchdy.okchedam
→ NPAROL  COŌSARNM  COŌPARNM  COTSARM  OTUII?  COTRNM  LŌRNUI?  NULSANM  OŌSARNUS

`f115v.4`  ykcheodain.lkchedy.otechdy.qotar.or,al.ytchedy.lched.otchd.chokeedy
→ MŌSARONUI?  LŌSARNM  OTRSANM  COTUR  ORUL  MTSARNM  LSARN  OTSAN  SAOŌRRNM

`f115v.5`  dair.cheky.qoteey.otar.chl.oleed
→ NUIR  SARŌM  COTRRM  OTUR  SAL  OLRRN

`f115v.6`  pchody.odaiin.chcphy.qokchdain.qotain.qokor.shed.oteody.solkaiin.al
→ MSAONM  ONUII?  SASMAM  COŌSANUI?  COTUI?  COŌOR  PARN  OTRONM  POLŌUII?  UL

`f115v.7`  dchedy.tedy.qokeey.roiin,shedy.okor.air.cheoor.olkchedy.chotam
→ NSARNM  TRNM  COŌRRM  ROII?PARNM  OŌOR  UIR  SAROOR  OLŌSARNM  SAOTUS

`f115v.8`  tchoros.sheol.qotchs.olchees.otchdy.qotol.lpchedy.okar.lkechedy,pchdam
→ TSAOROP  PAROL  COTSAP  OLSARRP  OTSANM  COTOL  LMSARNM  OŌUR  LŌRSARNMMSANUS

`f115v.9`  ychees.chdaiin.chotain.cholkeedy.qotchy.chody.qotain.lkchey.lchey.ror
→ MSARRP  SANUII?  SAOTUI?  SAOLŌRRNM  COTSAM  SAONM  COTUI?  LŌSARM  LSARM  ROR

`f115v.10`  saiin.sho,sheody.okaiin.dalchedy.oteeo.chedy
→ PUII?  PAOPARONM  OŌUII?  NULSARNM  OTRRO  SARNM

`f115v.11`  tchdor.shorail.chodaiin.chkol.chkchol.qotched.qotchey.dpchedy.q[?:o]tam
→ TSANOR  PAORUIL  SAONUII?  SAŌOL  SAŌSAOL  COTSARN  COTSARM  NMSARNM  CTUS

`f115v.12`  ysheed.lchedy.lkchedy.soraiin
→ MPARRN  LSARNM  LŌSARNM  PORUII?

`f115v.13`  pchdarody.pcheed.rar.tcheody.polched.lpchdy.tol.rchees.cphor.orair.kol
→ MSANURONM  MSARRN  RUR  TSARONM  MOLSARN  LMSANM  TOL  RSARRP  SMAOR  ORUIR  ŌOL

`f115v.14`  okeeo,kaiin.lkeeey.lkor.sheedy.chockhy.qockheedy.qokechy.lkeey.ldaiin
→ OŌRROŌUII?  LŌRRRM  LŌOR  PARRNM  SAOSŌAM  COSŌARRNM  COŌRSAM  LŌRRM  LNUII?

`f115v.15`  saiin.chol.qotain.qokain.chl.lr.chdain.qoteey.rcheey.r.ar.rodam
→ PUII?  SAOL  COTUI?  COŌUI?  SAL  LR  SANUI?  COTRRM  RSARRM  R  UR  RONUS

`f115v.16`  dain.ar,oteey.qoteol,kar.y.sheo.lkechdy.qokar.qokey.lko.rokeedy.ld
→ NUI?  UROTRRM  COTROLŌUR  M  PARO  LŌRSANM  COŌUR  COŌRM  LŌO  ROŌRRNM  LN

`f115v.17`  okai[?:r].chey.keey.lcho.racthy
→ OŌUI  SARM  ŌRRM  LSAO  RUSTAM

`f115v.18`  pchodain.chotain.choky.lchain.lpchdain.dalchedy.qotolchedy.qopchedy
→ MSAONUI?  SAOTUI?  SAOŌM  LSAUI?  LMSANUI?  NULSARNM  COTOLSARNM  COMSARNM

`f115v.19`  yshedy.qokeedy.lxor,xoiin.choto.keeody.qoteody.dain.qokchedy.ralom
→ MPARNM  COŌRRNM  L?OR?OII?  SAOTO  ŌRRONM  COTRONM  NUI?  COŌSARNM  RULOS

`f115v.20`  ysheey.qoteey.lkeey.raiin.cheo,lor.otal.otchedy
→ MPARRM  COTRRM  LŌRRM  RUII?  SAROLOR  OTUL  OTSARNM

`f115v.21`  tshedy.sheolkeedy.lkeeshdy.cheeo.lor.eees.aiin.okchedy.qopcheddy.lky
→ TPARNM  PAROLŌRRNM  LŌRRPANM  SARRO  LOR  RRRP  UII?  OŌSARNM  COMSARNNM  LŌM

`f115v.22`  soiin.shedain.qokeedy.chodain.otedain.qokeedy.qokeedy.qotedy.[r:s]osy
→ POII?  PARNUI?  COŌRRNM  SAONUI?  OTRNUI?  COŌRRNM  COŌRRNM  COTRNM  ROPM

`f115v.23`  lshes.sheet.chdy.otedy.shdy.lchedy
→ LPARP  PARRT  SANM  OTRNM  PANM  LSARNM

`f115v.24`  pcheo.cheeody.qoteeotchy.soin,opchees.chpcheod.rchl.cho,pchdy.qopcham
→ MSARO  SARRONM  COTRROTSAM  POI?OMSARRP  SAMSARON  RSAL  SAOMSANM  COMSAUS

`f115v.25`  ykees.aiin.olkeeody.qos,ain.cheodain.chcthy.tchedy.qokeedy.lkeedas
→ MŌRRP  UII?  OLŌRRONM  COPUI?  SARONUI?  SASTAM  TSARNM  COŌRRNM  LŌRRNUP

`f115v.26`  dcheedy.kchedy,lcheey.ror.al.chokedy.dol.qokeeeos.qolkeedy.qokar,ar
→ NSARRNM  ŌSARNMLSARRM  ROR  UL  SAOŌRNM  NOL  COŌRRROP  COLŌRRNM  COŌURUR

`f115v.27`  olain.cheo,lkain.cheey.qot.cheody.lor.aiin.oteed.chkal.kchetam
→ OLUI?  SAROLŌUI?  SARRM  COT  SARONM  LOR  UII?  OTRRN  SAŌUL  ŌSARTUS

`f115v.28`  y,chey.lcho.lor.chedy.chol.chedy.chdy
→ MSARM  LSAO  LOR  SARNM  SAOL  SARNM  SANM

`f115v.29`  polor.sheedy.qoteedy.qokechy.lraly,l,shey.sheot.shedy.chteey.lky.raram
→ MOLOR  PARRNM  COTRRNM  COŌRSAM  LRULMLPARM  PAROT  PARNM  SATRRM  LŌM  RURUS

`f115v.30`  ycheedaiin.ol.chlor.lkchedy.rchedar.oteedal.ar.lky
→ MSARRNUII?  OL  SALOR  LŌSARNM  RSARNUR  OTRRNUL  UR  LŌM

`f115v.31`  pchdair.opchedy.qopor.iirchal.sheey.qotain.chety.rodaiin.opchepy.shokchy
→ MSANUIR  OMSARNM  COMOR  IIRSAUL  PARRM  COTUI?  SARTM  RONUII?  OMSARMM  PAOŌSAM

`f115v.32`  ykchedy.okar.chedar.rolsheedy.lkchdy.chddy.ch[cph:cth]edy.cheey.teeodaiin
→ MŌSARNM  OŌUR  SARNUR  ROLPARRNM  LŌSANM  SANNM  SASMARNM  SARRM  TRRONUII?

`f115v.33`  ychedal.qotchy.chcthy.chdal.lchedy
→ MSARNUL  COTSAM  SASTAM  SANUL  LSARNM

`f115v.34`  taiin.she{ck}eey.lchckhy.ldar.shdar.qotchdy.qoky.shedy.qokar.chckhy
→ TUII?  PARSŌRRM  LSASŌAM  LNUR  PANUR  COTSANM  COŌM  PARNM  COŌUR  SASŌAM

`f115v.35`  shos.shee.oky.cheo,lkain.cheeos.al,ches.kcheo.rain.checthey.lcham
→ PAOP  PARR  OŌM  SAROLŌUI?  SARROP  ULSARP  ŌSARO  RUI?  SARSTARM  LSAUS

`f115v.36`  ytar.aiin.qoteey.lkchedy
→ MTUR  UII?  COTRRM  LŌSARNM

`f115v.37`  tshar.shor.sh{ckhh}y.olkeeo.lkeedol.ltchdy.chkaidararal.lkeedy
→ TPAUR  PAOR  PASŌAAM  OLŌRRO  LŌRRNOL  LTSANM  SAŌUINURURUL  LŌRRNM

`f115v.38`  oiiin.chees.otairos.loedy.cheo,keeo.llchs.o.l.r.aiiin.chkain.sham
→ OIII?  SARRP  OTUIROP  LORNM  SAROŌRRO  LLSAP  O  L  R  UIII?  SAŌUI?  PAUS

`f115v.39`  dairal.chain.ykeedy.qokedy.qokain.lkaiin.lkchey.lkain.lror
→ NUIRUL  SAUI?  MŌRRNM  COŌRNM  COŌUI?  LŌUII?  LŌSARM  LŌUI?  LROR

`f115v.40`  ycheeol,kaiin.shedain.s,cho,r.okas.cheos.qokchy
→ MSARROLŌUII?  PARNUI?  PSAOR  OŌUP  SAROP  COŌSAM

`f115v.41`  dcheodl.sheo,kolchey.fchedol.shedy.qotoee,tchy.cho{iph}y.qopch[y:?]r
→ NSARONL  PAROŌOLSARM  ?SARNOL  PARNM  COTORRTSAM  SAOIMAM  COMSAMR

`f115v.42`  yair.al,sheey.oteeol,keody.rcheey.lkchdy.qokchey.lkar.l[k:?]l.rodam
→ MUIR  ULPARRM  OTRROLŌRONM  RSARRM  LŌSANM  COŌSARM  LŌUR  LŌL  RONUS

`f115v.43`  ysheo[k:t]aiin.qotchdal.lkchdy.lkshedy.qokar.cheos.qokaiin.aky
→ MPAROŌUII?  COTSANUL  LŌSANM  LŌPARNM  COŌUR  SAROP  COŌUII?  UŌM

`f115v.44`  ototar.sheey.qokey.qokchey.qokchey.ral.rchos.oty.lchedy
→ OTOTUR  PARRM  COŌRM  COŌSARM  COŌSARM  RUL  RSAOP  OTM  LSARNM

`f115v.45`  yk,chedaiin.chody.qokaiin.dary.cholaiim
→ MŌSARNUII?  SAONM  COŌUII?  NURM  SAOLUIIS

### f116r  ·  stars

`f116r.1`  kchdpy.shey.qokain.otalsh[?:e]dy.qoteey.shear.ain.or,llory.{i'h}earamom
→ ŌSANMM  PARM  COŌUI?  OTULPANM  COTRRM  PARUR  UI?  ORLLORM  IARURUSOS

`f116r.2`  shain.cheor.ain.okeey.okeey.shy.lar.ar.aiiin.oky.char.ar.okain.ykanam
→ PAUI?  SAROR  UI?  OŌRRM  OŌRRM  PAM  LUR  UR  UIII?  OŌM  SAUR  UR  OŌUI?  MŌU?US

`f116r.3`  dain.chl.lshey.cthy.lshedy.oteor.shey.qo.saly
→ NUI?  SAL  LPARM  STAM  LPARNM  OTROR  PARM  CO  PULM

`f116r.4`  padar.shey.osheeky.qol.laiin.chckhy.okam.chedy.oteedy.qotar.aralar.y
→ MUNUR  PARM  OPARRŌM  COL  LUII?  SASŌAM  OŌUS  SARNM  OTRRNM  COTUR  URULUR  M

`f116r.5`  dain.sheed.qokchdy.otal.chedy.lkain.oteedy.otor.aiin.oty.lol.rol.oly
→ NUI?  PARRN  COŌSANM  OTUL  SARNM  LŌUI?  OTRRNM  OTOR  UII?  OTM  LOL  ROL  OLM

`f116r.6`  sain.ol.lchedy.chedy.otey.chedy.{yko}lain.otedy.oteey
→ PUI?  OL  LSARNM  SARNM  OTRM  SARNM  MŌOLUI?  OTRNM  OTRRM

`f116r.7`  pcholchdy,teody.otey.qo.qokain.qoteey.tokain.otedy.totol.rotydy
→ MSAOLSANMTRONM  OTRM  CO  COŌUI?  COTRRM  TOŌUI?  OTRNM  TOTOL  ROTMNM

`f116r.8`  dar.yteedy.chedy.qokeey.qokain.qotody.oteedar.otedy.ldy.lchedy
→ NUR  MTRRNM  SARNM  COŌRRM  COŌUI?  COTONM  OTRRNUR  OTRNM  LNM  LSARNM

`f116r.9`  qokeey.lchey.qokeedy.qokain.okeeylkaiin
→ COŌRRM  LSARM  COŌRRNM  COŌUI?  OŌRRMLŌUII?

`f116r.10`  chd?in.checkhy.dar.shedy.qokeedy.shdy.rain.sheedy.cphol.r,teol.chcpham
→ SANI?  SARSŌAM  NUR  PARNM  COŌRRNM  PANM  RUI?  PARRNM  SMAOL  RTROL  SASMAUS

`f116r.11`  ol.aiin.shed.qoteedy.okeolshy.qotain.okedy.chedy.olchedy.olkain.als
→ OL  UII?  PARN  COTRRNM  OŌROLPAM  COTUI?  OŌRNM  SARNM  OLSARNM  OLŌUI?  ULP

`f116r.12`  qo?in.ar.cholches.okain.dain.cheey.okeey.otain.olchdy.otal,d[a:?]in.olam
→ COI?  UR  SAOLSARP  OŌUI?  NUI?  SARRM  OŌRRM  OTUI?  OLSANM  OTULNUI?  OLUS

`f116r.13`  sar,ain.tey.chetain.sht{ch'}ey.okey.chedy.qoteedy.qokain.shety.okeedam
→ PURUI?  TRM  SARTUI?  PATSARM  OŌRM  SARNM  COTRRNM  COŌUI?  PARTM  OŌRRNUS

`f116r.14`  sain.cheychear.ain.chl,l.s.oleedy
→ PUI?  SARMSARUR  UI?  SALL  P  OLRRNM

`f116r.15`  pchoetal.otedal.otal.oteedy.olr.daiin.okeedy.qoky.dar.al.keedy.shdy
→ MSAORTUL  OTRNUL  OTUL  OTRRNM  OLR  NUII?  OŌRRNM  COŌM  NUR  UL  ŌRRNM  PANM

`f116r.16`  dar.chedy.sheedy.otal.al.lchedy.shcthy.qotey.dain.otar.otarar.opam
→ NUR  SARNM  PARRNM  OTUL  UL  LSARNM  PASTAM  COTRM  NUI?  OTUR  OTURUR  OMUS

`f116r.17`  dain.chey.qokeey.okeey.lain.okeey.qol.chedy
→ NUI?  SARM  COŌRRM  OŌRRM  LUI?  OŌRRM  COL  SARNM

`f116r.18`  pchar[a:o]lor.qokey.r.ain.otedy.opain.lor.oiin.otain.otar.oteeedy.ches.ar,y
→ MSAURULOR  COŌRM  R  UI?  OTRNM  OMUI?  LOR  OII?  OTUI?  OTUR  OTRRRNM  SARP  URM

`f116r.19`  porchey.sheedy.qotain.chetar.qotar.ar.arody.chcthy.rain.otey.ot,y.dain
→ MORSARM  PARRNM  COTUI?  SARTUR  COTUR  UR  URONM  SASTAM  RUI?  OTRM  OTM  NUI?

`f116r.20`  chol.keedy.ol.cheey.raiin.y.chedy.otar.o,kal.okain.olar.otedy.qoty.sf?m
→ SAOL  ŌRRNM  OL  SARRM  RUII?  M  SARNM  OTUR  OŌUL  OŌUI?  OLUR  OTRNM  COTM  P?S

`f116r.21`  sairol.sheey.qokain.chal.qol.chl.l,rain.okain.shckhy.dtal.orchcthdy.lty
→ PUIROL  PARRM  COŌUI?  SAUL  COL  SAL  LRUI?  OŌUI?  PASŌAM  NTUL  ORSASTANM  LTM

`f116r.22`  dol.shedy.shekchy.qokain.chedy.otar.okalain.shcthy.oteey.dar.chedy.lg
→ NOL  PARNM  PARŌSAM  COŌUI?  SARNM  OTUR  OŌULUI?  PASTAM  OTRRM  NUR  SARNM  L?

`f116r.23`  dain.cheeteey.lkar.shedy.qokal.shedy.qoteedy.ches.ain.ain.aly.salo.lm
→ NUI?  SARRTRRM  LŌUR  PARNM  COŌUL  PARNM  COTRRNM  SARP  UI?  UI?  ULM  PULO  LS

`f116r.24`  qokedy.okain.chcthy.oty.shedy.qokeey.chalkeey.okey.kedy.chey.lag
→ COŌRNM  OŌUI?  SASTAM  OTM  PARNM  COŌRRM  SAULŌRRM  OŌRM  ŌRNM  SARM  LU?

`f116r.25`  chol.sheky.shedy.qokeey.qokeedy.shckhy.qokain.otal,ches.oin,ain,al,om
→ SAOL  PARŌM  PARNM  COŌRRM  COŌRRNM  PASŌAM  COŌUI?  OTULSARP  OI?UI?ULOS

`f116r.26`  ytchey.qokaiin.chckhol.shechol.qotey.ol.cheedy.otain.okedy.qotam
→ MTSARM  COŌUII?  SASŌAOL  PARSAOL  COTRM  OL  SARRNM  OTUI?  OŌRNM  COTUS

`f116r.27`  daiin.chey.qokey.lshedy.orain.chckhy.lkain.chy,pshedy.lshedy.qoky.ram
→ NUII?  SARM  COŌRM  LPARNM  ORUI?  SASŌAM  LŌUI?  SAMMPARNM  LPARNM  COŌM  RUS

`f116r.28`  cheol.lchey.lkeey.sheal.lshalshy.qotalshy.cthedy.l,ky.chedy.oteedy.lched
→ SAROL  LSARM  LŌRRM  PARUL  LPAULPAM  COTULPAM  STARNM  LŌM  SARNM  OTRRNM  LSARN

`f116r.29`  cthan.cheey.lkeeal.lshey.chl,l.lkain.chear.aiin.chl.l.keedy.raraiin.ory
→ STAU?  SARRM  LŌRRUL  LPARM  SALL  LŌUI?  SARUR  UII?  SAL  L  ŌRRNM  RURUII?  ORM

`f116r.30`  saraiin.shey.qokain.chcthy.okar.air,ollaiin.okaly
→ PURUII?  PARM  COŌUI?  SASTAM  OŌUR  UIROLLUII?  OŌULM

`f116r.31`  pchall[a:o]rar.al.ckhal.rain.alolfchy.rpchey.shfy.ches.ar.opchekan,dlr
→ MSAULLURUR  UL  SŌAUL  RUI?  ULOL?SAM  RMSARM  PA?M  SARP  UR  OMSARŌU?NLR

`f116r.32`  olkeey.rain,shey.qor.aiin.shey.ol.lchedy.rshey.qokeedy.chtain.oly
→ OLŌRRM  RUI?PARM  COR  UII?  PARM  OL  LSARNM  RPARM  COŌRRNM  SATUI?  OLM

`f116r.33`  soraiin.ykeey.arain.sheeky.qokain.sheey.qol.cheds.ar.r.[?:a]rsheg
→ PORUII?  MŌRRM  URUI?  PARRŌM  COŌUI?  PARRM  COL  SARNP  UR  R  RPAR?

`f116r.34`  qokain.ar.raiin.shek.okain.y,r,shey.qolchey.okaiin.shckhy.qokam
→ COŌUI?  UR  RUII?  PARŌ  OŌUI?  MRPARM  COLSARM  OŌUII?  PASŌAM  COŌUS

`f116r.35`  shedy.qokeey.qokain.qokeey.lchey.olkey.raiin.cthar.shckhy.qorar
→ PARNM  COŌRRM  COŌUI?  COŌRRM  LSARM  OLŌRM  RUII?  STAUR  PASŌAM  CORUR

`f116r.36`  qokeey.rain.shey.okeey.lkain.l.dain.chey.sheckhy.q{cthh}y.qokl.ain
→ COŌRRM  RUI?  PARM  OŌRRM  LŌUI?  L  NUI?  SARM  PARSŌAM  CSTAAM  COŌL  UI?

`f116r.37`  pairain.sheek,l,y.oiin.cheey.lkeey.olkeey.lchey.qoky.lshedy.cheam.sham
→ MUIRUI?  PARRŌLM  OII?  SARRM  LŌRRM  OLŌRRM  LSARM  COŌM  LPARNM  SARUS  PAUS

`f116r.38`  daiin.qokeey.lshey.qokaiin.chkar.shey.okaiin.chedy.qokeedy.raiin.shy
→ NUII?  COŌRRM  LPARM  COŌUII?  SAŌUR  PARM  OŌUII?  SARNM  COŌRRNM  RUII?  PAM

`f116r.39`  qokain.chey.olr.ain.shey.qokain.o,l,keey,keeey.lkeal.or.al.lom
→ COŌUI?  SARM  OLR  UI?  PARM  COŌUI?  OLŌRRMŌRRRM  LŌRUL  OR  UL  LOS

`f116r.40`  dsheey.shey.qokey.shey.qokain.shckhy.chery.ol,chedy.l,chey,lchy
→ NPARRM  PARM  COŌRM  PARM  COŌUI?  PASŌAM  SARRM  OLSARNM  LSARMLSAM

`f116r.41`  dlar.shar.shar.r.ain.sheain.okain.shey.qokchy.chckhy.orain
→ NLUR  PAUR  PAUR  R  UI?  PARUI?  OŌUI?  PARM  COŌSAM  SASŌAM  ORUI?

`f116r.42`  qo.qokain.sheckhy.qokain.shekain.shkain.shedy.shey.qokan.cham
→ CO  COŌUI?  PARSŌAM  COŌUI?  PARŌUI?  PAŌUI?  PARNM  PARM  COŌU?  SAUS

`f116r.43`  [a:o]s???.ar.al.shear.teey.chcphy.rain.cphan.ydar.oty.shey.qokam
→ UP  UR  UL  PARUR  TRRM  SASMAM  RUI?  SMAU?  MNUR  OTM  PARM  COŌUS

`f116r.44`  s[?:o].o[k:?]eedy.qokain.shckhy.ol.lcheor.chky.raiin.chey.qol.okam
→ P  OŌRRNM  COŌUI?  PASŌAM  OL  LSAROR  SAŌM  RUII?  SARM  COL  OŌUS

`f116r.45`  odain.sh??y.qoka[r:s].oleey.chy
→ ONUI?  PAM  COŌUR  OLRRM  SAM

`f116r.46`  oqokaiin.al.shey.qokar.okaral.okeysh{cphh}y.oteey.ookar.okydy
→ OCOŌUII?  UL  PARM  COŌUR  OŌURUL  OŌRMPASMAAM  OTRRM  OOŌUR  OŌMNM

`f116r.47`  osain.shky.qorain.chckhey.qokey.lkechy.okeey.okal.chedkaly
→ OPUI?  PAŌM  CORUI?  SASŌARM  COŌRM  LŌRSAM  OŌRRM  OŌUL  SARNŌULM

`f116r.48`  sykar.ain.olkeey.dainchey.qokar.chey.dain.y.otan.otain.oly
→ PMŌUR  UI?  OLŌRRM  NUI?SARM  COŌUR  SARM  NUI?  M  OTU?  OTUI?  OLM

`f116r.49`  sysor,shey.qokey.okeolan.chey.qol.or.cheey.qor.arom.ol.lkan
→ PMPORPARM  COŌRM  OŌROLU?  SARM  COL  OR  SARRM  COR  UROS  OL  LŌU?

`f116r.50`  sodal.ch,al.chcthy.chckhy.qol,ain,ary
→ PONUL  SAUL  SASTAM  SASŌAM  COLUI?URM

### f116v  ·  text/preface

`f116v.1`  oror.sheey
→ OROR  PARRM
