"""IVTFF / EVA (ZL) parser.

Handles folio headers, line loci, inline comments, plant-cut markers,
and EVA bracket notation [primary:alternate].
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

HEADER_RE = re.compile(r"^<(f\d+[rv]\d*)>\s*(.*)")
LINE_RE = re.compile(r"^<(f\d+[rv]\d*\.\d+),([^>]*)>\s*(.*)")
META_RE = re.compile(r"\$([A-Z])=([A-Za-z0-9@]+)")
COMMENT_RE = re.compile(r"<!.*?>")
MARKER_RE = re.compile(r"<%.*?>")
END_RE = re.compile(r"<\$?>")


def parse_brackets(tok: str) -> dict[str, Any]:
    """Return primary reading plus any alternate readings from [a:b] groups."""
    groups = re.findall(r"\[([^\]]+)\]", tok)
    primary = tok
    alts: list[str] = []
    for g in groups:
        if ":" in g:
            first, rest = g.split(":", 1)
            primary = primary.replace("[" + g + "]", first, 1)
            alts.append(rest)
        else:
            primary = primary.replace("[" + g + "]", g, 1)
    return {"raw": tok, "primary": primary, "alts": alts}


def clean_token(tok: str) -> str:
    """Strip EVA markup down to lowercase latin letters only."""
    tok = re.sub(r"\[([^:\]]+):[^\]]*\]", r"\1", tok)
    tok = re.sub(r"\[([^\]]+)\]", r"\1", tok)
    tok = re.sub(r"[{}]", "", tok)
    tok = re.sub(r"[^a-z]", "", tok.lower())
    return tok


def _strip_inline(text: str) -> str:
    text = COMMENT_RE.sub("", text)
    text = MARKER_RE.sub("", text)
    text = END_RE.sub("", text)
    return text.strip()


def parse_zl(path: str | Path) -> dict[str, Any]:
    """Parse a ZL IVTFF file into folios -> lines.

    Returns
    -------
    {
      "folios": {
        "f1r": {
          "id": "f1r",
          "meta": {"Q": "A", "I": "T", "L": "A", ...},
          "lines": [
            {"locus": "f1r.1", "tag": "@P0", "raw": "...", "tokens": ["fachys", ...]}
          ]
        }
      },
      "order": ["f1r", "f1v", ...]
    }
    """
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")

    folios: dict[str, Any] = {}
    order: list[str] = []
    current: str | None = None

    for line in text.splitlines():
        hm = HEADER_RE.match(line)
        if hm:
            current = hm.group(1)
            rest = hm.group(2)
            meta = dict(META_RE.findall(rest))
            folios[current] = {"id": current, "meta": meta, "lines": []}
            order.append(current)
            continue

        lm = LINE_RE.match(line)
        if lm and current:
            locus = lm.group(1)
            tag = lm.group(2)
            raw = _strip_inline(lm.group(3))
            if not raw:
                continue
            tokens = [t for t in raw.split(".") if t]
            folios[current]["lines"].append(
                {
                    "locus": locus,
                    "tag": tag,
                    "raw": raw,
                    "tokens": tokens,
                }
            )

    return {"folios": folios, "order": order}
