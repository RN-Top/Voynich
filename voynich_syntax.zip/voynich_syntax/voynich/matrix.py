"""Load the rule spec and map EVA tokens to phonemes."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .parser import clean_token, parse_brackets

DEFAULT_SPEC = Path(__file__).resolve().parents[1] / "spec" / "matrix.json"


def load_spec(path: str | Path | None = None) -> dict[str, Any]:
    p = Path(path) if path else DEFAULT_SPEC
    return json.loads(p.read_text(encoding="utf-8"))


def translate_token(tok: str, spec: dict[str, Any]) -> dict[str, Any]:
    """Map one EVA token through the spec.

    Returns phoneme string, cleaned form, unknown glyphs, and any alts.
    """
    parsed = parse_brackets(tok)
    cleaned = clean_token(parsed["primary"])
    table = spec.get("glyph_to_sound", {})
    sounds: list[str] = []
    unknown: list[str] = []
    for ch in cleaned:
        if ch in table:
            sounds.append(table[ch])
        else:
            sounds.append("?")
            unknown.append(ch)
    alt_phonemes = []
    for a in parsed["alts"]:
        ac = clean_token(a)
        alt_phonemes.append("".join(table.get(ch, "?") for ch in ac))
    terminal = cleaned[-1] if cleaned else ""
    return {
        "raw": tok,
        "cleaned": cleaned,
        "phoneme": "".join(sounds),
        "alts": parsed["alts"],
        "alt_phonemes": alt_phonemes,
        "unknown": unknown,
        "terminal": terminal,
        "terminal_class": spec.get("terminal_class", {}).get(terminal, ""),
        "crib": spec.get("cribs", {}).get(cleaned, ""),
    }


def translate_line(tokens: list[str], spec: dict[str, Any]) -> list[dict[str, Any]]:
    return [translate_token(t, spec) for t in tokens]


def folio_section(folio: dict[str, Any], spec: dict[str, Any]) -> str:
    code = folio.get("meta", {}).get("I", "X")
    return spec.get("section_map", {}).get(code, "unknown")
