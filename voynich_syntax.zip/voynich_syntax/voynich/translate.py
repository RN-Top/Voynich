"""Batch-translate the entire ZL file using spec/matrix.json.

Usage (from repo root):
    python -m voynich.translate
    python -m voynich.translate --out output/full_translation.md
    python -m voynich.translate --csv output/full_translation.csv
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

from .matrix import folio_section, load_spec, translate_line
from .parser import parse_zl

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ZL = ROOT / "data" / "ZL3b-n.txt"
DEFAULT_OUT = ROOT / "output" / "full_translation.md"
DEFAULT_CSV = ROOT / "output" / "full_translation.csv"
DEFAULT_JSON = ROOT / "output" / "stats.json"


def run(zl_path: Path, spec_path: Path | None = None) -> dict:
    spec = load_spec(spec_path)
    parsed = parse_zl(zl_path)
    crib_folios = set(spec.get("crib_folios", []))

    rows = []
    term_by_section: dict[str, Counter] = defaultdict(Counter)
    stem_by_section: dict[str, Counter] = defaultdict(Counter)
    crib_hits = []
    total_tokens = 0
    alt_count = 0

    for fid in parsed["order"]:
        folio = parsed["folios"][fid]
        section = folio_section(folio, spec)
        for line in folio["lines"]:
            mapped = translate_line(line["tokens"], spec)
            phonemes = []
            for m in mapped:
                total_tokens += 1
                if m["alts"]:
                    alt_count += 1
                phonemes.append(m["phoneme"] or "—")
                if m["terminal"]:
                    term_by_section[section][m["terminal"]] += 1
                if m["cleaned"]:
                    stem_by_section[section][m["cleaned"]] += 1
                if m["crib"] and fid in crib_folios:
                    crib_hits.append(
                        {
                            "folio": fid,
                            "locus": line["locus"],
                            "token": m["cleaned"],
                            "phoneme": m["phoneme"],
                            "crib": m["crib"],
                        }
                    )
                rows.append(
                    {
                        "folio": fid,
                        "section": section,
                        "locus": line["locus"],
                        "tag": line["tag"],
                        "raw_token": m["raw"],
                        "cleaned": m["cleaned"],
                        "phoneme": m["phoneme"],
                        "alts": "|".join(m["alts"]),
                        "terminal": m["terminal"],
                        "crib": m["crib"] if fid in crib_folios else "",
                    }
                )
            line["phonemes"] = phonemes
            line["mapped"] = mapped
        folio["section"] = section

    stats = {
        "spec_version": spec.get("version"),
        "folios": len(parsed["order"]),
        "tokens": total_tokens,
        "alt_readings": alt_count,
        "crib_hits": crib_hits,
        "terminals_by_section": {
            s: dict(c) for s, c in term_by_section.items()
        },
        "top_stems_by_section": {
            s: c.most_common(20) for s, c in stem_by_section.items()
        },
    }
    return {"parsed": parsed, "rows": rows, "stats": stats, "spec": spec}


def write_markdown(result: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    parsed = result["parsed"]
    spec = result["spec"]
    stats = result["stats"]
    lines = [
        f"# Voynich full translation  — spec {spec.get('version')}",
        "",
        "Pharmaceutical / procedural syntax. Not a spoken language.",
        "",
        f"- Folios: {stats['folios']}",
        f"- Tokens: {stats['tokens']}",
        f"- Bracket alternate readings captured: {stats['alt_readings']}",
        f"- Zodiac-restricted crib hits: {len(stats['crib_hits'])}",
        "",
        "## Glyph map",
        "",
        "| Glyph | Sound | Role |",
        "|---|---|---|",
    ]
    for g, s in spec["glyph_to_sound"].items():
        role = spec.get("affix_role", {}).get(g, "")
        lines.append(f"| `{g}` | {s} | {role} |")
    lines += ["", "## Crib hits (zodiac range only)", ""]
    if stats["crib_hits"]:
        lines += ["| Folio | Locus | Token | Phoneme | Crib |", "|---|---|---|---|---|"]
        for h in stats["crib_hits"]:
            lines.append(
                f"| {h['folio']} | {h['locus']} | `{h['token']}` | {h['phoneme']} | {h['crib']} |"
            )
    else:
        lines.append("_None._")
    lines += ["", "## Manuscript", ""]
    for fid in parsed["order"]:
        folio = parsed["folios"][fid]
        lines.append(f"### {fid}  ·  {folio.get('section', '')}")
        lines.append("")
        for line in folio["lines"]:
            phon = "  ".join(line.get("phonemes", []))
            lines.append(f"`{line['locus']}`  {line['raw']}")
            lines.append(f"→ {phon}")
            lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def write_csv(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "folio",
        "section",
        "locus",
        "tag",
        "raw_token",
        "cleaned",
        "phoneme",
        "alts",
        "terminal",
        "crib",
    ]
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description="Translate the full ZL Voynich file.")
    ap.add_argument("--zl", type=Path, default=DEFAULT_ZL)
    ap.add_argument("--spec", type=Path, default=None)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--csv", type=Path, default=DEFAULT_CSV)
    ap.add_argument("--stats", type=Path, default=DEFAULT_JSON)
    args = ap.parse_args()

    result = run(args.zl, args.spec)
    write_markdown(result, args.out)
    write_csv(result["rows"], args.csv)
    args.stats.parent.mkdir(parents=True, exist_ok=True)
    dump = {
        k: v
        for k, v in result["stats"].items()
        if k != "top_stems_by_section" or True
    }
    args.stats.write_text(json.dumps(dump, indent=2), encoding="utf-8")
    print(f"folios={result['stats']['folios']}  tokens={result['stats']['tokens']}")
    print(f"wrote {args.out}")
    print(f"wrote {args.csv}")
    print(f"wrote {args.stats}")


if __name__ == "__main__":
    main()
