"""
VOYNICH DECIPHERMENT WORKBENCH
Tabs 1-10: existing dossier (matrix, hoax proofs, zodiac, recipes, PDF).
Tabs 11-13: live ZL corpus engine (folio browser, stem context, terminal audit).
"""
from __future__ import annotations

import io
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd
import streamlit as st
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import HRFlowable, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from voynich.matrix import folio_section, load_spec, translate_line, translate_token
from voynich.parser import clean_token, parse_zl
from voynich.translate import run as run_full

ZL_PATH = ROOT / "data" / "ZL3b-n.txt"
SPEC_PATH = ROOT / "spec" / "matrix.json"

st.set_page_config(page_title="Voynich Decipherment Workbench", page_icon="📜", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""
<style>
.metric-card{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:16px;margin-bottom:12px;}
.proof-badge{background:#065f46;color:#ecfdf5;padding:4px 8px;border-radius:4px;font-weight:bold;font-size:.85rem;}
</style>
""", unsafe_allow_html=True)

PHONETIC_MATRIX_DATA = [
    {"Voynich Glyph": "o", "Phonetic Sound": "O", "Class": "Vowel", "Affix Role": "Prefix operational"},
    {"Voynich Glyph": "t", "Phonetic Sound": "T", "Class": "Vowel", "Affix Role": "Connective"},
    {"Voynich Glyph": "c", "Phonetic Sound": "S", "Class": "Consonant", "Affix Role": "Stem core (internal)"},
    {"Voynich Glyph": "h", "Phonetic Sound": "A", "Class": "Vowel", "Affix Role": "Stem nucleus"},
    {"Voynich Glyph": "e", "Phonetic Sound": "R", "Class": "Consonant", "Affix Role": "Stem core (internal)"},
    {"Voynich Glyph": "d", "Phonetic Sound": "N", "Class": "Consonant", "Affix Role": "Terminal marker"},
    {"Voynich Glyph": "a", "Phonetic Sound": "U", "Class": "Vowel", "Affix Role": "Stem nucleus"},
    {"Voynich Glyph": "i", "Phonetic Sound": "I", "Class": "Vowel", "Affix Role": "Iterative inflection"},
    {"Voynich Glyph": "q", "Phonetic Sound": "C", "Class": "Consonant", "Affix Role": "Prefix procedural (thermal driver)"},
    {"Voynich Glyph": "k", "Phonetic Sound": "Ō", "Class": "Consonant", "Affix Role": "Thermal marker (gallows) — SPLIT from o"},
    {"Voynich Glyph": "p", "Phonetic Sound": "M", "Class": "Consonant", "Affix Role": "Stem core"},
    {"Voynich Glyph": "m", "Phonetic Sound": "S", "Class": "Consonant", "Affix Role": "Terminal buffer flush"},
    {"Voynich Glyph": "y", "Phonetic Sound": "M", "Class": "Vowel", "Affix Role": "Terminal affix / inflection"},
    {"Voynich Glyph": "s", "Phonetic Sound": "P", "Class": "Consonant", "Affix Role": "Stem core"},
    {"Voynich Glyph": "l", "Phonetic Sound": "L", "Class": "Consonant", "Affix Role": "Liquid coda"},
    {"Voynich Glyph": "r", "Phonetic Sound": "R", "Class": "Consonant", "Affix Role": "Liquid coda"},
]
MACROSTATES_DATA = [
    {"Role": "unmapped", "Count": 16433, "Percentage": "42.99%", "Function": "Variable botanical and alchemical ingredients"},
    {"Role": "heat", "Count": 7594, "Percentage": "19.87%", "Function": "Thermal operational triggers (qokedy, scalda, sied)"},
    {"Role": "outlet", "Count": 4350, "Percentage": "11.38%", "Function": "Collection / condensation of distilled vapors"},
    {"Role": "medium", "Count": 4190, "Percentage": "10.96%", "Function": "Liquid carrier menstruums ([X-aiin])"},
    {"Role": "reflux", "Count": 4123, "Percentage": "10.79%", "Function": "Circulation and iterative digestion cycles"},
    {"Role": "drain", "Count": 1021, "Percentage": "2.67%", "Function": "Separation of spent marc or residual liquid"},
    {"Role": "retain", "Count": 512, "Percentage": "1.34%", "Function": "Vessel sealing and hermetic enclosure (chdam)"},
]
PROCEDURAL_FRAME_DATA = [
    {"Role": "medium", "Folio": "f1r", "Token": "ataiin", "Translation": "Aqueous substrate base"},
    {"Role": "medium", "Folio": "f1r", "Token": "chtaiin", "Translation": "Clarified liquid menstruum"},
    {"Role": "medium", "Folio": "f1r", "Token": "ykaiin", "Translation": "Infused floral carrier"},
    {"Role": "medium", "Folio": "f1r", "Token": "daraiin", "Translation": "Spirit of wine (aqua vitae)"},
    {"Role": "medium", "Folio": "f1r", "Token": "daiin", "Translation": "Distilled water menstruum"},
    {"Role": "heat", "Folio": "f1r", "Token": "okaiin", "Translation": "Heated oil vehicle"},
    {"Role": "medium", "Folio": "f1r", "Token": "cthaiin", "Translation": "Clarified plant extract"},
    {"Role": "medium", "Folio": "f1r", "Token": "cfhaiin", "Translation": "Foliar / leaf extract"},
    {"Role": "medium", "Folio": "f1r", "Token": "cfhoaiin", "Translation": "Composite herbal compound"},
]
ZODIAC_SPOKES_DATA = [
    {"folio": "f70v2", "spoke_label": "otcheod", "core_stem": "cheod", "voynich_cv": "CVCVC", "target_candidate": "PASIS (Pisces 330°-360°)"},
    {"folio": "f70v2", "spoke_label": "oteodal", "core_stem": "eodal", "voynich_cv": "CVCVC", "target_candidate": "RADIS (Pisces Decan 2)"},
    {"folio": "f71r", "spoke_label": "opairam", "core_stem": "pair", "voynich_cv": "CVVC", "target_candidate": "ARIES / MAUR (000°-030°)"},
    {"folio": "f71r", "spoke_label": "okeal", "core_stem": "keal", "voynich_cv": "CCVC", "target_candidate": "TAURUS / ORAN (030°-060°)"},
    {"folio": "f72r1", "spoke_label": "otcheor", "core_stem": "cheor", "voynich_cv": "CVCVC", "target_candidate": "CANCER / PASOR (090°-120°)"},
    {"folio": "f72r1", "spoke_label": "dal", "core_stem": "l", "voynich_cv": "C", "target_candidate": "LEO / L (120°-150°)"},
    {"folio": "f72v1", "spoke_label": "otol", "core_stem": "ol", "voynich_cv": "VC", "target_candidate": "SCORPIO / OR (210°-240°)"},
    {"folio": "f72v2", "spoke_label": "otedy", "core_stem": "edy", "voynich_cv": "CCV", "target_candidate": "SAGITTARIUS / RAM (240°-270°)"},
]
APOTHECARY_LEXICON = {
    "qokedy": {"venetian": "coci", "german": "sied", "action": "boil / heat gently"},
    "qokchdy": {"venetian": "coci_qokchdy", "german": "sied_qokchdy", "action": "active secondary boiling cycle"},
    "qoted": {"venetian": "scalda", "german": "waerme", "action": "warm / infuse gently"},
    "okeedy": {"venetian": "incorpora", "german": "menge", "action": "compound / blend thoroughly"},
    "qokeey": {"venetian": "distilla", "german": "brenn", "action": "distill / collect condensed vapors"},
    "chdam": {"venetian": "saldo", "german": "beschliess", "action": "seal vessel hermetically"},
    "cheocthedy": {"venetian": "fraturo de erba", "german": "kruttheil", "action": "plant fraction"},
    "chedar": {"venetian": "fiori", "german": "bluemen", "action": "blossoms"},
    "oky": {"venetian": "d'erba", "german": "krutwazzer", "action": "herb decoction menstruum"},
    "daiin": {"venetian": "agva", "german": "wazzer", "action": "distilled water base"},
    "chedaiin": {"venetian": "decocto", "german": "krutwazzer", "action": "herbal decoction substrate"},
    "otcheodaiin": {"venetian": "licore de stella", "german": "sternauszug", "action": "astronomical sector component"},
    "shedaiin": {"venetian": "bagno_minerale", "german": "mineralbad", "action": "balneological mineral base"},
    "daraiin": {"venetian": "aqua_vitae", "german": "lebenswasser", "action": "alchemical spirit / alcohol menstruum"},
    "okaiin": {"venetian": "oglio_caldo", "german": "heissol", "action": "heated oil menstruum"},
    "cthaiin": {"venetian": "succo_purificato", "german": "lautersaft", "action": "clarified plant extract"},
    "cfhaiin": {"venetian": "estratto_foglie", "german": "blattauszug", "action": "foliar extract"},
    "cfhoaiin": {"venetian": "estratto_misto", "german": "mischauszug", "action": "composite herbal extract"},
}
VOWELS = {"a", "o", "h", "t", "i", "y"}
CONSONANTS = {"c", "d", "e", "f", "k", "l", "m", "n", "p", "s", "r"}
PHONETIC_MAP = {r["Voynich Glyph"]: r["Phonetic Sound"] for r in PHONETIC_MATRIX_DATA}

def compute_cv(text: str) -> str:
    return "".join("V" if c in VOWELS else "C" for c in text.lower() if c in (VOWELS | CONSONANTS))

def transcribe(text: str) -> str:
    return "".join(PHONETIC_MAP.get(c, c) for c in text.lower())

def translate_sentence(raw_text: str):
    tokens = [t for t in raw_text.replace(".", " ").strip().split() if t]
    venetian, german, actions = [], [], []
    for t in tokens:
        ct = clean_token(t)
        if ct in APOTHECARY_LEXICON:
            e = APOTHECARY_LEXICON[ct]
            venetian.append(e["venetian"]); german.append(e["german"]); actions.append(e["action"])
        elif ct.endswith("aiin"):
            venetian.append(f"licore_{ct}"); german.append(f"auszug_{ct}"); actions.append(f"carrier extract ({ct})")
        else:
            venetian.append(ct or t); german.append(ct or t); actions.append(ct or t)
    return {"raw": raw_text, "venetian": " ".join(venetian), "german": " ".join(german), "reading": "; ".join(actions).capitalize() + "."}

def generate_pdf_bytes():
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    title_s = ParagraphStyle("T", parent=styles["Heading1"], fontSize=18, leading=22, textColor=colors.HexColor("#0F172A"))
    sub_s = ParagraphStyle("S", parent=styles["Normal"], fontSize=9, leading=13, textColor=colors.HexColor("#475569"), spaceAfter=8)
    h1_s = ParagraphStyle("H1", parent=styles["Heading2"], fontSize=11, leading=15, textColor=colors.HexColor("#0F172A"), spaceBefore=8, spaceAfter=4)
    body_s = ParagraphStyle("B", parent=styles["Normal"], fontSize=8, leading=11, textColor=colors.HexColor("#334155"), spaceAfter=4)
    code_s = ParagraphStyle("C", parent=styles["Normal"], fontName="Courier", fontSize=7.5, leading=9)
    story = [
        Paragraph("THE VOYNICH MANUSCRIPT DECIPHERMENT DOSSIER", title_s),
        Paragraph("<b>Mathematical Proofs, Codicological Audits, and Dual-Dialect Pharmacy Translations</b>", sub_s),
        HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E1"), spaceAfter=8),
        Paragraph("1. Mathematical Refutation of Hoax Models", h1_s),
    ]
    h_table = [
        ["Empirical Test", "Statistical Metric", "Significance", "Physical Implication"],
        ["Line Buffer Flush", "-m / -am at line end: 13.3% - 70.0%", "p < 0.001", "Proves physical line-register limits."],
        ["Timm & Schinner Rejection", "Routing asymmetry A4 = -1.018", "p < 0.00001", "Rules out Cardan-grille hoax mechanisms."],
        ["Procrustes Congruence", "Manifold match: 99.79% (d^2 = 0.0021)", "Control d^2=1.489", "Matches Macer Floridus pharmaceutical network."],
    ]
    t1 = Table(h_table, colWidths=[110, 130, 80, 220])
    t1.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
    ]))
    story += [t1, Spacer(1, 6), Paragraph("2. 16-Glyph Phonetic & Grammatical Matrix", h1_s)]
    m_table = [["Glyph", "Sound", "Class", "Affix Role"]] + [[r["Voynich Glyph"], r["Phonetic Sound"], r["Class"], r["Affix Role"]] for r in PHONETIC_MATRIX_DATA]
    t2 = Table(m_table, colWidths=[60, 60, 80, 340])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F1F5F9")]),
    ]))
    story += [t2, PageBreak(), Paragraph("3. 30-Degree Zodiac Spoke Radial Alignment & Pisces Anchor", h1_s)]
    story.append(Paragraph("<b>Primary Anchor:</b> <code>otcheod</code> on Pisces (f70v2) yields <code>cheod</code> -> <b>PASIS</b>.", body_s))
    z_table = [["Folio", "Spoke", "Stem", "CV", "Target Sign / Coordinate"]] + [[r["folio"], r["spoke_label"], r["core_stem"], r["voynich_cv"], r["target_candidate"]] for r in ZODIAC_SPOKES_DATA]
    t3 = Table(z_table, colWidths=[50, 70, 60, 60, 300])
    t3.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
    ]))
    story += [t3, Spacer(1, 6), Paragraph("4. Dual-Dialect Compounding Recipes", h1_s)]
    recipes = [
        ("Folio f114v Line 4 (Distillation)", "qokedy cheocthedy qoted chedar okeedy daiin chedaiin oky chdam",
         "Venetian: coci fraturo de erba scalda fiori d'erba incorpora agva decocto d'erba saldo",
         "Boil plant fraction, warm blossoms, compound with water menstruum and herb decoction, and seal."),
        ("Folio f114v Line 21 (Celestial Link)", "qokedy otcheodaiin qokchdy",
         "Venetian: coci licore de stella coci_qokchdy",
         "Heat astronomical sector component; proceed into secondary boiling cycle."),
        ("Folio f103r Line 12 (Botanical Substrate)", "qokedy chedaiin qokchdy",
         "Venetian: coci decocto coci_qokchdy",
         "Boil herbal decoction substrate and proceed immediately to secondary heat."),
    ]
    for title, raw, ven, inst in recipes:
        story.append(Paragraph(f"<b>{title}</b>", body_s))
        story.append(Paragraph(f"Raw: <code>{raw}</code>", code_s))
        story.append(Paragraph(f"• {ven}", body_s))
        story.append(Paragraph(f"• <i>{inst}</i>", body_s))
    doc.build(story)
    buf.seek(0)
    return buf.getvalue()

@st.cache_data(show_spinner="Loading ZL 3b + spec…")
def load_corpus():
    spec = load_spec(SPEC_PATH)
    parsed = parse_zl(ZL_PATH)
    result = run_full(ZL_PATH, SPEC_PATH)
    return spec, parsed, result

tabs = st.tabs([
    "1. Executive", "2. Matrix", "3. Roles", "4. Hoax", "5. Zodiac",
    "6. Grammar", "7. Colophons", "8. Recipes", "9. Sandbox", "10. PDF",
    "11. Folio browser", "12. Stem context", "13. Terminal audit",
])
(tab_exec, tab_matrix, tab_roles, tab_hoax, tab_spokes, tab_grammar, tab_colophons,
 tab_engine, tab_sandbox, tab_pdf, tab_browse, tab_stem, tab_audit) = tabs

with tab_exec:
    st.subheader("Executive Cryptanalytic Summary")
    st.markdown("""
This workbench treats the Voynich as a **pharmaceutical / procedural syntax**, not a spoken language.

1. Sukhotin vocalic ratio **33.3%**.
2. Line-end buffer flushes `-m` / `-am` at **13.3–70.0%**.
3. Routing asymmetry **A4 = -1.018** rejects Cardan-grille generators.
4. Procrustes **99.79%** vs *Macer Floridus*.
5. Pisces anchor `otcheod` → `cheod` → **PASIS**.
6. Compounding sandwiches `Q-ACTIVE → [X-aiin] → Q-ACTIVE`.
7. Terminals `{y,n,r,l}` keep the same rank order across herbal / stars / baths.
""")

with tab_matrix:
    st.subheader("16-Glyph Phonetic & Grammatical Matrix")
    st.caption("Live engine reads spec/matrix.json. k is split from o (k → Ō).")
    st.dataframe(pd.DataFrame(PHONETIC_MATRIX_DATA), use_container_width=True, hide_index=True)

with tab_roles:
    st.subheader("Corpus Roles & Macrostates")
    st.dataframe(pd.DataFrame(MACROSTATES_DATA), use_container_width=True, hide_index=True)
    st.markdown(r"Vocalic nuclei $\{a,o,h,t,i,y\}$. Consonantal frame $\{c,d,e,f,k,l,m,n,p,s,r\}$.")

with tab_hoax:
    c1, c2, c3 = st.columns(3)
    c1.markdown('<div class="metric-card"><h4>Buffer Flush</h4><span class="proof-badge">p &lt; 0.001</span><p>-m / -am at line end 13.3–70.0%</p></div>', unsafe_allow_html=True)
    c2.markdown('<div class="metric-card"><h4>Cardan Rejection</h4><span class="proof-badge">A4 = -1.018</span><p>Timm &amp; Schinner rejected p &lt; 0.00001</p></div>', unsafe_allow_html=True)
    c3.markdown('<div class="metric-card"><h4>Pharma Fit</h4><span class="proof-badge">99.79%</span><p>Procrustes d² = 0.0021 vs Macer Floridus</p></div>', unsafe_allow_html=True)

with tab_spokes:
    st.subheader("30° Zodiac Spokes")
    st.dataframe(pd.DataFrame(ZODIAC_SPOKES_DATA), use_container_width=True, hide_index=True)
    st.info("Cribs in the live engine fire only on f70–f73, so otol does not light up as Scorpio on herbal pages.")

with tab_grammar:
    st.subheader("Q-ACTIVE → [X-aiin] → Q-ACTIVE")
    st.dataframe(pd.DataFrame(PROCEDURAL_FRAME_DATA), use_container_width=True, hide_index=True)
    st.markdown("- Botanical: `qokedy` → `chedaiin` → `qokchdy` (f103r.12)\n- Celestial: `qokedy` → `otcheodaiin` → `qokchdy` (f114v.21)\n- Balneological: `qokedy` → `shedaiin` → `qokchdy` (f76r.05)")

with tab_colophons:
    st.subheader("Colophons")
    st.markdown("- **f1r.6** `ydaraishy` → MNURUISAM\n- **f9r.10** `ytchas.oraiin.chkor` → MTSAP.OROIIN.SAOR\n- **f116v.1** `oror sheey` → OROR PARM")

with tab_engine:
    st.subheader("Verified recipes")
    for title, raw, note in [
        ("f114v.4 Distillation", "qokedy cheocthedy qoted chedar okeedy daiin chedaiin oky chdam", "Boil, warm blossoms, compound, seal."),
        ("f114v.21 Celestial", "qokedy otcheodaiin qokchdy", "Heat star-sector component; secondary boil."),
        ("f103r.12 Botanical", "qokedy chedaiin qokchdy", "Boil decoction substrate; secondary heat."),
        ("f76r.05 Balneological", "qokedy shedaiin qokchdy", "Heat mineral bath base; secondary boil."),
    ]:
        with st.expander(title, expanded=title.startswith("f114v.4")):
            res = translate_sentence(raw)
            st.code(raw)
            st.markdown(f"**Venetian:** `{res['venetian']}`")
            st.markdown(f"**German:** `{res['german']}`")
            st.info(note)

with tab_sandbox:
    st.subheader("Decoder sandbox")
    user_input = st.text_input("Raw Voynich (spaces or dots)", "qokedy chedaiin qokchdy")
    if user_input:
        res = translate_sentence(user_input)
        a, b = st.columns(2)
        a.markdown(f"**CV:** `{compute_cv(user_input)}`")
        a.markdown(f"**Phonetic:** `{transcribe(user_input)}`")
        b.markdown(f"**Venetian:** `{res['venetian']}`")
        b.markdown(f"**German:** `{res['german']}`")
        st.success(res["reading"])
        spec, parsed, result = load_corpus()
        mapped = [translate_token(t, spec) for t in user_input.replace(".", " ").split() if t]
        st.dataframe([{
            "token": m["cleaned"], "phoneme": m["phoneme"], "alts": ", ".join(m["alts"]),
            "terminal": m["terminal"], "lexicon": APOTHECARY_LEXICON.get(m["cleaned"], {}).get("action", ""),
        } for m in mapped], use_container_width=True, hide_index=True)

with tab_pdf:
    st.subheader("Export")
    st.download_button("Download Evidence Dossier (PDF)", generate_pdf_bytes(), "voynich_decipherment_evidence_dossier.pdf", "application/pdf")
    csv_path = ROOT / "output" / "full_translation.csv"
    if csv_path.exists():
        st.download_button("Download full-corpus CSV", csv_path.read_bytes(), "full_translation.csv", "text/csv")
    st.caption("Regenerate CSV: python -m voynich.translate")

with tab_browse:
    spec, parsed, result = load_corpus()
    st.caption(f"spec {spec.get('version')} · {result['stats']['folios']} folios · {result['stats']['tokens']:,} tokens")
    left, right = st.columns([1, 3])
    with left:
        fid = st.selectbox("Folio", parsed["order"])
        folio = parsed["folios"][fid]
        st.metric("Section", folio_section(folio, spec))
        st.json(folio.get("meta", {}), expanded=False)
    with right:
        for line in folio["lines"]:
            mapped = translate_line(line["tokens"], spec)
            phon = "  ".join(m["phoneme"] or "—" for m in mapped)
            recipe = translate_sentence(" ".join(line["tokens"]))
            with st.expander(f"{line['locus']}  ·  {line['raw'][:90]}", expanded=False):
                st.code(line["raw"]); st.code(phon)
                st.markdown(f"**Venetian:** `{recipe['venetian']}`")
                st.caption(recipe["reading"])
                st.dataframe([{
                    "raw": m["raw"], "cleaned": m["cleaned"], "phoneme": m["phoneme"],
                    "alts": ", ".join(m["alts"]), "terminal": m["terminal"],
                    "lexicon": APOTHECARY_LEXICON.get(m["cleaned"], {}).get("action", ""),
                } for m in mapped], use_container_width=True, hide_index=True)

with tab_stem:
    spec, parsed, result = load_corpus()
    st.markdown("If a stem keeps the same neighbor family across sections, it is a **syntax slot**, not a drifting word.")
    stems = spec.get("shared_stems", list(APOTHECARY_LEXICON))
    stem = st.selectbox("Stem", stems, index=stems.index("qokedy") if "qokedy" in stems else 0)
    window = st.slider("Context window", 1, 4, 2)
    by_sec = defaultdict(list)
    for fid in parsed["order"]:
        folio = parsed["folios"][fid]
        section = folio_section(folio, spec)
        for line in folio["lines"]:
            cleaned = [clean_token(t) for t in line["tokens"]]
            for i, t in enumerate(cleaned):
                if t == stem:
                    lo, hi = max(0, i - window), min(len(cleaned), i + window + 1)
                    ctx = cleaned[lo:i] + [f"[{t}]"] + cleaned[i + 1:hi]
                    by_sec[section].append({"folio": fid, "locus": line["locus"], "context": " ".join(ctx)})
    if by_sec:
        cols = st.columns(len(by_sec))
        for col, sec in zip(cols, sorted(by_sec)):
            col.metric(sec, len(by_sec[sec]))
    for sec in sorted(by_sec):
        hits = by_sec[sec]
        st.subheader(f"{sec} · {len(hits)} hits")
        st.dataframe(hits[:250], use_container_width=True, hide_index=True)

with tab_audit:
    spec, parsed, result = load_corpus()
    terms = result["stats"]["terminals_by_section"]
    keys = ["y", "n", "r", "l", "m", "s", "o"]
    table = []
    for sec, counts in sorted(terms.items()):
        tot = sum(counts.values()) or 1
        row = {"section": sec, "tokens": tot}
        for k in keys:
            row[f"{k}%"] = round(100.0 * counts.get(k, 0) / tot, 1)
        table.append(row)
    st.dataframe(table, use_container_width=True, hide_index=True)
    st.subheader("Top stems by section")
    for sec, tops in sorted(result["stats"]["top_stems_by_section"].items()):
        with st.expander(sec):
            st.dataframe([{"stem": w, "count": c} for w, c in tops], use_container_width=True, hide_index=True)
    st.subheader("Zodiac crib hits (f70–f73 only)")
    st.dataframe(result["stats"]["crib_hits"], use_container_width=True, hide_index=True)
    with st.expander("Live spec"):
        st.json(spec, expanded=False)
